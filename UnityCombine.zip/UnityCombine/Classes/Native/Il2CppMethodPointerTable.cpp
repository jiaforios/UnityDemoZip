﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"









extern "C" void SimpleCollator_GetContraction_m3383256934 ();
extern "C" void SimpleCollator_GetContraction_m2205549079 ();
extern "C" void SimpleCollator_GetTailContraction_m2377844406 ();
extern "C" void SimpleCollator_GetTailContraction_m2107754083 ();
extern "C" void SimpleCollator_GetExtenderType_m407776429 ();
extern "C" void MSCompatUnicodeTable_GetTailoringInfo_m1575560208 ();
extern "C" void Kernel_AddSameSign_m3267067385 ();
extern "C" void Kernel_AddSameSign_m1676432471 ();
extern "C" void Kernel_LeftShift_m3302851050 ();
extern "C" void Kernel_LeftShift_m4140742987 ();
extern "C" void Kernel_MultiplyByDword_m1266935086 ();
extern "C" void Kernel_RightShift_m3246168448 ();
extern "C" void Kernel_RightShift_m2207393597 ();
extern "C" void Kernel_Subtract_m657044818 ();
extern "C" void Kernel_Subtract_m846005223 ();
extern "C" void Kernel_modInverse_m3523342258 ();
extern "C" void Kernel_modInverse_m652700340 ();
extern "C" void ModulusRing_Difference_m1345688434 ();
extern "C" void ModulusRing_Difference_m3686091506 ();
extern "C" void ModulusRing_Multiply_m343333088 ();
extern "C" void ModulusRing_Multiply_m1975391470 ();
extern "C" void ModulusRing_Pow_m1124248336 ();
extern "C" void ModulusRing_Pow_m83007704 ();
extern "C" void ModulusRing_Pow_m317016278 ();
extern "C" void ModulusRing_Pow_m729002192 ();
extern "C" void BigInteger_GeneratePseudoPrime_m1941064930 ();
extern "C" void BigInteger_GeneratePseudoPrime_m2547138838 ();
extern "C" void BigInteger_GenerateRandom_m1790382084 ();
extern "C" void BigInteger_GenerateRandom_m2556426062 ();
extern "C" void BigInteger_GenerateRandom_m3872771375 ();
extern "C" void BigInteger_GenerateRandom_m3141592944 ();
extern "C" void BigInteger_ModInverse_m3469244086 ();
extern "C" void BigInteger_ModInverse_m2426215562 ();
extern "C" void BigInteger_ModPow_m3776562770 ();
extern "C" void BigInteger_ModPow_m2277842115 ();
extern "C" void BigInteger_op_Addition_m2544206388 ();
extern "C" void BigInteger_op_Addition_m1114527046 ();
extern "C" void BigInteger_op_Division_m3713793389 ();
extern "C" void BigInteger_op_Division_m2437128540 ();
extern "C" void BigInteger_op_Implicit_m2847009755 ();
extern "C" void BigInteger_op_Implicit_m2547142909 ();
extern "C" void BigInteger_op_Implicit_m3414367033 ();
extern "C" void BigInteger_op_Implicit_m378428706 ();
extern "C" void BigInteger_op_LeftShift_m1192375522 ();
extern "C" void BigInteger_op_LeftShift_m3681213422 ();
extern "C" void BigInteger_op_Modulus_m2565477533 ();
extern "C" void BigInteger_op_Modulus_m3223754023 ();
extern "C" void BigInteger_op_Multiply_m3801644593 ();
extern "C" void BigInteger_op_Multiply_m3683746602 ();
extern "C" void BigInteger_op_Multiply_m3854773313 ();
extern "C" void BigInteger_op_RightShift_m2934036419 ();
extern "C" void BigInteger_op_RightShift_m460065452 ();
extern "C" void BigInteger_op_Subtraction_m4245834512 ();
extern "C" void BigInteger_op_Subtraction_m1575155386 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m907640859 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m1689384666 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m2891860459 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m533229219 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m3595783982 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m1918143664 ();
extern "C" void Kernel_Compare_m1530940716 ();
extern "C" void Kernel_Compare_m2669603547 ();
extern "C" void Kernel_DwordDivMod_m631886101 ();
extern "C" void Kernel_DwordDivMod_m1540317819 ();
extern "C" void Kernel_multiByteDivide_m4249920547 ();
extern "C" void Kernel_multiByteDivide_m450694282 ();
extern "C" void PrimeGeneratorBase_get_Confidence_m359324283 ();
extern "C" void PrimeGeneratorBase_get_Confidence_m3172213559 ();
extern "C" void PrimeGeneratorBase_get_PrimalityTest_m2131070257 ();
extern "C" void PrimeGeneratorBase_get_PrimalityTest_m2487240563 ();
extern "C" void ASN1_Add_m2431139999 ();
extern "C" void ASN1_Add_m3468571571 ();
extern "C" void ASN1_Element_m2680269109 ();
extern "C" void ASN1_Element_m4088315026 ();
extern "C" void ASN1_get_Item_m3901126023 ();
extern "C" void ASN1_get_Item_m2255075813 ();
extern "C" void ASN1Convert_FromInt32_m2935389061 ();
extern "C" void ASN1Convert_FromInt32_m1154451899 ();
extern "C" void ASN1Convert_FromOid_m3844102704 ();
extern "C" void ASN1Convert_FromOid_m3740816339 ();
extern "C" void ContentInfo_GetASN1_m3665489137 ();
extern "C" void ContentInfo_GetASN1_m2535172199 ();
extern "C" void ContentInfo_get_ASN1_m2959326143 ();
extern "C" void ContentInfo_get_ASN1_m1776225219 ();
extern "C" void ContentInfo_get_Content_m1945593776 ();
extern "C" void ContentInfo_get_Content_m4053224038 ();
extern "C" void PKCS12_CertificateSafeBag_m3469173172 ();
extern "C" void PKCS12_CertificateSafeBag_m1505366012 ();
extern "C" void SafeBag_get_ASN1_m2293701606 ();
extern "C" void SafeBag_get_ASN1_m3167501969 ();
extern "C" void X509Certificate_GetIssuerName_m3173047029 ();
extern "C" void X509Certificate_GetIssuerName_m4238857993 ();
extern "C" void X509Certificate_GetSubjectName_m3288368674 ();
extern "C" void X509Certificate_GetSubjectName_m584504796 ();
extern "C" void X509Extension_get_Value_m3529546267 ();
extern "C" void X509Certificate2_Find_m2734168143 ();
extern "C" void HMAC_get_Block_m1432537422 ();
extern "C" void MD2_Create_m3511476020 ();
extern "C" void MD2_Create_m1292792200 ();
extern "C" void MD4_Create_m1588482044 ();
extern "C" void MD4_Create_m4111026039 ();
extern "C" void EncryptedData_get_EncryptionAlgorithm_m1297902161 ();
extern "C" void EncryptedData_get_EncryptionAlgorithm_m905084934 ();
extern "C" void PKCS12_EncryptedContentInfo_m729936927 ();
extern "C" void PKCS12_EncryptedContentInfo_m1012097402 ();
extern "C" void TlsException_get_Alert_m1206526559 ();
extern "C" void Alert_get_Description_m3833114036 ();
extern "C" void Alert_get_Level_m4249630350 ();
extern "C" void SslClientStream_get_ClientCertSelectionDelegate_m473995521 ();
extern "C" void SslClientStream_get_ServerCertValidationDelegate_m2765155187 ();
extern "C" void CipherSuite_get_CipherAlgorithmType_m137858741 ();
extern "C" void SslStreamBase_get_CipherAlgorithm_m2320969781 ();
extern "C" void CipherSuiteCollection_Add_m2046232751 ();
extern "C" void CipherSuiteCollection_get_Item_m3790183696 ();
extern "C" void CipherSuiteCollection_get_Item_m4188309062 ();
extern "C" void CipherSuiteCollection_get_Item_m2791953484 ();
extern "C" void RecordProtocol_MapV2CipherCode_m4087331414 ();
extern "C" void SecurityParameters_get_Cipher_m108846204 ();
extern "C" void CipherSuiteFactory_GetSsl3SupportedCiphers_m3757358569 ();
extern "C" void CipherSuiteFactory_GetSupportedCiphers_m3260014148 ();
extern "C" void CipherSuiteFactory_GetTls1SupportedCiphers_m3691819504 ();
extern "C" void Context_get_SupportedCiphers_m1883682196 ();
extern "C" void ClientSessionCache_FromContext_m343076119 ();
extern "C" void HandshakeMessage_get_ContentType_m1693718190 ();
extern "C" void CipherSuite_get_Context_m1621551997 ();
extern "C" void HandshakeMessage_get_Context_m3036797856 ();
extern "C" void RecordProtocol_get_Context_m3273611300 ();
extern "C" void CipherSuite_get_ExchangeAlgorithmType_m1633709183 ();
extern "C" void SslStreamBase_get_KeyExchangeAlgorithm_m1073399962 ();
extern "C" void ClientRecordProtocol_GetMessage_m797000123 ();
extern "C" void ClientRecordProtocol_createClientHandshakeMessage_m3325677558 ();
extern "C" void ClientRecordProtocol_createServerHandshakeMessage_m2804371400 ();
extern "C" void SendRecordAsyncResult_get_Message_m1204240861 ();
extern "C" void RecordProtocol_GetMessage_m2086135164 ();
extern "C" void Context_get_LastHandshakeMsg_m2730646725 ();
extern "C" void HandshakeMessage_get_HandshakeType_m478242308 ();
extern "C" void Context_get_HandshakeState_m2425796590 ();
extern "C" void CipherSuite_get_HashAlgorithmType_m1029363505 ();
extern "C" void SslStreamBase_get_HashAlgorithm_m2687781311 ();
extern "C" void SslClientStream_get_PrivateKeyCertSelectionDelegate_m3868652817 ();
extern "C" void Context_get_RecordProtocol_m2261754827 ();
extern "C" void Context_get_CompressionMethod_m2647114016 ();
extern "C" void Context_get_Current_m2853615040 ();
extern "C" void Context_get_Negotiating_m2044579817 ();
extern "C" void Context_get_Read_m4172356735 ();
extern "C" void Context_get_Write_m1564343513 ();
extern "C" void Context_DecodeProtocolCode_m2249547310 ();
extern "C" void Context_get_SecurityProtocol_m3228286292 ();
extern "C" void Context_get_SecurityProtocolFlags_m2022471746 ();
extern "C" void SslStreamBase_get_SecurityProtocol_m596101988 ();
extern "C" void CipherSuiteCollection_add_m1422128145 ();
extern "C" void ClientContext_get_SslStream_m1583577309 ();
extern "C" void CipherSuiteCollection_add_m3005595589 ();
extern "C" void Context_get_ClientSettings_m2874391194 ();
extern "C" void Context_get_ServerSettings_m1982578801 ();
extern "C" void Context_get_HandshakeMessages_m3655705111 ();
extern "C" void CertificateValidationCallback2_EndInvoke_m2456956161 ();
extern "C" void CertificateValidationCallback2_Invoke_m3381554834 ();
extern "C" void SslClientStream_OnRemoteCertificateValidation2_m2342781980 ();
extern "C" void SslClientStream_RaiseServerCertificateValidation2_m2589974695 ();
extern "C" void SslStreamBase_RaiseRemoteCertificateValidation2_m2908038766 ();
extern "C" void StrongNameKeyPair_StrongName_m1031343114 ();
extern "C" void X509CertificateEnumerator_get_Current_m3041233561 ();
extern "C" void X509CertificateEnumerator_get_Current_m1004537031 ();
extern "C" void X509CertificateCollection_get_Item_m3219599455 ();
extern "C" void X509CertificateCollection_get_Item_m3285563224 ();
extern "C" void X509Chain_FindCertificateParent_m2809823532 ();
extern "C" void X509Chain_FindCertificateRoot_m1937726457 ();
extern "C" void X509Store_LoadCertificate_m1587806288 ();
extern "C" void X509Certificate2_get_MonoCertificate_m4228255308 ();
extern "C" void SslStreamBase_get_ServerCertificates_m2154373069 ();
extern "C" void TlsServerSettings_get_Certificates_m3981837031 ();
extern "C" void PKCS12_get_Certificates_m1630860723 ();
extern "C" void PKCS12_get_Certificates_m166242546 ();
extern "C" void X509Chain_get_TrustAnchors_m2434696767 ();
extern "C" void X509Store_BuildCertificatesCollection_m3030935583 ();
extern "C" void X509Store_get_Certificates_m1092347772 ();
extern "C" void X509StoreManager_get_TrustedRootCertificates_m2180997293 ();
extern "C" void X509CertificateCollection_GetEnumerator_m1275665495 ();
extern "C" void X509CertificateCollection_GetEnumerator_m4229251522 ();
extern "C" void X509Chain_get_Status_m348797749 ();
extern "C" void X509Store_LoadCrl_m1881903843 ();
extern "C" void X509Chain_FindCrl_m1657810964 ();
extern "C" void X509Crl_GetCrlEntry_m1550247114 ();
extern "C" void X509Crl_GetCrlEntry_m641501875 ();
extern "C" void X509ExtensionCollection_get_Item_m4249795832 ();
extern "C" void X509Certificate_get_Extensions_m2532937142 ();
extern "C" void X509CrlEntry_get_Extensions_m3390427621 ();
extern "C" void X509Crl_get_Extensions_m922657393 ();
extern "C" void X509Stores_Open_m1037335183 ();
extern "C" void X509Stores_get_TrustedRoot_m1736182879 ();
extern "C" void X509Store_get_Store_m1426986552 ();
extern "C" void X509StoreManager_get_CurrentUser_m719101392 ();
extern "C" void X509StoreManager_get_LocalMachine_m269504582 ();
extern "C" void X509Store_get_Factory_m3282910266 ();
extern "C" void AppDomain_InternalSetDomain_m3622943898 ();
extern "C" void AppDomain_InternalSetDomainByID_m560451773 ();
extern "C" void AppDomain_getCurDomain_m1005431575 ();
extern "C" void AppDomain_get_CurrentDomain_m182766250 ();
extern "C" void SecurityFrame_get_Domain_m681627326_AdjustorThunk ();
extern "C" void Thread_GetDomain_m1615404259 ();
extern "C" void Parser_NewParseException_m686511029 ();
extern "C" void Array_CreateInstance_m2750085942 ();
extern "C" void Array_CreateInstance_m1740754882 ();
extern "C" void Array_CreateInstance_m2696293787 ();
extern "C" void Array_CreateInstance_m2175520447 ();
extern "C" void Array_CreateInstance_m3395539612 ();
extern "C" void Array_CreateInstance_m1027597705 ();
extern "C" void Array_CreateInstanceImpl_m1073152296 ();
extern "C" void ArrayListWrapper_ToArray_m3192696690 ();
extern "C" void SynchronizedArrayListWrapper_ToArray_m1519105559 ();
extern "C" void ArrayList_ToArray_m3439706433 ();
extern "C" void SecurityFrame__GetSecurityStack_m449275820 ();
extern "C" void Array_get_swapper_m3428716670 ();
extern "C" void Attribute_GetCustomAttribute_m4034845276 ();
extern "C" void Attribute_GetCustomAttribute_m1244111375 ();
extern "C" void MonoCustomAttrs_GetCustomAttribute_m1568487577 ();
extern "C" void AttributeInfo_get_Usage_m3705131115 ();
extern "C" void MonoCustomAttrs_RetrieveAttributeUsage_m2717094301 ();
extern "C" void SafeHandleZeroOrMinusOneIsInvalid_get_IsInvalid_m1185299356 ();
extern "C" void SafeWaitHandle_ReleaseHandle_m2890681297 ();
extern "C" void MSCompatUnicodeTable_HasSpecialWeight_m1621324272 ();
extern "C" void MSCompatUnicodeTable_IsHalfWidthKana_m4030661976 ();
extern "C" void MSCompatUnicodeTable_IsHiragana_m3884380055 ();
extern "C" void MSCompatUnicodeTable_IsIgnorable_m3957534007 ();
extern "C" void MSCompatUnicodeTable_IsIgnorableNonSpacing_m47098938 ();
extern "C" void MSCompatUnicodeTable_IsJapaneseSmallLetter_m2666144582 ();
extern "C" void MSCompatUnicodeTable_get_IsReady_m366684638 ();
extern "C" void SimpleCollator_IsHalfKana_m3959736042 ();
extern "C" void SimpleCollator_IsIgnorable_m2840693628 ();
extern "C" void SimpleCollator_IsPrefix_m3581642267 ();
extern "C" void SimpleCollator_IsPrefix_m3601454628 ();
extern "C" void SimpleCollator_IsPrefix_m3884753235 ();
extern "C" void SimpleCollator_IsSafe_m310268646 ();
extern "C" void SimpleCollator_IsSuffix_m1548422615 ();
extern "C" void SimpleCollator_IsSuffix_m1291687763 ();
extern "C" void SimpleCollator_MatchesBackward_m485433520 ();
extern "C" void SimpleCollator_MatchesBackwardCore_m3441733084 ();
extern "C" void SimpleCollator_MatchesForward_m541234454 ();
extern "C" void SimpleCollator_MatchesForwardCore_m850743967 ();
extern "C" void SimpleCollator_MatchesPrimitive_m3079388596 ();
extern "C" void SimpleCollator_QuickCheckPossible_m649925260 ();
extern "C" void BigInteger_Equals_m63093403 ();
extern "C" void BigInteger_Equals_m1948500455 ();
extern "C" void BigInteger_IsProbablePrime_m567194283 ();
extern "C" void BigInteger_TestBit_m1507066813 ();
extern "C" void BigInteger_TestBit_m2798226118 ();
extern "C" void BigInteger_TestBit_m1365094736 ();
extern "C" void BigInteger_op_Equality_m1194739960 ();
extern "C" void BigInteger_op_Equality_m3263851871 ();
extern "C" void BigInteger_op_Equality_m970226143 ();
extern "C" void BigInteger_op_Equality_m3872814973 ();
extern "C" void BigInteger_op_GreaterThan_m2974122765 ();
extern "C" void BigInteger_op_GreaterThan_m2062805246 ();
extern "C" void BigInteger_op_GreaterThanOrEqual_m3313329514 ();
extern "C" void BigInteger_op_GreaterThanOrEqual_m700865613 ();
extern "C" void BigInteger_op_Inequality_m2365536750 ();
extern "C" void BigInteger_op_Inequality_m2697143438 ();
extern "C" void BigInteger_op_Inequality_m2239968970 ();
extern "C" void BigInteger_op_Inequality_m3469726044 ();
extern "C" void BigInteger_op_LessThan_m463398176 ();
extern "C" void BigInteger_op_LessThan_m798881406 ();
extern "C" void BigInteger_op_LessThanOrEqual_m3925173639 ();
extern "C" void BigInteger_op_LessThanOrEqual_m2553515144 ();
extern "C" void SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m1127740833 ();
extern "C" void SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m3637196143 ();
extern "C" void PrimalityTest_EndInvoke_m1035389364 ();
extern "C" void PrimalityTest_EndInvoke_m1454743433 ();
extern "C" void PrimalityTest_Invoke_m2948246884 ();
extern "C" void PrimalityTest_Invoke_m476975163 ();
extern "C" void PrimalityTests_RabinMillerTest_m1471415870 ();
extern "C" void PrimalityTests_RabinMillerTest_m2544317101 ();
extern "C" void PrimalityTests_SmallPrimeSppTest_m1224130639 ();
extern "C" void PrimalityTests_Test_m2932837908 ();
extern "C" void ASN1_CompareArray_m3928975006 ();
extern "C" void ASN1_CompareArray_m448994814 ();
extern "C" void ASN1_CompareValue_m251306338 ();
extern "C" void ASN1_CompareValue_m1642100296 ();
extern "C" void ARC4Managed_get_CanReuseTransform_m1145713138 ();
extern "C" void DSAManaged_VerifySignature_m2909094577 ();
extern "C" void DSAManaged_get_PublicOnly_m3575594967 ();
extern "C" void KeyPairPersistence_CanSecure_m3598829533 ();
extern "C" void KeyPairPersistence_IsMachineProtected_m644209340 ();
extern "C" void KeyPairPersistence_IsUserProtected_m2000878920 ();
extern "C" void KeyPairPersistence_Load_m2518737071 ();
extern "C" void KeyPairPersistence_ProtectMachine_m1313131097 ();
extern "C" void KeyPairPersistence_ProtectUser_m2715637552 ();
extern "C" void KeyPairPersistence__CanSecure_m3516574278 ();
extern "C" void KeyPairPersistence__IsMachineProtected_m2170750712 ();
extern "C" void KeyPairPersistence__IsUserProtected_m438961964 ();
extern "C" void KeyPairPersistence__ProtectMachine_m813172390 ();
extern "C" void KeyPairPersistence__ProtectUser_m3263950383 ();
extern "C" void KeyPairPersistence_get_CanChange_m4275265699 ();
extern "C" void KeyPairPersistence_get_UseDefaultKeyContainer_m1646107069 ();
extern "C" void KeyPairPersistence_get_UseMachineKeyStore_m3206839918 ();
extern "C" void MD5SHA1_VerifySignature_m915115209 ();
extern "C" void PKCS1_Compare_m8562819 ();
extern "C" void PKCS1_Compare_m2442824967 ();
extern "C" void PKCS1_Verify_v15_m2816868480 ();
extern "C" void PKCS1_Verify_v15_m4192025173 ();
extern "C" void PKCS1_Verify_v15_m400093581 ();
extern "C" void PKCS1_Verify_v15_m3708133908 ();
extern "C" void RSAManaged_get_IsCrtPossible_m3949564681 ();
extern "C" void RSAManaged_get_PublicOnly_m595121416 ();
extern "C" void RSAManaged_get_PublicOnly_m405847294 ();
extern "C" void SymmetricTransform_get_CanReuseTransform_m3947311416 ();
extern "C" void SymmetricTransform_get_CanReuseTransform_m3495714228 ();
extern "C" void SymmetricTransform_get_KeepLastBlock_m2492071306 ();
extern "C" void SymmetricTransform_get_KeepLastBlock_m3105157421 ();
extern "C" void Alert_get_IsCloseNotify_m3157384796 ();
extern "C" void Alert_get_IsWarning_m1365397992 ();
extern "C" void CertificateValidationCallback_EndInvoke_m4224203910 ();
extern "C" void CertificateValidationCallback_Invoke_m1014111289 ();
extern "C" void CipherSuite_get_IsExportable_m677202963 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Contains_m1220133031 ();
extern "C" void CipherSuiteCollection_cultureAwareCompare_m2072548979 ();
extern "C" void ClientSessionCache_SetContextFromCache_m3781380849 ();
extern "C" void ClientSessionCache_SetContextInCache_m2875733100 ();
extern "C" void ClientSessionInfo_get_Valid_m1260893789 ();
extern "C" void Context_get_AbbreviatedHandshake_m3907920227 ();
extern "C" void Context_get_ProtocolNegotiated_m4220412840 ();
extern "C" void Context_get_ReceivedConnectionEnd_m4011125537 ();
extern "C" void Context_get_SentConnectionEnd_m963812869 ();
extern "C" void TlsServerCertificate_Match_m2996121276 ();
extern "C" void TlsServerCertificate_checkCertificateUsage_m2152016773 ();
extern "C" void TlsServerCertificate_checkDomainName_m2543190336 ();
extern "C" void TlsServerCertificate_checkServerIdentity_m2801575130 ();
extern "C" void HandshakeMessage_Compare_m2214647946 ();
extern "C" void HttpsClientStream_RaiseServerCertificateValidation_m3782467213 ();
extern "C" void HttpsClientStream_get_TrustFailure_m1151901888 ();
extern "C" void RSASslSignatureDeformatter_VerifySignature_m1061897602 ();
extern "C" void ReceiveRecordAsyncResult_get_CompletedWithError_m2856009536 ();
extern "C" void ReceiveRecordAsyncResult_get_IsCompleted_m1918259948 ();
extern "C" void SendRecordAsyncResult_get_CompletedWithError_m3232037803 ();
extern "C" void SendRecordAsyncResult_get_IsCompleted_m3929307031 ();
extern "C" void RecordProtocol_Compare_m4182754688 ();
extern "C" void SslClientStream_OnRemoteCertificateValidation_m2343517080 ();
extern "C" void SslClientStream_RaiseServerCertificateValidation_m3477149273 ();
extern "C" void SslClientStream_get_HaveRemoteValidation2Callback_m2858953511 ();
extern "C" void InternalAsyncResult_get_CompletedWithError_m3777099678 ();
extern "C" void InternalAsyncResult_get_FromWrite_m4228047810 ();
extern "C" void InternalAsyncResult_get_IsCompleted_m2607263611 ();
extern "C" void InternalAsyncResult_get_ProceedAfterHandshake_m2508379800 ();
extern "C" void SslStreamBase_BeginNegotiateHandshake_m4180435790 ();
extern "C" void SslStreamBase_RaiseRemoteCertificateValidation_m944390272 ();
extern "C" void SslStreamBase_get_CanRead_m2005873964 ();
extern "C" void SslStreamBase_get_CanSeek_m701584365 ();
extern "C" void SslStreamBase_get_CanWrite_m1622082918 ();
extern "C" void SslStreamBase_get_CheckCertRevocationStatus_m2739906607 ();
extern "C" void SslStreamBase_get_MightNeedHandshake_m909005056 ();
extern "C" void TlsServerSettings_get_CertificateRequest_m842655670 ();
extern "C" void TlsServerSettings_get_ServerKeyExchange_m691183033 ();
extern "C" void TlsStream_get_CanRead_m2847511450 ();
extern "C" void TlsStream_get_CanSeek_m1261421145 ();
extern "C" void TlsStream_get_CanWrite_m16389328 ();
extern "C" void TlsStream_get_EOF_m953226442 ();
extern "C" void ValidationResult_get_Trusted_m2108852505 ();
extern "C" void BasicConstraintsExtension_get_CertificateAuthority_m391198292 ();
extern "C" void KeyUsageExtension_Support_m3508856672 ();
extern "C" void NetscapeCertTypeExtension_Support_m3981181230 ();
extern "C" void PKCS12_Compare_m2975811353 ();
extern "C" void PKCS12_Compare_m219153845 ();
extern "C" void X509Certificate_VerifySignature_m429904987 ();
extern "C" void X509Certificate_VerifySignature_m3988463526 ();
extern "C" void X509Certificate_VerifySignature_m3538124832 ();
extern "C" void X509Certificate_WasCurrent_m1146083014 ();
extern "C" void X509Certificate_get_IsCurrent_m469817010 ();
extern "C" void X509Certificate_get_IsSelfSigned_m4064195693 ();
extern "C" void X509CertificateEnumerator_MoveNext_m3925432749 ();
extern "C" void X509CertificateEnumerator_MoveNext_m2269241175 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m708500216 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m2626270621 ();
extern "C" void X509CertificateCollection_Compare_m3676635762 ();
extern "C" void X509CertificateCollection_Contains_m743657353 ();
extern "C" void X509Chain_Build_m2469702749 ();
extern "C" void X509Chain_IsParent_m2689546349 ();
extern "C" void X509Chain_IsTrusted_m1243554942 ();
extern "C" void X509Chain_IsValid_m3670863655 ();
extern "C" void X509Crl_Compare_m3418726913 ();
extern "C" void X509Crl_VerifySignature_m2177510742 ();
extern "C" void X509Crl_VerifySignature_m1902456590 ();
extern "C" void X509Crl_VerifySignature_m1808348256 ();
extern "C" void X509Extension_Equals_m1779194186 ();
extern "C" void X509Extension_Equals_m1222951829 ();
extern "C" void X509Extension_get_Critical_m2974578711 ();
extern "C" void X509Store_CheckStore_m2045435685 ();
extern "C" void SmallXmlParser_IsNameChar_m2946368541 ();
extern "C" void SmallXmlParser_IsWhitespace_m156831381 ();
extern "C" void ArgIterator_Equals_m4289772452_AdjustorThunk ();
extern "C" void SimpleEnumerator_MoveNext_m3097336207 ();
extern "C" void Array_FastCopy_m1662204957 ();
extern "C" void Array_InternalArray__ICollection_get_IsReadOnly_m4276975044 ();
extern "C" void Array_System_Collections_IList_Contains_m3297693594 ();
extern "C" void Array_get_IsFixedSize_m433207027 ();
extern "C" void Array_get_IsReadOnly_m1420176977 ();
extern "C" void Array_get_IsSynchronized_m3066873806 ();
extern "C" void Attribute_Equals_m710241514 ();
extern "C" void Attribute_IsDefined_m3363303722 ();
extern "C" void Attribute_IsDefined_m1430686743 ();
extern "C" void Attribute_IsDefined_m4069052474 ();
extern "C" void Attribute_IsDefined_m3355705882 ();
extern "C" void AttributeUsageAttribute_get_AllowMultiple_m2247746686 ();
extern "C" void AttributeUsageAttribute_get_Inherited_m2911062450 ();
extern "C" void BitConverter_AmILittleEndian_m4092412670 ();
extern "C" void BitConverter_DoubleWordsAreSwapped_m1474345095 ();
extern "C" void Boolean_Equals_m535526264_AdjustorThunk ();
extern "C" void Boolean_Equals_m2410333903_AdjustorThunk ();
extern "C" void Boolean_Parse_m2370352694 ();
extern "C" void Boolean_System_IConvertible_ToBoolean_m422934902_AdjustorThunk ();
extern "C" void Buffer_BlockCopyInternal_m418318694 ();
extern "C" void Byte_Equals_m2522165325_AdjustorThunk ();
extern "C" void Byte_Equals_m1161982810_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToBoolean_m2888023769_AdjustorThunk ();
extern "C" void Byte_TryParse_m1615417784 ();
extern "C" void Byte_TryParse_m1467448483 ();
extern "C" void Char_Equals_m198757577_AdjustorThunk ();
extern "C" void Char_Equals_m1279957088_AdjustorThunk ();
extern "C" void Char_IsDigit_m3646673943 ();
extern "C" void Char_IsLetter_m3996985877 ();
extern "C" void Char_IsLetterOrDigit_m3494175785 ();
extern "C" void Char_IsLower_m3108076820 ();
extern "C" void Char_IsSurrogate_m3686972571 ();
extern "C" void Char_IsWhiteSpace_m2148390798 ();
extern "C" void Char_IsWhiteSpace_m3213701995 ();
extern "C" void Char_System_IConvertible_ToBoolean_m309214875_AdjustorThunk ();
extern "C" void CharEnumerator_MoveNext_m599189179 ();
extern "C" void ArrayListWrapper_Contains_m2641184447 ();
extern "C" void ArrayListWrapper_get_IsReadOnly_m322171850 ();
extern "C" void ArrayListWrapper_get_IsSynchronized_m877742690 ();
extern "C" void ReadOnlyArrayListWrapper_get_IsReadOnly_m2332097348 ();
extern "C" void SimpleEnumerator_MoveNext_m3113120129 ();
extern "C" void SynchronizedArrayListWrapper_Contains_m3809499313 ();
extern "C" void SynchronizedArrayListWrapper_get_IsReadOnly_m2240310664 ();
extern "C" void SynchronizedArrayListWrapper_get_IsSynchronized_m3380436820 ();
extern "C" void ArrayList_Contains_m974354901 ();
extern "C" void ArrayList_get_IsReadOnly_m913775115 ();
extern "C" void ArrayList_get_IsSynchronized_m854316597 ();
extern "C" void BitArrayEnumerator_MoveNext_m3806676766 ();
extern "C" void BitArray_Get_m1610855460 ();
extern "C" void BitArray_get_Item_m2970562587 ();
extern "C" void CaseInsensitiveHashCodeProvider_AreEqual_m1790260777 ();
extern "C" void CaseInsensitiveHashCodeProvider_AreEqual_m3534448780 ();
extern "C" void CollectionBase_System_Collections_IList_Contains_m2994901969 ();
extern "C" void Enumerator_MoveNext_m1474126172 ();
extern "C" void SyncHashtable_Contains_m2292068165 ();
extern "C" void SyncHashtable_ContainsKey_m4051091192 ();
extern "C" void Hashtable_Contains_m2145146412 ();
extern "C" void Hashtable_ContainsKey_m2963904694 ();
extern "C" void Hashtable_KeyEquals_m2549637027 ();
extern "C" void Hashtable_TestPrime_m3839319309 ();
extern "C" void QueueEnumerator_MoveNext_m386897816 ();
extern "C" void Enumerator_MoveNext_m635366482 ();
extern "C" void SortedList_Contains_m559482983 ();
extern "C" void SortedList_ContainsKey_m2883715045 ();
extern "C" void SortedList_get_IsFixedSize_m2192379219 ();
extern "C" void SortedList_get_IsReadOnly_m1554442113 ();
extern "C" void DictionaryNodeEnumerator_MoveNext_m736126844 ();
extern "C" void _KeysEnumerator_MoveNext_m4289758929 ();
extern "C" void NameObjectCollectionBase_get_IsReadOnly_m1249375452 ();
extern "C" void Enumerator_MoveNext_m3995713679 ();
extern "C" void EditorBrowsableAttribute_Equals_m3041896197 ();
extern "C" void TypeConverterAttribute_Equals_m1580461255 ();
extern "C" void Convert_ToBoolean_m2984378204 ();
extern "C" void Convert_ToBoolean_m2694598181 ();
extern "C" void Convert_ToBoolean_m4098720762 ();
extern "C" void Convert_ToBoolean_m2833752130 ();
extern "C" void Convert_ToBoolean_m2833489984 ();
extern "C" void Convert_ToBoolean_m2833621053 ();
extern "C" void Convert_ToBoolean_m2072772931 ();
extern "C" void Convert_ToBoolean_m4120735400 ();
extern "C" void Convert_ToBoolean_m40300963 ();
extern "C" void Convert_ToBoolean_m4244349331 ();
extern "C" void Convert_ToBoolean_m3588715767 ();
extern "C" void Convert_ToBoolean_m481380807 ();
extern "C" void Convert_ToBoolean_m2807110707 ();
extern "C" void Convert_ToBoolean_m3613483153 ();
extern "C" void CultureAwareComparer_Equals_m710929189 ();
extern "C" void CurrentSystemTimeZone_GetTimeZoneData_m2641861607 ();
extern "C" void DBNull_System_IConvertible_ToBoolean_m702787761 ();
extern "C" void DateTime_CoreParse_m428043272 ();
extern "C" void DateTime_Equals_m4001498422_AdjustorThunk ();
extern "C" void DateTime_Equals_m611432332_AdjustorThunk ();
extern "C" void DateTime_IsLeapYear_m1852497299 ();
extern "C" void DateTime_IsLetter_m156019844 ();
extern "C" void DateTime_ParseExact_m317338046 ();
extern "C" void DateTime_System_IConvertible_ToBoolean_m3229932458_AdjustorThunk ();
extern "C" void DateTime__DoParse_m552486664 ();
extern "C" void DateTime__ParseAmPm_m3478436123 ();
extern "C" void DateTime__ParseDateSeparator_m1803046501 ();
extern "C" void DateTime__ParseString_m2913931606 ();
extern "C" void DateTime__ParseTimeSeparator_m2659275695 ();
extern "C" void DateTime_op_Equality_m1022058599 ();
extern "C" void DateTime_op_GreaterThan_m3768590082 ();
extern "C" void DateTime_op_GreaterThanOrEqual_m674703316 ();
extern "C" void DateTime_op_Inequality_m1382517918 ();
extern "C" void DateTime_op_LessThan_m2497205152 ();
extern "C" void DateTime_op_LessThanOrEqual_m2360948759 ();
extern "C" void DateTimeOffset_Equals_m605268013_AdjustorThunk ();
extern "C" void DateTimeOffset_Equals_m3030958070_AdjustorThunk ();
extern "C" void Decimal_Equals_m2486655999_AdjustorThunk ();
extern "C" void Decimal_Equals_m3759456653 ();
extern "C" void Decimal_Equals_m2592017260_AdjustorThunk ();
extern "C" void Decimal_IsZero_m4250358244_AdjustorThunk ();
extern "C" void Decimal_PerformParse_m1679987175 ();
extern "C" void Decimal_System_IConvertible_ToBoolean_m1123794670_AdjustorThunk ();
extern "C" void Decimal_op_Equality_m77262825 ();
extern "C" void Decimal_op_GreaterThan_m627311519 ();
extern "C" void Decimal_op_Inequality_m3543190500 ();
extern "C" void Decimal_op_LessThan_m1273833514 ();
extern "C" void Delegate_Equals_m821895546 ();
extern "C" void Delegate_arg_type_match_m870692501 ();
extern "C" void Delegate_return_type_match_m2309328069 ();
extern "C" void StackFrame_get_frame_info_m2312611643 ();
extern "C" void Double_Equals_m2309369974_AdjustorThunk ();
extern "C" void Double_Equals_m1674752021_AdjustorThunk ();
extern "C" void Double_IsInfinity_m820013146 ();
extern "C" void Double_IsNaN_m649024406 ();
extern "C" void Double_IsNegativeInfinity_m538614603 ();
extern "C" void Double_IsPositiveInfinity_m1245619811 ();
extern "C" void Double_Parse_m2152196909 ();
extern "C" void Double_ParseImpl_m3514935432 ();
extern "C" void Double_System_IConvertible_ToBoolean_m652944629_AdjustorThunk ();
extern "C" void Double_TryParseStringConstant_m3290212599 ();
extern "C" void Enum_Equals_m3617313991 ();
extern "C" void Enum_IsDefined_m1442314461 ();
extern "C" void Enum_System_IConvertible_ToBoolean_m1977632688 ();
extern "C" void Environment_get_IsRunningOnWindows_m1804804030 ();
extern "C" void Environment_get_SocketSecurityEnabled_m190813817 ();
extern "C" void CCGregorianCalendar_is_leap_year_m2193335769 ();
extern "C" void CompareInfo_Equals_m1257808801 ();
extern "C" void CompareInfo_IsPrefix_m796715920 ();
extern "C" void CompareInfo_IsSuffix_m1571711387 ();
extern "C" void CompareInfo_get_UseManagedCollation_m3599558938 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromCurrentLocale_m3684789125 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromLcid_m2304903600 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromName_m4012802696 ();
extern "C" void CultureInfo_Equals_m1360976324 ();
extern "C" void CultureInfo_construct_internal_locale_from_current_locale_m2484355412 ();
extern "C" void CultureInfo_construct_internal_locale_from_lcid_m2668301444 ();
extern "C" void CultureInfo_construct_internal_locale_from_name_m3254739477 ();
extern "C" void CultureInfo_get_IsNeutralCulture_m3370126681 ();
extern "C" void CultureInfo_get_IsReadOnly_m3799952118 ();
extern "C" void DateTimeFormatInfo_get_IsReadOnly_m1173781646 ();
extern "C" void RegionInfo_Equals_m2499055654 ();
extern "C" void RegionInfo_GetByTerritory_m2536737365 ();
extern "C" void RegionInfo_construct_internal_region_from_name_m1315402456 ();
extern "C" void RegionInfo_get_IsMetric_m254276301 ();
extern "C" void SortKey_Equals_m3124075298 ();
extern "C" void TextInfo_Equals_m3029092201 ();
extern "C" void GuidParser_AtEnd_m3409982497 ();
extern "C" void GuidParser_ParseOptChar_m1342400948 ();
extern "C" void Guid_Equals_m3683678873_AdjustorThunk ();
extern "C" void Guid_Equals_m1866984197_AdjustorThunk ();
extern "C" void Guid_op_Equality_m4289903222 ();
extern "C" void BinaryReader_ReadBoolean_m3271855799 ();
extern "C" void Directory_Exists_m1484791558 ();
extern "C" void DirectoryInfo_get_Exists_m3142069876 ();
extern "C" void File_Exists_m3943585060 ();
extern "C" void FileStream_get_CanRead_m860786786 ();
extern "C" void FileStream_get_CanSeek_m331583577 ();
extern "C" void FileStream_get_CanWrite_m1199612770 ();
extern "C" void FileStreamAsyncResult_get_IsCompleted_m2730893434 ();
extern "C" void MemoryStream_get_CanRead_m1639425566 ();
extern "C" void MemoryStream_get_CanSeek_m2835368013 ();
extern "C" void MemoryStream_get_CanWrite_m3127242210 ();
extern "C" void MonoIO_Close_m3406045462 ();
extern "C" void MonoIO_CreateDirectory_m120522531 ();
extern "C" void MonoIO_DeleteFile_m3839141322 ();
extern "C" void MonoIO_ExistsDirectory_m2182482658 ();
extern "C" void MonoIO_ExistsFile_m812572516 ();
extern "C" void MonoIO_GetFileStat_m678141354 ();
extern "C" void MonoIO_RemapPath_m1142466502 ();
extern "C" void MonoIO_SetLength_m2811105392 ();
extern "C" void NullStream_get_CanRead_m1034149266 ();
extern "C" void NullStream_get_CanSeek_m500620687 ();
extern "C" void NullStream_get_CanWrite_m1245688616 ();
extern "C" void Path_IsDsc_m138487241 ();
extern "C" void Path_IsPathRooted_m3515805419 ();
extern "C" void Path_SameRoot_m1518354096 ();
extern "C" void StreamAsyncResult_get_Done_m3405983634 ();
extern "C" void StreamAsyncResult_get_IsCompleted_m2732733162 ();
extern "C" void UnexceptionalStreamReader_CheckEOL_m187999544 ();
extern "C" void UnmanagedMemoryStream_get_CanRead_m3770815400 ();
extern "C" void UnmanagedMemoryStream_get_CanSeek_m2636857629 ();
extern "C" void UnmanagedMemoryStream_get_CanWrite_m2913951513 ();
extern "C" void Int16_Equals_m1479112859_AdjustorThunk ();
extern "C" void Int16_Equals_m82811458_AdjustorThunk ();
extern "C" void Int16_Parse_m2276856944 ();
extern "C" void Int16_System_IConvertible_ToBoolean_m1656400658_AdjustorThunk ();
extern "C" void Int16_TryParse_m1675418240 ();
extern "C" void Int32_CheckStyle_m3421319992 ();
extern "C" void Int32_Equals_m2976157357_AdjustorThunk ();
extern "C" void Int32_Equals_m3996243976_AdjustorThunk ();
extern "C" void Int32_FindExponent_m2938219441 ();
extern "C" void Int32_FindOther_m3593812441 ();
extern "C" void Int32_JumpOverWhite_m208298144 ();
extern "C" void Int32_Parse_m2309670223 ();
extern "C" void Int32_Parse_m3020773399 ();
extern "C" void Int32_ProcessTrailingWhitespace_m220059206 ();
extern "C" void Int32_System_IConvertible_ToBoolean_m2787524506_AdjustorThunk ();
extern "C" void Int32_TryParse_m135955795 ();
extern "C" void Int32_TryParse_m2404707562 ();
extern "C" void Int32_ValidDigit_m1059003769 ();
extern "C" void Int64_Equals_m680137412_AdjustorThunk ();
extern "C" void Int64_Equals_m858582563_AdjustorThunk ();
extern "C" void Int64_Parse_m3309897583 ();
extern "C" void Int64_Parse_m1800613309 ();
extern "C" void Int64_System_IConvertible_ToBoolean_m2413769966_AdjustorThunk ();
extern "C" void Int64_TryParse_m3606398488 ();
extern "C" void Int64_TryParse_m2208578514 ();
extern "C" void IntPtr_Equals_m3408989655_AdjustorThunk ();
extern "C" void IntPtr_op_Equality_m408849716 ();
extern "C" void IntPtr_op_Inequality_m3063970704 ();
extern "C" void MonoCustomAttrs_IsDefined_m2996012389 ();
extern "C" void MonoCustomAttrs_IsDefinedInternal_m2193933235 ();
extern "C" void MonoCustomAttrs_IsUserCattrProvider_m2878058089 ();
extern "C" void MonoType_HasElementTypeImpl_m2861175951 ();
extern "C" void MonoType_IsArrayImpl_m3283552941 ();
extern "C" void MonoType_IsByRefImpl_m2022486753 ();
extern "C" void MonoType_IsDefined_m838143016 ();
extern "C" void MonoType_IsPointerImpl_m3340652279 ();
extern "C" void MonoType_IsPrimitiveImpl_m2401722705 ();
extern "C" void MonoType_IsSubclassOf_m1667794028 ();
extern "C" void MonoType_get_ContainsGenericParameters_m1687910863 ();
extern "C" void MonoType_get_IsGenericParameter_m2855599887 ();
extern "C" void MulticastDelegate_BaseEquals_m335858574 ();
extern "C" void MulticastDelegate_Equals_m2502840627 ();
extern "C" void DefaultCertificatePolicy_CheckValidationResult_m3811448269 ();
extern "C" void FtpWebRequest_U3CcallbackU3Em__B_m3681041041 ();
extern "C" void IPAddress_Equals_m1823478787 ();
extern "C" void IPAddress_IsLoopback_m29387631 ();
extern "C" void IPAddress_TryParse_m2320149543 ();
extern "C" void IPv6Address_Equals_m2165515875 ();
extern "C" void IPv6Address_IsIPv4Compatible_m2636354880 ();
extern "C" void IPv6Address_IsIPv4Mapped_m2527005544 ();
extern "C" void IPv6Address_IsLoopback_m3712926451 ();
extern "C" void IPv6Address_TryParse_m3387120421 ();
extern "C" void IPv6Address_TryParse_m2586816298 ();
extern "C" void RemoteCertificateValidationCallback_EndInvoke_m1360061860 ();
extern "C" void RemoteCertificateValidationCallback_Invoke_m727898444 ();
extern "C" void ServicePoint_get_AvailableForRecycling_m936700514 ();
extern "C" void SPKey_Equals_m4205549017 ();
extern "C" void ServicePointManager_get_CheckCertificateRevocationList_m1716454075 ();
extern "C" void WebHeaderCollection_IsHeaderName_m2906290131 ();
extern "C" void WebHeaderCollection_IsHeaderValue_m3837500493 ();
extern "C" void WebHeaderCollection_IsRestricted_m2639089215 ();
extern "C" void WebProxy_IsBypassed_m2918071028 ();
extern "C" void WebProxy_get_UseDefaultCredentials_m1572240836 ();
extern "C" void NumberFormatter_IsZeroOnly_m46572730 ();
extern "C" void NumberFormatter_RoundBits_m2305061002 ();
extern "C" void NumberFormatter_RoundDecimal_m2957290908 ();
extern "C" void NumberFormatter_get_IsFloatingSource_m3714711779 ();
extern "C" void NumberFormatter_get_IsZero_m3770699077 ();
extern "C" void NumberFormatter_get_IsZeroInteger_m2263284741 ();
extern "C" void Object_Equals_m2439880830 ();
extern "C" void Object_Equals_m1397037629 ();
extern "C" void Object_ReferenceEquals_m610702577 ();
extern "C" void OrdinalComparer_Equals_m1106612171 ();
extern "C" void Assembly_IsDefined_m1652198537 ();
extern "C" void AssemblyName_get_IsPublicKeyValid_m1483495830 ();
extern "C" void Default_IsArrayAssignable_m953489228 ();
extern "C" void Default_check_arguments_m3882727959 ();
extern "C" void Default_check_type_m3691874551 ();
extern "C" void Binder_ConvertArgs_m2124461494 ();
extern "C" void CustomAttributeData_Equals_m4034962021 ();
extern "C" void CustomAttributeNamedArgument_Equals_m1414002036_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_Equals_m2261980307_AdjustorThunk ();
extern "C" void AssemblyBuilder_get_IsCompilerContext_m4201958597 ();
extern "C" void AssemblyBuilder_get_IsRun_m3300414718 ();
extern "C" void AssemblyBuilder_get_IsSave_m879473088 ();
extern "C" void ConstructorBuilder_IsDefined_m3603803379 ();
extern "C" void ConstructorBuilder_get_IsCompilerContext_m3364441562 ();
extern "C" void DynamicMethod_IsDefined_m2556354904 ();
extern "C" void EnumBuilder_HasElementTypeImpl_m3477408451 ();
extern "C" void EnumBuilder_IsArrayImpl_m572123653 ();
extern "C" void EnumBuilder_IsByRefImpl_m210003629 ();
extern "C" void EnumBuilder_IsDefined_m4222535176 ();
extern "C" void EnumBuilder_IsPointerImpl_m2644353933 ();
extern "C" void EnumBuilder_IsPrimitiveImpl_m3796774069 ();
extern "C" void EnumBuilder_IsValueTypeImpl_m57969026 ();
extern "C" void FieldBuilder_IsDefined_m838988679 ();
extern "C" void GenericTypeParameterBuilder_Equals_m3260957994 ();
extern "C" void GenericTypeParameterBuilder_HasElementTypeImpl_m2509088011 ();
extern "C" void GenericTypeParameterBuilder_IsArrayImpl_m67259334 ();
extern "C" void GenericTypeParameterBuilder_IsAssignableFrom_m67565415 ();
extern "C" void GenericTypeParameterBuilder_IsByRefImpl_m4112722356 ();
extern "C" void GenericTypeParameterBuilder_IsDefined_m98179866 ();
extern "C" void GenericTypeParameterBuilder_IsInstanceOfType_m1071939531 ();
extern "C" void GenericTypeParameterBuilder_IsPointerImpl_m2257540205 ();
extern "C" void GenericTypeParameterBuilder_IsPrimitiveImpl_m1952010459 ();
extern "C" void GenericTypeParameterBuilder_IsSubclassOf_m2266644074 ();
extern "C" void GenericTypeParameterBuilder_IsValueTypeImpl_m480678299 ();
extern "C" void GenericTypeParameterBuilder_get_ContainsGenericParameters_m786165540 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericParameter_m792248181 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericType_m2493787252 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericTypeDefinition_m3082475717 ();
extern "C" void Label_Equals_m1321622490_AdjustorThunk ();
extern "C" void MethodBuilder_Equals_m3329023947 ();
extern "C" void MethodBuilder_IsDefined_m662196788 ();
extern "C" void MethodBuilder_get_ContainsGenericParameters_m1358274636 ();
extern "C" void MethodBuilder_get_IsGenericMethod_m3216441561 ();
extern "C" void MethodBuilder_get_IsGenericMethodDefinition_m2943035191 ();
extern "C" void MethodToken_Equals_m460628456_AdjustorThunk ();
extern "C" void ModuleBuilder_IsTransient_m421403846 ();
extern "C" void OpCode_Equals_m1376200488_AdjustorThunk ();
extern "C" void OpCode_op_Equality_m3082103192 ();
extern "C" void PropertyBuilder_IsDefined_m406627924 ();
extern "C" void PropertyBuilder_get_CanRead_m3783190070 ();
extern "C" void PropertyBuilder_get_CanWrite_m2657562188 ();
extern "C" void TypeBuilder_HasElementTypeImpl_m1871001960 ();
extern "C" void TypeBuilder_IsArrayImpl_m2884820883 ();
extern "C" void TypeBuilder_IsAssignableFrom_m3127348202 ();
extern "C" void TypeBuilder_IsAssignableTo_m547961029 ();
extern "C" void TypeBuilder_IsByRefImpl_m3775334677 ();
extern "C" void TypeBuilder_IsDefined_m1289323273 ();
extern "C" void TypeBuilder_IsPointerImpl_m2837168342 ();
extern "C" void TypeBuilder_IsPrimitiveImpl_m1753586266 ();
extern "C" void TypeBuilder_IsSubclassOf_m3458909121 ();
extern "C" void TypeBuilder_IsValueTypeImpl_m3935440087 ();
extern "C" void TypeBuilder_get_ContainsGenericParameters_m1769080325 ();
extern "C" void TypeBuilder_get_IsCompilerContext_m4056143290 ();
extern "C" void TypeBuilder_get_IsGenericParameter_m1751799710 ();
extern "C" void TypeBuilder_get_IsGenericType_m2295780578 ();
extern "C" void TypeBuilder_get_IsGenericTypeDefinition_m1477212742 ();
extern "C" void TypeBuilder_get_is_created_m1192848807 ();
extern "C" void TypeBuilder_has_ctor_method_m2987175843 ();
extern "C" void TypeBuilder_is_nested_in_m1146519762 ();
extern "C" void FieldInfo_get_IsLiteral_m534699794 ();
extern "C" void FieldInfo_get_IsNotSerialized_m2684033086 ();
extern "C" void FieldInfo_get_IsPublic_m3378038140 ();
extern "C" void FieldInfo_get_IsStatic_m3482711189 ();
extern "C" void MemberFilter_EndInvoke_m3130107476 ();
extern "C" void MemberFilter_Invoke_m2890658112 ();
extern "C" void MethodBase_get_ContainsGenericParameters_m2144492325 ();
extern "C" void MethodBase_get_IsAbstract_m428833029 ();
extern "C" void MethodBase_get_IsGenericMethod_m3017096435 ();
extern "C" void MethodBase_get_IsGenericMethodDefinition_m3619640237 ();
extern "C" void MethodBase_get_IsPublic_m2180846589 ();
extern "C" void MethodBase_get_IsStatic_m2399864271 ();
extern "C" void MethodBase_get_IsVirtual_m2008546636 ();
extern "C" void MethodInfo_get_ContainsGenericParameters_m3008250450 ();
extern "C" void MethodInfo_get_IsGenericMethod_m1711950591 ();
extern "C" void MethodInfo_get_IsGenericMethodDefinition_m3304621588 ();
extern "C" void Module_IsDefined_m2423524910 ();
extern "C" void Module_IsResource_m553227372 ();
extern "C" void Module_filter_by_type_name_m1840126910 ();
extern "C" void Module_filter_by_type_name_ignore_case_m711265203 ();
extern "C" void MonoCMethod_IsDefined_m3900688634 ();
extern "C" void MonoEvent_IsDefined_m10931749 ();
extern "C" void MonoField_IsDefined_m2274038045 ();
extern "C" void MonoMethod_IsDefined_m2906130478 ();
extern "C" void MonoMethod_ShouldPrintFullName_m1607666412 ();
extern "C" void MonoMethod_get_ContainsGenericParameters_m3860345224 ();
extern "C" void MonoMethod_get_IsGenericMethod_m1665512545 ();
extern "C" void MonoMethod_get_IsGenericMethodDefinition_m3024870835 ();
extern "C" void MonoProperty_IsDefined_m2173657168 ();
extern "C" void MonoProperty_get_CanRead_m2001748608 ();
extern "C" void MonoProperty_get_CanWrite_m3409349928 ();
extern "C" void ParameterInfo_IsDefined_m1890759429 ();
extern "C" void ParameterInfo_get_IsIn_m1278224586 ();
extern "C" void ParameterInfo_get_IsOptional_m2957997858 ();
extern "C" void ParameterInfo_get_IsOut_m867677222 ();
extern "C" void ParameterInfo_get_IsRetval_m86270398 ();
extern "C" void TypeDelegator_HasElementTypeImpl_m2350626737 ();
extern "C" void TypeDelegator_IsArrayImpl_m2097588942 ();
extern "C" void TypeDelegator_IsByRefImpl_m613197127 ();
extern "C" void TypeDelegator_IsDefined_m1601251036 ();
extern "C" void TypeDelegator_IsPointerImpl_m458295709 ();
extern "C" void TypeDelegator_IsPrimitiveImpl_m2362421338 ();
extern "C" void TypeDelegator_IsValueTypeImpl_m3770949884 ();
extern "C" void TypeFilter_EndInvoke_m998903841 ();
extern "C" void TypeFilter_Invoke_m3862132457 ();
extern "C" void NameOrId_get_IsName_m2723783478 ();
extern "C" void ResourceEnumerator_MoveNext_m422576100 ();
extern "C" void GCHandle_Equals_m146069735_AdjustorThunk ();
extern "C" void GCHandle_get_IsAllocated_m1058226959_AdjustorThunk ();
extern "C" void RemoteActivationAttribute_IsContextOK_m112778382 ();
extern "C" void UrlAttribute_Equals_m758046158 ();
extern "C" void UrlAttribute_IsContextOK_m1228378186 ();
extern "C" void ChannelServices_IsLocalCall_m3035930722 ();
extern "C" void ConfigHandler_CheckPath_m3079311646 ();
extern "C" void Context_RegisterDynamicProperty_m2307208816 ();
extern "C" void Context_UnregisterDynamicProperty_m1191983692 ();
extern "C" void Context_get_HasDynamicSinks_m3952434387 ();
extern "C" void Context_get_HasExitSinks_m408916482 ();
extern "C" void Context_get_HasGlobalDynamicSinks_m3672814609 ();
extern "C" void Context_get_IsDefaultContext_m588840058 ();
extern "C" void Context_get_NeedsContextSink_m2822465981 ();
extern "C" void ContextAttribute_Equals_m614768756 ();
extern "C" void ContextAttribute_IsContextOK_m1726359618 ();
extern "C" void ContextAttribute_IsNewContextOK_m2778900898 ();
extern "C" void DynamicPropertyCollection_RegisterDynamicProperty_m3950689041 ();
extern "C" void DynamicPropertyCollection_UnregisterDynamicProperty_m3435802631 ();
extern "C" void DynamicPropertyCollection_get_HasProperties_m4067429750 ();
extern "C" void SynchronizationAttribute_IsContextOK_m324067792 ();
extern "C" void SynchronizationAttribute_get_IsReEntrant_m3503478049 ();
extern "C" void Identity_get_Disposed_m2663903683 ();
extern "C" void Identity_get_HasServerDynamicSinks_m2759301415 ();
extern "C" void Identity_get_IsConnected_m2848760353 ();
extern "C" void AsyncResult_get_CompletedSynchronously_m3353049627 ();
extern "C" void AsyncResult_get_EndInvokeCalled_m3770405353 ();
extern "C" void AsyncResult_get_IsCompleted_m2089788488 ();
extern "C" void CADMessageBase_IsPossibleToIgnoreMarshal_m817717449 ();
extern "C" void ConstructionCall_get_IsContextOk_m2782950412 ();
extern "C" void LogicalCallContext_get_HasInfo_m3847716861 ();
extern "C" void DictionaryEnumerator_MoveNext_m1462973125 ();
extern "C" void MethodDictionary_IsOverridenKey_m946843558 ();
extern "C" void MethodDictionary_get_HasInternalProperties_m1604426346 ();
extern "C" void SoapAttribute_get_UseAttribute_m3866369531 ();
extern "C" void SoapFieldAttribute_IsInteropXmlElement_m2819415462 ();
extern "C" void SoapMethodAttribute_get_UseAttribute_m1147780171 ();
extern "C" void SoapTypeAttribute_get_IsInteropXmlElement_m3413949955 ();
extern "C" void SoapTypeAttribute_get_IsInteropXmlType_m629667929 ();
extern "C" void SoapTypeAttribute_get_UseAttribute_m3046604208 ();
extern "C" void ObjRef_get_IsReferenceToWellKnow_m3951611746 ();
extern "C" void ProxyAttribute_IsContextOK_m1572386839 ();
extern "C" void RemotingConfiguration_CustomErrorsEnabled_m646255533 ();
extern "C" void RemotingConfiguration_IsActivationAllowed_m1504757950 ();
extern "C" void RemotingServices_IsMethodOverloaded_m3262659413 ();
extern "C" void RemotingServices_IsOneWay_m1772807839 ();
extern "C" void RemotingServices_IsTransparentProxy_m1535738947 ();
extern "C" void SoapServices_GetXmlElementForInteropType_m1310850578 ();
extern "C" void SoapServices_GetXmlTypeForInteropType_m226269097 ();
extern "C" void BaseFixupRecord_DoFixup_m1407429548 ();
extern "C" void FormatterConverter_ToBoolean_m1680758923 ();
extern "C" void BinaryCommon_IsPrimitive_m378904036 ();
extern "C" void ClrTypeMetadata_get_RequiresTypes_m1619438370 ();
extern "C" void MessageFormatter_AllTypesArePrimitive_m3953742542 ();
extern "C" void MessageFormatter_IsInternalKey_m3679497458 ();
extern "C" void MessageFormatter_IsMethodPrimitive_m2805243043 ();
extern "C" void ObjectReader_ReadNextObject_m2150937777 ();
extern "C" void ObjectReader_ReadNextObject_m1498077612 ();
extern "C" void SerializableTypeMetadata_IsCompatible_m3569756077 ();
extern "C" void SerializableTypeMetadata_get_RequiresTypes_m556665051 ();
extern "C" void TypeMetadata_IsCompatible_m3213233239 ();
extern "C" void ObjectRecord_DoFixups_m1169675535 ();
extern "C" void ObjectRecord_LoadData_m1119843494 ();
extern "C" void ObjectRecord_get_HasPendingFixups_m1177656782 ();
extern "C" void ObjectRecord_get_IsInstanceReady_m2304516395 ();
extern "C" void ObjectRecord_get_IsRegistered_m1980446745 ();
extern "C" void ObjectRecord_get_IsUnsolvedObjectReference_m1163921033 ();
extern "C" void SerializationCallbacks_get_HasDeserializedCallbacks_m989630968 ();
extern "C" void SerializationCallbacks_get_HasSerializedCallbacks_m104160818 ();
extern "C" void SerializationInfo_GetBoolean_m1756153320 ();
extern "C" void SerializationInfoEnumerator_MoveNext_m2496151825 ();
extern "C" void StreamingContext_Equals_m2722903674_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_Equals_m4012367076_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_Equals_m3301340296_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_Equals_m2857439487_AdjustorThunk ();
extern "C" void SByte_Equals_m865896384_AdjustorThunk ();
extern "C" void SByte_Equals_m3032561558_AdjustorThunk ();
extern "C" void SByte_Parse_m3630846728 ();
extern "C" void SByte_System_IConvertible_ToBoolean_m3272910093_AdjustorThunk ();
extern "C" void SByte_TryParse_m2431806379 ();
extern "C" void CodeAccessPermission_Equals_m1555575992 ();
extern "C" void DES_IsSemiWeakKey_m2495136119 ();
extern "C" void DES_IsWeakKey_m1784515364 ();
extern "C" void DSACryptoServiceProvider_VerifySignature_m2080101421 ();
extern "C" void DSACryptoServiceProvider_get_PublicOnly_m3933928860 ();
extern "C" void DSASignatureDeformatter_VerifySignature_m4260177023 ();
extern "C" void HashAlgorithm_get_CanReuseTransform_m3278578776 ();
extern "C" void KeySizes_IsLegal_m2429848889 ();
extern "C" void KeySizes_IsLegalKeySize_m2571462035 ();
extern "C" void OidEnumerator_MoveNext_m3138911739 ();
extern "C" void RNGCryptoServiceProvider_RngOpen_m792795472 ();
extern "C" void RSACryptoServiceProvider_get_PublicOnly_m4039982639 ();
extern "C" void RSAPKCS1SignatureDeformatter_VerifySignature_m1810970621 ();
extern "C" void RijndaelManagedTransform_get_CanReuseTransform_m2604443164 ();
extern "C" void ToBase64Transform_get_CanReuseTransform_m702204640 ();
extern "C" void TripleDES_IsWeakKey_m2147489852 ();
extern "C" void X500DistinguishedName_AreEqual_m2828302026 ();
extern "C" void X509BasicConstraintsExtension_get_CertificateAuthority_m3360658367 ();
extern "C" void X509BasicConstraintsExtension_get_HasPathLengthConstraint_m2072837820 ();
extern "C" void X509Certificate2_Verify_m1464738766 ();
extern "C" void X509Certificate2Collection_Contains_m3300508662 ();
extern "C" void X509Certificate2Enumerator_MoveNext_m2220460870 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_MoveNext_m1563787129 ();
extern "C" void X509Certificate_Equals_m3784196370 ();
extern "C" void X509Certificate_Equals_m861530042 ();
extern "C" void X509CertificateEnumerator_MoveNext_m1557350766 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m1392570645 ();
extern "C" void X509Chain_Build_m1705729171 ();
extern "C" void X509Chain_IsChainComplete_m1577524584 ();
extern "C" void X509Chain_IsSelfIssued_m2588855382 ();
extern "C" void X509Chain_IsSignedWith_m2691255686 ();
extern "C" void X509Chain_ProcessCrlEntryExtensions_m3203112264 ();
extern "C" void X509Chain_ProcessCrlExtensions_m236234529 ();
extern "C" void X509ChainElementCollection_Contains_m2924813355 ();
extern "C" void X509ChainElementEnumerator_MoveNext_m3940594045 ();
extern "C" void X509Extension_get_Critical_m1315280133 ();
extern "C" void X509ExtensionEnumerator_MoveNext_m3077762850 ();
extern "C" void SecurityPermission_IsEmpty_m2033068359 ();
extern "C" void SecurityPermission_IsSubsetOf_m545000671 ();
extern "C" void SecurityPermission_IsUnrestricted_m3327262311 ();
extern "C" void StrongNamePublicKeyBlob_Equals_m3655422942 ();
extern "C" void EvidenceEnumerator_MoveNext_m183460296 ();
extern "C" void Evidence_Equals_m1478353107 ();
extern "C" void StrongName_Equals_m384811149 ();
extern "C" void SecurityContext_get_FlowSuppressed_m1627541854 ();
extern "C" void SecurityElement_IsValidAttributeName_m713904709 ();
extern "C" void SecurityElement_IsValidAttributeValue_m948345692 ();
extern "C" void SecurityElement_IsValidTag_m1803475254 ();
extern "C" void SecurityElement_IsValidText_m1346599242 ();
extern "C" void SecurityManager_get_SecurityEnabled_m3467182822 ();
extern "C" void Single_Equals_m438106747_AdjustorThunk ();
extern "C" void Single_Equals_m1601893879_AdjustorThunk ();
extern "C" void Single_IsInfinity_m936314085 ();
extern "C" void Single_IsNaN_m4024467661 ();
extern "C" void Single_IsNegativeInfinity_m1556741963 ();
extern "C" void Single_IsPositiveInfinity_m1411272350 ();
extern "C" void Single_System_IConvertible_ToBoolean_m1716619219_AdjustorThunk ();
extern "C" void String_EndsWith_m1901926500 ();
extern "C" void String_Equals_m1039194686 ();
extern "C" void String_Equals_m2270643605 ();
extern "C" void String_Equals_m1744302937 ();
extern "C" void String_IsNullOrEmpty_m2969720369 ();
extern "C" void String_StartsWith_m1759067526 ();
extern "C" void String_System_IConvertible_ToBoolean_m887520575 ();
extern "C" void String_op_Equality_m920492651 ();
extern "C" void String_op_Inequality_m215368492 ();
extern "C" void StringComparer_Equals_m1418565653 ();
extern "C" void DecoderExceptionFallback_Equals_m1082173956 ();
extern "C" void DecoderExceptionFallbackBuffer_Fallback_m3780167086 ();
extern "C" void DecoderReplacementFallback_Equals_m3183889441 ();
extern "C" void DecoderReplacementFallbackBuffer_Fallback_m1261056214 ();
extern "C" void EncoderExceptionFallback_Equals_m2760188920 ();
extern "C" void EncoderExceptionFallbackBuffer_Fallback_m2954286723 ();
extern "C" void EncoderExceptionFallbackBuffer_Fallback_m1464194819 ();
extern "C" void EncoderReplacementFallback_Equals_m1070129250 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m19060368 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m2728476550 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m3618896307 ();
extern "C" void Encoding_Equals_m1755424895 ();
extern "C" void Encoding_get_IsReadOnly_m3084286821 ();
extern "C" void CategoryUtils_IsCategory_m3604944547 ();
extern "C" void CategoryUtils_IsCategory_m278753792 ();
extern "C" void Key_Equals_m3074271967 ();
extern "C" void Group_get_Success_m3823591889 ();
extern "C" void RepeatContext_get_IsLazy_m2261224997 ();
extern "C" void RepeatContext_get_IsMaximum_m332552678 ();
extern "C" void RepeatContext_get_IsMinimum_m3640286252 ();
extern "C" void Interpreter_Balance_m1978770534 ();
extern "C" void Interpreter_Eval_m858596062 ();
extern "C" void Interpreter_EvalChar_m959577577 ();
extern "C" void Interpreter_IsPosition_m3326918850 ();
extern "C" void Interpreter_IsWordChar_m2858055765 ();
extern "C" void Interpreter_TryMatch_m2615355060 ();
extern "C" void Interval_Contains_m110351300_AdjustorThunk ();
extern "C" void Interval_Contains_m1454846757_AdjustorThunk ();
extern "C" void Interval_Intersects_m525534288_AdjustorThunk ();
extern "C" void Interval_IsAdjacent_m3021964761_AdjustorThunk ();
extern "C" void Interval_IsDisjoint_m1532171337_AdjustorThunk ();
extern "C" void Interval_get_IsDiscontiguous_m3016063288_AdjustorThunk ();
extern "C" void Interval_get_IsEmpty_m2731597232_AdjustorThunk ();
extern "C" void Interval_get_IsSingleton_m3386290029_AdjustorThunk ();
extern "C" void Enumerator_MoveNext_m55255603 ();
extern "C" void LinkStack_Pop_m4048583474 ();
extern "C" void Mark_get_IsDefined_m2539660708_AdjustorThunk ();
extern "C" void Enumerator_System_Collections_IEnumerator_MoveNext_m3182190557 ();
extern "C" void MatchCollection_TryToGet_m1813945069 ();
extern "C" void Regex_IsMatch_m4067478295 ();
extern "C" void Regex_IsMatch_m2113092601 ();
extern "C" void Regex_get_RightToLeft_m2317867572 ();
extern "C" void AnchorInfo_get_IgnoreCase_m4084905689 ();
extern "C" void AnchorInfo_get_IsComplete_m4053892818 ();
extern "C" void AnchorInfo_get_IsPosition_m2100552190 ();
extern "C" void AnchorInfo_get_IsSubstring_m1536110387 ();
extern "C" void AnchorInfo_get_IsUnknownWidth_m830883035 ();
extern "C" void BackslashNumber_ResolveReference_m4176908213 ();
extern "C" void CaptureAssertion_IsComplex_m237493585 ();
extern "C" void CapturingGroup_IsComplex_m4061114763 ();
extern "C" void CapturingGroup_get_IsNamed_m570289083 ();
extern "C" void CharacterClass_IsComplex_m1490839133 ();
extern "C" void CompositeExpression_IsComplex_m2236888323 ();
extern "C" void ExpressionAssertion_IsComplex_m2085675212 ();
extern "C" void Literal_IsComplex_m4067122560 ();
extern "C" void NonBacktrackingGroup_IsComplex_m823336948 ();
extern "C" void Parser_IsECMAScript_m674158805 ();
extern "C" void Parser_IsExplicitCapture_m2741347241 ();
extern "C" void Parser_IsIgnoreCase_m2210120858 ();
extern "C" void Parser_IsIgnorePatternWhitespace_m2107132682 ();
extern "C" void Parser_IsMultiline_m3953355516 ();
extern "C" void Parser_IsNameChar_m698176442 ();
extern "C" void Parser_IsSingleline_m326238187 ();
extern "C" void Parser_ParseAssertionType_m2403454228 ();
extern "C" void Parser_ParseRepetitionBounds_m1246581246 ();
extern "C" void PositionAssertion_IsComplex_m3339056668 ();
extern "C" void Reference_IsComplex_m3000063927 ();
extern "C" void Reference_get_IgnoreCase_m241264953 ();
extern "C" void UTF32Encoding_Equals_m2278544394 ();
extern "C" void UTF7Encoding_Equals_m227704363 ();
extern "C" void UTF8Encoding_Equals_m3216333608 ();
extern "C" void UnicodeEncoding_Equals_m701742893 ();
extern "C" void CompressedStack_IsEmpty_m1305135551 ();
extern "C" void EventWaitHandle_IsManualReset_m3553816275 ();
extern "C" void EventWaitHandle_Reset_m3348053200 ();
extern "C" void EventWaitHandle_Set_m2445193251 ();
extern "C" void ExecutionContext_IsFlowSuppressed_m1061993478 ();
extern "C" void ExecutionContext_get_FlowSuppressed_m3684775418 ();
extern "C" void Monitor_Monitor_test_synchronised_m517272294 ();
extern "C" void Monitor_Monitor_wait_m3706677354 ();
extern "C" void Monitor_Wait_m1121125180 ();
extern "C" void Mutex_ReleaseMutex_internal_m1411299633 ();
extern "C" void NativeEventCalls_ResetEvent_internal_m885886540 ();
extern "C" void NativeEventCalls_SetEvent_internal_m4068607488 ();
extern "C" void ThreadPool_QueueUserWorkItem_m1526970260 ();
extern "C" void Timer_Change_m3939852749 ();
extern "C" void Timer_Change_m3724315326 ();
extern "C" void WaitHandle_WaitOne_m2659830932 ();
extern "C" void WaitHandle_WaitOne_m2577152516 ();
extern "C" void WaitHandle_WaitOne_internal_m3849881646 ();
extern "C" void TimeSpan_Equals_m45505612_AdjustorThunk ();
extern "C" void TimeSpan_Equals_m3956248018_AdjustorThunk ();
extern "C" void TimeSpan_op_Equality_m1999885032 ();
extern "C" void TimeSpan_op_GreaterThan_m734703194 ();
extern "C" void TimeSpan_op_GreaterThanOrEqual_m3604983771 ();
extern "C" void TimeSpan_op_Inequality_m2467851530 ();
extern "C" void TimeSpan_op_LessThan_m1594498345 ();
extern "C" void TimeSpan_op_LessThanOrEqual_m300470010 ();
extern "C" void TimeZone_IsDaylightSavingTime_m2508743323 ();
extern "C" void TimeZone_IsDaylightSavingTime_m3100698649 ();
extern "C" void Type_Equals_m1673304139 ();
extern "C" void Type_Equals_m709225487 ();
extern "C" void Type_EqualsInternal_m3027143100 ();
extern "C" void Type_FilterAttribute_impl_m2354619618 ();
extern "C" void Type_FilterNameIgnoreCase_impl_m626688405 ();
extern "C" void Type_FilterName_impl_m2651733559 ();
extern "C" void Type_IsArrayImpl_m2757480859 ();
extern "C" void Type_IsAssignableFrom_m3195021585 ();
extern "C" void Type_IsContextfulImpl_m3693603908 ();
extern "C" void Type_IsInstanceOfType_m2427069822 ();
extern "C" void Type_IsMarshalByRefImpl_m914778231 ();
extern "C" void Type_IsSubclassOf_m527829736 ();
extern "C" void Type_IsValueTypeImpl_m3263052508 ();
extern "C" void Type_get_ContainsGenericParameters_m3456799426 ();
extern "C" void Type_get_HasElementType_m710151977 ();
extern "C" void Type_get_IsAbstract_m1120089130 ();
extern "C" void Type_get_IsArray_m2591212821 ();
extern "C" void Type_get_IsByRef_m1262524108 ();
extern "C" void Type_get_IsClass_m589177581 ();
extern "C" void Type_get_IsContextful_m1494289047 ();
extern "C" void Type_get_IsEnum_m208091508 ();
extern "C" void Type_get_IsExplicitLayout_m1182254884 ();
extern "C" void Type_get_IsGenericParameter_m2240142090 ();
extern "C" void Type_get_IsGenericType_m3396650057 ();
extern "C" void Type_get_IsGenericTypeDefinition_m1202066969 ();
extern "C" void Type_get_IsInterface_m3284996719 ();
extern "C" void Type_get_IsMarshalByRef_m1681525688 ();
extern "C" void Type_get_IsNested_m3546087448 ();
extern "C" void Type_get_IsPointer_m4067542339 ();
extern "C" void Type_get_IsPrimitive_m1114712797 ();
extern "C" void Type_get_IsSealed_m3543837727 ();
extern "C" void Type_get_IsSerializable_m1040556850 ();
extern "C" void Type_get_IsSystemType_m624798880 ();
extern "C" void Type_get_IsUserType_m555861786 ();
extern "C" void Type_get_IsValueType_m3108065642 ();
extern "C" void Type_type_is_assignable_from_m76737532 ();
extern "C" void Type_type_is_subtype_of_m1406623598 ();
extern "C" void TypedReference_Equals_m2034077850_AdjustorThunk ();
extern "C" void UInt16_Equals_m642257745_AdjustorThunk ();
extern "C" void UInt16_Equals_m3755275785_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToBoolean_m3911119012_AdjustorThunk ();
extern "C" void UInt16_TryParse_m3193697465 ();
extern "C" void UInt16_TryParse_m4139137016 ();
extern "C" void UInt32_Equals_m351935437_AdjustorThunk ();
extern "C" void UInt32_Equals_m4250336581_AdjustorThunk ();
extern "C" void UInt32_Parse_m197815874 ();
extern "C" void UInt32_Parse_m2778221109 ();
extern "C" void UInt32_System_IConvertible_ToBoolean_m1763673183_AdjustorThunk ();
extern "C" void UInt32_TryParse_m535404612 ();
extern "C" void UInt32_TryParse_m2819179361 ();
extern "C" void UInt64_Equals_m1879425698_AdjustorThunk ();
extern "C" void UInt64_Equals_m367573732_AdjustorThunk ();
extern "C" void UInt64_Parse_m2329819578 ();
extern "C" void UInt64_System_IConvertible_ToBoolean_m3071416000_AdjustorThunk ();
extern "C" void UInt64_TryParse_m2263420204 ();
extern "C" void UIntPtr_Equals_m1316671746_AdjustorThunk ();
extern "C" void UnhandledExceptionEventArgs_get_IsTerminating_m4073714616 ();
extern "C" void Uri_CheckSchemeName_m108657675 ();
extern "C" void Uri_CompactEscaped_m2984961597 ();
extern "C" void Uri_Equals_m3263316701 ();
extern "C" void Uri_InternalEquals_m2029068366 ();
extern "C" void Uri_IsAlpha_m1282293464 ();
extern "C" void Uri_IsDomainAddress_m2867513594 ();
extern "C" void Uri_IsHexDigit_m3389749670 ();
extern "C" void Uri_IsHexEncoding_m3290929897 ();
extern "C" void Uri_IsIPv4Address_m3535481943 ();
extern "C" void Uri_IsPredefinedScheme_m1188665625 ();
extern "C" void Uri_get_IsAbsoluteUri_m3666899587 ();
extern "C" void Uri_get_IsFile_m2450018824 ();
extern "C" void Uri_get_IsLoopback_m2492530169 ();
extern "C" void Uri_get_IsUnc_m2977972311 ();
extern "C" void Uri_op_Equality_m685520154 ();
extern "C" void ValueType_DefaultEquals_m2927252100 ();
extern "C" void ValueType_Equals_m1524437845 ();
extern "C" void ValueType_InternalEquals_m1384040357 ();
extern "C" void Version_Equals_m3073813696 ();
extern "C" void Version_Equals_m1564427710 ();
extern "C" void Version_op_Equality_m3804852517 ();
extern "C" void Version_op_Inequality_m1696193441 ();
extern "C" void WeakReference_get_TrackResurrection_m942701017 ();
extern "C" void AnalyticsEvent_get_debugMode_m2240954048 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0_MoveNext_m825792986 ();
extern "C" void CustomEventData_AddBool_m1904653514 ();
extern "C" void CustomEventData_AddDictionary_m266566478 ();
extern "C" void CustomEventData_AddDouble_m631895201 ();
extern "C" void CustomEventData_AddInt32_m548429697 ();
extern "C" void CustomEventData_AddInt64_m3934322106 ();
extern "C" void CustomEventData_AddString_m1770058667 ();
extern "C" void CustomEventData_AddUInt32_m4102684736 ();
extern "C" void CustomEventData_AddUInt64_m725801310 ();
extern "C" void EventTrigger_Test_m2021527001 ();
extern "C" void StandardEventPayload_IsCustomDataValid_m922891381 ();
extern "C" void StandardEventPayload_IsRequiredDataValid_m361738930 ();
extern "C" void FieldWithTarget_get_doStatic_m1956244749 ();
extern "C" void TriggerRule_SafeEquals_m2862813043 ();
extern "C" void TriggerRule_Test_m2595382785 ();
extern "C" void TriggerRule_Test_m3134988565 ();
extern "C" void TriggerRule_TestByBool_m4144604729 ();
extern "C" void TriggerRule_TestByDouble_m960810189 ();
extern "C" void TriggerRule_TestByEnum_m2798194165 ();
extern "C" void TriggerRule_TestByObject_m3099447300 ();
extern "C" void TriggerRule_TestByString_m2890887363 ();
extern "C" void UnityAnalyticsHandler_IsInitialized_m2620746640 ();
extern "C" void ValueProperty_IsValid_m3724034537 ();
extern "C" void Application_Internal_ApplicationWantsToQuit_m2059931957 ();
extern "C" void AttributeHelperEngine_CheckIsEditorScript_m705968799 ();
extern "C" void AudioClipPlayable_Equals_m3705880618_AdjustorThunk ();
extern "C" void AudioMixerPlayable_Equals_m1649866213_AdjustorThunk ();
extern "C" void AudioClip_get_ambisonic_m3815052287 ();
extern "C" void AudioSource_get_isPlaying_m1896551654 ();
extern "C" void AudioSource_get_spatialize_m3609701298 ();
extern "C" void AudioSource_get_spatializeInternal_m2117549793 ();
extern "C" void Behaviour_get_enabled_m753527255 ();
extern "C" void Cubemap_Internal_CreateImpl_m2853780628 ();
extern "C" void ArgumentCache_get_boolArgument_m2277082935 ();
extern "C" void BaseInvokableCall_AllowInvoke_m878393606 ();
extern "C" void InvokableCall_Find_m1300374869 ();
extern "C" void PersistentCall_IsValid_m2325196163 ();
extern "C" void CameraPlayable_Equals_m4009879053_AdjustorThunk ();
extern "C" void MaterialEffectPlayable_Equals_m3750885802_AdjustorThunk ();
extern "C" void TextureMixerPlayable_Equals_m1074187513_AdjustorThunk ();
extern "C" void GraphicsFormatUtility_IsCrunchFormat_m1697721778 ();
extern "C" void GraphicsFormatUtility_IsSRGBFormat_m3893170616 ();
extern "C" void SupportedRenderingFeatures_IsLightmapBakeTypeSupported_m625512092 ();
extern "C" void SupportedRenderingFeatures_IsMixedLightingModeSupported_m1976902692 ();
extern "C" void Input_GetMouseButton_m513753021 ();
extern "C" void Input_GetMouseButtonDown_m2081676745 ();
extern "C" void DefaultValueAttribute_Equals_m443523471 ();
extern "C" void Logger_IsLogTypeAllowed_m3527674834 ();
extern "C" void Logger_get_logEnabled_m3154120769 ();
extern "C" void Mathf_Approximately_m245805902 ();
extern "C" void MonoBehaviour_Internal_IsInvokingAll_m2820042090 ();
extern "C" void MonoBehaviour_IsInvoking_m3949123101 ();
extern "C" void MonoBehaviour_IsInvoking_m1028838749 ();
extern "C" void MonoBehaviour_IsInvoking_m3285132449 ();
extern "C" void MonoBehaviour_IsObjectMonoBehaviour_m2134950949 ();
extern "C" void MonoBehaviour_get_useGUILayout_m2803119319 ();
extern "C" void CertificateHandler_ValidateCertificate_m937187171 ();
extern "C" void CertificateHandler_ValidateCertificateNative_m2315002656 ();
extern "C" void U3CRegisterU3Ec__AnonStorey0_U3CU3Em__0_m491998414 ();
extern "C" void U3CUnregisterU3Ec__AnonStorey1_U3CU3Em__0_m1122526650 ();
extern "C" void PlayerConnection_BlockUntilRecvMsg_m1369178756 ();
extern "C" void PlayerConnection_get_isConnected_m911966057 ();
extern "C" void U3CAddAndCreateU3Ec__AnonStorey1_U3CU3Em__0_m2847856411 ();
extern "C" void U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_U3CU3Em__0_m444206473 ();
extern "C" void U3CUnregisterManagedCallbackU3Ec__AnonStorey2_U3CU3Em__0_m4104626642 ();
extern "C" void Object_CompareBaseObjects_m2405226032 ();
extern "C" void Object_Equals_m4262027856 ();
extern "C" void Object_IsNativeObjectAlive_m3095908075 ();
extern "C" void Object_op_Equality_m1810815630 ();
extern "C" void Object_op_Implicit_m3574996620 ();
extern "C" void Object_op_Inequality_m4071470834 ();
extern "C" void Playable_Equals_m328753404_AdjustorThunk ();
extern "C" void PlayableHandle_CompareVersion_m2748798983 ();
extern "C" void PlayableHandle_Equals_m1666612586_AdjustorThunk ();
extern "C" void PlayableHandle_Equals_m2546735654_AdjustorThunk ();
extern "C" void PlayableHandle_op_Equality_m3344837515 ();
extern "C" void PlayableOutput_Equals_m3146274716_AdjustorThunk ();
extern "C" void PlayableOutputHandle_CompareVersion_m841260813 ();
extern "C" void PlayableOutputHandle_Equals_m334596297_AdjustorThunk ();
extern "C" void PlayableOutputHandle_Equals_m2815498676_AdjustorThunk ();
extern "C" void PlayableOutputHandle_op_Equality_m388301694 ();
extern "C" void PlayerConnectionInternal_IsConnected_m1260708709 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_IsConnected_m2695194553 ();
extern "C" void PropertyName_Equals_m2608649819_AdjustorThunk ();
extern "C" void PropertyName_Equals_m3623975820_AdjustorThunk ();
extern "C" void PropertyName_op_Equality_m2761233272 ();
extern "C" void Quaternion_Equals_m1863659319_AdjustorThunk ();
extern "C" void Quaternion_Equals_m2038868948_AdjustorThunk ();
extern "C" void Rect_Contains_m1232228501_AdjustorThunk ();
extern "C" void Rect_Equals_m4169342960_AdjustorThunk ();
extern "C" void Rect_Equals_m3951234117_AdjustorThunk ();
extern "C" void Scene_Equals_m581999093_AdjustorThunk ();
extern "C" void HitInfo_Compare_m2336739674 ();
extern "C" void HitInfo_op_Implicit_m665224877 ();
extern "C" void GameCenterPlatform_GetAuthenticated_m3482613734 ();
extern "C" void GameCenterPlatform_GetIsUnderage_m1283642296 ();
extern "C" void GameCenterPlatform_GetLoading_m3528572516 ();
extern "C" void GameCenterPlatform_VerifyAuthentication_m3694658262 ();
extern "C" void GcLeaderboard_Contains_m3398117473 ();
extern "C" void GcLeaderboard_GcLeaderboard_Loading_m3170934238 ();
extern "C" void GcLeaderboard_Loading_m224610944 ();
extern "C" void Achievement_get_completed_m1377700980 ();
extern "C" void Achievement_get_hidden_m4063998500 ();
extern "C" void AchievementDescription_get_hidden_m1497330198 ();
extern "C" void LocalUser_get_authenticated_m385074490 ();
extern "C" void UserProfile_get_isFriend_m3838691482 ();
extern "C" void StackTraceUtility_IsSystemStacktraceType_m299828041 ();
extern "C" void SystemInfo_IsFormatSupported_m1855899386 ();
extern "C" void Texture2D_Internal_CreateImpl_m110138258 ();
extern "C" void Texture2DArray_Internal_CreateImpl_m1122945648 ();
extern "C" void Texture3D_Internal_CreateImpl_m1882516456 ();
extern "C" void Texture_ValidateFormat_m3925257631 ();
extern "C" void Enumerator_MoveNext_m4275888254 ();
extern "C" void SpriteAtlasManager_RequestAtlas_m455709951 ();
extern "C" void Vector2_Equals_m832062989_AdjustorThunk ();
extern "C" void Vector2_Equals_m1313188271_AdjustorThunk ();
extern "C" void Vector3_Equals_m1753054704_AdjustorThunk ();
extern "C" void Vector3_Equals_m906392898_AdjustorThunk ();
extern "C" void Vector3_op_Equality_m4231250055 ();
extern "C" void Vector3_op_Inequality_m315980366 ();
extern "C" void MSCompatUnicodeTable_Category_m1834196420 ();
extern "C" void MSCompatUnicodeTable_Level1_m18730923 ();
extern "C" void MSCompatUnicodeTable_Level2_m3823292331 ();
extern "C" void MSCompatUnicodeTable_Level3_m1870873670 ();
extern "C" void SimpleCollator_Category_m119590608 ();
extern "C" void SimpleCollator_Level1_m634954506 ();
extern "C" void SimpleCollator_Level2_m2830638875 ();
extern "C" void SimpleCollator_ToDashTypeValue_m6184468 ();
extern "C" void ASN1_get_Tag_m1032367219 ();
extern "C" void ASN1_get_Tag_m2789147236 ();
extern "C" void CipherSuite_get_ExpandedKeyMaterialSize_m197590106 ();
extern "C" void CipherSuite_get_IvSize_m630778063 ();
extern "C" void CipherSuite_get_KeyMaterialSize_m3569550689 ();
extern "C" void TlsStream_ReadByte_m3396126844 ();
extern "C" void Boolean_System_IConvertible_ToByte_m3917074947_AdjustorThunk ();
extern "C" void Byte_Parse_m678312347 ();
extern "C" void Byte_Parse_m3200377149 ();
extern "C" void Byte_Parse_m2607942050 ();
extern "C" void Byte_System_IConvertible_ToByte_m162267264_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToByte_m2347554595_AdjustorThunk ();
extern "C" void BitArray_getByte_m2467886923 ();
extern "C" void Convert_ToByte_m306367912 ();
extern "C" void Convert_ToByte_m143827699 ();
extern "C" void Convert_ToByte_m4214436835 ();
extern "C" void Convert_ToByte_m3824130483 ();
extern "C" void Convert_ToByte_m1336644845 ();
extern "C" void Convert_ToByte_m1734770211 ();
extern "C" void Convert_ToByte_m2122266396 ();
extern "C" void Convert_ToByte_m3527805587 ();
extern "C" void Convert_ToByte_m1442000130 ();
extern "C" void Convert_ToByte_m4146281512 ();
extern "C" void Convert_ToByte_m1779682469 ();
extern "C" void Convert_ToByte_m3367409178 ();
extern "C" void Convert_ToByte_m2375887898 ();
extern "C" void Convert_ToByte_m1993550870 ();
extern "C" void Convert_ToByte_m3567528984 ();
extern "C" void DBNull_System_IConvertible_ToByte_m3625770190 ();
extern "C" void DateTime_System_IConvertible_ToByte_m3025810066_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToByte_m1059182322_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m2848387298 ();
extern "C" void Double_System_IConvertible_ToByte_m410894149_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToByte_m1219166845 ();
extern "C" void BinaryReader_ReadByte_m2842288049 ();
extern "C" void Int16_System_IConvertible_ToByte_m3161982419_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToByte_m3832391412_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToByte_m375085029_AdjustorThunk ();
extern "C" void Marshal_ReadByte_m1960935664 ();
extern "C" void BinaryCommon_GetTypeCode_m448697888 ();
extern "C" void SByte_System_IConvertible_ToByte_m2268214252_AdjustorThunk ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHexChar_m1249358531 ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHexChars_m3244835916 ();
extern "C" void Single_System_IConvertible_ToByte_m997362015_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToByte_m4057316234 ();
extern "C" void UInt16_System_IConvertible_ToByte_m3185614807_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToByte_m4072781199_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToByte_m1501504925_AdjustorThunk ();
extern "C" void BigInteger_GetBytes_m1259701831 ();
extern "C" void BigInteger_GetBytes_m997192583 ();
extern "C" void ASN1_GetBytes_m3305539297 ();
extern "C" void ASN1_GetBytes_m1968380955 ();
extern "C" void ASN1_get_Value_m63296490 ();
extern "C" void ASN1_get_Value_m1857007406 ();
extern "C" void BitConverterLE_GetBytes_m3350143782 ();
extern "C" void BitConverterLE_GetBytes_m4130646282 ();
extern "C" void BitConverterLE_GetBytes_m3268825786 ();
extern "C" void BitConverterLE_GetBytes_m2590852453 ();
extern "C" void BitConverterLE_GetUIntBytes_m949779219 ();
extern "C" void BitConverterLE_GetUIntBytes_m795219058 ();
extern "C" void BitConverterLE_GetULongBytes_m1393773100 ();
extern "C" void ARC4Managed_TransformFinalBlock_m2223084380 ();
extern "C" void ARC4Managed_get_Key_m2476146969 ();
extern "C" void BlockProcessor_Final_m3350443194 ();
extern "C" void CryptoConvert_GetBytesLE_m3076458968 ();
extern "C" void CryptoConvert_ToCapiKeyBlob_m3371450375 ();
extern "C" void CryptoConvert_ToCapiPrivateKeyBlob_m2502515575 ();
extern "C" void CryptoConvert_ToCapiPublicKeyBlob_m1931330842 ();
extern "C" void CryptoConvert_Trim_m3900804798 ();
extern "C" void DSAManaged_CreateSignature_m2233977444 ();
extern "C" void DSAManaged_NormalizeArray_m3285505169 ();
extern "C" void HMAC_HashFinal_m1453827676 ();
extern "C" void HMAC_get_Key_m1410673610 ();
extern "C" void KeyBuilder_IV_m3340234014 ();
extern "C" void KeyBuilder_IV_m2230195376 ();
extern "C" void KeyBuilder_Key_m2503211157 ();
extern "C" void KeyBuilder_Key_m1482371611 ();
extern "C" void KeyBuilder_Key_m876696100 ();
extern "C" void MACAlgorithm_Final_m3756738689 ();
extern "C" void MD2Managed_HashFinal_m808964912 ();
extern "C" void MD2Managed_Padding_m1334210368 ();
extern "C" void MD4Managed_HashFinal_m3850238392 ();
extern "C" void MD4Managed_Padding_m3091724296 ();
extern "C" void MD5SHA1_CreateSignature_m3583449066 ();
extern "C" void MD5SHA1_HashFinal_m4115488658 ();
extern "C" void PKCS1_Encode_v15_m3116793121 ();
extern "C" void PKCS1_Encode_v15_m2077073129 ();
extern "C" void PKCS1_Encrypt_v15_m1016948107 ();
extern "C" void PKCS1_I2OSP_m1314988212 ();
extern "C" void PKCS1_I2OSP_m2559784711 ();
extern "C" void PKCS1_OS2IP_m1443067185 ();
extern "C" void PKCS1_OS2IP_m65970018 ();
extern "C" void PKCS1_RSAEP_m594928261 ();
extern "C" void PKCS1_RSASP1_m3912327535 ();
extern "C" void PKCS1_RSASP1_m4286349561 ();
extern "C" void PKCS1_RSAVP1_m43771175 ();
extern "C" void PKCS1_RSAVP1_m2014482508 ();
extern "C" void PKCS1_Sign_v15_m3459793192 ();
extern "C" void PKCS1_Sign_v15_m2719206817 ();
extern "C" void EncryptedPrivateKeyInfo_get_EncryptedData_m491452551 ();
extern "C" void EncryptedPrivateKeyInfo_get_EncryptedData_m1695265614 ();
extern "C" void EncryptedPrivateKeyInfo_get_Salt_m1261804721 ();
extern "C" void EncryptedPrivateKeyInfo_get_Salt_m3453455261 ();
extern "C" void PrivateKeyInfo_Normalize_m2274647848 ();
extern "C" void PrivateKeyInfo_Normalize_m1855800471 ();
extern "C" void PrivateKeyInfo_RemoveLeadingZero_m3921889925 ();
extern "C" void PrivateKeyInfo_RemoveLeadingZero_m3592760008 ();
extern "C" void PrivateKeyInfo_get_PrivateKey_m3647771102 ();
extern "C" void PrivateKeyInfo_get_PrivateKey_m2768243057 ();
extern "C" void RC4_get_IV_m2290186270 ();
extern "C" void RSAManaged_DecryptValue_m1804388365 ();
extern "C" void RSAManaged_DecryptValue_m1864805746 ();
extern "C" void RSAManaged_EncryptValue_m4149543654 ();
extern "C" void RSAManaged_EncryptValue_m799827583 ();
extern "C" void RSAManaged_GetPaddedValue_m2182626630 ();
extern "C" void RSAManaged_GetPaddedValue_m2104792084 ();
extern "C" void SymmetricTransform_FinalDecrypt_m764004682 ();
extern "C" void SymmetricTransform_FinalDecrypt_m1677319445 ();
extern "C" void SymmetricTransform_FinalEncrypt_m748885414 ();
extern "C" void SymmetricTransform_FinalEncrypt_m69518647 ();
extern "C" void SymmetricTransform_TransformFinalBlock_m4059448527 ();
extern "C" void SymmetricTransform_TransformFinalBlock_m1030888689 ();
extern "C" void EncryptedData_get_EncryptedContent_m3205649670 ();
extern "C" void EncryptedData_get_EncryptedContent_m4211024111 ();
extern "C" void CipherSuite_CreatePremasterSecret_m4264566459 ();
extern "C" void CipherSuite_EncryptRecord_m4196378593 ();
extern "C" void CipherSuite_Expand_m2729769226 ();
extern "C" void CipherSuite_PRF_m2801806009 ();
extern "C" void ClientSessionCache_FromHost_m273325760 ();
extern "C" void ClientSessionInfo_get_Id_m2119140021 ();
extern "C" void Context_GetSecureRandomBytes_m3676009387 ();
extern "C" void Context_get_ClientRandom_m1437588520 ();
extern "C" void Context_get_ClientWriteIV_m1729804632 ();
extern "C" void Context_get_ClientWriteKey_m3174706656 ();
extern "C" void Context_get_MasterSecret_m676083615 ();
extern "C" void Context_get_RandomCS_m1367948315 ();
extern "C" void Context_get_RandomSC_m1891758699 ();
extern "C" void Context_get_ServerRandom_m2710024742 ();
extern "C" void Context_get_ServerWriteIV_m1839374659 ();
extern "C" void Context_get_ServerWriteKey_m2199131569 ();
extern "C" void Context_get_SessionId_m1086671147 ();
extern "C" void TlsClientCertificateVerify_getUnsignedBigInteger_m3003216819 ();
extern "C" void HandshakeMessage_EncodeMessage_m3919107786 ();
extern "C" void RSASslSignatureFormatter_CreateSignature_m2614788251 ();
extern "C" void ReceiveRecordAsyncResult_get_InitialBuffer_m2924495696 ();
extern "C" void ReceiveRecordAsyncResult_get_ResultingBuffer_m1839161335 ();
extern "C" void RecordProtocol_EncodeRecord_m164201598 ();
extern "C" void RecordProtocol_EncodeRecord_m3312835762 ();
extern "C" void RecordProtocol_EndReceiveRecord_m1872541318 ();
extern "C" void RecordProtocol_ReadClientHelloV2_m4052496367 ();
extern "C" void RecordProtocol_ReadRecordBuffer_m180543381 ();
extern "C" void RecordProtocol_ReadStandardRecordBuffer_m3738063864 ();
extern "C" void RecordProtocol_ReceiveRecord_m3797641756 ();
extern "C" void RecordProtocol_decryptRecordFragment_m66623237 ();
extern "C" void RecordProtocol_encryptRecordFragment_m710101985 ();
extern "C" void SecurityParameters_get_ClientWriteMAC_m225554750 ();
extern "C" void SecurityParameters_get_ServerWriteMAC_m3430427271 ();
extern "C" void SslCipherSuite_ComputeClientRecordMAC_m3756410489 ();
extern "C" void SslCipherSuite_ComputeServerRecordMAC_m1297079805 ();
extern "C" void SslCipherSuite_prf_m922878400 ();
extern "C" void SslHandshakeHash_CreateSignature_m1634235041 ();
extern "C" void SslHandshakeHash_HashFinal_m2573455475 ();
extern "C" void InternalAsyncResult_get_Buffer_m228115020 ();
extern "C" void TlsCipherSuite_ComputeClientRecordMAC_m886198623 ();
extern "C" void TlsCipherSuite_ComputeServerRecordMAC_m3941098609 ();
extern "C" void TlsStream_ReadBytes_m2334803179 ();
extern "C" void TlsStream_ReadSmallValue_m2559586275 ();
extern "C" void TlsStream_ToArray_m4177184296 ();
extern "C" void StrongName_get_PublicKey_m1841537984 ();
extern "C" void StrongName_get_PublicKeyToken_m2115276552 ();
extern "C" void AuthorityKeyIdentifierExtension_get_Identifier_m548598067 ();
extern "C" void DeriveBytes_Derive_m408582823 ();
extern "C" void DeriveBytes_Derive_m1232352666 ();
extern "C" void DeriveBytes_DeriveIV_m3639813821 ();
extern "C" void DeriveBytes_DeriveIV_m973925711 ();
extern "C" void DeriveBytes_DeriveKey_m2238010581 ();
extern "C" void DeriveBytes_DeriveKey_m2933043667 ();
extern "C" void DeriveBytes_DeriveMAC_m2121691743 ();
extern "C" void DeriveBytes_DeriveMAC_m694919248 ();
extern "C" void PKCS12_Decrypt_m3310864946 ();
extern "C" void PKCS12_Decrypt_m3441995779 ();
extern "C" void PKCS12_Decrypt_m2241300865 ();
extern "C" void PKCS12_Decrypt_m1280162536 ();
extern "C" void PKCS12_Encrypt_m2617413749 ();
extern "C" void PKCS12_Encrypt_m3618991685 ();
extern "C" void PKCS12_GetBytes_m415958948 ();
extern "C" void PKCS12_GetBytes_m3933153476 ();
extern "C" void PKCS12_MAC_m3401183837 ();
extern "C" void PKCS12_MAC_m3355614022 ();
extern "C" void X509Certificate_GetUnsignedBigInteger_m877462855 ();
extern "C" void X509Certificate_GetUnsignedBigInteger_m1025066663 ();
extern "C" void X509Certificate_PEM_m2020851166 ();
extern "C" void X509Certificate_PEM_m1177570576 ();
extern "C" void X509Certificate_get_Hash_m410033711 ();
extern "C" void X509Certificate_get_KeyAlgorithmParameters_m3698130868 ();
extern "C" void X509Certificate_get_KeyAlgorithmParameters_m681676289 ();
extern "C" void X509Certificate_get_PublicKey_m950835056 ();
extern "C" void X509Certificate_get_PublicKey_m1627137142 ();
extern "C" void X509Certificate_get_RawData_m2387471414 ();
extern "C" void X509Certificate_get_RawData_m2626675988 ();
extern "C" void X509Certificate_get_SerialNumber_m3924188880 ();
extern "C" void X509Certificate_get_Signature_m2498854864 ();
extern "C" void X509CrlEntry_get_SerialNumber_m3627212772 ();
extern "C" void X509Crl_get_Hash_m464217067 ();
extern "C" void X509Store_Load_m2048139132 ();
extern "C" void BitConverter_GetBytes_m2120707223 ();
extern "C" void BitConverter_GetBytes_m3693159656 ();
extern "C" void Convert_FromBase64String_m3685135396 ();
extern "C" void Convert_InternalFromBase64String_m918800179 ();
extern "C" void SortKey_get_KeyData_m3446923386 ();
extern "C" void Guid_FastNewGuidArray_m920913610 ();
extern "C" void BinaryReader_ReadBytes_m2025629328 ();
extern "C" void MemoryStream_GetBuffer_m1167568916 ();
extern "C" void MemoryStream_ToArray_m3911744835 ();
extern "C" void AssemblyName_ComputePublicKeyToken_m824893834 ();
extern "C" void AssemblyName_GetPublicKey_m1356287156 ();
extern "C" void AssemblyName_InternalGetPublicKeyToken_m3407918444 ();
extern "C" void AesManaged_get_IV_m118095902 ();
extern "C" void AesManaged_get_Key_m538801386 ();
extern "C" void AsnEncodedData_get_RawData_m1706087592 ();
extern "C" void AsymmetricAlgorithm_GetNamedParam_m2128682280 ();
extern "C" void CryptoConfig_EncodeLongNumber_m4127306320 ();
extern "C" void CryptoConfig_EncodeOID_m2635914623 ();
extern "C" void DES_get_Key_m3419790416 ();
extern "C" void DESTransform_GetStrongKey_m1464830895 ();
extern "C" void DSACryptoServiceProvider_CreateSignature_m267208648 ();
extern "C" void DSASignatureFormatter_CreateSignature_m3254505990 ();
extern "C" void HMAC_HashFinal_m1921180827 ();
extern "C" void HMAC_KeySetup_m661741544 ();
extern "C" void HMAC_get_Key_m623825087 ();
extern "C" void HashAlgorithm_ComputeHash_m2825542963 ();
extern "C" void HashAlgorithm_ComputeHash_m2044824070 ();
extern "C" void HashAlgorithm_TransformFinalBlock_m3005451348 ();
extern "C" void HashAlgorithm_get_Hash_m482540885 ();
extern "C" void KeyedHashAlgorithm_get_Key_m1843505301 ();
extern "C" void MACTripleDES_HashFinal_m3613553534 ();
extern "C" void MD5CryptoServiceProvider_HashFinal_m2625727830 ();
extern "C" void RIPEMD160Managed_HashFinal_m1016449914 ();
extern "C" void RSACryptoServiceProvider_DecryptValue_m3095079293 ();
extern "C" void RSACryptoServiceProvider_EncryptValue_m944137256 ();
extern "C" void RSAPKCS1KeyExchangeFormatter_CreateKeyExchange_m1611814432 ();
extern "C" void RSAPKCS1SignatureFormatter_CreateSignature_m3191980616 ();
extern "C" void RijndaelManagedTransform_TransformFinalBlock_m1454105523 ();
extern "C" void SHA1CryptoServiceProvider_HashFinal_m2727634713 ();
extern "C" void SHA1Internal_HashFinal_m1760803056 ();
extern "C" void SHA1Managed_HashFinal_m2365675383 ();
extern "C" void SHA256Managed_HashFinal_m2914312286 ();
extern "C" void SHA384Managed_HashFinal_m2401837128 ();
extern "C" void SHA512Managed_HashFinal_m2173184560 ();
extern "C" void SymmetricAlgorithm_get_IV_m1875559108 ();
extern "C" void SymmetricAlgorithm_get_Key_m3241860519 ();
extern "C" void ToBase64Transform_InternalTransformFinalBlock_m360524956 ();
extern "C" void ToBase64Transform_TransformFinalBlock_m2460017188 ();
extern "C" void TripleDES_get_Key_m1921822970 ();
extern "C" void TripleDESTransform_GetStrongKey_m292426577 ();
extern "C" void PublicKey_GetUnsignedBigInteger_m3873409673 ();
extern "C" void X509BasicConstraintsExtension_Encode_m2310708419 ();
extern "C" void X509Certificate_GetCertHash_m274210048 ();
extern "C" void X509Certificate_GetPublicKey_m4184729161 ();
extern "C" void X509Certificate_GetRawCertData_m781236105 ();
extern "C" void X509KeyUsageExtension_Encode_m2128077825 ();
extern "C" void X509SubjectKeyIdentifierExtension_Encode_m3345759265 ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHex_m1011249985 ();
extern "C" void Hash_GetData_m1957063775 ();
extern "C" void Encoding_GetBytes_m992709859 ();
extern "C" void Encoding_GetBytes_m3735967069 ();
extern "C" void Encoding_GetBytes_m3148649984 ();
extern "C" void Encoding_GetPreamble_m388603245 ();
extern "C" void UTF32Encoding_GetPreamble_m2844389005 ();
extern "C" void UTF8Encoding_GetPreamble_m1911470058 ();
extern "C" void UnicodeEncoding_GetPreamble_m3002287178 ();
extern "C" void Thread_GetSerializedCurrentCulture_m30188251 ();
extern "C" void Thread_GetSerializedCurrentUICulture_m3681656498 ();
extern "C" void Boolean_System_IConvertible_ToChar_m4279513009_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToChar_m2173687830_AdjustorThunk ();
extern "C" void Char_Parse_m82218915 ();
extern "C" void Char_System_IConvertible_ToChar_m3578899883_AdjustorThunk ();
extern "C" void Char_ToLower_m844856331 ();
extern "C" void Char_ToLower_m3999837485 ();
extern "C" void Char_ToLowerInvariant_m1926695830 ();
extern "C" void Char_ToUpper_m3999570441 ();
extern "C" void Char_ToUpperInvariant_m3658711221 ();
extern "C" void CharEnumerator_get_Current_m525608209 ();
extern "C" void Convert_ToChar_m2532412511 ();
extern "C" void Convert_ToChar_m2261593104 ();
extern "C" void Convert_ToChar_m4189066566 ();
extern "C" void Convert_ToChar_m4210014069 ();
extern "C" void Convert_ToChar_m3757390865 ();
extern "C" void Convert_ToChar_m3776556379 ();
extern "C" void Convert_ToChar_m2522572389 ();
extern "C" void Convert_ToChar_m1442101407 ();
extern "C" void Convert_ToChar_m3178343373 ();
extern "C" void Convert_ToChar_m2796006345 ();
extern "C" void Convert_ToChar_m1604365259 ();
extern "C" void DBNull_System_IConvertible_ToChar_m4140628367 ();
extern "C" void DateTime_System_IConvertible_ToChar_m197318076_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToChar_m2248324273_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToChar_m285688079_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToChar_m3901971946 ();
extern "C" void TextInfo_ToLower_m2744057472 ();
extern "C" void TextInfo_ToUpper_m4031511609 ();
extern "C" void Guid_ToHex_m2592644778 ();
extern "C" void BinaryReader_ReadChar_m3380594564 ();
extern "C" void MonoIO_get_AltDirectorySeparatorChar_m563952479 ();
extern "C" void MonoIO_get_DirectorySeparatorChar_m820086465 ();
extern "C" void MonoIO_get_PathSeparator_m4045322458 ();
extern "C" void MonoIO_get_VolumeSeparatorChar_m3246170182 ();
extern "C" void Int16_System_IConvertible_ToChar_m1265932681_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToChar_m2005926864_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToChar_m1509243576_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToChar_m1489191771_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToChar_m1898259383_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToChar_m863771412 ();
extern "C" void String_get_Chars_m2986988803 ();
extern "C" void DecoderExceptionFallbackBuffer_GetNextChar_m2067268124 ();
extern "C" void DecoderReplacementFallbackBuffer_GetNextChar_m2858228391 ();
extern "C" void EncoderExceptionFallbackBuffer_GetNextChar_m471453226 ();
extern "C" void EncoderReplacementFallbackBuffer_GetNextChar_m1303403587 ();
extern "C" void QuickSearch_GetChar_m1297698557 ();
extern "C" void StringBuilder_get_Chars_m1819843468 ();
extern "C" void UInt16_System_IConvertible_ToChar_m2096055221_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToChar_m1873050533_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToChar_m2074245892_AdjustorThunk ();
extern "C" void Uri_HexUnescapeMultiByte_m332853996 ();
extern "C" void Path_GetInvalidPathChars_m3959874485 ();
extern "C" void String_ToCharArray_m1492846834 ();
extern "C" void String_ToCharArray_m2268354229 ();
extern "C" void Encoding_GetChars_m1678858748 ();
extern "C" void ExtendedKeyUsageExtension_get_KeyPurpose_m187586919 ();
extern "C" void PKCS12_get_Keys_m3893933360 ();
extern "C" void X509Store_BuildCrlsCollection_m1991312527 ();
extern "C" void X509Store_get_Crls_m1211262034 ();
extern "C" void ArrayList_ReadOnly_m1905796817 ();
extern "C" void ArrayList_Synchronized_m1327684267 ();
extern "C" void CollectionBase_get_InnerList_m132195395 ();
extern "C" void ChannelData_get_ClientProviders_m594662942 ();
extern "C" void ChannelData_get_ServerProviders_m632481016 ();
extern "C" void CADMethodCallMessage_GetArguments_m3041854375 ();
extern "C" void CADMethodReturnMessage_GetArguments_m1470050566 ();
extern "C" void SerializationCallbacks_GetMethodsByAttribute_m2095490433 ();
extern "C" void Evidence_get_AssemblyEvidenceList_m632963901 ();
extern "C" void Evidence_get_HostEvidenceList_m2705108086 ();
extern "C" void SecurityElement_get_Children_m1231540612 ();
extern "C" void SecurityFrame_GetStack_m347707425 ();
extern "C" void CaseInsensitiveComparer_get_DefaultInvariant_m2155614047 ();
extern "C" void CaseInsensitiveHashCodeProvider_get_DefaultInvariant_m4264275163 ();
extern "C" void Enumerator_get_Entry_m2184304359 ();
extern "C" void Enumerator_get_Entry_m3561948123 ();
extern "C" void DictionaryNodeEnumerator_get_Entry_m2309234501 ();
extern "C" void ResourceEnumerator_get_Entry_m1508537883 ();
extern "C" void DictionaryEnumerator_get_Entry_m1635969600 ();
extern "C" void StandardEventPayload_GetParameters_m2672427676 ();
extern "C" void PlayableAsset_get_outputs_m2130546921 ();
extern "C" void String_System_Collections_Generic_IEnumerableU3CcharU3E_GetEnumerator_m1490086850 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesData_m3138951217 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m2970182643 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m2141595938 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m1033457578 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m1863564558 ();
extern "C" void CustomAttributeData_get_NamedArguments_m2950811181 ();
extern "C" void CustomAttributeData_get_ConstructorArguments_m1602558961 ();
extern "C" void AnalyticsEventParamListContainer_get_parameters_m4180299006 ();
extern "C" void TrackableProperty_get_fields_m3682628132 ();
extern "C" void TriggerListContainer_get_rules_m110726358 ();
extern "C" void InvokableCallList_PrepareInvoke_m4003891334 ();
extern "C" void UnityEventBase_PrepareInvoke_m1785382128 ();
extern "C" void Hashtable_Synchronized_m2228653257 ();
extern "C" void MonoEnumInfo_get_Cache_m752167006 ();
extern "C" void ChannelData_get_CustomProperties_m1852130080 ();
extern "C" void LogicalCallContext_get_Datastore_m629418756 ();
extern "C" void SyncHashtable_get_Keys_m1469437863 ();
extern "C" void SyncHashtable_get_Values_m3820929471 ();
extern "C" void Hashtable_get_Keys_m625158339 ();
extern "C" void Hashtable_get_Values_m1643322147 ();
extern "C" void MethodDictionary_get_Values_m957801003 ();
extern "C" void MatchCollection_get_FullList_m1829231879 ();
extern "C" void HybridDictionary_get_inner_m3689521430 ();
extern "C" void SinkProviderData_get_Properties_m3454573235 ();
extern "C" void ConstructionCall_get_Properties_m3011379795 ();
extern "C" void ConstructionResponse_get_Properties_m4079816931 ();
extern "C" void ErrorMessage_get_Properties_m240354089 ();
extern "C" void MethodCall_get_Properties_m3740161820 ();
extern "C" void MethodDictionary_AllocInternalProperties_m1683153261 ();
extern "C" void MethodDictionary_GetInternalProperties_m2215984424 ();
extern "C" void MethodDictionary_get_InternalProperties_m321207497 ();
extern "C" void MethodResponse_get_Properties_m2411220224 ();
extern "C" void MonoMethodMessage_get_Properties_m3713673222 ();
extern "C" void ReturnMessage_get_Properties_m3665464616 ();
extern "C" void InterpreterFactory_get_Mapping_m1356145599 ();
extern "C" void SyncHashtable_GetEnumerator_m4254656826 ();
extern "C" void Hashtable_GetEnumerator_m4240267690 ();
extern "C" void SortedList_GetEnumerator_m772783392 ();
extern "C" void HybridDictionary_GetEnumerator_m1379032493 ();
extern "C" void ListDictionary_GetEnumerator_m3395631195 ();
extern "C" void ResourceReader_GetEnumerator_m3404589731 ();
extern "C" void ResourceSet_GetEnumerator_m3459697719 ();
extern "C" void MethodDictionary_GetEnumerator_m1619497063 ();
extern "C" void CipherSuiteCollection_System_Collections_IEnumerable_GetEnumerator_m3240848888 ();
extern "C" void X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m279447643 ();
extern "C" void X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m647852366 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m2696143383 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m1475785462 ();
extern "C" void Array_GetEnumerator_m4277730612 ();
extern "C" void ArrayListWrapper_GetEnumerator_m2336495952 ();
extern "C" void SynchronizedArrayListWrapper_GetEnumerator_m1579424644 ();
extern "C" void ArrayList_GetEnumerator_m3176119603 ();
extern "C" void BitArray_GetEnumerator_m1964744199 ();
extern "C" void CollectionBase_GetEnumerator_m654829872 ();
extern "C" void HashKeys_GetEnumerator_m3432430781 ();
extern "C" void HashValues_GetEnumerator_m2924783834 ();
extern "C" void SyncHashtable_System_Collections_IEnumerable_GetEnumerator_m1325482064 ();
extern "C" void Hashtable_System_Collections_IEnumerable_GetEnumerator_m2751657639 ();
extern "C" void Queue_GetEnumerator_m3623929043 ();
extern "C" void SortedList_System_Collections_IEnumerable_GetEnumerator_m2738760439 ();
extern "C" void HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m168538452 ();
extern "C" void ListDictionary_System_Collections_IEnumerable_GetEnumerator_m884729149 ();
extern "C" void KeysCollection_GetEnumerator_m2005471619 ();
extern "C" void NameObjectCollectionBase_GetEnumerator_m3677320185 ();
extern "C" void Stack_GetEnumerator_m2673437525 ();
extern "C" void WebHeaderCollection_GetEnumerator_m2991425604 ();
extern "C" void ResourceReader_System_Collections_IEnumerable_GetEnumerator_m577123352 ();
extern "C" void ResourceSet_System_Collections_IEnumerable_GetEnumerator_m2807499934 ();
extern "C" void MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m4169036899 ();
extern "C" void OidCollection_System_Collections_IEnumerable_GetEnumerator_m685937025 ();
extern "C" void X509ChainElementCollection_System_Collections_IEnumerable_GetEnumerator_m3829089536 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m4033897067 ();
extern "C" void Evidence_GetEnumerator_m302914965 ();
extern "C" void String_System_Collections_IEnumerable_GetEnumerator_m3198926340 ();
extern "C" void CaptureCollection_GetEnumerator_m732412500 ();
extern "C" void GroupCollection_GetEnumerator_m2543003136 ();
extern "C" void IntervalCollection_GetEnumerator_m3422445219 ();
extern "C" void MatchCollection_GetEnumerator_m3899212470 ();
extern "C" void AnalyticsEventTracker_TimedTrigger_m758162441 ();
extern "C" void Transform_GetEnumerator_m2717073726 ();
extern "C" void CollectionBase_get_List_m490744407 ();
extern "C" void SinkProviderData_get_Children_m4009299018 ();
extern "C" void ConstructionCall_get_ContextProperties_m4226046805 ();
extern "C" void DictionaryNodeEnumerator_get_DictionaryNode_m2794172961 ();
extern "C" void ListDictionary_FindEntry_m4121604518 ();
extern "C" void ListDictionary_FindEntry_m2629402370 ();
extern "C" void NameObjectCollectionBase_get_Keys_m2856825671 ();
extern "C" void WebHeaderCollection_get_Keys_m910440889 ();
extern "C" void NameObjectCollectionBase_FindFirstMatchedItem_m840305173 ();
extern "C" void EditorBrowsableAttribute_get_State_m21497981 ();
extern "C" void ASN1Convert_ToDateTime_m1246060840 ();
extern "C" void ASN1Convert_ToDateTime_m3103388320 ();
extern "C" void X509Certificate_get_ValidFrom_m845748800 ();
extern "C" void X509Certificate_get_ValidFrom_m1469376000 ();
extern "C" void X509Certificate_get_ValidUntil_m678342786 ();
extern "C" void X509Certificate_get_ValidUntil_m1838041919 ();
extern "C" void X509CrlEntry_get_RevocationDate_m303599135 ();
extern "C" void X509Crl_get_NextUpdate_m604794549 ();
extern "C" void Boolean_System_IConvertible_ToDateTime_m603510836_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDateTime_m3654084722_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDateTime_m3564102661_AdjustorThunk ();
extern "C" void Convert_ToDateTime_m626620011 ();
extern "C" void Convert_ToDateTime_m228494645 ();
extern "C" void Convert_ToDateTime_m2616935982 ();
extern "C" void Convert_ToDateTime_m1567637286 ();
extern "C" void Convert_ToDateTime_m296553984 ();
extern "C" void Convert_ToDateTime_m1800003024 ();
extern "C" void Convert_ToDateTime_m3802186295 ();
extern "C" void Convert_ToDateTime_m649137482 ();
extern "C" void Convert_ToDateTime_m1031474510 ();
extern "C" void Convert_ToDateTime_m3752463692 ();
extern "C" void DBNull_System_IConvertible_ToDateTime_m3633350356 ();
extern "C" void DateTime_Add_m2995894549_AdjustorThunk ();
extern "C" void DateTime_AddMilliseconds_m3713972790_AdjustorThunk ();
extern "C" void DateTime_AddSeconds_m332574389_AdjustorThunk ();
extern "C" void DateTime_AddTicks_m3396580426_AdjustorThunk ();
extern "C" void DateTime_FromBinary_m2489276715 ();
extern "C" void DateTime_Parse_m3729096069 ();
extern "C" void DateTime_Parse_m1070804416 ();
extern "C" void DateTime_ParseExact_m2711902273 ();
extern "C" void DateTime_ParseExact_m1132380469 ();
extern "C" void DateTime_SpecifyKind_m3332658812 ();
extern "C" void DateTime_Subtract_m3522513701_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToDateTime_m616366890_AdjustorThunk ();
extern "C" void DateTime_ToLocalTime_m3134475597_AdjustorThunk ();
extern "C" void DateTime_ToUniversalTime_m1945318289_AdjustorThunk ();
extern "C" void DateTime_get_Now_m1277138875 ();
extern "C" void DateTime_get_Today_m2788644320 ();
extern "C" void DateTime_get_UtcNow_m1393945741 ();
extern "C" void DateTime_op_Addition_m1857121695 ();
extern "C" void DateTime_op_Subtraction_m529926081 ();
extern "C" void DateTimeOffset_get_DateTime_m620985777_AdjustorThunk ();
extern "C" void DateTimeOffset_get_UtcDateTime_m1021718282_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToDateTime_m106179626_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToDateTime_m2414543049_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToDateTime_m3823814707 ();
extern "C" void DaylightTime_get_End_m724819253 ();
extern "C" void DaylightTime_get_Start_m2228394704 ();
extern "C" void Int16_System_IConvertible_ToDateTime_m3080274979_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDateTime_m1824716955_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDateTime_m2535842508_AdjustorThunk ();
extern "C" void ServicePoint_get_IdleSince_m2373179824 ();
extern "C" void SByte_System_IConvertible_ToDateTime_m1659899958_AdjustorThunk ();
extern "C" void X509Certificate2_get_NotAfter_m1930122497 ();
extern "C" void X509Certificate2_get_NotBefore_m2514418239 ();
extern "C" void X509ChainPolicy_get_VerificationTime_m4085504449 ();
extern "C" void Single_System_IConvertible_ToDateTime_m1748479284_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToDateTime_m3578483777 ();
extern "C" void TimeZone_ToLocalTime_m3563701919 ();
extern "C" void TimeZone_ToUniversalTime_m2789507578 ();
extern "C" void UInt16_System_IConvertible_ToDateTime_m2594768090_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDateTime_m2767723441_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDateTime_m3434604642_AdjustorThunk ();
extern "C" void Achievement_get_lastReportedDate_m2200074798 ();
extern "C" void DateTime_get_Kind_m2154871796_AdjustorThunk ();
extern "C" void DateTime_get_DayOfWeek_m2326490739_AdjustorThunk ();
extern "C" void CCFixed_day_of_week_m674639858 ();
extern "C" void GregorianCalendar_GetDayOfWeek_m3823546942 ();
extern "C" void Boolean_System_IConvertible_ToDecimal_m3176932461_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDecimal_m3746192770_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDecimal_m3534906463_AdjustorThunk ();
extern "C" void Convert_ToDecimal_m2233265097 ();
extern "C" void Convert_ToDecimal_m3209124080 ();
extern "C" void Convert_ToDecimal_m1783778724 ();
extern "C" void Convert_ToDecimal_m841368097 ();
extern "C" void Convert_ToDecimal_m1284410333 ();
extern "C" void Convert_ToDecimal_m1284148187 ();
extern "C" void Convert_ToDecimal_m1284279264 ();
extern "C" void Convert_ToDecimal_m3815908452 ();
extern "C" void Convert_ToDecimal_m996138310 ();
extern "C" void Convert_ToDecimal_m3508035522 ();
extern "C" void Convert_ToDecimal_m1233667008 ();
extern "C" void Convert_ToDecimal_m2858622624 ();
extern "C" void Convert_ToDecimal_m889385228 ();
extern "C" void Convert_ToDecimal_m1695757674 ();
extern "C" void DBNull_System_IConvertible_ToDecimal_m1883582283 ();
extern "C" void DateTime_System_IConvertible_ToDecimal_m1044850612_AdjustorThunk ();
extern "C" void Decimal_Add_m114360190 ();
extern "C" void Decimal_Divide_m3489391442 ();
extern "C" void Decimal_Floor_m1786329488 ();
extern "C" void Decimal_Multiply_m462893147 ();
extern "C" void Decimal_Parse_m942471224 ();
extern "C" void Decimal_Parse_m4154418249 ();
extern "C" void Decimal_Subtract_m835601464 ();
extern "C" void Decimal_System_IConvertible_ToDecimal_m2403239382_AdjustorThunk ();
extern "C" void Decimal_op_Division_m2407964042 ();
extern "C" void Decimal_op_Explicit_m2433293820 ();
extern "C" void Decimal_op_Explicit_m2070069477 ();
extern "C" void Decimal_op_Implicit_m29414198 ();
extern "C" void Decimal_op_Implicit_m3696395396 ();
extern "C" void Decimal_op_Implicit_m1328901562 ();
extern "C" void Decimal_op_Implicit_m1349849065 ();
extern "C" void Decimal_op_Implicit_m1920400487 ();
extern "C" void Decimal_op_Implicit_m4256234411 ();
extern "C" void Decimal_op_Implicit_m3873897383 ();
extern "C" void Decimal_op_Implicit_m2299919277 ();
extern "C" void Decimal_op_Increment_m2045993911 ();
extern "C" void Decimal_op_Multiply_m2389849621 ();
extern "C" void Decimal_op_Subtraction_m2530510375 ();
extern "C" void Double_System_IConvertible_ToDecimal_m2316246766_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToDecimal_m3435237785 ();
extern "C" void BinaryReader_ReadDecimal_m272106980 ();
extern "C" void Int16_System_IConvertible_ToDecimal_m660016172_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDecimal_m2190376994_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDecimal_m70934849_AdjustorThunk ();
extern "C" void Math_Round_m3018379666 ();
extern "C" void SByte_System_IConvertible_ToDecimal_m2548745278_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToDecimal_m325860800_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToDecimal_m997069272 ();
extern "C" void UInt16_System_IConvertible_ToDecimal_m1320731319_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDecimal_m675004071_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDecimal_m806594027_AdjustorThunk ();
extern "C" void Delegate_Combine_m1859655160 ();
extern "C" void Delegate_Combine_m558799649 ();
extern "C" void Delegate_CombineImpl_m3572135514 ();
extern "C" void Delegate_CreateDelegate_m995503480 ();
extern "C" void Delegate_CreateDelegate_m2386636647 ();
extern "C" void Delegate_CreateDelegate_m1406740088 ();
extern "C" void Delegate_CreateDelegate_m4052969428 ();
extern "C" void Delegate_CreateDelegate_m819160572 ();
extern "C" void Delegate_CreateDelegate_m1051651521 ();
extern "C" void Delegate_CreateDelegate_m441173131 ();
extern "C" void Delegate_CreateDelegate_m466794306 ();
extern "C" void Delegate_CreateDelegate_internal_m2845516975 ();
extern "C" void Delegate_Remove_m334097152 ();
extern "C" void Delegate_RemoveImpl_m1108247463 ();
extern "C" void DelegateEntry_DeserializeDelegate_m691980016 ();
extern "C" void MulticastDelegate_CombineImpl_m2857239134 ();
extern "C" void MulticastDelegate_RemoveImpl_m615507760 ();
extern "C" void NetFxCoreExtensions_CreateDelegate_m751211712 ();
extern "C" void Delegate_GetInvocationList_m592727217 ();
extern "C" void MulticastDelegate_GetInvocationList_m4256593605 ();
extern "C" void StackTrace_GetFrame_m3844938190 ();
extern "C" void StackTrace_get_trace_m1194606084 ();
extern "C" void BitConverterLE_ToDouble_m1601000678 ();
extern "C" void Boolean_System_IConvertible_ToDouble_m2859188631_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDouble_m1540319472_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDouble_m3575321888_AdjustorThunk ();
extern "C" void Convert_ToDouble_m954895424 ();
extern "C" void Convert_ToDouble_m3124823876 ();
extern "C" void Convert_ToDouble_m1177445661 ();
extern "C" void Convert_ToDouble_m278900635 ();
extern "C" void Convert_ToDouble_m996590115 ();
extern "C" void Convert_ToDouble_m2924063577 ();
extern "C" void Convert_ToDouble_m2180337032 ();
extern "C" void Convert_ToDouble_m4017511472 ();
extern "C" void Convert_ToDouble_m2949593046 ();
extern "C" void Convert_ToDouble_m217737046 ();
extern "C" void Convert_ToDouble_m2291761709 ();
extern "C" void Convert_ToDouble_m1840199900 ();
extern "C" void Convert_ToDouble_m2222536920 ();
extern "C" void Convert_ToDouble_m1030895834 ();
extern "C" void DBNull_System_IConvertible_ToDouble_m150664744 ();
extern "C" void DateTime_System_IConvertible_ToDouble_m2116720007_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToDouble_m3125524987_AdjustorThunk ();
extern "C" void Decimal_decimal2double_m2573538823 ();
extern "C" void Decimal_op_Explicit_m2816896069 ();
extern "C" void Double_Parse_m4153729520 ();
extern "C" void Double_Parse_m1135962389 ();
extern "C" void Double_Parse_m3456374109 ();
extern "C" void Double_System_IConvertible_ToDouble_m3692611612_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToDouble_m440464077 ();
extern "C" void BinaryReader_ReadDouble_m2513998176 ();
extern "C" void Int16_System_IConvertible_ToDouble_m1661805412_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDouble_m1464782260_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDouble_m99143002_AdjustorThunk ();
extern "C" void Math_Abs_m3912393749 ();
extern "C" void Math_Floor_m1840375750 ();
extern "C" void Math_Pow_m754227594 ();
extern "C" void Math_Round_m101670467 ();
extern "C" void Math_Sqrt_m1297338011 ();
extern "C" void SByte_System_IConvertible_ToDouble_m2381680501_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToDouble_m1584722292_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToDouble_m3740733360 ();
extern "C" void CostDelegate_EndInvoke_m2797921932 ();
extern "C" void CostDelegate_Invoke_m898648402 ();
extern "C" void CharacterClass_GetIntervalCost_m4036989868 ();
extern "C" void TimeSpan_get_TotalDays_m2049019055_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalHours_m306507525_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalMilliseconds_m2429771311_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalMinutes_m3920401708_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalSeconds_m4083325051_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToDouble_m333121300_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDouble_m940039456_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDouble_m602078108_AdjustorThunk ();
extern "C" void TriggerRule_GetDouble_m2201978033 ();
extern "C" void PlayableAsset_get_duration_m3549083384 ();
extern "C" void Achievement_get_percentCompleted_m2110138160 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncException_m631453737 ();
extern "C" void SendRecordAsyncResult_get_AsyncException_m3556917569 ();
extern "C" void InternalAsyncResult_get_AsyncException_m3185530354 ();
extern "C" void SmallXmlParser_Error_m3899025466 ();
extern "C" void SmallXmlParser_UnexpectedEndError_m1914362401 ();
extern "C" void Exception_get_InnerException_m3836775 ();
extern "C" void MonoIO_GetException_m865954703 ();
extern "C" void MonoIO_GetException_m1522387862 ();
extern "C" void StreamAsyncResult_get_Exception_m4050930077 ();
extern "C" void Int32_GetFormatException_m519586683 ();
extern "C" void WebRequest_GetMustImplement_m1485657458 ();
extern "C" void AssemblyBuilder_not_supported_m1735277432 ();
extern "C" void ConstructorBuilder_not_created_m1456215494 ();
extern "C" void ConstructorBuilder_not_supported_m1054126936 ();
extern "C" void EnumBuilder_CreateNotSupportedException_m3236297331 ();
extern "C" void FieldBuilder_CreateNotSupportedException_m2447945803 ();
extern "C" void GenericTypeParameterBuilder_not_supported_m3358960901 ();
extern "C" void MethodBuilder_NotSupported_m1497589941 ();
extern "C" void PropertyBuilder_not_supported_m1290265515 ();
extern "C" void TypeBuilder_not_supported_m1239084737 ();
extern "C" void CADMethodReturnMessage_GetException_m4034410903 ();
extern "C" void MethodResponse_get_Exception_m2873702313 ();
extern "C" void MonoMethodMessage_get_Exception_m1271355240 ();
extern "C" void ReturnMessage_get_Exception_m3375728265 ();
extern "C" void DateTimeFormatInfo_get_Calendar_m2815249551 ();
extern "C" void CultureInfo_get_CompareInfo_m2930343429 ();
extern "C" void SimpleCollator_GetNeutralCulture_m3694654043 ();
extern "C" void CultureInfo_ConstructCurrentCulture_m2704365233 ();
extern "C" void CultureInfo_ConstructCurrentUICulture_m3439838233 ();
extern "C" void CultureInfo_CreateCulture_m1493441763 ();
extern "C" void CultureInfo_GetCultureInfo_m630276874 ();
extern "C" void CultureInfo_GetCultureInfo_m56098747 ();
extern "C" void CultureInfo_get_CurrentCulture_m1632690660 ();
extern "C" void CultureInfo_get_CurrentUICulture_m959203371 ();
extern "C" void CultureInfo_get_InvariantCulture_m3532445182 ();
extern "C" void CultureInfo_get_Parent_m672689885 ();
extern "C" void AssemblyName_get_CultureInfo_m3135152423 ();
extern "C" void Thread_GetCachedCurrentCulture_m3435630977 ();
extern "C" void Thread_GetCachedCurrentUICulture_m3553957669 ();
extern "C" void Thread_get_CurrentCulture_m349116646 ();
extern "C" void Thread_get_CurrentUICulture_m1397429997 ();
extern "C" void CultureInfo_get_DateTimeFormat_m1982351742 ();
extern "C" void DateTimeFormatInfo_GetInstance_m684998497 ();
extern "C" void DateTimeFormatInfo_ReadOnly_m890935083 ();
extern "C" void DateTimeFormatInfo_get_CurrentInfo_m2315174029 ();
extern "C" void DateTimeFormatInfo_get_InvariantInfo_m2329875772 ();
extern "C" void CurrentSystemTimeZone_GetDaylightChanges_m2394763749 ();
extern "C" void CurrentSystemTimeZone_GetDaylightTimeFromData_m2196414210 ();
extern "C" void CultureInfo_get_NumberFormat_m1244033732 ();
extern "C" void NumberFormatInfo_GetInstance_m2833078205 ();
extern "C" void NumberFormatInfo_get_CurrentInfo_m2605582008 ();
extern "C" void NumberFormatInfo_get_InvariantInfo_m349577018 ();
extern "C" void NumberFormatter_GetNumberFormatInstance_m4015471089 ();
extern "C" void RegionInfo_get_CurrentRegion_m3443163374 ();
extern "C" void SimpleCollator_GetSortKey_m3181176421 ();
extern "C" void SimpleCollator_GetSortKey_m1483713513 ();
extern "C" void SortKeyBuffer_GetResult_m3043958424 ();
extern "C" void SortKeyBuffer_GetResultAndReset_m1300773060 ();
extern "C" void CompareInfo_GetSortKey_m1915852346 ();
extern "C" void CultureInfo_CreateTextInfo_m1222487997 ();
extern "C" void CultureInfo_get_TextInfo_m2342840448 ();
extern "C" void Char_GetUnicodeCategory_m57882613 ();
extern "C" void GuidParser_Parse_m3524913675 ();
extern "C" void GuidParser_ParseGuid1_m348754878 ();
extern "C" void GuidParser_ParseGuid2_m1914838819 ();
extern "C" void Guid_NewGuid_m923091018 ();
extern "C" void MessageTypeSubscribers_get_MessageTypeId_m1143155832 ();
extern "C" void PrimalityTest_BeginInvoke_m1203148458 ();
extern "C" void PrimalityTest_BeginInvoke_m742423211 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m3949196697 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m3227934731 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m1299225259 ();
extern "C" void CertificateSelectionCallback_BeginInvoke_m598704794 ();
extern "C" void CertificateValidationCallback2_BeginInvoke_m3360174801 ();
extern "C" void CertificateValidationCallback_BeginInvoke_m3301716879 ();
extern "C" void PrivateKeySelectionCallback_BeginInvoke_m2814232473 ();
extern "C" void RecordProtocol_BeginReceiveRecord_m295321170 ();
extern "C" void RecordProtocol_BeginSendRecord_m3926976520 ();
extern "C" void RecordProtocol_BeginSendRecord_m615249746 ();
extern "C" void SslClientStream_OnBeginNegotiateHandshake_m3734240069 ();
extern "C" void SslStreamBase_BeginRead_m3146234303 ();
extern "C" void SslStreamBase_BeginWrite_m2003981130 ();
extern "C" void Action_BeginInvoke_m2907948038 ();
extern "C" void AppDomainInitializer_BeginInvoke_m2460927216 ();
extern "C" void Swapper_BeginInvoke_m1688449973 ();
extern "C" void AssemblyLoadEventHandler_BeginInvoke_m1281107466 ();
extern "C" void AsyncCallback_BeginInvoke_m2710486612 ();
extern "C" void EventHandler_BeginInvoke_m829877076 ();
extern "C" void ReadDelegate_BeginInvoke_m3697522094 ();
extern "C" void WriteDelegate_BeginInvoke_m39624777 ();
extern "C" void FileStream_BeginRead_m2419864669 ();
extern "C" void FileStream_BeginWrite_m626715259 ();
extern "C" void Stream_BeginRead_m2233539237 ();
extern "C" void Stream_BeginWrite_m1696564506 ();
extern "C" void RemoteCertificateValidationCallback_BeginInvoke_m1840268146 ();
extern "C" void AddEventAdapter_BeginInvoke_m913431108 ();
extern "C" void MemberFilter_BeginInvoke_m3549240552 ();
extern "C" void GetterAdapter_BeginInvoke_m3429316396 ();
extern "C" void TypeFilter_BeginInvoke_m1623271879 ();
extern "C" void ResolveEventHandler_BeginInvoke_m762369743 ();
extern "C" void CrossContextDelegate_BeginInvoke_m3781308708 ();
extern "C" void RenewalDelegate_BeginInvoke_m1180839451 ();
extern "C" void HeaderHandler_BeginInvoke_m3867166640 ();
extern "C" void CallbackHandler_BeginInvoke_m1038689394 ();
extern "C" void CostDelegate_BeginInvoke_m2828452701 ();
extern "C" void SendOrPostCallback_BeginInvoke_m1648400288 ();
extern "C" void ThreadStart_BeginInvoke_m614889321 ();
extern "C" void TimerCallback_BeginInvoke_m2250763656 ();
extern "C" void WaitCallback_BeginInvoke_m3012509827 ();
extern "C" void WaitOrTimerCallback_BeginInvoke_m2905803559 ();
extern "C" void UnhandledExceptionEventHandler_BeginInvoke_m1761611550 ();
extern "C" void SessionStateChanged_BeginInvoke_m1132835327 ();
extern "C" void OnTrigger_BeginInvoke_m1406677296 ();
extern "C" void LogCallback_BeginInvoke_m1868775196 ();
extern "C" void LowMemoryCallback_BeginInvoke_m2877696488 ();
extern "C" void PCMReaderCallback_BeginInvoke_m3391809637 ();
extern "C" void PCMSetPositionCallback_BeginInvoke_m2701134198 ();
extern "C" void AudioConfigurationChangeHandler_BeginInvoke_m4104069447 ();
extern "C" void CameraCallback_BeginInvoke_m4249233405 ();
extern "C" void StateChanged_BeginInvoke_m4029305912 ();
extern "C" void DisplaysUpdatedDelegate_BeginInvoke_m1285971490 ();
extern "C" void UnityAction_BeginInvoke_m1892359299 ();
extern "C" void ConsumeSampleFramesNativeFunction_BeginInvoke_m342678987 ();
extern "C" void SampleFramesHandler_BeginInvoke_m2992664336 ();
extern "C" void UpdateFunction_BeginInvoke_m1039085470 ();
extern "C" void CreateOutputMethod_BeginInvoke_m3202548900 ();
extern "C" void ReapplyDrivenProperties_BeginInvoke_m4260606555 ();
extern "C" void UpdatedEventHandler_BeginInvoke_m424999959 ();
extern "C" void RequestAtlasCallback_BeginInvoke_m2655374249 ();
extern "C" void Directory_CreateDirectoriesInternal_m3735342319 ();
extern "C" void Directory_CreateDirectory_m751642867 ();
extern "C" void DirectoryInfo_get_Parent_m3736638393 ();
extern "C" void MonoIO_GetFileAttributes_m2086493016 ();
extern "C" void File_Open_m664439378 ();
extern "C" void File_OpenRead_m2936789020 ();
extern "C" void CADSerializer_SerializeMessage_m899341376 ();
extern "C" void CADSerializer_SerializeObject_m2985211104 ();
extern "C" void MonoIO_GetFileType_m101289143 ();
extern "C" void ReceiveRecordAsyncResult_get_Record_m223479150 ();
extern "C" void SslClientStream_get_InputBuffer_m4092356391 ();
extern "C" void Console_Open_m3077673205 ();
extern "C" void Console_OpenStandardError_m294613724 ();
extern "C" void Console_OpenStandardInput_m3262421490 ();
extern "C" void Console_OpenStandardOutput_m1257556731 ();
extern "C" void BinaryReader_get_BaseStream_m3993550412 ();
extern "C" void File_OpenText_m196858847 ();
extern "C" void TextReader_Synchronized_m3004980758 ();
extern "C" void Console_get_Error_m1839879495 ();
extern "C" void TextWriter_Synchronized_m904006265 ();
extern "C" void BitConverterLE_ToInt16_m1855092160 ();
extern "C" void CipherSuite_get_Code_m3847824475 ();
extern "C" void CipherSuite_get_EffectiveKeyBits_m2380229009 ();
extern "C" void ClientContext_get_ClientHelloProtocol_m1654639078 ();
extern "C" void Context_get_Protocol_m1078422015 ();
extern "C" void TlsStream_ReadInt16_m1728211431 ();
extern "C" void Boolean_System_IConvertible_ToInt16_m973746887_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt16_m4136764794_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt16_m975497224_AdjustorThunk ();
extern "C" void Convert_ToInt16_m3324557887 ();
extern "C" void Convert_ToInt16_m701474428 ();
extern "C" void Convert_ToInt16_m3018161032 ();
extern "C" void Convert_ToInt16_m2763665794 ();
extern "C" void Convert_ToInt16_m2780199356 ();
extern "C" void Convert_ToInt16_m4174570464 ();
extern "C" void Convert_ToInt16_m4174308322 ();
extern "C" void Convert_ToInt16_m4174439391 ();
extern "C" void Convert_ToInt16_m198393465 ();
extern "C" void Convert_ToInt16_m1223489986 ();
extern "C" void Convert_ToInt16_m155265449 ();
extern "C" void Convert_ToInt16_m1336719169 ();
extern "C" void Convert_ToInt16_m3185404879 ();
extern "C" void Convert_ToInt16_m2896657713 ();
extern "C" void Convert_ToInt16_m571189957 ();
extern "C" void Convert_ToInt16_m1733792763 ();
extern "C" void DBNull_System_IConvertible_ToInt16_m4228856009 ();
extern "C" void DateTime_System_IConvertible_ToInt16_m3239820399_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt16_m1574696763_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m4231101593 ();
extern "C" void Double_System_IConvertible_ToInt16_m3591921965_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToInt16_m2887101011 ();
extern "C" void BinaryReader_ReadInt16_m816003668 ();
extern "C" void Int16_Parse_m3641256939 ();
extern "C" void Int16_Parse_m138525169 ();
extern "C" void Int16_System_IConvertible_ToInt16_m2224134411_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToInt16_m453278239_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToInt16_m4062196970_AdjustorThunk ();
extern "C" void IPAddress_HostToNetworkOrder_m1393269408 ();
extern "C" void IPAddress_NetworkToHostOrder_m2704605532 ();
extern "C" void IPAddress_SwapShort_m703207735 ();
extern "C" void OpCode_get_Value_m917085326_AdjustorThunk ();
extern "C" void FormatterConverter_ToInt16_m4282804414 ();
extern "C" void SerializationInfo_GetInt16_m3858430398 ();
extern "C" void SByte_System_IConvertible_ToInt16_m885121451_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt16_m809233024_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToInt16_m1880095008 ();
extern "C" void UInt16_System_IConvertible_ToInt16_m2337134904_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt16_m1659441601_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt16_m3895479143_AdjustorThunk ();
extern "C" void CodePointIndexer_ToIndex_m1008730487 ();
extern "C" void ContractionComparer_Compare_m732151595 ();
extern "C" void Level2MapComparer_Compare_m2874495629 ();
extern "C" void MSCompatUnicodeTable_ToKanaTypeInsensitive_m2886449430 ();
extern "C" void MSCompatUnicodeTable_ToWidthCompat_m3110108204 ();
extern "C" void SimpleCollator_Compare_m809124712 ();
extern "C" void SimpleCollator_CompareFlagPair_m3270665809 ();
extern "C" void SimpleCollator_CompareInternal_m3938174601 ();
extern "C" void SimpleCollator_CompareOrdinal_m1829915258 ();
extern "C" void SimpleCollator_CompareOrdinalIgnoreCase_m2749548392 ();
extern "C" void SimpleCollator_CompareQuick_m3272475794 ();
extern "C" void SimpleCollator_FilterExtender_m72900315 ();
extern "C" void SimpleCollator_FilterOptions_m4183839400 ();
extern "C" void SimpleCollator_IndexOf_m3396932533 ();
extern "C" void SimpleCollator_IndexOf_m2273655786 ();
extern "C" void SimpleCollator_IndexOfOrdinal_m2995071964 ();
extern "C" void SimpleCollator_IndexOfOrdinalIgnoreCase_m2647969565 ();
extern "C" void SimpleCollator_IndexOfSortKey_m481945176 ();
extern "C" void SimpleCollator_LastIndexOf_m2130553617 ();
extern "C" void SimpleCollator_LastIndexOf_m3026739976 ();
extern "C" void SimpleCollator_LastIndexOfOrdinal_m388102249 ();
extern "C" void SimpleCollator_LastIndexOfOrdinalIgnoreCase_m2984667899 ();
extern "C" void SimpleCollator_LastIndexOfSortKey_m2864365168 ();
extern "C" void SimpleCollator_QuickIndexOf_m2519071357 ();
extern "C" void SortKeyBuffer_GetOptimizedLength_m1735248204 ();
extern "C" void BigInteger_BitCount_m2055977486 ();
extern "C" void BigInteger_BitCount_m3710900808 ();
extern "C" void BigInteger_GetHashCode_m1594560121 ();
extern "C" void BigInteger_GetHashCode_m1262812797 ();
extern "C" void BigInteger_LowestSetBit_m1199244228 ();
extern "C" void BigInteger_LowestSetBit_m3082714978 ();
extern "C" void PrimeGeneratorBase_get_TrialDivisionBounds_m349266641 ();
extern "C" void PrimeGeneratorBase_get_TrialDivisionBounds_m1980088695 ();
extern "C" void PrimalityTests_GetSPPRounds_m2558073743 ();
extern "C" void PrimalityTests_GetSPPRounds_m228447904 ();
extern "C" void ASN1_get_Count_m1789520042 ();
extern "C" void ASN1_get_Count_m3580979881 ();
extern "C" void ASN1_get_Length_m1923878580 ();
extern "C" void ASN1_get_Length_m3269728307 ();
extern "C" void ASN1Convert_ToInt32_m1017403318 ();
extern "C" void ASN1Convert_ToInt32_m254930636 ();
extern "C" void BitConverterLE_ToInt32_m1510163321 ();
extern "C" void ARC4Managed_InternalTransformBlock_m1047162329 ();
extern "C" void ARC4Managed_TransformBlock_m1687647868 ();
extern "C" void CryptoConvert_ToInt32LE_m3340980429 ();
extern "C" void DSAManaged_get_KeySize_m2738463749 ();
extern "C" void EncryptedPrivateKeyInfo_get_IterationCount_m2389157423 ();
extern "C" void EncryptedPrivateKeyInfo_get_IterationCount_m2912222740 ();
extern "C" void RSAManaged_get_KeySize_m1441482916 ();
extern "C" void RSAManaged_get_KeySize_m1420503080 ();
extern "C" void SymmetricTransform_InternalTransformBlock_m946892271 ();
extern "C" void SymmetricTransform_InternalTransformBlock_m1743612142 ();
extern "C" void SymmetricTransform_TransformBlock_m851059707 ();
extern "C" void SymmetricTransform_TransformBlock_m2339552481 ();
extern "C" void CipherSuite_get_HashSize_m4060916532 ();
extern "C" void CipherSuite_get_KeyBlockSize_m519075451 ();
extern "C" void CipherSuiteCollection_IndexOf_m2770510321 ();
extern "C" void CipherSuiteCollection_IndexOf_m2232557119 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Add_m1178326810 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_IndexOf_m1361500977 ();
extern "C" void CipherSuiteCollection_get_Count_m4271692531 ();
extern "C" void Context_GetUnixTime_m3811151335 ();
extern "C" void InternalAsyncResult_get_BytesRead_m3975435112 ();
extern "C" void InternalAsyncResult_get_Count_m2015941083 ();
extern "C" void InternalAsyncResult_get_Offset_m2101861835 ();
extern "C" void SslStreamBase_EndRead_m495357226 ();
extern "C" void SslStreamBase_Read_m2534198002 ();
extern "C" void SslStreamBase_Read_m231548581 ();
extern "C" void SslStreamBase_get_CipherStrength_m449292740 ();
extern "C" void SslStreamBase_get_HashStrength_m2770482134 ();
extern "C" void SslStreamBase_get_KeyExchangeStrength_m217695965 ();
extern "C" void TlsStream_Read_m3392972801 ();
extern "C" void TlsStream_ReadInt24_m3096782201 ();
extern "C" void ValidationResult_get_ErrorCode_m1533688152 ();
extern "C" void PKCS12_get_IterationCount_m3005687235 ();
extern "C" void PKCS12_get_IterationCount_m626423090 ();
extern "C" void PKCS12_get_MaximumPasswordLength_m883183191 ();
extern "C" void PKCS12_get_MaximumPasswordLength_m3603260090 ();
extern "C" void X509Certificate_get_Version_m3419034307 ();
extern "C" void X509CertificateCollection_Add_m2277657976 ();
extern "C" void X509CertificateCollection_Add_m3136524580 ();
extern "C" void X509CertificateCollection_GetHashCode_m324533873 ();
extern "C" void X509CertificateCollection_GetHashCode_m2303492950 ();
extern "C" void X509CertificateCollection_IndexOf_m2003755268 ();
extern "C" void X509Extension_GetHashCode_m2866442052 ();
extern "C" void X509Extension_GetHashCode_m1797796679 ();
extern "C" void X509ExtensionCollection_IndexOf_m2996504451 ();
extern "C" void AttrListImpl_get_Length_m1163071530 ();
extern "C" void SmallXmlParser_Peek_m1303779789 ();
extern "C" void SmallXmlParser_Read_m3485223434 ();
extern "C" void SmallXmlParser_ReadCharacterReference_m548953186 ();
extern "C" void ArgIterator_GetHashCode_m2630206016_AdjustorThunk ();
extern "C" void Array_BinarySearch_m3171087170 ();
extern "C" void Array_BinarySearch_m1987924169 ();
extern "C" void Array_BinarySearch_m687718979 ();
extern "C" void Array_BinarySearch_m157235616 ();
extern "C" void Array_DoBinarySearch_m3657328456 ();
extern "C" void Array_GetLength_m2178203778 ();
extern "C" void Array_GetLowerBound_m2045984623 ();
extern "C" void Array_GetRank_m2893148338 ();
extern "C" void Array_GetUpperBound_m4018715963 ();
extern "C" void Array_IndexOf_m1714973386 ();
extern "C" void Array_IndexOf_m2527777724 ();
extern "C" void Array_IndexOf_m2805394078 ();
extern "C" void Array_InternalArray__ICollection_get_Count_m2423031222 ();
extern "C" void Array_LastIndexOf_m1426784917 ();
extern "C" void Array_LastIndexOf_m3999123122 ();
extern "C" void Array_LastIndexOf_m707980579 ();
extern "C" void Array_System_Collections_ICollection_get_Count_m415154915 ();
extern "C" void Array_System_Collections_IList_Add_m1063688101 ();
extern "C" void Array_System_Collections_IList_IndexOf_m3301661616 ();
extern "C" void Array_compare_m2837221808 ();
extern "C" void Array_get_Length_m21610649 ();
extern "C" void Array_get_Rank_m3448755881 ();
extern "C" void Array_new_gap_m262136975 ();
extern "C" void Attribute_GetHashCode_m2508706224 ();
extern "C" void Boolean_CompareTo_m3774767002_AdjustorThunk ();
extern "C" void Boolean_CompareTo_m3665076258_AdjustorThunk ();
extern "C" void Boolean_GetHashCode_m3167312162_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToInt32_m1127498050_AdjustorThunk ();
extern "C" void Buffer_ByteLength_m2639516074 ();
extern "C" void Buffer_ByteLengthInternal_m1388208719 ();
extern "C" void Byte_CompareTo_m4207847027_AdjustorThunk ();
extern "C" void Byte_CompareTo_m4285128861_AdjustorThunk ();
extern "C" void Byte_GetHashCode_m850171870_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt32_m3495522413_AdjustorThunk ();
extern "C" void Char_CompareTo_m1035527789_AdjustorThunk ();
extern "C" void Char_CompareTo_m42489266_AdjustorThunk ();
extern "C" void Char_GetHashCode_m2163065211_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt32_m1777243200_AdjustorThunk ();
extern "C" void ArrayListWrapper_Add_m1926015631 ();
extern "C" void ArrayListWrapper_IndexOf_m4166445051 ();
extern "C" void ArrayListWrapper_IndexOf_m3692065720 ();
extern "C" void ArrayListWrapper_IndexOf_m3995939336 ();
extern "C" void ArrayListWrapper_get_Capacity_m51087796 ();
extern "C" void ArrayListWrapper_get_Count_m3954826285 ();
extern "C" void FixedSizeArrayListWrapper_Add_m4066213493 ();
extern "C" void FixedSizeArrayListWrapper_get_Capacity_m484550855 ();
extern "C" void SynchronizedArrayListWrapper_Add_m1623408305 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m666666436 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m1028529531 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m3642674350 ();
extern "C" void SynchronizedArrayListWrapper_get_Capacity_m603836496 ();
extern "C" void SynchronizedArrayListWrapper_get_Count_m527215081 ();
extern "C" void ArrayList_Add_m730026926 ();
extern "C" void ArrayList_IndexOf_m771193320 ();
extern "C" void ArrayList_IndexOf_m305368842 ();
extern "C" void ArrayList_IndexOf_m1052788661 ();
extern "C" void ArrayList_get_Capacity_m431818936 ();
extern "C" void ArrayList_get_Count_m1015046493 ();
extern "C" void BitArray_get_Count_m3250012040 ();
extern "C" void BitArray_get_Length_m3181964206 ();
extern "C" void CaseInsensitiveComparer_Compare_m1224120810 ();
extern "C" void CaseInsensitiveHashCodeProvider_GetHashCode_m2168170016 ();
extern "C" void CollectionBase_System_Collections_IList_Add_m3784093852 ();
extern "C" void CollectionBase_System_Collections_IList_IndexOf_m3655834224 ();
extern "C" void CollectionBase_get_Count_m1708965601 ();
extern "C" void Comparer_Compare_m3984347512 ();
extern "C" void HashKeys_get_Count_m4206343425 ();
extern "C" void HashValues_get_Count_m1050845476 ();
extern "C" void SyncHashtable_get_Count_m3689832098 ();
extern "C" void Hashtable_CalcPrime_m550773117 ();
extern "C" void Hashtable_Find_m1835111773 ();
extern "C" void Hashtable_GetHash_m3068611952 ();
extern "C" void Hashtable_ToPrime_m33531354 ();
extern "C" void Hashtable_get_Count_m3541651130 ();
extern "C" void Queue_get_Count_m2065247734 ();
extern "C" void SortedList_Find_m3363512987 ();
extern "C" void SortedList_IndexOfKey_m91331983 ();
extern "C" void SortedList_get_Capacity_m919184864 ();
extern "C" void SortedList_get_Count_m3860639970 ();
extern "C" void HybridDictionary_get_Count_m1166314536 ();
extern "C" void ListDictionary_get_Count_m414236492 ();
extern "C" void KeysCollection_get_Count_m3943311735 ();
extern "C" void NameObjectCollectionBase_get_Count_m823453971 ();
extern "C" void Stack_get_Count_m2258661097 ();
extern "C" void EditorBrowsableAttribute_GetHashCode_m123071459 ();
extern "C" void TypeConverterAttribute_GetHashCode_m948291090 ();
extern "C" void Convert_ToInt32_m2100527582 ();
extern "C" void Convert_ToInt32_m2505564049 ();
extern "C" void Convert_ToInt32_m1876369743 ();
extern "C" void Convert_ToInt32_m3048308591 ();
extern "C" void Convert_ToInt32_m2880498116 ();
extern "C" void Convert_ToInt32_m1085744762 ();
extern "C" void Convert_ToInt32_m1085875835 ();
extern "C" void Convert_ToInt32_m2608095889 ();
extern "C" void Convert_ToInt32_m3211312035 ();
extern "C" void Convert_ToInt32_m1405693041 ();
extern "C" void Convert_ToInt32_m1613163543 ();
extern "C" void Convert_ToInt32_m2128774575 ();
extern "C" void Convert_ToInt32_m1987758323 ();
extern "C" void Convert_ToInt32_m3956995719 ();
extern "C" void Convert_ToInt32_m825155517 ();
extern "C" void CultureAwareComparer_Compare_m1644833365 ();
extern "C" void CultureAwareComparer_GetHashCode_m1902485640 ();
extern "C" void DBNull_System_IConvertible_ToInt32_m4178834757 ();
extern "C" void DateTime_AbsoluteDays_m4235097773 ();
extern "C" void DateTime_Compare_m2855073242 ();
extern "C" void DateTime_CompareTo_m3889078633_AdjustorThunk ();
extern "C" void DateTime_CompareTo_m3687348273_AdjustorThunk ();
extern "C" void DateTime_DaysInMonth_m2587936260 ();
extern "C" void DateTime_FromTicks_m4059645178_AdjustorThunk ();
extern "C" void DateTime_GetHashCode_m2261847002_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToInt32_m340560789_AdjustorThunk ();
extern "C" void DateTime__ParseEnum_m253019513 ();
extern "C" void DateTime__ParseNumber_m1240316250 ();
extern "C" void DateTime_get_Day_m1623500273_AdjustorThunk ();
extern "C" void DateTime_get_Hour_m4153505178_AdjustorThunk ();
extern "C" void DateTime_get_Minute_m87527789_AdjustorThunk ();
extern "C" void DateTime_get_Month_m1566006993_AdjustorThunk ();
extern "C" void DateTime_get_Second_m2686182256_AdjustorThunk ();
extern "C" void DateTime_get_Year_m1184003812_AdjustorThunk ();
extern "C" void DateTimeOffset_CompareTo_m1350732322_AdjustorThunk ();
extern "C" void DateTimeOffset_GetHashCode_m2209105223_AdjustorThunk ();
extern "C" void DateTimeOffset_System_IComparable_CompareTo_m176229495_AdjustorThunk ();
extern "C" void DateTimeUtils_CountRepeat_m3396693018 ();
extern "C" void DateTimeUtils_ParseQuotedString_m2573610321 ();
extern "C" void Decimal_Compare_m3062820418 ();
extern "C" void Decimal_CompareTo_m3502307243_AdjustorThunk ();
extern "C" void Decimal_CompareTo_m3345610437_AdjustorThunk ();
extern "C" void Decimal_GetHashCode_m2838600885_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt32_m1488426794_AdjustorThunk ();
extern "C" void Decimal_decimal2Int64_m2102545213 ();
extern "C" void Decimal_decimal2UInt64_m3460477816 ();
extern "C" void Decimal_decimalCompare_m3796132203 ();
extern "C" void Decimal_decimalDiv_m3235226503 ();
extern "C" void Decimal_decimalIncr_m1887017143 ();
extern "C" void Decimal_decimalMult_m3812462972 ();
extern "C" void Decimal_decimalSetExponent_m3707787243 ();
extern "C" void Decimal_op_Explicit_m1842265407 ();
extern "C" void Decimal_string2decimal_m207208267 ();
extern "C" void Delegate_GetHashCode_m2102814970 ();
extern "C" void StackFrame_GetFileLineNumber_m1986974137 ();
extern "C" void StackFrame_GetILOffset_m1850960982 ();
extern "C" void StackFrame_GetNativeOffset_m4140370738 ();
extern "C" void StackTrace_get_FrameCount_m344690939 ();
extern "C" void Double_CompareTo_m3151899116_AdjustorThunk ();
extern "C" void Double_CompareTo_m2275617179_AdjustorThunk ();
extern "C" void Double_GetHashCode_m2295714610_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToInt32_m2896275711_AdjustorThunk ();
extern "C" void Enum_CompareTo_m4158304618 ();
extern "C" void Enum_FindName_m293338090 ();
extern "C" void Enum_FindPosition_m1093426213 ();
extern "C" void Enum_GetHashCode_m2848082716 ();
extern "C" void Enum_System_IConvertible_ToInt32_m2383479183 ();
extern "C" void Enum_compare_value_to_m1105953270 ();
extern "C" void Enum_get_hashcode_m902175016 ();
extern "C" void Environment_get_TickCount_m2088073110 ();
extern "C" void Exception_get_HResult_m1877758991 ();
extern "C" void CCFixed_FromDateTime_m3894190577 ();
extern "C" void CCGregorianCalendar_GetDayOfMonth_m1578922674 ();
extern "C" void CCGregorianCalendar_GetMonth_m1547203696 ();
extern "C" void CCGregorianCalendar_GetYear_m1605108522 ();
extern "C" void CCGregorianCalendar_day_from_fixed_m1674702403 ();
extern "C" void CCGregorianCalendar_fixed_from_dmy_m806432533 ();
extern "C" void CCGregorianCalendar_month_from_fixed_m4268992710 ();
extern "C" void CCGregorianCalendar_year_from_fixed_m463929682 ();
extern "C" void CCMath_div_m3792567336 ();
extern "C" void CCMath_div_mod_m348500398 ();
extern "C" void CCMath_mod_m3631663509 ();
extern "C" void CompareInfo_Compare_m1030179556 ();
extern "C" void CompareInfo_Compare_m894311506 ();
extern "C" void CompareInfo_Compare_m1980361250 ();
extern "C" void CompareInfo_GetHashCode_m912891044 ();
extern "C" void CompareInfo_IndexOf_m2631915198 ();
extern "C" void CompareInfo_IndexOf_m667936183 ();
extern "C" void CompareInfo_LastIndexOf_m2688553706 ();
extern "C" void CompareInfo_LastIndexOf_m3774208875 ();
extern "C" void CompareInfo_get_LCID_m2851766819 ();
extern "C" void CompareInfo_internal_compare_m2522722857 ();
extern "C" void CompareInfo_internal_compare_managed_m718834345 ();
extern "C" void CompareInfo_internal_compare_switch_m1882891666 ();
extern "C" void CompareInfo_internal_index_m2592793775 ();
extern "C" void CompareInfo_internal_index_managed_m2912760462 ();
extern "C" void CompareInfo_internal_index_switch_m2232588269 ();
extern "C" void CultureInfo_GetHashCode_m4280654343 ();
extern "C" void CultureInfo_get_LCID_m3475551012 ();
extern "C" void GregorianCalendar_GetDayOfMonth_m3068119146 ();
extern "C" void GregorianCalendar_GetEra_m2369958449 ();
extern "C" void GregorianCalendar_GetMonth_m3359423849 ();
extern "C" void GregorianCalendar_GetYear_m854131864 ();
extern "C" void NumberFormatInfo_get_CurrencyDecimalDigits_m4006331471 ();
extern "C" void NumberFormatInfo_get_CurrencyNegativePattern_m2134016253 ();
extern "C" void NumberFormatInfo_get_CurrencyPositivePattern_m2327563925 ();
extern "C" void NumberFormatInfo_get_NumberDecimalDigits_m4271638382 ();
extern "C" void NumberFormatInfo_get_NumberNegativePattern_m1699547496 ();
extern "C" void NumberFormatInfo_get_PercentDecimalDigits_m4236240374 ();
extern "C" void NumberFormatInfo_get_PercentNegativePattern_m1304634118 ();
extern "C" void NumberFormatInfo_get_PercentPositivePattern_m1800841633 ();
extern "C" void RegionInfo_GetHashCode_m1608374012 ();
extern "C" void RegionInfo_get_GeoId_m945815123 ();
extern "C" void SortKey_Compare_m1705990888 ();
extern "C" void SortKey_GetHashCode_m3547067087 ();
extern "C" void TextInfo_GetHashCode_m4032637166 ();
extern "C" void Guid_Compare_m231009821 ();
extern "C" void Guid_CompareTo_m2129361928_AdjustorThunk ();
extern "C" void Guid_CompareTo_m243656946_AdjustorThunk ();
extern "C" void Guid_GetHashCode_m3042133858_AdjustorThunk ();
extern "C" void BinaryReader_Read_m1362176249 ();
extern "C" void BinaryReader_Read_m763986032 ();
extern "C" void BinaryReader_Read_m3708759962 ();
extern "C" void BinaryReader_Read7BitEncodedInt_m3079148249 ();
extern "C" void BinaryReader_ReadCharBytes_m2668665998 ();
extern "C" void BinaryReader_ReadInt32_m2994982418 ();
extern "C" void ReadDelegate_EndInvoke_m1567259657 ();
extern "C" void ReadDelegate_Invoke_m853483996 ();
extern "C" void FileStream_EndRead_m3904255625 ();
extern "C" void FileStream_Read_m3303017364 ();
extern "C" void FileStream_ReadByte_m2651547500 ();
extern "C" void FileStream_ReadData_m1637551634 ();
extern "C" void FileStream_ReadInternal_m2099474616 ();
extern "C" void FileStream_ReadSegment_m3875398069 ();
extern "C" void FileStream_WriteSegment_m4018885935 ();
extern "C" void MemoryStream_CalculateNewCapacity_m30466263 ();
extern "C" void MemoryStream_Read_m337792459 ();
extern "C" void MemoryStream_ReadByte_m881980848 ();
extern "C" void MonoIO_Read_m1129074620 ();
extern "C" void MonoIO_Write_m3999708352 ();
extern "C" void NullStream_Read_m3464254343 ();
extern "C" void NullStream_ReadByte_m3043548024 ();
extern "C" void Path_findExtension_m910255017 ();
extern "C" void Stream_EndRead_m1896469262 ();
extern "C" void Stream_ReadByte_m4291052673 ();
extern "C" void StreamAsyncResult_get_NBytes_m548041729 ();
extern "C" void NullStreamReader_Peek_m1755552867 ();
extern "C" void NullStreamReader_Read_m3851775014 ();
extern "C" void NullStreamReader_Read_m4144924479 ();
extern "C" void StreamReader_DoChecks_m1235625723 ();
extern "C" void StreamReader_FindNextEOL_m2574298119 ();
extern "C" void StreamReader_Peek_m2272511193 ();
extern "C" void StreamReader_Read_m2554901735 ();
extern "C" void StreamReader_Read_m830111915 ();
extern "C" void StreamReader_ReadBuffer_m761134843 ();
extern "C" void StringReader_Peek_m3605235793 ();
extern "C" void StringReader_Read_m3322058819 ();
extern "C" void StringReader_Read_m478895463 ();
extern "C" void SynchronizedReader_Peek_m148942882 ();
extern "C" void SynchronizedReader_Read_m2047574604 ();
extern "C" void SynchronizedReader_Read_m1388613247 ();
extern "C" void TextReader_Peek_m4032451740 ();
extern "C" void TextReader_Read_m2044559986 ();
extern "C" void TextReader_Read_m4213268240 ();
extern "C" void UnexceptionalStreamReader_Peek_m1842169584 ();
extern "C" void UnexceptionalStreamReader_Read_m16956299 ();
extern "C" void UnexceptionalStreamReader_Read_m39696771 ();
extern "C" void UnmanagedMemoryStream_Read_m3982577147 ();
extern "C" void UnmanagedMemoryStream_ReadByte_m4248453739 ();
extern "C" void Int16_CompareTo_m3705372115_AdjustorThunk ();
extern "C" void Int16_CompareTo_m2285977076_AdjustorThunk ();
extern "C" void Int16_GetHashCode_m2858888309_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToInt32_m172369210_AdjustorThunk ();
extern "C" void Int32_CompareTo_m4284770383_AdjustorThunk ();
extern "C" void Int32_CompareTo_m2864982090_AdjustorThunk ();
extern "C" void Int32_GetHashCode_m1876651407_AdjustorThunk ();
extern "C" void Int32_Parse_m1033611559 ();
extern "C" void Int32_Parse_m3682462547 ();
extern "C" void Int32_Parse_m2087562008 ();
extern "C" void Int32_System_IConvertible_ToInt32_m265310525_AdjustorThunk ();
extern "C" void Int64_CompareTo_m3345789408_AdjustorThunk ();
extern "C" void Int64_CompareTo_m1928360444_AdjustorThunk ();
extern "C" void Int64_GetHashCode_m703091690_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToInt32_m772105781_AdjustorThunk ();
extern "C" void IntPtr_GetHashCode_m3588219647_AdjustorThunk ();
extern "C" void IntPtr_get_Size_m370911744 ();
extern "C" void IntPtr_op_Explicit_m4220076518 ();
extern "C" void Math_Abs_m1208936174 ();
extern "C" void Math_Max_m1873195862 ();
extern "C" void Math_Min_m3468062251 ();
extern "C" void AttributeInfo_get_InheritanceLevel_m1477952822 ();
extern "C" void IntComparer_Compare_m3469594474 ();
extern "C" void IntComparer_Compare_m1224674392 ();
extern "C" void LongComparer_Compare_m1396422012 ();
extern "C" void LongComparer_Compare_m3267206388 ();
extern "C" void SByteComparer_Compare_m3045065039 ();
extern "C" void SByteComparer_Compare_m533535269 ();
extern "C" void ShortComparer_Compare_m1881262465 ();
extern "C" void ShortComparer_Compare_m1360829877 ();
extern "C" void MonoType_GetArrayRank_m3267817731 ();
extern "C" void MulticastDelegate_GetHashCode_m3864330728 ();
extern "C" void IPAddress_GetHashCode_m1210636859 ();
extern "C" void IPAddress_Hash_m3747500957 ();
extern "C" void IPv6Address_AsIPv4Int_m844941024 ();
extern "C" void IPv6Address_Fill_m1519528280 ();
extern "C" void IPv6Address_GetHashCode_m2362916428 ();
extern "C" void IPv6Address_Hash_m2034463181 ();
extern "C" void ServicePoint_get_CurrentConnections_m1937296360 ();
extern "C" void SPKey_GetHashCode_m1832733826 ();
extern "C" void WebHeaderCollection_get_Count_m3224978046 ();
extern "C" void NumberFormatter_CountTrailingZeros_m1178387884 ();
extern "C" void NumberFormatter_CountTrailingZeros_m1036924976 ();
extern "C" void NumberFormatter_DecHexLen_m510984344 ();
extern "C" void NumberFormatter_DecHexLen_m3886828604 ();
extern "C" void NumberFormatter_FastDecHexLen_m224865815 ();
extern "C" void NumberFormatter_InitialFloatingPrecision_m2468520485 ();
extern "C" void NumberFormatter_ParsePrecision_m2004010615 ();
extern "C" void NumberFormatter_ScaleOrder_m3813786990 ();
extern "C" void NumberFormatter_get_DecimalDigits_m1471374423 ();
extern "C" void NumberFormatter_get_IntegerDigits_m1758408763 ();
extern "C" void Object_GetHashCode_m2705121830 ();
extern "C" void Object_InternalGetHashCode_m4213713973 ();
extern "C" void OrdinalComparer_Compare_m2819174916 ();
extern "C" void OrdinalComparer_GetHashCode_m3219897106 ();
extern "C" void Default_CompareCloserType_m2643961470 ();
extern "C" void Default_check_arguments_with_score_m3467814020 ();
extern "C" void Default_check_type_with_score_m3022331006 ();
extern "C" void Binder_GetDerivedLevel_m3216810447 ();
extern "C" void CustomAttributeData_GetHashCode_m3727773664 ();
extern "C" void CustomAttributeNamedArgument_GetHashCode_m2317130892_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_GetHashCode_m1121388927_AdjustorThunk ();
extern "C" void ConstructorBuilder_GetParameterCount_m1122995462 ();
extern "C" void ConstructorBuilder_get_next_table_index_m2681706538 ();
extern "C" void FieldBuilder_GetFieldOffset_m725157755 ();
extern "C" void GenericTypeParameterBuilder_GetHashCode_m852224381 ();
extern "C" void ILGenerator_Mono_GetCurrentOffset_m993338688 ();
extern "C" void ILGenerator_target_len_m542103396 ();
extern "C" void Label_GetHashCode_m1231913871_AdjustorThunk ();
extern "C" void MethodBuilder_GetHashCode_m2905063929 ();
extern "C" void MethodBuilder_GetParameterCount_m3108880742 ();
extern "C" void MethodBuilder_get_next_table_index_m2755473113 ();
extern "C" void MethodToken_GetHashCode_m673885300_AdjustorThunk ();
extern "C" void MethodToken_get_Token_m966062910_AdjustorThunk ();
extern "C" void ModuleBuilder_GetToken_m4274310417 ();
extern "C" void ModuleBuilder_GetToken_m1735168917 ();
extern "C" void ModuleBuilder_GetToken_m1823519114 ();
extern "C" void ModuleBuilder_getMethodToken_m454517975 ();
extern "C" void ModuleBuilder_getToken_m4290400349 ();
extern "C" void ModuleBuilder_getUSIndex_m1446676113 ();
extern "C" void ModuleBuilder_get_next_table_index_m1158040331 ();
extern "C" void ModuleBuilderTokenGenerator_GetToken_m2588853565 ();
extern "C" void ModuleBuilderTokenGenerator_GetToken_m1396347424 ();
extern "C" void ModuleBuilderTokenGenerator_GetToken_m2356555833 ();
extern "C" void OpCode_GetHashCode_m1374201362_AdjustorThunk ();
extern "C" void OpCode_get_Size_m3461506715_AdjustorThunk ();
extern "C" void ParameterBuilder_get_Attributes_m2132969861 ();
extern "C" void ParameterBuilder_get_Position_m3885059176 ();
extern "C" void TypeBuilder_get_next_table_index_m789974556 ();
extern "C" void FieldInfo_GetFieldOffset_m1356898082 ();
extern "C" void MethodBase_GetParameterCount_m2917849922 ();
extern "C" void MethodBase_get_next_table_index_m3259310018 ();
extern "C" void MonoField_GetFieldOffset_m3808764875 ();
extern "C" void ParameterInfo_get_Position_m2927189904 ();
extern "C" void NameOrId_get_Id_m2318951827 ();
extern "C" void ResourceReader_Read7BitEncodedInt_m3568166465 ();
extern "C" void FixedBufferAttribute_get_Length_m1478886548 ();
extern "C" void RuntimeHelpers_get_OffsetToStringData_m2192601476 ();
extern "C" void GCHandle_GetHashCode_m2446251778_AdjustorThunk ();
extern "C" void GCHandle_GetTargetHandle_m423901123 ();
extern "C" void UrlAttribute_GetHashCode_m3894447089 ();
extern "C" void CrossAppDomainChannel_get_ChannelPriority_m3418073750 ();
extern "C" void CrossAppDomainData_get_DomainID_m3516796532 ();
extern "C" void CrossAppDomainSink_get_TargetDomainId_m1510098893 ();
extern "C" void Context_get_ContextID_m438722087 ();
extern "C" void ContextAttribute_GetHashCode_m3530575001 ();
extern "C" void DynamicPropertyCollection_FindProperty_m2338552444 ();
extern "C" void ArgInfo_GetInOutArgCount_m2742066148 ();
extern "C" void CADMessageBase_MarshalProperties_m466198678 ();
extern "C" void CADMethodCallMessage_get_PropertiesCount_m1249125054 ();
extern "C" void CADMethodReturnMessage_get_PropertiesCount_m4281298296 ();
extern "C" void ErrorMessage_get_ArgCount_m3216492616 ();
extern "C" void MethodCall_get_ArgCount_m1601487409 ();
extern "C" void MethodDictionary_get_Count_m4037025569 ();
extern "C" void MethodResponse_get_ArgCount_m1397964487 ();
extern "C" void MethodResponse_get_OutArgCount_m116356169 ();
extern "C" void MonoMethodMessage_get_ArgCount_m632716600 ();
extern "C" void MonoMethodMessage_get_OutArgCount_m3123660340 ();
extern "C" void ReturnMessage_get_ArgCount_m51405423 ();
extern "C" void ReturnMessage_get_OutArgCount_m1954300070 ();
extern "C" void FormatterConverter_ToInt32_m2929341202 ();
extern "C" void ObjectWriter_GetAssemblyId_m1980650584 ();
extern "C" void ObjectWriter_GetAssemblyNameId_m2316410453 ();
extern "C" void ObjectWriter_RegisterAssembly_m1967120293 ();
extern "C" void ObjectWriter_WriteAssembly_m3173779754 ();
extern "C" void ObjectWriter_WriteAssemblyName_m3097158773 ();
extern "C" void InstanceComparer_System_Collections_IComparer_Compare_m1420501866 ();
extern "C" void InstanceComparer_System_Collections_IHashCodeProvider_GetHashCode_m1305577427 ();
extern "C" void SerializationInfo_GetInt32_m2640574809 ();
extern "C" void SerializationInfo_get_MemberCount_m3751947557 ();
extern "C" void StreamingContext_GetHashCode_m2281950854_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_GetHashCode_m2632095277_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_GetHashCode_m750321292_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_GetHashCode_m3999856879_AdjustorThunk ();
extern "C" void SByte_CompareTo_m3835733927_AdjustorThunk ();
extern "C" void SByte_CompareTo_m2441919575_AdjustorThunk ();
extern "C" void SByte_GetHashCode_m2824841835_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToInt32_m1636694485_AdjustorThunk ();
extern "C" void CodeAccessPermission_GetHashCode_m880096813 ();
extern "C" void AesManaged_get_KeySize_m1181452829 ();
extern "C" void AsymmetricAlgorithm_get_KeySize_m2113907895 ();
extern "C" void DSACryptoServiceProvider_get_KeySize_m786836990 ();
extern "C" void HMAC_get_BlockSizeValue_m455678067 ();
extern "C" void HashAlgorithm_TransformBlock_m4006041779 ();
extern "C" void HashAlgorithm_get_HashSize_m1025185937 ();
extern "C" void KeySizes_get_MaxSize_m3897255827 ();
extern "C" void KeySizes_get_MinSize_m1903718763 ();
extern "C" void KeySizes_get_SkipSize_m2783487614 ();
extern "C" void OidCollection_Add_m2569544356 ();
extern "C" void OidCollection_get_Count_m3720881332 ();
extern "C" void RC2_get_EffectiveKeySize_m285632245 ();
extern "C" void RC2_get_KeySize_m146781412 ();
extern "C" void RC2CryptoServiceProvider_get_EffectiveKeySize_m3835262416 ();
extern "C" void RSACryptoServiceProvider_get_KeySize_m2654153358 ();
extern "C" void RijndaelManagedTransform_TransformBlock_m1610137419 ();
extern "C" void SymmetricAlgorithm_get_BlockSize_m3551721617 ();
extern "C" void SymmetricAlgorithm_get_FeedbackSize_m3666584308 ();
extern "C" void SymmetricAlgorithm_get_KeySize_m4185004893 ();
extern "C" void ToBase64Transform_TransformBlock_m2497349397 ();
extern "C" void ToBase64Transform_get_InputBlockSize_m1094416431 ();
extern "C" void ToBase64Transform_get_OutputBlockSize_m1897680077 ();
extern "C" void X509BasicConstraintsExtension_get_PathLengthConstraint_m1198369084 ();
extern "C" void X509Certificate2_get_Version_m2534012675 ();
extern "C" void X509Certificate2Collection_Add_m3151757943 ();
extern "C" void X509Certificate_GetHashCode_m3969199094 ();
extern "C" void X509CertificateCollection_GetHashCode_m1953348376 ();
extern "C" void X509ChainElement_Count_m383583639 ();
extern "C" void X509ChainElementCollection_get_Count_m1678779750 ();
extern "C" void X509ExtensionCollection_get_Count_m3589967016 ();
extern "C" void StrongNamePublicKeyBlob_GetHashCode_m1678068698 ();
extern "C" void Evidence_GetHashCode_m2129946875 ();
extern "C" void Evidence_get_Count_m4079441921 ();
extern "C" void StrongName_GetHashCode_m4255451393 ();
extern "C" void Single_CompareTo_m2785801815_AdjustorThunk ();
extern "C" void Single_CompareTo_m189772128_AdjustorThunk ();
extern "C" void Single_GetHashCode_m1558506138_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt32_m872115569_AdjustorThunk ();
extern "C" void String_Compare_m945110377 ();
extern "C" void String_Compare_m3735043349 ();
extern "C" void String_Compare_m1071830722 ();
extern "C" void String_Compare_m1293271421 ();
extern "C" void String_CompareOrdinal_m1012192092 ();
extern "C" void String_CompareOrdinalCaseInsensitiveUnchecked_m2925624579 ();
extern "C" void String_CompareOrdinalUnchecked_m2277084468 ();
extern "C" void String_CompareTo_m3030934538 ();
extern "C" void String_CompareTo_m3414379165 ();
extern "C" void String_FindNotInTable_m421831114 ();
extern "C" void String_FindNotWhiteSpace_m2733198255 ();
extern "C" void String_GetCaseInsensitiveHashCode_m3282844242 ();
extern "C" void String_GetHashCode_m1906374149 ();
extern "C" void String_IndexOf_m363431711 ();
extern "C" void String_IndexOf_m2466398549 ();
extern "C" void String_IndexOf_m1248948328 ();
extern "C" void String_IndexOf_m1977622757 ();
extern "C" void String_IndexOf_m3406607758 ();
extern "C" void String_IndexOf_m2410372598 ();
extern "C" void String_IndexOf_m3950524021 ();
extern "C" void String_IndexOf_m1298810678 ();
extern "C" void String_IndexOfAny_m4159774896 ();
extern "C" void String_IndexOfAny_m2323029521 ();
extern "C" void String_IndexOfAny_m2882391940 ();
extern "C" void String_IndexOfAnyUnchecked_m953388766 ();
extern "C" void String_IndexOfOrdinal_m962178384 ();
extern "C" void String_IndexOfOrdinalIgnoreCaseUnchecked_m2823953141 ();
extern "C" void String_IndexOfOrdinalUnchecked_m460601827 ();
extern "C" void String_IndexOfUnchecked_m3677172170 ();
extern "C" void String_LastIndexOf_m3451222878 ();
extern "C" void String_LastIndexOf_m578673845 ();
extern "C" void String_LastIndexOf_m3228770703 ();
extern "C" void String_LastIndexOf_m2676535141 ();
extern "C" void String_LastIndexOf_m95398196 ();
extern "C" void String_LastIndexOfAny_m545540478 ();
extern "C" void String_LastIndexOfAnyUnchecked_m1231532039 ();
extern "C" void String_LastIndexOfUnchecked_m2119268555 ();
extern "C" void String_ParseDecimal_m3629679395 ();
extern "C" void String_System_IConvertible_ToInt32_m2665383247 ();
extern "C" void String_get_Length_m3847582255 ();
extern "C" void StringComparer_Compare_m991165676 ();
extern "C" void StringComparer_GetHashCode_m2080455020 ();
extern "C" void ASCIIEncoding_GetByteCount_m1773359527 ();
extern "C" void ASCIIEncoding_GetByteCount_m2129416242 ();
extern "C" void ASCIIEncoding_GetByteCount_m1278774099 ();
extern "C" void ASCIIEncoding_GetBytes_m2555927703 ();
extern "C" void ASCIIEncoding_GetBytes_m2774699525 ();
extern "C" void ASCIIEncoding_GetBytes_m2264249800 ();
extern "C" void ASCIIEncoding_GetBytes_m4130454866 ();
extern "C" void ASCIIEncoding_GetBytes_m2569027226 ();
extern "C" void ASCIIEncoding_GetCharCount_m1680860125 ();
extern "C" void ASCIIEncoding_GetChars_m2543669481 ();
extern "C" void ASCIIEncoding_GetChars_m3984780680 ();
extern "C" void ASCIIEncoding_GetMaxByteCount_m3220079164 ();
extern "C" void ASCIIEncoding_GetMaxCharCount_m3025651522 ();
extern "C" void DecoderExceptionFallback_GetHashCode_m1820789965 ();
extern "C" void DecoderExceptionFallbackBuffer_get_Remaining_m2901856506 ();
extern "C" void DecoderReplacementFallback_GetHashCode_m1611165826 ();
extern "C" void DecoderReplacementFallbackBuffer_get_Remaining_m1493654090 ();
extern "C" void EncoderExceptionFallback_GetHashCode_m3988634959 ();
extern "C" void EncoderExceptionFallbackBuffer_get_Remaining_m1573636148 ();
extern "C" void EncoderReplacementFallback_GetHashCode_m3235834578 ();
extern "C" void EncoderReplacementFallbackBuffer_get_Remaining_m671378385 ();
extern "C" void ForwardingDecoder_GetChars_m4228908854 ();
extern "C" void Encoding_GetByteCount_m1966030650 ();
extern "C" void Encoding_GetByteCount_m1979300643 ();
extern "C" void Encoding_GetByteCount_m1264711659 ();
extern "C" void Encoding_GetBytes_m2313240322 ();
extern "C" void Encoding_GetBytes_m3823106599 ();
extern "C" void Encoding_GetHashCode_m2631196485 ();
extern "C" void Latin1Encoding_GetByteCount_m4202252024 ();
extern "C" void Latin1Encoding_GetByteCount_m1145650505 ();
extern "C" void Latin1Encoding_GetBytes_m4216440037 ();
extern "C" void Latin1Encoding_GetBytes_m3765139542 ();
extern "C" void Latin1Encoding_GetBytes_m1655294126 ();
extern "C" void Latin1Encoding_GetBytes_m3327999871 ();
extern "C" void Latin1Encoding_GetCharCount_m3241384207 ();
extern "C" void Latin1Encoding_GetChars_m1437558423 ();
extern "C" void Latin1Encoding_GetMaxByteCount_m1284135491 ();
extern "C" void Latin1Encoding_GetMaxCharCount_m1720752733 ();
extern "C" void Capture_get_Index_m745081289 ();
extern "C" void Capture_get_Length_m4245536461 ();
extern "C" void CaptureCollection_get_Count_m2294375304 ();
extern "C" void Key_GetHashCode_m1667525669 ();
extern "C" void GroupCollection_get_Count_m1328438810 ();
extern "C" void IntStack_Pop_m1779514793_AdjustorThunk ();
extern "C" void IntStack_get_Count_m1427289819_AdjustorThunk ();
extern "C" void RepeatContext_get_Count_m1112834530 ();
extern "C" void RepeatContext_get_Expression_m255006542 ();
extern "C" void RepeatContext_get_Start_m1076992038 ();
extern "C" void Interpreter_Checkpoint_m1239052598 ();
extern "C" void Interpreter_CreateMark_m468807491 ();
extern "C" void Interpreter_GetLastDefined_m4107643411 ();
extern "C" void Interpreter_ReadProgramCount_m1121096263 ();
extern "C" void InterpreterFactory_get_Gap_m2263656528 ();
extern "C" void InterpreterFactory_get_GroupCount_m2226373271 ();
extern "C" void Interval_CompareTo_m3282557545_AdjustorThunk ();
extern "C" void Interval_get_Size_m4163671410_AdjustorThunk ();
extern "C" void IntervalCollection_get_Count_m3041256718 ();
extern "C" void Mark_get_Index_m3048692661_AdjustorThunk ();
extern "C" void Mark_get_Length_m2532192442_AdjustorThunk ();
extern "C" void MatchCollection_get_Count_m1586545784 ();
extern "C" void PatternLinkStack_GetOffset_m3697714525 ();
extern "C" void PatternLinkStack_get_OffsetAddress_m3101911097 ();
extern "C" void PatternCompiler_get_CurrentAddress_m295383652 ();
extern "C" void QuickSearch_GetShiftDistance_m2542665852 ();
extern "C" void QuickSearch_Search_m3063517397 ();
extern "C" void QuickSearch_get_Length_m1693906716 ();
extern "C" void Regex_GetGroupIndex_m4131147974 ();
extern "C" void Regex_default_startat_m4206401165 ();
extern "C" void Regex_get_Gap_m3259754026 ();
extern "C" void AnchorInfo_get_Length_m1361685865 ();
extern "C" void AnchorInfo_get_Offset_m2045445765 ();
extern "C" void AnchorInfo_get_Width_m3579824419 ();
extern "C" void CapturingGroup_CompareTo_m4265294460 ();
extern "C" void CapturingGroup_get_Index_m3406974370 ();
extern "C" void Expression_GetFixedWidth_m945658 ();
extern "C" void Parser_GetMapping_m1792972121 ();
extern "C" void Parser_ParseDecimal_m245094461 ();
extern "C" void Parser_ParseDigit_m2336300552 ();
extern "C" void Parser_ParseEscape_m956682155 ();
extern "C" void Parser_ParseHex_m3698548444 ();
extern "C" void Parser_ParseNumber_m3464424197 ();
extern "C" void Parser_ParseNumber_m2114552835 ();
extern "C" void Parser_ParseOctal_m1193445574 ();
extern "C" void Repetition_get_Minimum_m2550947568 ();
extern "C" void StringBuilder_get_Capacity_m2088663745 ();
extern "C" void StringBuilder_get_Length_m3238060835 ();
extern "C" void UTF32Decoder_GetChars_m1925558948 ();
extern "C" void UTF32Encoding_GetByteCount_m3610769032 ();
extern "C" void UTF32Encoding_GetByteCount_m3787179419 ();
extern "C" void UTF32Encoding_GetByteCount_m3318495092 ();
extern "C" void UTF32Encoding_GetBytes_m2832872594 ();
extern "C" void UTF32Encoding_GetBytes_m3180303867 ();
extern "C" void UTF32Encoding_GetBytes_m4022298172 ();
extern "C" void UTF32Encoding_GetCharCount_m3062341871 ();
extern "C" void UTF32Encoding_GetChars_m208559531 ();
extern "C" void UTF32Encoding_GetHashCode_m2910638225 ();
extern "C" void UTF32Encoding_GetMaxByteCount_m2445516862 ();
extern "C" void UTF32Encoding_GetMaxCharCount_m2375204529 ();
extern "C" void UTF7Decoder_GetChars_m3413809261 ();
extern "C" void UTF7Encoding_GetByteCount_m209415911 ();
extern "C" void UTF7Encoding_GetByteCount_m3616172568 ();
extern "C" void UTF7Encoding_GetByteCount_m1175520321 ();
extern "C" void UTF7Encoding_GetBytes_m521917477 ();
extern "C" void UTF7Encoding_GetBytes_m3609725875 ();
extern "C" void UTF7Encoding_GetBytes_m4073063585 ();
extern "C" void UTF7Encoding_GetCharCount_m2792854727 ();
extern "C" void UTF7Encoding_GetChars_m732948009 ();
extern "C" void UTF7Encoding_GetHashCode_m587267901 ();
extern "C" void UTF7Encoding_GetMaxByteCount_m1806591568 ();
extern "C" void UTF7Encoding_GetMaxCharCount_m3050332930 ();
extern "C" void UTF7Encoding_InternalGetByteCount_m711304883 ();
extern "C" void UTF7Encoding_InternalGetBytes_m797138468 ();
extern "C" void UTF7Encoding_InternalGetCharCount_m1454619382 ();
extern "C" void UTF7Encoding_InternalGetChars_m2722395139 ();
extern "C" void UTF8Decoder_GetChars_m1236346907 ();
extern "C" void UTF8Encoding_Fallback_m1398662657 ();
extern "C" void UTF8Encoding_GetByteCount_m4153686982 ();
extern "C" void UTF8Encoding_GetByteCount_m4152118078 ();
extern "C" void UTF8Encoding_GetByteCount_m3800586529 ();
extern "C" void UTF8Encoding_GetBytes_m3254542575 ();
extern "C" void UTF8Encoding_GetBytes_m3927828659 ();
extern "C" void UTF8Encoding_GetBytes_m1676006378 ();
extern "C" void UTF8Encoding_GetCharCount_m2272165989 ();
extern "C" void UTF8Encoding_GetChars_m1433288684 ();
extern "C" void UTF8Encoding_GetHashCode_m641510078 ();
extern "C" void UTF8Encoding_GetMaxByteCount_m420651053 ();
extern "C" void UTF8Encoding_GetMaxCharCount_m3762459613 ();
extern "C" void UTF8Encoding_InternalGetByteCount_m2120178851 ();
extern "C" void UTF8Encoding_InternalGetByteCount_m771565606 ();
extern "C" void UTF8Encoding_InternalGetBytes_m359000633 ();
extern "C" void UTF8Encoding_InternalGetBytes_m1965760031 ();
extern "C" void UTF8Encoding_InternalGetCharCount_m3717563502 ();
extern "C" void UTF8Encoding_InternalGetCharCount_m82458470 ();
extern "C" void UTF8Encoding_InternalGetChars_m1682357736 ();
extern "C" void UTF8Encoding_InternalGetChars_m1502871718 ();
extern "C" void UnicodeDecoder_GetChars_m3463258340 ();
extern "C" void UnicodeEncoding_GetByteCount_m3498858619 ();
extern "C" void UnicodeEncoding_GetByteCount_m2118773625 ();
extern "C" void UnicodeEncoding_GetByteCount_m3262451645 ();
extern "C" void UnicodeEncoding_GetBytes_m3223155660 ();
extern "C" void UnicodeEncoding_GetBytes_m3426267301 ();
extern "C" void UnicodeEncoding_GetBytes_m1366350399 ();
extern "C" void UnicodeEncoding_GetBytesInternal_m1902824297 ();
extern "C" void UnicodeEncoding_GetCharCount_m845015490 ();
extern "C" void UnicodeEncoding_GetChars_m3561826263 ();
extern "C" void UnicodeEncoding_GetCharsInternal_m98244547 ();
extern "C" void UnicodeEncoding_GetHashCode_m354003420 ();
extern "C" void UnicodeEncoding_GetMaxByteCount_m3053620432 ();
extern "C" void UnicodeEncoding_GetMaxCharCount_m1592623696 ();
extern "C" void Interlocked_CompareExchange_m3023855514 ();
extern "C" void Interlocked_Increment_m3548166048 ();
extern "C" void Thread_GetDomainID_m3416930910 ();
extern "C" void Thread_GetHashCode_m3479107071 ();
extern "C" void Thread_GetNewManagedId_m2361425608 ();
extern "C" void Thread_GetNewManagedId_internal_m397574299 ();
extern "C" void Thread_get_ManagedThreadId_m1068113671 ();
extern "C" void Scheduler_InternalRemove_m3297531302 ();
extern "C" void TimerComparer_Compare_m4202371654 ();
extern "C" void WaitHandle_WaitAny_m1809371212 ();
extern "C" void WaitHandle_WaitAny_internal_m1870329233 ();
extern "C" void TimeSpan_Compare_m753151303 ();
extern "C" void TimeSpan_CompareTo_m2181997813_AdjustorThunk ();
extern "C" void TimeSpan_CompareTo_m3633415627_AdjustorThunk ();
extern "C" void TimeSpan_GetHashCode_m1939414618_AdjustorThunk ();
extern "C" void TimeSpan_get_Days_m2243259430_AdjustorThunk ();
extern "C" void TimeSpan_get_Hours_m550761902_AdjustorThunk ();
extern "C" void TimeSpan_get_Milliseconds_m3438015508_AdjustorThunk ();
extern "C" void TimeSpan_get_Minutes_m4278980001_AdjustorThunk ();
extern "C" void TimeSpan_get_Seconds_m1883479191_AdjustorThunk ();
extern "C" void Type_GetArrayRank_m276452511 ();
extern "C" void Type_GetHashCode_m1947148725 ();
extern "C" void TypedReference_GetHashCode_m2046447331_AdjustorThunk ();
extern "C" void UInt16_CompareTo_m2664746316_AdjustorThunk ();
extern "C" void UInt16_CompareTo_m243264328_AdjustorThunk ();
extern "C" void UInt16_GetHashCode_m329858256_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToInt32_m1950778303_AdjustorThunk ();
extern "C" void UInt32_CompareTo_m362578384_AdjustorThunk ();
extern "C" void UInt32_CompareTo_m2218823230_AdjustorThunk ();
extern "C" void UInt32_GetHashCode_m3722548385_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt32_m220754611_AdjustorThunk ();
extern "C" void UInt64_CompareTo_m3619843473_AdjustorThunk ();
extern "C" void UInt64_CompareTo_m1614517204_AdjustorThunk ();
extern "C" void UInt64_GetHashCode_m4209760355_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt32_m949522652_AdjustorThunk ();
extern "C" void UIntPtr_GetHashCode_m3482152298_AdjustorThunk ();
extern "C" void Uri_FromHex_m2610708947 ();
extern "C" void Uri_GetDefaultPort_m2547653357 ();
extern "C" void Uri_GetHashCode_m321999866 ();
extern "C" void UriParser_get_DefaultPort_m2544851211 ();
extern "C" void ValueType_GetHashCode_m715362416 ();
extern "C" void ValueType_InternalGetHashCode_m58786863 ();
extern "C" void Version_CompareTo_m1662919407 ();
extern "C" void Version_CompareTo_m3146217210 ();
extern "C" void Version_GetHashCode_m672974201 ();
extern "C" void Version_get_Build_m3667751407 ();
extern "C" void Version_get_Major_m2457928275 ();
extern "C" void Version_get_Minor_m150536655 ();
extern "C" void Version_get_Revision_m3982234017 ();
extern "C" void EventTrigger_get_repetitions_m2606968061 ();
extern "C" void TrackableProperty_GetHashCode_m3407865350 ();
extern "C" void AttributeHelperEngine_GetDefaultExecutionOrderFor_m2255077112 ();
extern "C" void AudioListener_GetNumExtensionProperties_m3139224773 ();
extern "C" void AudioSource_GetNumExtensionProperties_m1231815209 ();
extern "C" void Camera_GetAllCameras_m668492922 ();
extern "C" void Camera_GetAllCamerasCount_m2278705835 ();
extern "C" void Camera_GetAllCamerasImpl_m2534099441 ();
extern "C" void Camera_get_allCamerasCount_m528453758 ();
extern "C" void Camera_get_cullingMask_m679085748 ();
extern "C" void Camera_get_eventMask_m819189086 ();
extern "C" void Camera_get_targetDisplay_m2285699927 ();
extern "C" void DefaultExecutionOrder_get_order_m1454999278 ();
extern "C" void Display_RelativeMouseAtImpl_m3843151955 ();
extern "C" void Display_get_systemHeight_m730809466 ();
extern "C" void Display_get_systemWidth_m2423595549 ();
extern "C" void ArgumentCache_get_intArgument_m1309958679 ();
extern "C" void DefaultValueAttribute_GetHashCode_m3368187153 ();
extern "C" void Object_GetHashCode_m1944636947 ();
extern "C" void PlayableHandle_GetHashCode_m1297878485_AdjustorThunk ();
extern "C" void PlayableOutputHandle_GetHashCode_m2803245663_AdjustorThunk ();
extern "C" void PropertyName_GetHashCode_m3570549176_AdjustorThunk ();
extern "C" void Quaternion_GetHashCode_m2636680144_AdjustorThunk ();
extern "C" void Rect_GetHashCode_m1816164252_AdjustorThunk ();
extern "C" void RenderTextureDescriptor_get_depthBufferBits_m2160829816_AdjustorThunk ();
extern "C" void RenderTextureDescriptor_get_height_m1891977024_AdjustorThunk ();
extern "C" void RenderTextureDescriptor_get_msaaSamples_m2437860573_AdjustorThunk ();
extern "C" void RenderTextureDescriptor_get_volumeDepth_m3098156076_AdjustorThunk ();
extern "C" void RenderTextureDescriptor_get_width_m26344548_AdjustorThunk ();
extern "C" void Scene_GetHashCode_m2998285532_AdjustorThunk ();
extern "C" void Scene_get_handle_m1544696971_AdjustorThunk ();
extern "C" void Screen_get_height_m1623532518 ();
extern "C" void Screen_get_width_m345039817 ();
extern "C" void AchievementDescription_get_points_m4273978152 ();
extern "C" void Transform_get_childCount_m3145433196 ();
extern "C" void Vector2_GetHashCode_m3916089713_AdjustorThunk ();
extern "C" void Vector3_GetHashCode_m2879461828_AdjustorThunk ();
extern "C" void Array_GetIntArray_m1205726566 ();
extern "C" void Decimal_GetBits_m453754410 ();
extern "C" void GregorianCalendar_get_Eras_m3930946427 ();
extern "C" void NumberFormatInfo_get_RawCurrencyGroupSizes_m815972208 ();
extern "C" void NumberFormatInfo_get_RawNumberGroupSizes_m1148947207 ();
extern "C" void NumberFormatInfo_get_RawPercentGroupSizes_m97703232 ();
extern "C" void Regex_get_GroupNumbers_m2296197918 ();
extern "C" void SslStreamBase_Seek_m270320723 ();
extern "C" void SslStreamBase_get_Length_m561490526 ();
extern "C" void SslStreamBase_get_Position_m3505809821 ();
extern "C" void TlsStream_Seek_m895611617 ();
extern "C" void TlsStream_get_Length_m1907852793 ();
extern "C" void TlsStream_get_Position_m1904146856 ();
extern "C" void Array_GetLongLength_m561139708 ();
extern "C" void Array_get_LongLength_m978104875 ();
extern "C" void BitConverter_DoubleToInt64Bits_m3574395137 ();
extern "C" void BitConverter_ToInt64_m349022421 ();
extern "C" void Boolean_System_IConvertible_ToInt64_m2059204559_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt64_m285584218_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt64_m1630543716_AdjustorThunk ();
extern "C" void Convert_ToInt64_m2812720657 ();
extern "C" void Convert_ToInt64_m395638860 ();
extern "C" void Convert_ToInt64_m3122543124 ();
extern "C" void Convert_ToInt64_m4082637156 ();
extern "C" void Convert_ToInt64_m3758262873 ();
extern "C" void Convert_ToInt64_m2075031821 ();
extern "C" void Convert_ToInt64_m2075293963 ();
extern "C" void Convert_ToInt64_m2075162888 ();
extern "C" void Convert_ToInt64_m3240678588 ();
extern "C" void Convert_ToInt64_m2643251823 ();
extern "C" void Convert_ToInt64_m3916071102 ();
extern "C" void Convert_ToInt64_m658295522 ();
extern "C" void Convert_ToInt64_m4087101237 ();
extern "C" void Convert_ToInt64_m2849840611 ();
extern "C" void Convert_ToInt64_m1422776160 ();
extern "C" void Convert_ToInt64_m3392013556 ();
extern "C" void Convert_ToInt64_m260173354 ();
extern "C" void DBNull_System_IConvertible_ToInt64_m3889862579 ();
extern "C" void DateTime_GetNow_m1268643815 ();
extern "C" void DateTime_GetTimeMonotonic_m2320662727 ();
extern "C" void DateTime_System_IConvertible_ToInt64_m850544508_AdjustorThunk ();
extern "C" void DateTime_ToBinary_m1193069875_AdjustorThunk ();
extern "C" void DateTime_get_Ticks_m1550640881_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt64_m1446427516_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m438967917 ();
extern "C" void Decimal_s64_m309158181 ();
extern "C" void Double_System_IConvertible_ToInt64_m3968660899_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToInt64_m3491891092 ();
extern "C" void BinaryReader_ReadInt64_m939370142 ();
extern "C" void FileStream_Seek_m2017853129 ();
extern "C" void FileStream_get_Length_m426703983 ();
extern "C" void FileStream_get_Position_m3002807042 ();
extern "C" void MemoryStream_Seek_m3459579537 ();
extern "C" void MemoryStream_get_Length_m1064991453 ();
extern "C" void MemoryStream_get_Position_m3733941202 ();
extern "C" void MonoIO_GetLength_m2300093603 ();
extern "C" void MonoIO_Seek_m390267705 ();
extern "C" void NullStream_Seek_m1914924606 ();
extern "C" void NullStream_get_Length_m3184233382 ();
extern "C" void NullStream_get_Position_m4048431226 ();
extern "C" void UnmanagedMemoryStream_Seek_m541442656 ();
extern "C" void UnmanagedMemoryStream_get_Length_m3699800948 ();
extern "C" void UnmanagedMemoryStream_get_Position_m3800945932 ();
extern "C" void Int16_System_IConvertible_ToInt64_m4101803559_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToInt64_m3520470966_AdjustorThunk ();
extern "C" void Int64_Parse_m662659148 ();
extern "C" void Int64_Parse_m3250361603 ();
extern "C" void Int64_Parse_m1331690076 ();
extern "C" void Int64_System_IConvertible_ToInt64_m1560218307_AdjustorThunk ();
extern "C" void IntPtr_ToInt64_m192765549_AdjustorThunk ();
extern "C" void Math_Abs_m2270691510 ();
extern "C" void IPAddress_get_InternalIPv4Address_m3963971538 ();
extern "C" void IPAddress_get_ScopeId_m4237202723 ();
extern "C" void IPv6Address_get_ScopeId_m2285850181 ();
extern "C" void NumberFormatter_GetTenPowerOf_m3725144548 ();
extern "C" void FormatterConverter_ToInt64_m495840699 ();
extern "C" void ObjectIDGenerator_GetId_m2052009363 ();
extern "C" void ObjectIDGenerator_get_NextId_m3343770173 ();
extern "C" void SerializationInfo_GetInt64_m2503729515 ();
extern "C" void SByte_System_IConvertible_ToInt64_m2107229906_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt64_m1650421025_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToInt64_m3494136111 ();
extern "C" void TimeSpan_CalculateTicks_m1336746319 ();
extern "C" void TimeSpan_get_Ticks_m2137362016_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToInt64_m3635199533_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt64_m2261037378_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt64_m4241475606_AdjustorThunk ();
extern "C" void Score_get_value_m3180422307 ();
extern "C" void MSCompatUnicodeTable_GetResource_m731831298 ();
extern "C" void MonoIO_Open_m2245605962 ();
extern "C" void MonoIO_get_ConsoleError_m1156784591 ();
extern "C" void MonoIO_get_ConsoleInput_m610865495 ();
extern "C" void MonoIO_get_ConsoleOutput_m1601613425 ();
extern "C" void IntPtr_op_Explicit_m1593216315 ();
extern "C" void IntPtr_op_Explicit_m1593085246 ();
extern "C" void IntPtr_op_Explicit_m536245531 ();
extern "C" void Assembly_GetManifestResourceInternal_m1224391897 ();
extern "C" void SafeHandle_DangerousGetHandle_m3697436134 ();
extern "C" void RuntimeFieldHandle_get_Value_m4138444424_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_get_Value_m723997769_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_get_Value_m1525396455_AdjustorThunk ();
extern "C" void RNGCryptoServiceProvider_RngGetBytes_m1695806698 ();
extern "C" void RNGCryptoServiceProvider_RngInitialize_m2025286560 ();
extern "C" void WindowsIdentity_GetCurrentToken_m841791956 ();
extern "C" void Mutex_CreateMutex_internal_m3763633491 ();
extern "C" void NativeEventCalls_CreateEvent_internal_m3212149556 ();
extern "C" void Thread_Thread_internal_m4184414727 ();
extern "C" void WaitHandle_get_Handle_m3260446580 ();
extern "C" void CustomEventData_Internal_Create_m4267220301 ();
extern "C" void UnityAnalyticsHandler_Internal_Create_m852466012 ();
extern "C" void AnimationCurve_Internal_Create_m3956683041 ();
extern "C" void Gradient_Init_m2499008394 ();
extern "C" void Object_GetCachedPtr_m151292858 ();
extern "C" void GcLeaderboard_GcLeaderboard_LoadScores_m4200881954 ();
extern "C" void Context_AllocateDataSlot_m2078817162 ();
extern "C" void Context_AllocateNamedDataSlot_m103537862 ();
extern "C" void Context_GetNamedDataSlot_m2010711813 ();
extern "C" void ClientActivatedIdentity_GetServerObject_m446547394 ();
extern "C" void ClientIdentity_get_ClientProxy_m1281632708 ();
extern "C" void ProxyAttribute_CreateInstance_m1531306115 ();
extern "C" void SingletonIdentity_GetServerObject_m4017943093 ();
extern "C" void MulticastDelegate_KPM_m22863605 ();
extern "C" void ServicePointManager_get_CertificatePolicy_m1966679142 ();
extern "C" void IPAddress_Parse_m2200822423 ();
extern "C" void IPAddress_ParseIPV4_m2273992661 ();
extern "C" void IPAddress_ParseIPV6_m750830007 ();
extern "C" void IPv6Address_Parse_m3004687047 ();
extern "C" void GlobalProxySelection_get_Select_m3427048860 ();
extern "C" void WebRequest_GetDefaultWebProxy_m696404479 ();
extern "C" void WebRequest_get_DefaultWebProxy_m4155870144 ();
extern "C" void ServicePointManager_get_ServerCertificateValidationCallback_m984921647 ();
extern "C" void ServicePointManager_get_SecurityProtocol_m4259357356 ();
extern "C" void HttpWebRequest_GetServicePoint_m2640244283 ();
extern "C" void HttpWebRequest_get_ServicePoint_m1080482337 ();
extern "C" void ServicePointManager_FindServicePoint_m4119451290 ();
extern "C" void IPAddress_get_AddressFamily_m1010663936 ();
extern "C" void FileWebRequestCreator_Create_m987324668 ();
extern "C" void FtpRequestCreator_Create_m3326083364 ();
extern "C" void HttpRequestCreator_Create_m400548686 ();
extern "C" void NumberFormatter_GetClone_m4126883757 ();
extern "C" void NumberFormatter_GetInstance_m971769829 ();
extern "C" void CustomInfo_Parse_m4163382069 ();
extern "C" void CipherSuiteCollection_System_Collections_ICollection_get_SyncRoot_m630394386 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_get_Item_m2175128671 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncState_m431861941 ();
extern "C" void SendRecordAsyncResult_get_AsyncState_m4196194494 ();
extern "C" void InternalAsyncResult_get_AsyncState_m1436290550 ();
extern "C" void PKCS12_Clone_m93617975 ();
extern "C" void PKCS12_Clone_m2085085101 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m418791713 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m1846030361 ();
extern "C" void Activator_CreateInstance_m3631483688 ();
extern "C" void Activator_CreateInstance_m2597605935 ();
extern "C" void Activator_CreateInstance_m94526014 ();
extern "C" void Activator_CreateInstance_m3736402505 ();
extern "C" void Activator_CreateInstance_m2998273980 ();
extern "C" void Activator_CreateInstanceInternal_m1337209899 ();
extern "C" void AppDomain_InitializeLifetimeService_m1122536350 ();
extern "C" void AppDomain_InvokeInDomainByID_m1902345728 ();
extern "C" void SimpleEnumerator_Clone_m1890729616 ();
extern "C" void SimpleEnumerator_get_Current_m72361444 ();
extern "C" void Array_Clone_m2672907798 ();
extern "C" void Array_GetValue_m2528546681 ();
extern "C" void Array_GetValue_m352525925 ();
extern "C" void Array_GetValue_m793801589 ();
extern "C" void Array_GetValue_m120423883 ();
extern "C" void Array_GetValue_m2528415604 ();
extern "C" void Array_GetValue_m4249310555 ();
extern "C" void Array_GetValue_m1062368071 ();
extern "C" void Array_GetValue_m116098292 ();
extern "C" void Array_GetValueImpl_m3048550958 ();
extern "C" void Array_System_Collections_IList_get_Item_m631337679 ();
extern "C" void Array_get_SyncRoot_m1984189992 ();
extern "C" void Boolean_System_IConvertible_ToType_m2078828242_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToType_m2251112646_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToType_m4138905176_AdjustorThunk ();
extern "C" void CharEnumerator_Clone_m1884400089 ();
extern "C" void CharEnumerator_System_Collections_IEnumerator_get_Current_m1328529384 ();
extern "C" void ArrayListWrapper_Clone_m1058391593 ();
extern "C" void ArrayListWrapper_get_Item_m1313829881 ();
extern "C" void ArrayListWrapper_get_SyncRoot_m3460954073 ();
extern "C" void ReadOnlyArrayListWrapper_get_Item_m2341088672 ();
extern "C" void SimpleEnumerator_Clone_m936565740 ();
extern "C" void SimpleEnumerator_get_Current_m2439519409 ();
extern "C" void SynchronizedArrayListWrapper_Clone_m1959734504 ();
extern "C" void SynchronizedArrayListWrapper_get_Item_m4084958564 ();
extern "C" void SynchronizedArrayListWrapper_get_SyncRoot_m3862302789 ();
extern "C" void ArrayList_Clone_m2682741233 ();
extern "C" void ArrayList_get_Item_m3820278660 ();
extern "C" void ArrayList_get_SyncRoot_m2222042655 ();
extern "C" void BitArrayEnumerator_Clone_m2928080346 ();
extern "C" void BitArrayEnumerator_get_Current_m4220391712 ();
extern "C" void BitArray_Clone_m3537018332 ();
extern "C" void BitArray_get_SyncRoot_m680463907 ();
extern "C" void CollectionBase_System_Collections_ICollection_get_SyncRoot_m1463722401 ();
extern "C" void CollectionBase_System_Collections_IList_get_Item_m3743372945 ();
extern "C" void DictionaryEntry_get_Key_m3117378551_AdjustorThunk ();
extern "C" void DictionaryEntry_get_Value_m618120527_AdjustorThunk ();
extern "C" void Enumerator_get_Current_m2763018784 ();
extern "C" void Enumerator_get_Key_m2288024554 ();
extern "C" void Enumerator_get_Value_m1047280424 ();
extern "C" void HashKeys_get_SyncRoot_m3757723936 ();
extern "C" void HashValues_get_SyncRoot_m337642017 ();
extern "C" void SyncHashtable_Clone_m3726939774 ();
extern "C" void SyncHashtable_get_Item_m2686606216 ();
extern "C" void SyncHashtable_get_SyncRoot_m2724224665 ();
extern "C" void Hashtable_Clone_m3078962909 ();
extern "C" void Hashtable_get_Item_m2003685141 ();
extern "C" void Hashtable_get_SyncRoot_m2370273929 ();
extern "C" void QueueEnumerator_Clone_m1475796429 ();
extern "C" void QueueEnumerator_get_Current_m2177760484 ();
extern "C" void Queue_Clone_m178259971 ();
extern "C" void Queue_Dequeue_m2397857002 ();
extern "C" void Queue_Peek_m2705722908 ();
extern "C" void Queue_get_SyncRoot_m3475037374 ();
extern "C" void Enumerator_Clone_m1942171085 ();
extern "C" void Enumerator_get_Current_m3370609987 ();
extern "C" void Enumerator_get_Key_m1796421380 ();
extern "C" void Enumerator_get_Value_m3071982030 ();
extern "C" void SortedList_Clone_m928094797 ();
extern "C" void SortedList_GetByIndex_m3848565786 ();
extern "C" void SortedList_GetImpl_m3689246167 ();
extern "C" void SortedList_get_Item_m3673863299 ();
extern "C" void SortedList_get_SyncRoot_m914428425 ();
extern "C" void HybridDictionary_get_Item_m319681963 ();
extern "C" void HybridDictionary_get_SyncRoot_m1538457321 ();
extern "C" void DictionaryNodeEnumerator_get_Current_m4231688597 ();
extern "C" void DictionaryNodeEnumerator_get_Key_m2267812973 ();
extern "C" void DictionaryNodeEnumerator_get_Value_m1345533116 ();
extern "C" void ListDictionary_get_Item_m1272472363 ();
extern "C" void ListDictionary_get_SyncRoot_m4242825143 ();
extern "C" void KeysCollection_System_Collections_ICollection_get_SyncRoot_m2638728559 ();
extern "C" void _KeysEnumerator_get_Current_m2996478063 ();
extern "C" void NameObjectCollectionBase_BaseGet_m2807961990 ();
extern "C" void NameObjectCollectionBase_BaseGet_m2890420524 ();
extern "C" void NameObjectCollectionBase_System_Collections_ICollection_get_SyncRoot_m138749698 ();
extern "C" void Enumerator_Clone_m1203486474 ();
extern "C" void Enumerator_get_Current_m2520471220 ();
extern "C" void Stack_Clone_m2625073663 ();
extern "C" void Stack_Peek_m2216191248 ();
extern "C" void Stack_Pop_m4248134981 ();
extern "C" void Stack_get_SyncRoot_m2243371357 ();
extern "C" void Convert_ChangeType_m739676612 ();
extern "C" void Convert_ToType_m2406080310 ();
extern "C" void DBNull_System_IConvertible_ToType_m145027518 ();
extern "C" void DateTime_System_IConvertible_ToType_m1242864300_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToType_m2919262279_AdjustorThunk ();
extern "C" void Delegate_Clone_m4001596073 ();
extern "C" void Delegate_get_Target_m2361978888 ();
extern "C" void DelegateSerializationHolder_GetRealObject_m3777783762 ();
extern "C" void Double_System_IConvertible_ToType_m1438630475_AdjustorThunk ();
extern "C" void Enum_Parse_m1579637477 ();
extern "C" void Enum_System_IConvertible_ToType_m2699994218 ();
extern "C" void Enum_ToObject_m1949662789 ();
extern "C" void Enum_ToObject_m3092348831 ();
extern "C" void Enum_ToObject_m2710011811 ();
extern "C" void Enum_ToObject_m1136033697 ();
extern "C" void Enum_ToObject_m1628250250 ();
extern "C" void Enum_ToObject_m26687919 ();
extern "C" void Enum_ToObject_m121962870 ();
extern "C" void Enum_ToObject_m122225012 ();
extern "C" void Enum_ToObject_m121831801 ();
extern "C" void Enum_get_Value_m3943993911 ();
extern "C" void Enum_get_value_m3943994903 ();
extern "C" void Calendar_Clone_m1356182658 ();
extern "C" void CultureInfo_Clone_m2597938387 ();
extern "C" void CultureInfo_GetFormat_m732021304 ();
extern "C" void DateTimeFormatInfo_Clone_m335051388 ();
extern "C" void DateTimeFormatInfo_GetFormat_m3537254402 ();
extern "C" void NumberFormatInfo_Clone_m3276284539 ();
extern "C" void NumberFormatInfo_GetFormat_m1699707893 ();
extern "C" void TextInfo_Clone_m3838580862 ();
extern "C" void FileStreamAsyncResult_get_AsyncState_m3919989221 ();
extern "C" void StreamAsyncResult_get_AsyncState_m3822420114 ();
extern "C" void Int16_System_IConvertible_ToType_m3672347013_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToType_m3009233912_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToType_m3223988955_AdjustorThunk ();
extern "C" void MarshalByRefObject_InitializeLifetimeService_m3972547550 ();
extern "C" void MonoType_InvokeMember_m2156385067 ();
extern "C" void Object_MemberwiseClone_m1474068832 ();
extern "C" void OperatingSystem_Clone_m1122165140 ();
extern "C" void AssemblyName_Clone_m43657973 ();
extern "C" void Default_ChangeType_m1399759417 ();
extern "C" void ConstructorInfo_Invoke_m4089836896 ();
extern "C" void ConstructorBuilder_Invoke_m3979373259 ();
extern "C" void ConstructorBuilder_Invoke_m3010446651 ();
extern "C" void DynamicMethod_Invoke_m1697917514 ();
extern "C" void EnumBuilder_InvokeMember_m2995510206 ();
extern "C" void FieldBuilder_GetValue_m1576493031 ();
extern "C" void GenericTypeParameterBuilder_InvokeMember_m1647304778 ();
extern "C" void MethodBuilder_Invoke_m3837446660 ();
extern "C" void PropertyBuilder_GetValue_m1722444490 ();
extern "C" void PropertyBuilder_GetValue_m3592513194 ();
extern "C" void TypeBuilder_InvokeMember_m713975721 ();
extern "C" void MemberInfoSerializationHolder_GetRealObject_m3590242972 ();
extern "C" void MethodBase_Invoke_m1776411915 ();
extern "C" void MonoCMethod_InternalInvoke_m131287437 ();
extern "C" void MonoCMethod_Invoke_m1340636245 ();
extern "C" void MonoCMethod_Invoke_m2700167622 ();
extern "C" void MonoField_GetValue_m3124733531 ();
extern "C" void MonoField_GetValueInternal_m532651562 ();
extern "C" void MonoMethod_InternalInvoke_m1266143136 ();
extern "C" void MonoMethod_Invoke_m2898011027 ();
extern "C" void GetterAdapter_EndInvoke_m164602429 ();
extern "C" void GetterAdapter_Invoke_m3767885970 ();
extern "C" void MonoProperty_GetValue_m995140552 ();
extern "C" void MonoProperty_GetValue_m2828248678 ();
extern "C" void Pointer_Box_m389276611 ();
extern "C" void PropertyInfo_GetValue_m403181050 ();
extern "C" void TypeDelegator_InvokeMember_m4050724539 ();
extern "C" void ResourceEnumerator_get_Current_m3987005752 ();
extern "C" void ResourceEnumerator_get_Key_m3323042710 ();
extern "C" void ResourceEnumerator_get_Value_m3946340682 ();
extern "C" void ResourceReader_ReadNonPredefinedValue_m2638853518 ();
extern "C" void ResourceReader_ReadValueVer1_m183253382 ();
extern "C" void ResourceReader_ReadValueVer2_m2797880867 ();
extern "C" void ResourceSet_GetObject_m1383205650 ();
extern "C" void ResourceSet_GetObject_m3744937321 ();
extern "C" void ResourceSet_GetObjectInternal_m162983637 ();
extern "C" void RuntimeResourceSet_CloneDisposableObjectIfPossible_m2725520898 ();
extern "C" void RuntimeResourceSet_GetObject_m1236819169 ();
extern "C" void RuntimeResourceSet_GetObject_m2665759398 ();
extern "C" void GCHandle_GetTarget_m1711976502 ();
extern "C" void GCHandle_get_Target_m1824973883_AdjustorThunk ();
extern "C" void ActivationServices_AllocateUninitializedClassInstance_m1640049132 ();
extern "C" void ActivationServices_CreateProxyFromAttributes_m3864561181 ();
extern "C" void RemoteActivator_InitializeLifetimeService_m3335532355 ();
extern "C" void CADSerializer_DeserializeObject_m243132091 ();
extern "C" void ChannelServices_CreateProvider_m2537021726 ();
extern "C" void CrossAppDomainChannel_get_ChannelData_m2094862616 ();
extern "C" void Context_GetData_m2148900675 ();
extern "C" void AsyncResult_get_AsyncDelegate_m3808237550 ();
extern "C" void AsyncResult_get_AsyncState_m2322299153 ();
extern "C" void CADMessageBase_MarshalArgument_m1629674998 ();
extern "C" void CADMessageBase_UnmarshalArgument_m2058572696 ();
extern "C" void CADMethodReturnMessage_GetReturnValue_m2466270334 ();
extern "C" void CallContext_SetCurrentCallContext_m2971462454 ();
extern "C" void CallContextRemotingData_Clone_m14303327 ();
extern "C" void ConstructionCallDictionary_GetMethodProperty_m868507224 ();
extern "C" void ErrorMessage_GetArg_m2320124058 ();
extern "C" void ErrorMessage_get_MethodSignature_m3912515700 ();
extern "C" void HeaderHandler_EndInvoke_m1991538959 ();
extern "C" void HeaderHandler_Invoke_m3513051789 ();
extern "C" void LogicalCallContext_Clone_m1816384810 ();
extern "C" void MethodCall_GetArg_m502890301 ();
extern "C" void MethodCall_get_MethodSignature_m2407904958 ();
extern "C" void DictionaryEnumerator_get_Current_m2769714278 ();
extern "C" void DictionaryEnumerator_get_Key_m2423649820 ();
extern "C" void DictionaryEnumerator_get_Value_m2166220004 ();
extern "C" void MethodDictionary_GetMethodProperty_m3206728418 ();
extern "C" void MethodDictionary_get_Item_m1201458851 ();
extern "C" void MethodDictionary_get_SyncRoot_m518515391 ();
extern "C" void MethodResponse_GetArg_m4250300354 ();
extern "C" void MethodResponse_get_MethodSignature_m3918608730 ();
extern "C" void MethodResponse_get_ReturnValue_m3947544853 ();
extern "C" void MonoMethodMessage_GetArg_m2932717642 ();
extern "C" void MonoMethodMessage_get_MethodSignature_m580784519 ();
extern "C" void MonoMethodMessage_get_ReturnValue_m1500706237 ();
extern "C" void ObjRefSurrogate_SetObjectData_m2217650033 ();
extern "C" void RemotingSurrogate_SetObjectData_m2713731796 ();
extern "C" void ReturnMessage_GetArg_m3510565487 ();
extern "C" void ReturnMessage_get_MethodSignature_m399735125 ();
extern "C" void ReturnMessage_get_ReturnValue_m3976996692 ();
extern "C" void ObjRef_GetRealObject_m2243479605 ();
extern "C" void RealProxy_GetTransparentProxy_m3318846301 ();
extern "C" void RealProxy_InternalGetTransparentProxy_m1765012608 ();
extern "C" void RemotingServices_Connect_m1080129988 ();
extern "C" void RemotingServices_CreateClientProxy_m3886727610 ();
extern "C" void RemotingServices_CreateClientProxy_m809906894 ();
extern "C" void RemotingServices_CreateClientProxyForContextBound_m783705199 ();
extern "C" void RemotingServices_GetProxyForRemoteObject_m1790739297 ();
extern "C" void RemotingServices_GetRemoteObject_m2117098022 ();
extern "C" void RemotingServices_InternalExecute_m1851601664 ();
extern "C" void RemotingServices_Unmarshal_m3744595373 ();
extern "C" void RemotingServices_Unmarshal_m260048024 ();
extern "C" void FormatterConverter_Convert_m1357098163 ();
extern "C" void FormatterServices_GetSafeUninitializedObject_m3890738292 ();
extern "C" void FormatterServices_GetUninitializedObject_m3413592581 ();
extern "C" void BinaryFormatter_Deserialize_m193346007 ();
extern "C" void BinaryFormatter_Deserialize_m1553018041 ();
extern "C" void BinaryFormatter_DeserializeMethodResponse_m1401162302 ();
extern "C" void BinaryFormatter_NoCheckDeserialize_m2274318934 ();
extern "C" void BinaryFormatter_NoCheckDeserializeMethodResponse_m1919376975 ();
extern "C" void MessageFormatter_ReadMethodCall_m2327590823 ();
extern "C" void MessageFormatter_ReadMethodResponse_m1259800219 ();
extern "C" void MessageFormatter_ReadMethodResponse_m1946725361 ();
extern "C" void ObjectReader_ReadBoxedPrimitiveTypeValue_m4086653205 ();
extern "C" void ObjectReader_ReadPrimitiveTypeValue_m4293111728 ();
extern "C" void ObjectReader_get_CurrentObject_m2820303483 ();
extern "C" void ObjectManager_GetObject_m1462343561 ();
extern "C" void SerializationEntry_get_Value_m2039470570_AdjustorThunk ();
extern "C" void SerializationInfo_GetValue_m42271953 ();
extern "C" void SerializationInfoEnumerator_System_Collections_IEnumerator_get_Current_m2029240404 ();
extern "C" void SerializationInfoEnumerator_get_Value_m433044828 ();
extern "C" void StreamingContext_get_Context_m541495931_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToType_m4075253447_AdjustorThunk ();
extern "C" void CryptoConfig_CreateFromName_m1538277313 ();
extern "C" void CryptoConfig_CreateFromName_m2674746512 ();
extern "C" void OidCollection_get_SyncRoot_m3531934854 ();
extern "C" void OidEnumerator_System_Collections_IEnumerator_get_Current_m3426335186 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_get_Current_m352453934 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m4218613192 ();
extern "C" void X509ChainElementCollection_get_SyncRoot_m4174373457 ();
extern "C" void X509ChainElementEnumerator_System_Collections_IEnumerator_get_Current_m1913555061 ();
extern "C" void X509ExtensionCollection_get_SyncRoot_m2667861032 ();
extern "C" void X509ExtensionEnumerator_System_Collections_IEnumerator_get_Current_m2494161059 ();
extern "C" void EvidenceEnumerator_get_Current_m1264365535 ();
extern "C" void Evidence_get_SyncRoot_m2835084965 ();
extern "C" void SecurityException_get_Demanded_m2500043391 ();
extern "C" void Single_System_IConvertible_ToType_m3312441682_AdjustorThunk ();
extern "C" void String_Clone_m3573869765 ();
extern "C" void String_System_IConvertible_ToType_m3431692856 ();
extern "C" void Encoding_Clone_m841706634 ();
extern "C" void Encoding_InvokeI18N_m3098421862 ();
extern "C" void CaptureCollection_get_SyncRoot_m1721113318 ();
extern "C" void GroupCollection_get_SyncRoot_m501373446 ();
extern "C" void Enumerator_get_Current_m359737019 ();
extern "C" void IntervalCollection_get_SyncRoot_m3527457532 ();
extern "C" void MRUList_Evict_m4016329834 ();
extern "C" void Enumerator_System_Collections_IEnumerator_get_Current_m666159028 ();
extern "C" void MatchCollection_get_SyncRoot_m1957585059 ();
extern "C" void PatternLinkStack_GetCurrent_m2744014759 ();
extern "C" void UInt16_System_IConvertible_ToType_m1028622578_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToType_m922356584_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToType_m4049257834_AdjustorThunk ();
extern "C" void UnhandledExceptionEventArgs_get_ExceptionObject_m862578480 ();
extern "C" void UnitySerializationHolder_GetRealObject_m1624354633 ();
extern "C" void Version_Clone_m1749041863 ();
extern "C" void WeakReference_get_Target_m168713953 ();
extern "C" void AnalyticsEventParam_get_value_m2837935290 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3822291412 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m4218891528 ();
extern "C" void TrackableField_GetValue_m4059393238 ();
extern "C" void FieldWithTarget_GetValue_m2315870500 ();
extern "C" void DefaultValueAttribute_get_Value_m3086344020 ();
extern "C" void PlayableBehaviour_Clone_m2851991741 ();
extern "C" void SetupCoroutine_InvokeMember_m2661944898 ();
extern "C" void Enumerator_get_Current_m2591725252 ();
extern "C" void ArrayListWrapper_ToArray_m1192575409 ();
extern "C" void SynchronizedArrayListWrapper_ToArray_m2419932249 ();
extern "C" void ArrayList_ToArray_m3827492363 ();
extern "C" void MonoCustomAttrs_GetCustomAttributes_m1775925192 ();
extern "C" void MonoCustomAttrs_GetCustomAttributes_m1347331976 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesBase_m287804314 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesInternal_m648304078 ();
extern "C" void MonoCustomAttrs_GetPseudoCustomAttributes_m765345333 ();
extern "C" void MonoType_GetCustomAttributes_m164523340 ();
extern "C" void MonoType_GetCustomAttributes_m26060774 ();
extern "C" void Assembly_GetCustomAttributes_m1347362332 ();
extern "C" void ConstructorBuilder_GetCustomAttributes_m2495332786 ();
extern "C" void ConstructorBuilder_GetCustomAttributes_m330373636 ();
extern "C" void DynamicMethod_GetCustomAttributes_m826227141 ();
extern "C" void DynamicMethod_GetCustomAttributes_m179017115 ();
extern "C" void EnumBuilder_GetCustomAttributes_m3678770762 ();
extern "C" void EnumBuilder_GetCustomAttributes_m166600193 ();
extern "C" void FieldBuilder_GetCustomAttributes_m664752430 ();
extern "C" void FieldBuilder_GetCustomAttributes_m1915970159 ();
extern "C" void GenericTypeParameterBuilder_GetCustomAttributes_m386082976 ();
extern "C" void GenericTypeParameterBuilder_GetCustomAttributes_m580748276 ();
extern "C" void MethodBuilder_GetCustomAttributes_m587605549 ();
extern "C" void MethodBuilder_GetCustomAttributes_m731278908 ();
extern "C" void PropertyBuilder_GetCustomAttributes_m3798356764 ();
extern "C" void PropertyBuilder_GetCustomAttributes_m2917594003 ();
extern "C" void TypeBuilder_GetCustomAttributes_m2898560796 ();
extern "C" void TypeBuilder_GetCustomAttributes_m981725999 ();
extern "C" void FieldInfo_GetPseudoCustomAttributes_m3351706050 ();
extern "C" void Module_GetCustomAttributes_m76573271 ();
extern "C" void MonoCMethod_GetCustomAttributes_m3823059477 ();
extern "C" void MonoCMethod_GetCustomAttributes_m3068196335 ();
extern "C" void MonoEvent_GetCustomAttributes_m1729688056 ();
extern "C" void MonoEvent_GetCustomAttributes_m2369459044 ();
extern "C" void MonoField_GetCustomAttributes_m2142838032 ();
extern "C" void MonoField_GetCustomAttributes_m3687140927 ();
extern "C" void MonoMethod_GetCustomAttributes_m3677182122 ();
extern "C" void MonoMethod_GetCustomAttributes_m4130180212 ();
extern "C" void MonoMethod_GetPseudoCustomAttributes_m3959384572 ();
extern "C" void MonoProperty_GetCustomAttributes_m2723308902 ();
extern "C" void MonoProperty_GetCustomAttributes_m3619796755 ();
extern "C" void ParameterInfo_GetCustomAttributes_m2376494592 ();
extern "C" void ParameterInfo_GetPseudoCustomAttributes_m2207478763 ();
extern "C" void TypeDelegator_GetCustomAttributes_m3064730286 ();
extern "C" void TypeDelegator_GetCustomAttributes_m1118628524 ();
extern "C" void ChannelInfo_get_ChannelData_m1060390506 ();
extern "C" void ChannelServices_GetCurrentChannelInfo_m3041604116 ();
extern "C" void ArgInfo_GetInOutArgs_m3837333346 ();
extern "C" void CADMessageBase_MarshalArguments_m1927937746 ();
extern "C" void CADMessageBase_UnmarshalArguments_m1347717101 ();
extern "C" void CADMethodCallMessage_GetArgs_m4253987163 ();
extern "C" void CADMethodReturnMessage_GetArgs_m343322724 ();
extern "C" void ConstructionCall_get_CallSiteActivationAttributes_m3498917408 ();
extern "C" void ErrorMessage_get_Args_m1886173730 ();
extern "C" void MethodCall_get_Args_m148309537 ();
extern "C" void MethodResponse_get_Args_m3774150470 ();
extern "C" void MethodResponse_get_OutArgs_m1057512500 ();
extern "C" void MonoMethodMessage_get_Args_m2110710723 ();
extern "C" void MonoMethodMessage_get_OutArgs_m1742115111 ();
extern "C" void ReturnMessage_get_Args_m398905527 ();
extern "C" void ReturnMessage_get_OutArgs_m1641976511 ();
extern "C" void FormatterServices_GetObjectData_m4284691678 ();
extern "C" void MessageFormatter_GetExtraProperties_m305191653 ();
extern "C" void Type_GetPseudoCustomAttributes_m1069564574 ();
extern "C" void Environment_get_OSVersion_m961136977 ();
extern "C" void Environment_get_Platform_m520224871 ();
extern "C" void OperatingSystem_get_Platform_m2793423729 ();
extern "C" void AppDomain_DoTypeResolve_m1335093328 ();
extern "C" void AppDomain_Load_m4174353770 ();
extern "C" void AppDomain_Load_m2969998014 ();
extern "C" void AppDomain_LoadAssembly_m1557889794 ();
extern "C" void MonoType_get_Assembly_m4290914179 ();
extern "C" void Assembly_GetExecutingAssembly_m4021024968 ();
extern "C" void Assembly_Load_m3487507613 ();
extern "C" void Assembly_LoadWithPartialName_m3387477452 ();
extern "C" void Assembly_LoadWithPartialName_m3225299950 ();
extern "C" void Assembly_LoadWithPartialName_m3378291794 ();
extern "C" void Assembly_load_with_partial_name_m2517830235 ();
extern "C" void EnumBuilder_get_Assembly_m1175292766 ();
extern "C" void GenericTypeParameterBuilder_get_Assembly_m2257222024 ();
extern "C" void TypeBuilder_get_Assembly_m4071790036 ();
extern "C" void Module_get_Assembly_m2485063752 ();
extern "C" void TypeDelegator_get_Assembly_m3283071283 ();
extern "C" void ResolveEventHandler_EndInvoke_m1085261130 ();
extern "C" void ResolveEventHandler_Invoke_m1337322179 ();
extern "C" void SecurityFrame_get_Assembly_m2874566710_AdjustorThunk ();
extern "C" void Assembly_GetName_m2439919985 ();
extern "C" void Assembly_GetName_m981771927 ();
extern "C" void Assembly_UnprotectedGetName_m600830855 ();
extern "C" void AssemblyBuilder_UnprotectedGetName_m4080174862 ();
extern "C" void AssemblyName_get_Flags_m1616840602 ();
extern "C" void Binder_get_DefaultBinder_m950908649 ();
extern "C" void ConstructorBuilder_get_CallingConvention_m3019479360 ();
extern "C" void DynamicMethod_get_CallingConvention_m2686016598 ();
extern "C" void MethodBuilder_get_CallingConvention_m4267439137 ();
extern "C" void MethodBase_get_CallingConvention_m2371784139 ();
extern "C" void MonoCMethod_get_CallingConvention_m1104433355 ();
extern "C" void MonoMethod_get_CallingConvention_m4088809856 ();
extern "C" void MonoMethodInfo_GetCallingConvention_m3156036493 ();
extern "C" void MonoType_GetConstructorImpl_m441167626 ();
extern "C" void MonoType_GetDefaultConstructor_m1616852582 ();
extern "C" void CustomAttributeData_get_Constructor_m489601093 ();
extern "C" void EnumBuilder_GetConstructorImpl_m3068576149 ();
extern "C" void GenericTypeParameterBuilder_GetConstructorImpl_m863833310 ();
extern "C" void TypeBuilder_GetConstructorImpl_m3925526366 ();
extern "C" void TypeDelegator_GetConstructorImpl_m3080184268 ();
extern "C" void Type_GetConstructor_m1195697116 ();
extern "C" void Type_GetConstructor_m950313272 ();
extern "C" void Type_GetConstructor_m2219014380 ();
extern "C" void MonoType_GetConstructors_m2574682189 ();
extern "C" void MonoType_GetConstructors_internal_m2316633399 ();
extern "C" void EnumBuilder_GetConstructors_m3294436155 ();
extern "C" void GenericTypeParameterBuilder_GetConstructors_m1741403645 ();
extern "C" void TypeBuilder_GetConstructors_m26844333 ();
extern "C" void TypeBuilder_GetConstructorsInternal_m3565722264 ();
extern "C" void TypeDelegator_GetConstructors_m2496352484 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesDataInternal_m2195433393 ();
extern "C" void AppDomain_DefineInternalDynamicAssembly_m3889239439 ();
extern "C" void TypeBuilder_DefineConstructor_m2989882735 ();
extern "C" void TypeBuilder_DefineConstructor_m3514391445 ();
extern "C" void TypeBuilder_DefineDefaultConstructor_m2168449784 ();
extern "C" void ConstructorBuilder_GetILGenerator_m1421260830 ();
extern "C" void ConstructorBuilder_GetILGenerator_m1750792206 ();
extern "C" void MethodBuilder_GetILGenerator_m4152496715 ();
extern "C" void MethodBuilder_GetILGenerator_m2421555267 ();
extern "C" void ILGenerator_DefineLabel_m835079392 ();
extern "C" void ILGenerator_DeclareLocal_m191048170 ();
extern "C" void ILGenerator_DeclareLocal_m1660608214 ();
extern "C" void TypeBuilder_DefineMethod_m3408269778 ();
extern "C" void TypeBuilder_DefineMethod_m1997123315 ();
extern "C" void TypeBuilder_DefineMethod_m422510144 ();
extern "C" void ConstructorBuilder_GetToken_m109400720 ();
extern "C" void MethodBuilder_GetToken_m2784098896 ();
extern "C" void AssemblyBuilder_DefineDynamicModule_m1476011641 ();
extern "C" void AssemblyBuilder_DefineDynamicModule_m755027604 ();
extern "C" void OpCode_get_OperandType_m1634816806_AdjustorThunk ();
extern "C" void OpCode_get_StackBehaviourPop_m4250794726_AdjustorThunk ();
extern "C" void OpCode_get_StackBehaviourPush_m986094870_AdjustorThunk ();
extern "C" void ModuleBuilder_GetTokenGenerator_m4177350090 ();
extern "C" void ConstructorBuilder_get_TypeBuilder_m2755629087 ();
extern "C" void ModuleBuilder_DefineType_m3763661967 ();
extern "C" void ModuleBuilder_DefineType_m2262733165 ();
extern "C" void ModuleBuilder_DefineType_m3903640095 ();
extern "C" void ModuleBuilder_GetMaybeNested_m3875745566 ();
extern "C" void ModuleBuilder_search_in_array_m1832733816 ();
extern "C" void ModuleBuilder_search_nested_in_array_m942242794 ();
extern "C" void FieldBuilder_get_UMarshal_m1108254289 ();
extern "C" void FieldInfo_GetUnmanagedMarshal_m1813368915 ();
extern "C" void FieldInfo_get_UMarshal_m1217454798 ();
extern "C" void MonoEvent_get_Attributes_m3048829315 ();
extern "C" void MonoType_GetEvent_m28975240 ();
extern "C" void MonoType_InternalGetEvent_m1130657893 ();
extern "C" void EnumBuilder_GetEvent_m4074915332 ();
extern "C" void GenericTypeParameterBuilder_GetEvent_m1409082535 ();
extern "C" void TypeBuilder_GetEvent_m2166527753 ();
extern "C" void TypeDelegator_GetEvent_m3148520673 ();
extern "C" void FieldBuilder_get_Attributes_m1473479383 ();
extern "C" void MonoField_get_Attributes_m1814015643 ();
extern "C" void MonoType_GetField_m1337309786 ();
extern "C" void EnumBuilder_GetField_m3489745843 ();
extern "C" void GenericTypeParameterBuilder_GetField_m2300277606 ();
extern "C" void TypeBuilder_GetField_m2932767407 ();
extern "C" void FieldInfo_GetFieldFromHandle_m586851985 ();
extern "C" void FieldInfo_internal_from_handle_type_m3256989094 ();
extern "C" void TypeDelegator_GetField_m2897478010 ();
extern "C" void Type_GetField_m2961003358 ();
extern "C" void MonoType_GetFields_m4176012508 ();
extern "C" void MonoType_GetFields_internal_m776921855 ();
extern "C" void EnumBuilder_GetFields_m151883523 ();
extern "C" void GenericTypeParameterBuilder_GetFields_m292751540 ();
extern "C" void TypeBuilder_GetFields_m2518194342 ();
extern "C" void TypeDelegator_GetFields_m1661146203 ();
extern "C" void MonoCustomAttrs_GetBase_m624536374 ();
extern "C" void ParameterInfo_get_Member_m3284376465 ();
extern "C" void FormatterServices_GetSerializableMembers_m3934333240 ();
extern "C" void MonoType_get_MemberType_m4261270584 ();
extern "C" void ConstructorInfo_get_MemberType_m2297974335 ();
extern "C" void EventInfo_get_MemberType_m2405145162 ();
extern "C" void FieldInfo_get_MemberType_m143061680 ();
extern "C" void MethodInfo_get_MemberType_m3442377339 ();
extern "C" void PropertyInfo_get_MemberType_m2794839864 ();
extern "C" void Type_get_MemberType_m1631050582 ();
extern "C" void ConstructorBuilder_get_Attributes_m1598011285 ();
extern "C" void DynamicMethod_get_Attributes_m2260783207 ();
extern "C" void MethodBuilder_get_Attributes_m2740229145 ();
extern "C" void MonoCMethod_get_Attributes_m757768605 ();
extern "C" void MonoMethod_get_Attributes_m1519794451 ();
extern "C" void MonoMethodInfo_GetAttributes_m2458894713 ();
extern "C" void StackFrame_GetMethod_m1395840764 ();
extern "C" void MonoType_CheckMethodSecurity_m576144504 ();
extern "C" void Default_BindToMethod_m490530316 ();
extern "C" void Default_GetBetterMethod_m3232777160 ();
extern "C" void Default_SelectMethod_m3090153711 ();
extern "C" void Default_SelectMethod_m469311730 ();
extern "C" void Binder_FindMostDerivedMatch_m239579024 ();
extern "C" void MethodBase_GetMethodFromHandle_m286788163 ();
extern "C" void MethodBase_GetMethodFromHandleInternalType_m2695073734 ();
extern "C" void MethodBase_GetMethodFromHandleNoGenericCheck_m1262206995 ();
extern "C" void MethodBase_GetMethodFromIntPtr_m3014201362 ();
extern "C" void CADMethodCallMessage_GetMethod_m1779242604 ();
extern "C" void ErrorMessage_get_MethodBase_m2501437782 ();
extern "C" void MethodCall_get_MethodBase_m550047245 ();
extern "C" void MethodResponse_get_MethodBase_m513691916 ();
extern "C" void MonoMethodMessage_get_MethodBase_m2884727594 ();
extern "C" void ReturnMessage_get_MethodBase_m2391555884 ();
extern "C" void RemotingServices_FindInterfaceMethod_m2125212568 ();
extern "C" void RemotingServices_GetMethodBaseFromMethodMessage_m383468467 ();
extern "C" void RemotingServices_GetMethodBaseFromName_m3194612939 ();
extern "C" void RemotingServices_GetVirtualMethod_m3786317812 ();
extern "C" void Delegate_GetCandidateMethod_m640765260 ();
extern "C" void Delegate_get_Method_m3071622864 ();
extern "C" void MonoType_GetMethodImpl_m3558076162 ();
extern "C" void DynamicMethod_GetBaseDefinition_m2593491625 ();
extern "C" void EnumBuilder_GetMethodImpl_m3968140917 ();
extern "C" void GenericTypeParameterBuilder_GetMethodImpl_m1665936690 ();
extern "C" void MethodBuilder_GetBaseDefinition_m3391685745 ();
extern "C" void MethodBuilder_MakeGenericMethod_m2175748754 ();
extern "C" void PropertyBuilder_GetGetMethod_m1844574876 ();
extern "C" void PropertyBuilder_GetSetMethod_m128670376 ();
extern "C" void TypeBuilder_GetMethodImpl_m3583143647 ();
extern "C" void MethodInfo_MakeGenericMethod_m1996785325 ();
extern "C" void MonoEvent_GetAddMethod_m210217252 ();
extern "C" void MonoMethod_GetBaseDefinition_m2844667474 ();
extern "C" void MonoMethod_MakeGenericMethod_m1386790968 ();
extern "C" void MonoMethod_MakeGenericMethod_impl_m1719465708 ();
extern "C" void MonoProperty_GetGetMethod_m2489912362 ();
extern "C" void MonoProperty_GetSetMethod_m527596913 ();
extern "C" void PropertyInfo_GetGetMethod_m1510309854 ();
extern "C" void TypeDelegator_GetMethodImpl_m725915800 ();
extern "C" void Type_GetMethod_m2019726356 ();
extern "C" void Type_GetMethod_m1197120913 ();
extern "C" void Type_GetMethod_m1512604930 ();
extern "C" void Type_GetMethod_m637078096 ();
extern "C" void Type_GetMethod_m1479779718 ();
extern "C" void Type_GetMethodImplInternal_m2670548906 ();
extern "C" void UnityEvent_FindMethod_Impl_m2312362624 ();
extern "C" void UnityEventBase_FindMethod_m3366332957 ();
extern "C" void UnityEventBase_FindMethod_m622251156 ();
extern "C" void UnityEventBase_GetValidMethodInfo_m3989987635 ();
extern "C" void NetFxCoreExtensions_GetMethodInfo_m444570327 ();
extern "C" void MonoType_GetMethods_m3840584467 ();
extern "C" void MonoType_GetMethodsByName_m2005909471 ();
extern "C" void EnumBuilder_GetMethods_m415781370 ();
extern "C" void GenericTypeParameterBuilder_GetMethods_m2360745671 ();
extern "C" void PropertyBuilder_GetAccessors_m3962192052 ();
extern "C" void TypeBuilder_GetMethods_m455544206 ();
extern "C" void TypeBuilder_GetMethodsByName_m1441669940 ();
extern "C" void MonoProperty_GetAccessors_m412928203 ();
extern "C" void TypeDelegator_GetMethods_m911682671 ();
extern "C" void MonoType_get_Module_m2397868165 ();
extern "C" void Assembly_GetModule_m3867448062 ();
extern "C" void ConstructorBuilder_get_Module_m1709295866 ();
extern "C" void DynamicMethod_get_Module_m12989615 ();
extern "C" void EnumBuilder_get_Module_m3038920337 ();
extern "C" void FieldBuilder_get_Module_m1102715255 ();
extern "C" void GenericTypeParameterBuilder_get_Module_m1433762073 ();
extern "C" void MethodBuilder_get_Module_m2693263127 ();
extern "C" void PropertyBuilder_get_Module_m4024354932 ();
extern "C" void TypeBuilder_get_Module_m4154269895 ();
extern "C" void MemberInfo_get_Module_m4119009657 ();
extern "C" void TypeDelegator_get_Module_m402693140 ();
extern "C" void Assembly_GetModules_m4157408231 ();
extern "C" void Assembly_GetModulesInternal_m3569974584 ();
extern "C" void AssemblyBuilder_GetModulesInternal_m1170927462 ();
extern "C" void MonoEventInfo_GetEventInfo_m873645389 ();
extern "C" void MonoField_Clone_m3669042226 ();
extern "C" void MonoMethod_get_base_definition_m282872694 ();
extern "C" void MonoMethodInfo_GetMethodInfo_m2481349296 ();
extern "C" void MonoProperty_CreateGetterDelegate_m2478402519 ();
extern "C" void ParameterInfo_get_Attributes_m1582734594 ();
extern "C" void ConstructorBuilder_GetParameters_m1348730871 ();
extern "C" void ConstructorBuilder_GetParametersInternal_m2039842762 ();
extern "C" void DynamicMethod_GetParameters_m2873920314 ();
extern "C" void MethodBuilder_GetParameters_m3527753207 ();
extern "C" void PropertyBuilder_GetIndexParameters_m2501163646 ();
extern "C" void MonoCMethod_GetParameters_m3596508252 ();
extern "C" void MonoMethod_GetParameters_m2077150731 ();
extern "C" void MonoMethodInfo_GetParametersInfo_m2209427166 ();
extern "C" void MonoMethodInfo_get_parameter_info_m1729015241 ();
extern "C" void MonoProperty_GetIndexParameters_m440199833 ();
extern "C" void PropertyBuilder_get_Attributes_m466033853 ();
extern "C" void MonoProperty_get_Attributes_m1632795078 ();
extern "C" void MonoCustomAttrs_GetBasePropertyDefinition_m1562543378 ();
extern "C" void MonoType_GetPropertyImpl_m1327032087 ();
extern "C" void Default_SelectProperty_m1220817815 ();
extern "C" void EnumBuilder_GetPropertyImpl_m569583507 ();
extern "C" void GenericTypeParameterBuilder_GetPropertyImpl_m2584778600 ();
extern "C" void TypeBuilder_GetPropertyImpl_m3104345782 ();
extern "C" void TypeDelegator_GetPropertyImpl_m656398553 ();
extern "C" void Type_GetProperty_m3414567179 ();
extern "C" void Type_GetProperty_m4206634422 ();
extern "C" void Type_GetProperty_m3294104835 ();
extern "C" void Type_GetProperty_m2732503739 ();
extern "C" void Type_GetProperty_m2258969843 ();
extern "C" void Type_GetPropertyImplInternal_m2444270063 ();
extern "C" void MonoType_GetPropertiesByName_m2491778142 ();
extern "C" void AssemblyName_get_KeyPair_m4000803163 ();
extern "C" void MonoType_GetAttributeFlagsImpl_m167182975 ();
extern "C" void MonoType_get_attributes_m1332507727 ();
extern "C" void EnumBuilder_GetAttributeFlagsImpl_m2708654755 ();
extern "C" void GenericTypeParameterBuilder_GetAttributeFlagsImpl_m2144850054 ();
extern "C" void TypeBuilder_GetAttributeFlagsImpl_m2729077290 ();
extern "C" void TypeDelegator_GetAttributeFlagsImpl_m2642839032 ();
extern "C" void Type_get_Attributes_m58528356 ();
extern "C" void Win32Resource_get_ResourceType_m1654432376 ();
extern "C" void MonoMethod_GetDllImportAttribute_m853324018 ();
extern "C" void GCHandle_Alloc_m3823409740 ();
extern "C" void UnmanagedMarshal_ToMarshalAsAttribute_m3182194847 ();
extern "C" void RemotingConfiguration_IsRemotelyActivatedClientType_m4117048589 ();
extern "C" void ActivationServices_get_ConstructionActivator_m1239151545 ();
extern "C" void AppDomainLevelActivator_get_NextActivator_m2892367069 ();
extern "C" void ConstructionLevelActivator_get_NextActivator_m815517039 ();
extern "C" void ContextLevelActivator_get_NextActivator_m3456480201 ();
extern "C" void RemoteActivator_get_NextActivator_m31954545 ();
extern "C" void ConstructionCall_get_Activator_m2234315252 ();
extern "C" void AppDomainLevelActivator_Activate_m1419028841 ();
extern "C" void ConstructionLevelActivator_Activate_m1875520998 ();
extern "C" void ContextLevelActivator_Activate_m1196612728 ();
extern "C" void RemoteActivator_Activate_m3917386814 ();
extern "C" void CrossAppDomainSink_GetSink_m1351608552 ();
extern "C" void CrossAppDomainSink_ProcessMessageInDomain_m3657983318 ();
extern "C" void RemotingServices_CreateClientActivatedServerIdentity_m3488968707 ();
extern "C" void RemotingServices_CreateContextBoundObjectIdentity_m978835616 ();
extern "C" void RemotingServices_GetOrCreateClientIdentity_m648299611 ();
extern "C" void AppDomain_InternalGetContext_m114897961 ();
extern "C" void AppDomain_InternalGetDefaultContext_m1679027951 ();
extern "C" void AppDomain_InternalSetContext_m139827955 ();
extern "C" void Context_CreateNewContext_m3053563976 ();
extern "C" void Context_SwitchToContext_m1475712852 ();
extern "C" void Context_get_DefaultContext_m2041247543 ();
extern "C" void ServerIdentity_get_Context_m1732876343 ();
extern "C" void Thread_get_CurrentContext_m1695017876 ();
extern "C" void ChannelServices_get_CrossContextChannel_m2544947561 ();
extern "C" void Context_GetDynamicPropertyCollection_m3657471357 ();
extern "C" void Identity_get_ClientDynamicProperties_m60531821 ();
extern "C" void Identity_get_ServerDynamicProperties_m1517273532 ();
extern "C" void ActivatedClientTypeEntry_get_ContextAttributes_m4017563407 ();
extern "C" void Context_GetProperty_m3204855576 ();
extern "C" void Context_get_ContextProperties_m3283598326 ();
extern "C" void ObjRef_get_ChannelInfo_m434196038 ();
extern "C" void ObjRef_get_EnvoyInfo_m1782007847 ();
extern "C" void ObjRef_get_TypeInfo_m1614059810 ();
extern "C" void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m3106215723 ();
extern "C" void MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m3291545427 ();
extern "C" void MonoMethodMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m929239303 ();
extern "C" void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m2936584507 ();
extern "C" void RealProxy_get_ObjectIdentity_m2790771985 ();
extern "C" void RemotingServices_GetIdentityForUri_m2001974121 ();
extern "C" void RemotingServices_GetMessageTargetIdentity_m1302164612 ();
extern "C" void ServerIdentity_get_Lease_m2153931427 ();
extern "C" void Lease_get_CurrentState_m2210872233 ();
extern "C" void MonoMethodMessage_get_AsyncResult_m3874702476 ();
extern "C" void CADMethodCallMessage_Create_m3871584080 ();
extern "C" void CADMethodReturnMessage_Create_m691563714 ();
extern "C" void MonoMethodMessage_get_CallType_m3702481004 ();
extern "C" void ActivationServices_CreateConstructionCall_m2894682304 ();
extern "C" void ActivationServices_CreateInstanceFromMessage_m2493847255 ();
extern "C" void ActivationServices_RemoteActivate_m3345439282 ();
extern "C" void CADSerializer_DeserializeMessage_m4131058444 ();
extern "C" void ChannelServices_CheckReturnMessage_m42854321 ();
extern "C" void ChannelServices_SyncDispatchMessage_m1259812344 ();
extern "C" void CrossAppDomainSink_SyncProcessMessage_m2599866017 ();
extern "C" void ClientActivatedIdentity_SyncObjectProcessMessage_m2838343040 ();
extern "C" void ContextRestoreSink_SyncProcessMessage_m1014797578 ();
extern "C" void CrossContextChannel_SyncProcessMessage_m130533374 ();
extern "C" void SynchronizedClientContextSink_SyncProcessMessage_m2605077513 ();
extern "C" void SynchronizedContextReplySink_SyncProcessMessage_m3077458053 ();
extern "C" void SynchronizedServerContextSink_SyncProcessMessage_m395228665 ();
extern "C" void DisposerReplySink_SyncProcessMessage_m2432481672 ();
extern "C" void LeaseSink_SyncProcessMessage_m3942566741 ();
extern "C" void AsyncResult_EndInvoke_m2943900386 ();
extern "C" void AsyncResult_GetReplyMessage_m2321330725 ();
extern "C" void AsyncResult_SyncProcessMessage_m2334986884 ();
extern "C" void ClientContextReplySink_SyncProcessMessage_m2049760216 ();
extern "C" void ClientContextTerminatorSink_SyncProcessMessage_m432234354 ();
extern "C" void EnvoyTerminatorSink_SyncProcessMessage_m3404100686 ();
extern "C" void ServerContextTerminatorSink_SyncProcessMessage_m3762853959 ();
extern "C" void ServerObjectReplySink_SyncProcessMessage_m512968558 ();
extern "C" void ServerObjectTerminatorSink_SyncProcessMessage_m2085589766 ();
extern "C" void StackBuilderSink_SyncProcessMessage_m1218070084 ();
extern "C" void RemotingProxy_Invoke_m1410974208 ();
extern "C" void SingleCallIdentity_SyncObjectProcessMessage_m1937976823 ();
extern "C" void SingletonIdentity_SyncObjectProcessMessage_m2934017657 ();
extern "C" void CrossAppDomainSink_AsyncProcessMessage_m4214688566 ();
extern "C" void ClientActivatedIdentity_AsyncObjectProcessMessage_m195435417 ();
extern "C" void ContextRestoreSink_AsyncProcessMessage_m280611108 ();
extern "C" void CrossContextChannel_AsyncProcessMessage_m3361381761 ();
extern "C" void SynchronizedClientContextSink_AsyncProcessMessage_m3574843998 ();
extern "C" void SynchronizedContextReplySink_AsyncProcessMessage_m591479608 ();
extern "C" void SynchronizedServerContextSink_AsyncProcessMessage_m3545264767 ();
extern "C" void DisposerReplySink_AsyncProcessMessage_m614392448 ();
extern "C" void LeaseSink_AsyncProcessMessage_m2450477097 ();
extern "C" void AsyncResult_AsyncProcessMessage_m2076471000 ();
extern "C" void ClientContextReplySink_AsyncProcessMessage_m4062537038 ();
extern "C" void ClientContextTerminatorSink_AsyncProcessMessage_m980226669 ();
extern "C" void EnvoyTerminatorSink_AsyncProcessMessage_m3017446614 ();
extern "C" void ServerContextTerminatorSink_AsyncProcessMessage_m2674040571 ();
extern "C" void ServerObjectReplySink_AsyncProcessMessage_m1580266605 ();
extern "C" void ServerObjectTerminatorSink_AsyncProcessMessage_m3445474816 ();
extern "C" void StackBuilderSink_AsyncProcessMessage_m4112015303 ();
extern "C" void SingleCallIdentity_AsyncObjectProcessMessage_m1739361290 ();
extern "C" void SingletonIdentity_AsyncObjectProcessMessage_m1982295016 ();
extern "C" void ChannelServices_CreateClientChannelSinkChain_m1795214139 ();
extern "C" void ChannelServices_CreateClientChannelSinkChain_m3117081582 ();
extern "C" void CrossAppDomainChannel_CreateMessageSink_m3655964231 ();
extern "C" void Context_CreateEnvoySink_m3365634710 ();
extern "C" void Context_CreateServerObjectSinkChain_m1209471584 ();
extern "C" void Context_GetClientContextSinkChain_m2136947545 ();
extern "C" void Context_GetServerContextSinkChain_m3154465897 ();
extern "C" void SynchronizationAttribute_GetClientContextSink_m2797862094 ();
extern "C" void SynchronizationAttribute_GetServerContextSink_m2864017660 ();
extern "C" void EnvoyInfo_get_EnvoySinks_m1211050346 ();
extern "C" void Identity_get_ChannelSink_m3905420913 ();
extern "C" void Identity_get_EnvoySink_m1643114474 ();
extern "C" void AsyncResult_get_NextSink_m1844209137 ();
extern "C" void RemotingServices_GetClientChannelSinkChain_m1499550585 ();
extern "C" void RemotingServices_InternalExecuteMessage_m311230144 ();
extern "C" void CADMessageBase_GetLogicalCallContext_m3861983492 ();
extern "C" void CallContext_CreateLogicalCallContext_m4045492885 ();
extern "C" void ErrorMessage_get_LogicalCallContext_m597698035 ();
extern "C" void MethodCall_get_LogicalCallContext_m555393702 ();
extern "C" void MethodResponse_get_LogicalCallContext_m3456939940 ();
extern "C" void MonoMethodMessage_get_LogicalCallContext_m2835676725 ();
extern "C" void ReturnMessage_get_LogicalCallContext_m2352570297 ();
extern "C" void AsyncResult_get_CallMessage_m1679778649 ();
extern "C" void ChannelServices_CheckIncomingMessage_m1297157039 ();
extern "C" void InternalRemotingServices_GetCachedSoapAttribute_m1042302982 ();
extern "C" void MarshalByRefObject_CreateObjRef_m2444885068 ();
extern "C" void ClientIdentity_CreateObjRef_m3373052626 ();
extern "C" void RemotingServices_Marshal_m98061768 ();
extern "C" void RemotingServices_Marshal_m3646189857 ();
extern "C" void ServerIdentity_CreateObjRef_m3435315642 ();
extern "C" void ConfigHandler_ReadProvider_m3620509535 ();
extern "C" void ProxyAttribute_CreateProxy_m2826946776 ();
extern "C" void RemotingServices_GetRealProxy_m2081098851 ();
extern "C" void ConstructionCall_get_SourceProxy_m1712998109 ();
extern "C" void MarshalByRefObject_get_ObjectIdentity_m186877036 ();
extern "C" void RemotingServices_CreateWellKnownServerIdentity_m1170328801 ();
extern "C" void WellKnownServiceTypeEntry_get_Mode_m514401854 ();
extern "C" void ObjectReader_ReadTypeMetadata_m3785645385 ();
extern "C" void ObjectWriter_CreateMemberTypeMetadata_m577610186 ();
extern "C" void ObjectWriter_GetTypeTag_m1892768509 ();
extern "C" void BinaryFormatter_get_FilterLevel_m1292975963 ();
extern "C" void RemotingSurrogateSelector_GetSurrogate_m3900875713 ();
extern "C" void BinaryFormatter_get_DefaultSurrogateSelector_m3548531270 ();
extern "C" void BinaryFormatter_get_SurrogateSelector_m2111882017 ();
extern "C" void ObjectManager_GetObjectRecord_m1104835114 ();
extern "C" void BinaryFormatter_get_Binder_m166854567 ();
extern "C" void SerializationCallbacks_GetSerializationCallbacks_m2939476649 ();
extern "C" void SerializationInfoEnumerator_get_Current_m1365373082 ();
extern "C" void SerializationInfo_GetEnumerator_m1082663843 ();
extern "C" void BinaryFormatter_get_Context_m1651087560 ();
extern "C" void StreamingContext_get_State_m3338773567_AdjustorThunk ();
extern "C" void FieldBuilder_get_FieldHandle_m535167546 ();
extern "C" void MonoField_get_FieldHandle_m3729647377 ();
extern "C" void ConstructorBuilder_get_MethodHandle_m3934509563 ();
extern "C" void DynamicMethod_get_MethodHandle_m2498039394 ();
extern "C" void MethodBuilder_get_MethodHandle_m565241742 ();
extern "C" void MonoCMethod_get_MethodHandle_m3757890674 ();
extern "C" void MonoMethod_get_MethodHandle_m4198555269 ();
extern "C" void MonoType_get_TypeHandle_m1012024438 ();
extern "C" void EnumBuilder_get_TypeHandle_m825995360 ();
extern "C" void GenericTypeParameterBuilder_get_TypeHandle_m366353680 ();
extern "C" void TypeBuilder_get_TypeHandle_m3498565307 ();
extern "C" void TypeDelegator_get_TypeHandle_m1498852405 ();
extern "C" void Type_GetTypeHandle_m1526957577 ();
extern "C" void Type_get_TypeHandle_m160082026 ();
extern "C" void Boolean_System_IConvertible_ToSByte_m806999_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToSByte_m1869482168_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToSByte_m973063527_AdjustorThunk ();
extern "C" void Convert_ToSByte_m3284376536 ();
extern "C" void Convert_ToSByte_m717245755 ();
extern "C" void Convert_ToSByte_m1350241137 ();
extern "C" void Convert_ToSByte_m2991657475 ();
extern "C" void Convert_ToSByte_m3796870839 ();
extern "C" void Convert_ToSByte_m2653680449 ();
extern "C" void Convert_ToSByte_m2653418303 ();
extern "C" void Convert_ToSByte_m2653811524 ();
extern "C" void Convert_ToSByte_m4061885981 ();
extern "C" void Convert_ToSByte_m3472794164 ();
extern "C" void Convert_ToSByte_m4075629912 ();
extern "C" void Convert_ToSByte_m516918950 ();
extern "C" void Convert_ToSByte_m2486156346 ();
extern "C" void Convert_ToSByte_m1679390684 ();
extern "C" void DBNull_System_IConvertible_ToSByte_m3533624679 ();
extern "C" void DateTime_System_IConvertible_ToSByte_m4130251280_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToSByte_m1299038473_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m1824467517 ();
extern "C" void Double_System_IConvertible_ToSByte_m341638588_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToSByte_m779472798 ();
extern "C" void BinaryReader_ReadSByte_m3736742795 ();
extern "C" void Int16_System_IConvertible_ToSByte_m4128424691_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToSByte_m3133688512_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToSByte_m267591194_AdjustorThunk ();
extern "C" void SByte_Parse_m2899090751 ();
extern "C" void SByte_Parse_m3250497834 ();
extern "C" void SByte_System_IConvertible_ToSByte_m2452868086_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToSByte_m1208276900_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToSByte_m945078350 ();
extern "C" void UInt16_System_IConvertible_ToSByte_m2219828332_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToSByte_m1061556466_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToSByte_m30962591_AdjustorThunk ();
extern "C" void X509BasicConstraintsExtension_Decode_m120598446 ();
extern "C" void X509EnhancedKeyUsageExtension_Decode_m3726500073 ();
extern "C" void X509KeyUsageExtension_Decode_m3150759625 ();
extern "C" void X509SubjectKeyIdentifierExtension_Decode_m1505409124 ();
extern "C" void PublicKey_get_EncodedKeyValue_m199315148 ();
extern "C" void PublicKey_get_EncodedParameters_m4197029957 ();
extern "C" void HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1202173386 ();
extern "C" void PrivateKeySelectionCallback_EndInvoke_m2229365437 ();
extern "C" void PrivateKeySelectionCallback_Invoke_m921844982 ();
extern "C" void SslClientStream_OnLocalPrivateKeySelection_m1934775249 ();
extern "C" void SslClientStream_RaisePrivateKeySelection_m3394190501 ();
extern "C" void SslStreamBase_RaiseLocalPrivateKeySelection_m4112368540 ();
extern "C" void PublicKey_get_Key_m3077215602 ();
extern "C" void X509Certificate2_get_PrivateKey_m450647294 ();
extern "C" void CipherSuite_get_CipherMode_m425550365 ();
extern "C" void SymmetricAlgorithm_get_Mode_m654054760 ();
extern "C" void KeyPairPersistence_Copy_m2577206651 ();
extern "C" void CspParameters_get_Flags_m4238672607 ();
extern "C" void DES_Create_m1258183099 ();
extern "C" void DES_Create_m2166467748 ();
extern "C" void PrivateKeyInfo_DecodeDSA_m771724585 ();
extern "C" void PrivateKeyInfo_DecodeDSA_m2335813142 ();
extern "C" void X509Certificate_get_DSA_m2644963799 ();
extern "C" void X509Certificate_get_DSA_m1760272844 ();
extern "C" void DSA_Create_m1220983153 ();
extern "C" void DSA_Create_m2559649673 ();
extern "C" void PublicKey_DecodeDSA_m3490622362 ();
extern "C" void DSAManaged_ExportParameters_m1426347745 ();
extern "C" void PKCS12_GetExistingParameters_m3511027613 ();
extern "C" void PKCS12_GetExistingParameters_m3446652479 ();
extern "C" void DSACryptoServiceProvider_ExportParameters_m591135777 ();
extern "C" void HMAC_Create_m2390117573 ();
extern "C" void HMAC_Create_m2148924157 ();
extern "C" void HashAlgorithm_Create_m644612360 ();
extern "C" void ARC4Managed_CreateDecryptor_m1966583816 ();
extern "C" void ARC4Managed_CreateEncryptor_m2249585492 ();
extern "C" void CipherSuite_get_DecryptionCipher_m2839827488 ();
extern "C" void CipherSuite_get_EncryptionCipher_m3029637613 ();
extern "C" void AesManaged_CreateDecryptor_m752875210 ();
extern "C" void AesManaged_CreateDecryptor_m692040246 ();
extern "C" void AesManaged_CreateEncryptor_m1611897367 ();
extern "C" void AesManaged_CreateEncryptor_m2294080233 ();
extern "C" void DESCryptoServiceProvider_CreateDecryptor_m3245980552 ();
extern "C" void DESCryptoServiceProvider_CreateEncryptor_m2830855064 ();
extern "C" void RC2CryptoServiceProvider_CreateDecryptor_m3810731330 ();
extern "C" void RC2CryptoServiceProvider_CreateEncryptor_m1615052595 ();
extern "C" void RijndaelManaged_CreateDecryptor_m1421727258 ();
extern "C" void RijndaelManaged_CreateEncryptor_m263736311 ();
extern "C" void SymmetricAlgorithm_CreateDecryptor_m3477646776 ();
extern "C" void SymmetricAlgorithm_CreateEncryptor_m617415315 ();
extern "C" void TripleDESCryptoServiceProvider_CreateDecryptor_m740960117 ();
extern "C" void TripleDESCryptoServiceProvider_CreateEncryptor_m450924958 ();
extern "C" void SymmetricAlgorithm_get_LegalKeySizes_m1340766361 ();
extern "C" void CipherSuite_get_ClientHMAC_m377589750 ();
extern "C" void CipherSuite_get_ServerHMAC_m714506854 ();
extern "C" void MD5_Create_m3522414168 ();
extern "C" void MD5_Create_m3289886172 ();
extern "C" void AsnEncodedData_get_Oid_m402887164 ();
extern "C" void OidCollection_get_Item_m984725507 ();
extern "C" void PublicKey_get_Oid_m2056027242 ();
extern "C" void X509Certificate2_get_SignatureAlgorithm_m2810155907 ();
extern "C" void SymmetricAlgorithm_get_Padding_m1011382560 ();
extern "C" void RC2_Create_m2516417038 ();
extern "C" void RC2_Create_m2052783340 ();
extern "C" void CryptoConvert_FromCapiKeyBlob_m2655899792 ();
extern "C" void CryptoConvert_FromCapiKeyBlob_m1201868338 ();
extern "C" void CryptoConvert_FromCapiPrivateKeyBlob_m73613828 ();
extern "C" void CryptoConvert_FromCapiPublicKeyBlob_m184006806 ();
extern "C" void CryptoConvert_FromCapiPublicKeyBlob_m4073029974 ();
extern "C" void PrivateKeyInfo_DecodeRSA_m2889346634 ();
extern "C" void PrivateKeyInfo_DecodeRSA_m4129124827 ();
extern "C" void TlsClientCertificateVerify_getClientCertRSA_m1205662940 ();
extern "C" void TlsServerSettings_get_CertificateRSA_m597274968 ();
extern "C" void X509Certificate_get_RSA_m1755006809 ();
extern "C" void StrongNameKeyPair_GetRSA_m2008774769 ();
extern "C" void RSA_Create_m4065275734 ();
extern "C" void RSA_Create_m2021570897 ();
extern "C" void PublicKey_DecodeRSA_m1824703659 ();
extern "C" void RSAManaged_ExportParameters_m1754454264 ();
extern "C" void RSAManaged_ExportParameters_m280454101 ();
extern "C" void TlsServerSettings_get_RsaParameters_m2264301690 ();
extern "C" void RSACryptoServiceProvider_ExportParameters_m3871179960 ();
extern "C" void BigInteger_get_Rng_m3283260184 ();
extern "C" void BigInteger_get_Rng_m4216817480 ();
extern "C" void DSAManaged_get_Random_m923751780 ();
extern "C" void KeyBuilder_get_Rng_m1353817187 ();
extern "C" void KeyBuilder_get_Rng_m983065666 ();
extern "C" void KeyBuilder_get_Rng_m3373220441 ();
extern "C" void PKCS12_get_RNG_m2649456600 ();
extern "C" void PKCS12_get_RNG_m64541056 ();
extern "C" void RandomNumberGenerator_Create_m4162970280 ();
extern "C" void RandomNumberGenerator_Create_m2019689173 ();
extern "C" void Rijndael_Create_m3053077028 ();
extern "C" void Rijndael_Create_m1026182146 ();
extern "C" void SHA1_Create_m1390871308 ();
extern "C" void SHA1_Create_m2934697039 ();
extern "C" void SHA256_Create_m610202894 ();
extern "C" void SHA256_Create_m697467885 ();
extern "C" void SHA384_Create_m3237405884 ();
extern "C" void SHA384_Create_m1745173416 ();
extern "C" void SHA512_Create_m3934606971 ();
extern "C" void SHA512_Create_m3236870067 ();
extern "C" void PKCS12_GetSymmetricAlgorithm_m3480654844 ();
extern "C" void PKCS12_GetSymmetricAlgorithm_m1390440284 ();
extern "C" void SymmetricAlgorithm_Create_m2726390826 ();
extern "C" void TripleDES_Create_m3761371613 ();
extern "C" void TripleDES_Create_m2471273334 ();
extern "C" void X509Certificate2_get_PublicKey_m370665820 ();
extern "C" void X509Certificate2_get_IssuerName_m1277209535 ();
extern "C" void X509Certificate2_get_SubjectName_m2588317215 ();
extern "C" void CertificateSelectionCallback_EndInvoke_m916047629 ();
extern "C" void CertificateSelectionCallback_Invoke_m3129973019 ();
extern "C" void TlsClientCertificate_FindParentCertificate_m3844441401 ();
extern "C" void TlsClientCertificate_get_ClientCertificate_m1637836254 ();
extern "C" void HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2058474197 ();
extern "C" void SslClientStream_OnLocalCertificateSelection_m205226847 ();
extern "C" void SslClientStream_RaiseClientCertificateSelection_m3936211295 ();
extern "C" void SslClientStream_get_SelectedClientCertificate_m2941927287 ();
extern "C" void SslStreamBase_RaiseLocalCertificateSelection_m980106471 ();
extern "C" void SslStreamBase_get_ServerCertificate_m656316972 ();
extern "C" void TlsClientSettings_get_ClientCertificate_m3139459118 ();
extern "C" void X509CertificateEnumerator_get_Current_m364341970 ();
extern "C" void X509CertificateCollection_get_Item_m1177942658 ();
extern "C" void X509Certificate2Collection_get_Item_m1658740919 ();
extern "C" void X509Certificate2Enumerator_get_Current_m157909321 ();
extern "C" void X509Chain_FindParent_m1515820563 ();
extern "C" void X509Chain_SelectBestFromCollection_m1068759221 ();
extern "C" void X509ChainElement_get_Certificate_m2801643215 ();
extern "C" void X509Certificate2Collection_Find_m4007010753 ();
extern "C" void X509Chain_get_CertificateCollection_m511297491 ();
extern "C" void X509ChainPolicy_get_ExtraStore_m4191377387 ();
extern "C" void X509Store_get_Certificates_m2149701265 ();
extern "C" void X509Certificate2Collection_GetEnumerator_m3634416032 ();
extern "C" void SslClientStream_get_ClientCertificates_m998716871 ();
extern "C" void TlsClientSettings_get_Certificates_m2671943654 ();
extern "C" void X509CertificateCollection_GetEnumerator_m1686475779 ();
extern "C" void X509ChainElementCollection_get_Item_m1978766852 ();
extern "C" void X509ChainElementEnumerator_get_Current_m1301774989 ();
extern "C" void X509ChainElementCollection_GetEnumerator_m2610805770 ();
extern "C" void X509Chain_get_ChainPolicy_m2586552721 ();
extern "C" void X509Chain_BuildChainFrom_m2265372442 ();
extern "C" void X509Chain_CheckRevocation_m4216573099 ();
extern "C" void X509Chain_CheckRevocation_m3466271023 ();
extern "C" void X509ChainElement_get_StatusFlags_m3731832204 ();
extern "C" void X509ChainStatus_get_Status_m2572005749_AdjustorThunk ();
extern "C" void X509ChainElement_get_ChainElementStatus_m2982250012 ();
extern "C" void X509ExtensionCollection_get_Item_m3637880514 ();
extern "C" void X509ExtensionEnumerator_get_Current_m256207749 ();
extern "C" void X509Certificate2_get_Extensions_m3552930730 ();
extern "C" void X509ExtensionCollection_GetEnumerator_m3371013144 ();
extern "C" void X509KeyUsageExtension_GetValidFlags_m3447294145 ();
extern "C" void X509KeyUsageExtension_get_KeyUsages_m3263859785 ();
extern "C" void X509ChainPolicy_get_RevocationFlag_m3767879093 ();
extern "C" void X509ChainPolicy_get_RevocationMode_m3118822552 ();
extern "C" void X509Chain_get_CertificateAuthorities_m804805415 ();
extern "C" void X509Chain_get_Roots_m317091712 ();
extern "C" void X509ChainPolicy_get_VerificationFlags_m58569326 ();
extern "C" void SecurityException_get_FirstPermissionThatFailed_m3934559164 ();
extern "C" void PermissionSet_CreateFromBinaryFormat_m3762234240 ();
extern "C" void SecurityManager_Decode_m2551103128 ();
extern "C" void SecurityManager_Decode_m84973736 ();
extern "C" void SecurityPermission_Cast_m2392017566 ();
extern "C" void StrongName_get_PublicKey_m46076020 ();
extern "C" void SecurityContext_Capture_m1047743382 ();
extern "C" void ExecutionContext_get_SecurityContext_m1232420339 ();
extern "C" void SecurityParser_ToXml_m3880004309 ();
extern "C" void CodeAccessPermission_Element_m4280812549 ();
extern "C" void SecurityPermission_ToXml_m355131433 ();
extern "C" void SecurityElement_SearchForChildByTag_m900466299 ();
extern "C" void SecurityElement_GetAttribute_m3347489583 ();
extern "C" void BitConverterLE_ToSingle_m1153793442 ();
extern "C" void Boolean_System_IConvertible_ToSingle_m1524606222_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToSingle_m324484566_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToSingle_m2690985411_AdjustorThunk ();
extern "C" void Convert_ToSingle_m1386109941 ();
extern "C" void Convert_ToSingle_m2769033141 ();
extern "C" void Convert_ToSingle_m1389817074 ();
extern "C" void Convert_ToSingle_m3227075028 ();
extern "C" void Convert_ToSingle_m4033824286 ();
extern "C" void Convert_ToSingle_m3635698920 ();
extern "C" void Convert_ToSingle_m2891972375 ();
extern "C" void Convert_ToSingle_m3605848385 ();
extern "C" void Convert_ToSingle_m164367433 ();
extern "C" void Convert_ToSingle_m835189399 ();
extern "C" void Convert_ToSingle_m2533452644 ();
extern "C" void Convert_ToSingle_m3600812843 ();
extern "C" void Convert_ToSingle_m3983149863 ();
extern "C" void Convert_ToSingle_m2791508777 ();
extern "C" void DBNull_System_IConvertible_ToSingle_m13713620 ();
extern "C" void DateTime_System_IConvertible_ToSingle_m2193708681_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToSingle_m1019108991_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m3488287464 ();
extern "C" void Double_System_IConvertible_ToSingle_m4088557181_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToSingle_m1234919892 ();
extern "C" void BinaryReader_ReadSingle_m3384287259 ();
extern "C" void Int16_System_IConvertible_ToSingle_m3569332870_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToSingle_m896140682_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToSingle_m1368636517_AdjustorThunk ();
extern "C" void Math_Abs_m3353607971 ();
extern "C" void SByte_System_IConvertible_ToSingle_m1083054891_AdjustorThunk ();
extern "C" void Single_Parse_m3840407583 ();
extern "C" void Single_System_IConvertible_ToSingle_m1939829239_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToSingle_m2571483125 ();
extern "C" void UInt16_System_IConvertible_ToSingle_m2654722405_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToSingle_m1272823424_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToSingle_m925613075_AdjustorThunk ();
extern "C" void EventTrigger_get_initTime_m3511193067 ();
extern "C" void EventTrigger_get_repeatTime_m1602140789 ();
extern "C" void AudioListener_ReadExtensionPropertyValue_m2443832840 ();
extern "C" void AudioListenerExtension_ReadExtensionProperty_m3059773029 ();
extern "C" void AudioSource_ReadExtensionPropertyValue_m72717540 ();
extern "C" void AudioSourceExtension_ReadExtensionProperty_m2693120442 ();
extern "C" void Camera_get_farClipPlane_m538536689 ();
extern "C" void Camera_get_nearClipPlane_m837839537 ();
extern "C" void ArgumentCache_get_floatArgument_m3471193103 ();
extern "C" void Mathf_Abs_m3281243566 ();
extern "C" void Mathf_Max_m3146388979 ();
extern "C" void Rect_get_height_m1358425599_AdjustorThunk ();
extern "C" void Rect_get_width_m3421484486_AdjustorThunk ();
extern "C" void Rect_get_x_m3839990490_AdjustorThunk ();
extern "C" void Rect_get_xMax_m3018144503_AdjustorThunk ();
extern "C" void Rect_get_xMin_m581135837_AdjustorThunk ();
extern "C" void Rect_get_y_m1501338330_AdjustorThunk ();
extern "C" void Rect_get_yMax_m743455479_AdjustorThunk ();
extern "C" void Rect_get_yMin_m2601414109_AdjustorThunk ();
extern "C" void Vector3_SqrMagnitude_m3025115945 ();
extern "C" void Locale_GetText_m3875126938 ();
extern "C" void Locale_GetText_m3374010885 ();
extern "C" void Locale_GetText_m1626635120 ();
extern "C" void Locale_GetText_m3520169047 ();
extern "C" void Locale_GetText_m1601577974 ();
extern "C" void Locale_GetText_m2640320736 ();
extern "C" void Locale_GetText_m2427493201 ();
extern "C" void BigInteger_ToString_m3927393477 ();
extern "C" void BigInteger_ToString_m3278248272 ();
extern "C" void BigInteger_ToString_m3260066955 ();
extern "C" void BigInteger_ToString_m570257729 ();
extern "C" void BigInteger_ToString_m3475000413 ();
extern "C" void BigInteger_ToString_m1181683046 ();
extern "C" void Runtime_GetDisplayName_m2773861196 ();
extern "C" void ASN1_ToString_m45458043 ();
extern "C" void ASN1_ToString_m1340204511 ();
extern "C" void ASN1Convert_ToOid_m3847701408 ();
extern "C" void ASN1Convert_ToOid_m1223840396 ();
extern "C" void CryptoConvert_ToHex_m4034982758 ();
extern "C" void KeyPairPersistence_ToXml_m812591779 ();
extern "C" void KeyPairPersistence_get_ContainerName_m4274536094 ();
extern "C" void KeyPairPersistence_get_Filename_m2760692036 ();
extern "C" void KeyPairPersistence_get_KeyValue_m2994490605 ();
extern "C" void KeyPairPersistence_get_MachinePath_m3812267291 ();
extern "C" void KeyPairPersistence_get_UserPath_m610275969 ();
extern "C" void EncryptedPrivateKeyInfo_get_Algorithm_m2142585301 ();
extern "C" void EncryptedPrivateKeyInfo_get_Algorithm_m3027828440 ();
extern "C" void RSAManaged_ToXmlString_m2369501989 ();
extern "C" void RSAManaged_ToXmlString_m645792083 ();
extern "C" void ContentInfo_get_ContentType_m4018261807 ();
extern "C" void ContentInfo_get_ContentType_m275324816 ();
extern "C" void Alert_GetAlertMessage_m1942367141 ();
extern "C" void CipherSuite_get_HashAlgorithmName_m3758129154 ();
extern "C" void CipherSuite_get_Name_m1137568068 ();
extern "C" void ClientSessionInfo_get_HostName_m2118440995 ();
extern "C" void TlsClientSettings_get_TargetHost_m2463481414 ();
extern "C" void StrongName_get_TokenAlgorithm_m1794722022 ();
extern "C" void AuthorityKeyIdentifierExtension_ToString_m1643863557 ();
extern "C" void BasicConstraintsExtension_ToString_m2170556997 ();
extern "C" void ExtendedKeyUsageExtension_ToString_m2116504780 ();
extern "C" void GeneralNames_ToString_m489778282 ();
extern "C" void KeyUsageExtension_ToString_m3134109315 ();
extern "C" void NetscapeCertTypeExtension_ToString_m1800688476 ();
extern "C" void SubjectAltNameExtension_ToString_m3628154311 ();
extern "C" void SafeBag_get_BagOID_m2165567310 ();
extern "C" void SafeBag_get_BagOID_m2153399743 ();
extern "C" void X501_ToString_m2260475203 ();
extern "C" void X501_ToString_m4186311521 ();
extern "C" void X501_ToString_m3840057611 ();
extern "C" void X501_ToString_m2278029064 ();
extern "C" void X509Certificate_get_IssuerName_m605048065 ();
extern "C" void X509Certificate_get_IssuerName_m47554030 ();
extern "C" void X509Certificate_get_KeyAlgorithm_m3935660380 ();
extern "C" void X509Certificate_get_SignatureAlgorithm_m122054440 ();
extern "C" void X509Certificate_get_SubjectName_m3871411396 ();
extern "C" void X509Certificate_get_SubjectName_m3160893681 ();
extern "C" void X509Crl_GetHashName_m4214678741 ();
extern "C" void X509Crl_get_IssuerName_m552696835 ();
extern "C" void X509Extension_ToString_m3664524823 ();
extern "C" void X509Extension_ToString_m3727002866 ();
extern "C" void X509Extension_get_Oid_m1003388288 ();
extern "C" void AttrListImpl_GetName_m2880551319 ();
extern "C" void AttrListImpl_GetValue_m3657391095 ();
extern "C" void AttrListImpl_GetValue_m215192361 ();
extern "C" void SmallXmlParser_ReadName_m3409228522 ();
extern "C" void SmallXmlParser_ReadUntil_m2715581630 ();
extern "C" void AppDomain_GetProcessGuid_m3316193837 ();
extern "C" void AppDomain_InternalGetProcessGuid_m1352630171 ();
extern "C" void AppDomain_ToString_m1389451889 ();
extern "C" void AppDomain_getFriendlyName_m248495153 ();
extern "C" void ApplicationIdentity_ToString_m2074887951 ();
extern "C" void ArgumentException_get_Message_m520762021 ();
extern "C" void ArgumentException_get_ParamName_m2556126651 ();
extern "C" void ArgumentOutOfRangeException_get_Message_m1913926628 ();
extern "C" void BitConverter_ToString_m3464863163 ();
extern "C" void BitConverter_ToString_m3439099539 ();
extern "C" void Boolean_ToString_m2664721875_AdjustorThunk ();
extern "C" void Boolean_ToString_m663098404_AdjustorThunk ();
extern "C" void Byte_ToString_m721125428_AdjustorThunk ();
extern "C" void Byte_ToString_m2335342258_AdjustorThunk ();
extern "C" void Byte_ToString_m3735479648_AdjustorThunk ();
extern "C" void Byte_ToString_m4063101981_AdjustorThunk ();
extern "C" void Char_ToString_m3588025615_AdjustorThunk ();
extern "C" void Char_ToString_m954857583 ();
extern "C" void Char_ToString_m278452217_AdjustorThunk ();
extern "C" void FixedSizeArrayListWrapper_get_ErrorMessage_m3049061776 ();
extern "C" void ReadOnlyArrayListWrapper_get_ErrorMessage_m1121552994 ();
extern "C" void NameObjectCollectionBase_BaseGetKey_m2677971642 ();
extern "C" void NameValueCollection_AsSingleString_m3776180906 ();
extern "C" void NameValueCollection_Get_m2464480741 ();
extern "C" void NameValueCollection_GetKey_m3458770877 ();
extern "C" void TypeConverterAttribute_get_ConverterTypeName_m2038465322 ();
extern "C" void Convert_ToBase64String_m3839334935 ();
extern "C" void Convert_ToBase64String_m1959325926 ();
extern "C" void Convert_ToString_m2219349533 ();
extern "C" void Convert_ToString_m1854379141 ();
extern "C" void DBNull_ToString_m3638608738 ();
extern "C" void DBNull_ToString_m1318017576 ();
extern "C" void DateTime_ToString_m884486936_AdjustorThunk ();
extern "C" void DateTime_ToString_m1916142975_AdjustorThunk ();
extern "C" void DateTime_ToString_m2992030064_AdjustorThunk ();
extern "C" void DateTimeOffset_ToString_m3536563014_AdjustorThunk ();
extern "C" void DateTimeOffset_ToString_m3985341516_AdjustorThunk ();
extern "C" void DateTimeUtils_GetStandardPattern_m728910817 ();
extern "C" void DateTimeUtils_GetStandardPattern_m813010822 ();
extern "C" void DateTimeUtils_ToString_m1782212840 ();
extern "C" void DateTimeUtils_ToString_m93951406 ();
extern "C" void Decimal_ToString_m4018746482_AdjustorThunk ();
extern "C" void Decimal_ToString_m3653216873_AdjustorThunk ();
extern "C" void Decimal_ToString_m1815393864_AdjustorThunk ();
extern "C" void Decimal_ToString_m14270257_AdjustorThunk ();
extern "C" void Decimal_stripStyles_m1823381019 ();
extern "C" void StackFrame_GetFileName_m3683503392 ();
extern "C" void StackFrame_GetInternalMethodName_m1232559961 ();
extern "C" void StackFrame_GetSecureFileName_m1124504902 ();
extern "C" void StackFrame_ToString_m431970945 ();
extern "C" void StackTrace_ToString_m1758556626 ();
extern "C" void Double_ToString_m1229922074_AdjustorThunk ();
extern "C" void Double_ToString_m3828879243_AdjustorThunk ();
extern "C" void Double_ToString_m1051753975_AdjustorThunk ();
extern "C" void Enum_Format_m2588135982 ();
extern "C" void Enum_FormatFlags_m102703041 ();
extern "C" void Enum_FormatSpecifier_X_m2932245600 ();
extern "C" void Enum_GetName_m2151614395 ();
extern "C" void Enum_ToString_m2240012010 ();
extern "C" void Enum_ToString_m3124963174 ();
extern "C" void Enum_ToString_m2477889358 ();
extern "C" void Enum_ToString_m3248653065 ();
extern "C" void Environment_GetEnvironmentVariable_m394552009 ();
extern "C" void Environment_GetFolderPath_m327623990 ();
extern "C" void Environment_GetMachineConfigPath_m43519138 ();
extern "C" void Environment_GetOSVersionString_m407782784 ();
extern "C" void Environment_GetWindowsFolderPath_m1738399646 ();
extern "C" void Environment_InternalGetFolderPath_m468390978 ();
extern "C" void Environment_ReadXdgUserDir_m2654856189 ();
extern "C" void Environment_get_NewLine_m3211016485 ();
extern "C" void Environment_internalGetEnvironmentVariable_m3668851860 ();
extern "C" void Environment_internalGetHome_m2575860206 ();
extern "C" void Exception_ToString_m1413572637 ();
extern "C" void Exception_get_ClassName_m2428844642 ();
extern "C" void Exception_get_Message_m3320461627 ();
extern "C" void Exception_get_Source_m2777609286 ();
extern "C" void Exception_get_StackTrace_m1954706653 ();
extern "C" void CompareInfo_ToString_m2684143229 ();
extern "C" void CultureInfo_ToString_m2909304639 ();
extern "C" void CultureInfo_get_IcuName_m2258611679 ();
extern "C" void CultureInfo_get_Name_m3662098416 ();
extern "C" void CultureInfo_get_Territory_m3971126713 ();
extern "C" void DateTimeFormatInfo_GetAbbreviatedDayName_m1307320526 ();
extern "C" void DateTimeFormatInfo_GetAbbreviatedMonthName_m364480624 ();
extern "C" void DateTimeFormatInfo_GetDayName_m2279787668 ();
extern "C" void DateTimeFormatInfo_GetEraName_m3151483707 ();
extern "C" void DateTimeFormatInfo_GetMonthName_m2034512315 ();
extern "C" void DateTimeFormatInfo_get_AMDesignator_m1610196743 ();
extern "C" void DateTimeFormatInfo_get_DateSeparator_m3346695364 ();
extern "C" void DateTimeFormatInfo_get_FullDateTimePattern_m2611794812 ();
extern "C" void DateTimeFormatInfo_get_LongDatePattern_m2180875608 ();
extern "C" void DateTimeFormatInfo_get_LongTimePattern_m1595254249 ();
extern "C" void DateTimeFormatInfo_get_MonthDayPattern_m4068069839 ();
extern "C" void DateTimeFormatInfo_get_PMDesignator_m1609519124 ();
extern "C" void DateTimeFormatInfo_get_RFC1123Pattern_m1428703602 ();
extern "C" void DateTimeFormatInfo_get_RoundtripPattern_m796050488 ();
extern "C" void DateTimeFormatInfo_get_ShortDatePattern_m2502330401 ();
extern "C" void DateTimeFormatInfo_get_ShortTimePattern_m453440268 ();
extern "C" void DateTimeFormatInfo_get_SortableDateTimePattern_m1596151441 ();
extern "C" void DateTimeFormatInfo_get_TimeSeparator_m1179730581 ();
extern "C" void DateTimeFormatInfo_get_UniversalSortableDateTimePattern_m205892812 ();
extern "C" void DateTimeFormatInfo_get_YearMonthPattern_m2258041482 ();
extern "C" void NumberFormatInfo_get_CurrencyDecimalSeparator_m2685056987 ();
extern "C" void NumberFormatInfo_get_CurrencyGroupSeparator_m1514324779 ();
extern "C" void NumberFormatInfo_get_CurrencySymbol_m5935691 ();
extern "C" void NumberFormatInfo_get_NaNSymbol_m2562844481 ();
extern "C" void NumberFormatInfo_get_NegativeInfinitySymbol_m3630938097 ();
extern "C" void NumberFormatInfo_get_NegativeSign_m2757109362 ();
extern "C" void NumberFormatInfo_get_NumberDecimalSeparator_m33502788 ();
extern "C" void NumberFormatInfo_get_NumberGroupSeparator_m3292795925 ();
extern "C" void NumberFormatInfo_get_PerMilleSymbol_m1360140831 ();
extern "C" void NumberFormatInfo_get_PercentDecimalSeparator_m2449367000 ();
extern "C" void NumberFormatInfo_get_PercentGroupSeparator_m1849673260 ();
extern "C" void NumberFormatInfo_get_PercentSymbol_m2021660345 ();
extern "C" void NumberFormatInfo_get_PositiveInfinitySymbol_m1141345134 ();
extern "C" void NumberFormatInfo_get_PositiveSign_m240350949 ();
extern "C" void RegionInfo_ToString_m1243674882 ();
extern "C" void RegionInfo_get_CurrencyEnglishName_m1706473630 ();
extern "C" void RegionInfo_get_CurrencyNativeName_m2071178612 ();
extern "C" void RegionInfo_get_CurrencySymbol_m1879783455 ();
extern "C" void RegionInfo_get_DisplayName_m3679349812 ();
extern "C" void RegionInfo_get_EnglishName_m4080324067 ();
extern "C" void RegionInfo_get_ISOCurrencySymbol_m441808484 ();
extern "C" void RegionInfo_get_Name_m834510569 ();
extern "C" void RegionInfo_get_NativeName_m2676336050 ();
extern "C" void RegionInfo_get_ThreeLetterISORegionName_m3727404172 ();
extern "C" void RegionInfo_get_ThreeLetterWindowsRegionName_m3055965132 ();
extern "C" void RegionInfo_get_TwoLetterISORegionName_m168656244 ();
extern "C" void SortKey_ToString_m3992814724 ();
extern "C" void SortKey_get_OriginalString_m1428586816 ();
extern "C" void TextInfo_ToLower_m2989196362 ();
extern "C" void TextInfo_ToString_m3431897261 ();
extern "C" void TextInfo_get_CultureName_m3892243949 ();
extern "C" void TextInfo_get_ListSeparator_m1628160079 ();
extern "C" void Guid_BaseToString_m3600006650_AdjustorThunk ();
extern "C" void Guid_ToString_m3279186591_AdjustorThunk ();
extern "C" void Guid_ToString_m4056316049_AdjustorThunk ();
extern "C" void Guid_ToString_m2120285561_AdjustorThunk ();
extern "C" void BinaryReader_ReadString_m2204259855 ();
extern "C" void Directory_GetCurrentDirectory_m219218555 ();
extern "C" void DirectoryInfo_ToString_m330992229 ();
extern "C" void FileLoadException_ToString_m2989457882 ();
extern "C" void FileLoadException_get_Message_m1316268913 ();
extern "C" void FileNotFoundException_ToString_m3487423565 ();
extern "C" void FileNotFoundException_get_Message_m2807351025 ();
extern "C" void FileStream_GetSecureFileName_m449783930 ();
extern "C" void FileStream_GetSecureFileName_m2419304749 ();
extern "C" void FileSystemInfo_get_FullName_m3468398407 ();
extern "C" void MonoIO_GetCurrentDirectory_m762333289 ();
extern "C" void Path_CanonicalizePath_m620086118 ();
extern "C" void Path_CleanPath_m3974596557 ();
extern "C" void Path_Combine_m3389272516 ();
extern "C" void Path_GetDirectoryName_m3496866581 ();
extern "C" void Path_GetExtension_m1021339115 ();
extern "C" void Path_GetFileName_m1354558116 ();
extern "C" void Path_GetFullPath_m4142135635 ();
extern "C" void Path_GetPathRoot_m3499444155 ();
extern "C" void Path_GetServerAndShare_m2640882202 ();
extern "C" void Path_InsecureGetFullPath_m129101154 ();
extern "C" void Path_WindowsDriveAdjustment_m3256426255 ();
extern "C" void NullStreamReader_ReadLine_m1951583843 ();
extern "C" void NullStreamReader_ReadToEnd_m785591460 ();
extern "C" void StreamReader_ReadLine_m1468498645 ();
extern "C" void StreamReader_ReadToEnd_m371831293 ();
extern "C" void StringReader_ReadLine_m2337102945 ();
extern "C" void StringReader_ReadToEnd_m2679201613 ();
extern "C" void SynchronizedReader_ReadLine_m2411238064 ();
extern "C" void SynchronizedReader_ReadToEnd_m2160105378 ();
extern "C" void NullTextReader_ReadLine_m2308083993 ();
extern "C" void TextReader_ReadLine_m2549275032 ();
extern "C" void TextReader_ReadToEnd_m2648397074 ();
extern "C" void UnexceptionalStreamReader_ReadLine_m3663173848 ();
extern "C" void UnexceptionalStreamReader_ReadToEnd_m920589220 ();
extern "C" void Int16_ToString_m1270547562_AdjustorThunk ();
extern "C" void Int16_ToString_m2013897809_AdjustorThunk ();
extern "C" void Int16_ToString_m2072232391_AdjustorThunk ();
extern "C" void Int16_ToString_m1931491687_AdjustorThunk ();
extern "C" void Int32_ToString_m141394615_AdjustorThunk ();
extern "C" void Int32_ToString_m1760361794_AdjustorThunk ();
extern "C" void Int32_ToString_m372259452_AdjustorThunk ();
extern "C" void Int32_ToString_m2507389746_AdjustorThunk ();
extern "C" void Int64_ToString_m2986581816_AdjustorThunk ();
extern "C" void Int64_ToString_m623640997_AdjustorThunk ();
extern "C" void Int64_ToString_m414616559_AdjustorThunk ();
extern "C" void Int64_ToString_m2085073918_AdjustorThunk ();
extern "C" void IntPtr_ToString_m1831665121_AdjustorThunk ();
extern "C" void IntPtr_ToString_m900170569_AdjustorThunk ();
extern "C" void MissingFieldException_get_Message_m2809639043 ();
extern "C" void MissingMemberException_get_Message_m54658002 ();
extern "C" void MissingMethodException_get_Message_m3161775487 ();
extern "C" void MonoType_ToString_m2539641183 ();
extern "C" void MonoType_getFullName_m837685882 ();
extern "C" void MonoType_get_AssemblyQualifiedName_m2662925380 ();
extern "C" void MonoType_get_FullName_m3242181132 ();
extern "C" void MonoType_get_Name_m1751720248 ();
extern "C" void MonoType_get_Namespace_m2015358851 ();
extern "C" void IPAddress_ToString_m1181734207 ();
extern "C" void IPAddress_ToString_m3532415717 ();
extern "C" void IPv6Address_ToString_m568854716 ();
extern "C" void IPv6Address_ToString_m3978087033 ();
extern "C" void WebHeaderCollection_Get_m3921484261 ();
extern "C" void WebHeaderCollection_GetKey_m809097130 ();
extern "C" void WebHeaderCollection_ToString_m1263025316 ();
extern "C" void CustomInfo_Format_m1134896917 ();
extern "C" void NumberFormatter_FastIntegerToString_m390846811 ();
extern "C" void NumberFormatter_FormatCurrency_m2103540116 ();
extern "C" void NumberFormatter_FormatCustom_m1169507039 ();
extern "C" void NumberFormatter_FormatDecimal_m1921932981 ();
extern "C" void NumberFormatter_FormatExponential_m1436810062 ();
extern "C" void NumberFormatter_FormatExponential_m2139559983 ();
extern "C" void NumberFormatter_FormatFixedPoint_m2462948217 ();
extern "C" void NumberFormatter_FormatGeneral_m1667527152 ();
extern "C" void NumberFormatter_FormatHexadecimal_m2994610679 ();
extern "C" void NumberFormatter_FormatNumber_m1763569482 ();
extern "C" void NumberFormatter_FormatPercent_m270780421 ();
extern "C" void NumberFormatter_FormatRoundtrip_m1288785273 ();
extern "C" void NumberFormatter_FormatRoundtrip_m19342689 ();
extern "C" void NumberFormatter_IntegerToString_m1679294587 ();
extern "C" void NumberFormatter_NumberToString_m2966570377 ();
extern "C" void NumberFormatter_NumberToString_m1790947760 ();
extern "C" void NumberFormatter_NumberToString_m2562899600 ();
extern "C" void NumberFormatter_NumberToString_m567544656 ();
extern "C" void NumberFormatter_NumberToString_m3726402804 ();
extern "C" void NumberFormatter_NumberToString_m655666043 ();
extern "C" void NumberFormatter_NumberToString_m1373805200 ();
extern "C" void NumberFormatter_NumberToString_m827252518 ();
extern "C" void NumberFormatter_NumberToString_m4048866862 ();
extern "C" void NumberFormatter_NumberToString_m803024566 ();
extern "C" void NumberFormatter_NumberToString_m406010816 ();
extern "C" void NumberFormatter_NumberToString_m2481532188 ();
extern "C" void NumberFormatter_NumberToString_m2583974918 ();
extern "C" void NumberFormatter_NumberToString_m2529982306 ();
extern "C" void NumberFormatter_NumberToString_m264078176 ();
extern "C" void NumberFormatter_NumberToString_m1906030517 ();
extern "C" void NumberFormatter_NumberToString_m400339820 ();
extern "C" void NumberFormatter_NumberToString_m3906556024 ();
extern "C" void Object_ToString_m1740002499 ();
extern "C" void ObjectDisposedException_get_Message_m1666887471 ();
extern "C" void OperatingSystem_ToString_m3445473725 ();
extern "C" void Assembly_GetCodeBase_m2422053712 ();
extern "C" void Assembly_ToString_m2053237013 ();
extern "C" void Assembly_get_FullName_m293988418 ();
extern "C" void Assembly_get_Location_m3857174850 ();
extern "C" void Assembly_get_code_base_m282368939 ();
extern "C" void Assembly_get_fullname_m3421330653 ();
extern "C" void Assembly_get_location_m3128831763 ();
extern "C" void AssemblyName_ToString_m11651758 ();
extern "C" void AssemblyName_get_FullName_m3351492191 ();
extern "C" void AssemblyName_get_Name_m4072373679 ();
extern "C" void CustomAttributeData_ToString_m1995965208 ();
extern "C" void CustomAttributeNamedArgument_ToString_m1488801416_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_ToString_m864948362_AdjustorThunk ();
extern "C" void DefaultMemberAttribute_get_MemberName_m3384235354 ();
extern "C" void AssemblyBuilder_get_AssemblyDir_m1938411035 ();
extern "C" void AssemblyBuilder_get_Location_m384539722 ();
extern "C" void ConstructorBuilder_ToString_m1596813917 ();
extern "C" void ConstructorBuilder_get_Name_m2426555260 ();
extern "C" void DynamicMethod_ToString_m2710486086 ();
extern "C" void DynamicMethod_get_Name_m1287905 ();
extern "C" void EnumBuilder_get_AssemblyQualifiedName_m3542375588 ();
extern "C" void EnumBuilder_get_FullName_m86524873 ();
extern "C" void EnumBuilder_get_Name_m4016811629 ();
extern "C" void EnumBuilder_get_Namespace_m931779410 ();
extern "C" void FieldBuilder_get_Name_m510046506 ();
extern "C" void GenericTypeParameterBuilder_ToString_m2460043372 ();
extern "C" void GenericTypeParameterBuilder_get_AssemblyQualifiedName_m2323022482 ();
extern "C" void GenericTypeParameterBuilder_get_FullName_m4098525591 ();
extern "C" void GenericTypeParameterBuilder_get_Name_m1181273062 ();
extern "C" void GenericTypeParameterBuilder_get_Namespace_m2056767826 ();
extern "C" void MethodBuilder_ToString_m561658744 ();
extern "C" void MethodBuilder_get_Name_m610453823 ();
extern "C" void ModuleBuilder_get_FileName_m2155150858 ();
extern "C" void OpCode_ToString_m4248967054_AdjustorThunk ();
extern "C" void OpCode_get_Name_m149707431_AdjustorThunk ();
extern "C" void ParameterBuilder_get_Name_m4047684794 ();
extern "C" void PropertyBuilder_get_Name_m117186655 ();
extern "C" void TypeBuilder_GetFullName_m92522820 ();
extern "C" void TypeBuilder_ToString_m3497908325 ();
extern "C" void TypeBuilder_get_AssemblyQualifiedName_m4059714567 ();
extern "C" void TypeBuilder_get_FullName_m420272554 ();
extern "C" void TypeBuilder_get_Name_m1525921477 ();
extern "C" void TypeBuilder_get_Namespace_m4175323609 ();
extern "C" void LocalVariableInfo_ToString_m2552653929 ();
extern "C" void Module_ToString_m2471617896 ();
extern "C" void Module_get_Name_m1373448298 ();
extern "C" void Module_get_ScopeName_m4152486041 ();
extern "C" void MonoCMethod_ToString_m3992577062 ();
extern "C" void MonoCMethod_get_Name_m3090866252 ();
extern "C" void MonoEvent_ToString_m2145104522 ();
extern "C" void MonoEvent_get_Name_m3774595291 ();
extern "C" void MonoField_ToString_m2518484388 ();
extern "C" void MonoField_get_Name_m2861402224 ();
extern "C" void MonoMethod_ToString_m3550677523 ();
extern "C" void MonoMethod_get_Name_m3372146751 ();
extern "C" void MonoMethod_get_name_m2690633670 ();
extern "C" void MonoProperty_ToString_m3100929865 ();
extern "C" void MonoProperty_get_Name_m3049728465 ();
extern "C" void ParameterInfo_ToString_m2002405990 ();
extern "C" void ParameterInfo_get_Name_m3739685559 ();
extern "C" void TypeDelegator_get_AssemblyQualifiedName_m907578895 ();
extern "C" void TypeDelegator_get_FullName_m369652946 ();
extern "C" void TypeDelegator_get_Name_m690019205 ();
extern "C" void TypeDelegator_get_Namespace_m2110525994 ();
extern "C" void NameOrId_ToString_m1694085646 ();
extern "C" void Win32Resource_ToString_m1615154437 ();
extern "C" void COMException_ToString_m2192592964 ();
extern "C" void DllImportAttribute_get_Value_m621189650 ();
extern "C" void ActivatedClientTypeEntry_ToString_m2494181680 ();
extern "C" void ActivatedClientTypeEntry_get_ApplicationUrl_m2894992111 ();
extern "C" void ActivatedServiceTypeEntry_ToString_m1591455874 ();
extern "C" void UrlAttribute_get_UrlValue_m381261874 ();
extern "C" void CrossAppDomainChannel_get_ChannelName_m2549253909 ();
extern "C" void CrossAppDomainData_get_ProcessID_m2166337712 ();
extern "C" void ClientIdentity_get_TargetUri_m648770569 ();
extern "C" void ConfigHandler_ExtractAssembly_m2143791058 ();
extern "C" void ConfigHandler_GetNotNull_m2259274773 ();
extern "C" void Context_ToString_m1073616138 ();
extern "C" void ContextAttribute_get_Name_m1376922427 ();
extern "C" void Identity_get_ObjectUri_m3138646444 ();
extern "C" void CADMethodCallMessage_get_Uri_m1711428083 ();
extern "C" void CADObjRef_get_TypeName_m3141447028 ();
extern "C" void CADObjRef_get_URI_m3186150256 ();
extern "C" void ConstructionCall_get_ActivationTypeName_m3152330302 ();
extern "C" void ErrorMessage_get_MethodName_m2090524261 ();
extern "C" void ErrorMessage_get_TypeName_m4051144354 ();
extern "C" void ErrorMessage_get_Uri_m528922187 ();
extern "C" void MethodCall_GetTypeNameFromAssemblyQualifiedName_m1018622420 ();
extern "C" void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m2491597453 ();
extern "C" void MethodCall_get_MethodName_m264867159 ();
extern "C" void MethodCall_get_TypeName_m3873929301 ();
extern "C" void MethodCall_get_Uri_m1720935531 ();
extern "C" void MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m3937741607 ();
extern "C" void MethodResponse_get_MethodName_m256884228 ();
extern "C" void MethodResponse_get_TypeName_m1691049826 ();
extern "C" void MethodResponse_get_Uri_m3281745614 ();
extern "C" void MonoMethodMessage_get_MethodName_m3805361957 ();
extern "C" void MonoMethodMessage_get_TypeName_m3758247133 ();
extern "C" void MonoMethodMessage_get_Uri_m2484777536 ();
extern "C" void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m266953644 ();
extern "C" void ReturnMessage_get_MethodName_m1311605024 ();
extern "C" void ReturnMessage_get_TypeName_m3469766621 ();
extern "C" void ReturnMessage_get_Uri_m2690508903 ();
extern "C" void SoapAttribute_get_XmlNamespace_m859394681 ();
extern "C" void SoapFieldAttribute_get_XmlElementName_m2203304026 ();
extern "C" void SoapMethodAttribute_get_XmlNamespace_m4029617514 ();
extern "C" void SoapTypeAttribute_get_XmlElementName_m2920861364 ();
extern "C" void SoapTypeAttribute_get_XmlNamespace_m1959618787 ();
extern "C" void SoapTypeAttribute_get_XmlTypeName_m3319890470 ();
extern "C" void SoapTypeAttribute_get_XmlTypeNamespace_m4211398148 ();
extern "C" void ObjRef_get_URI_m3017576950 ();
extern "C" void RemotingProxy_get_TypeName_m4085898624 ();
extern "C" void RemotingConfiguration_get_ApplicationName_m593755586 ();
extern "C" void RemotingConfiguration_get_ProcessId_m2180277012 ();
extern "C" void RemotingServices_GetNormalizedUri_m3119784285 ();
extern "C" void RemotingServices_NewUri_m4184087063 ();
extern "C" void RemotingServices_RemoveAppNameFromUri_m388703745 ();
extern "C" void SoapServices_CodeXmlNamespaceForClrTypeNamespace_m4100633536 ();
extern "C" void SoapServices_EncodeNs_m635167772 ();
extern "C" void SoapServices_GetAssemblyName_m1160306025 ();
extern "C" void SoapServices_GetNameKey_m1553516689 ();
extern "C" void SoapServices_GetXmlNamespaceForMethodCall_m4199193440 ();
extern "C" void SoapServices_GetXmlNamespaceForMethodResponse_m72953636 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithAssembly_m2133585561 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithNs_m3680841936 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithNsAndAssembly_m2954042252 ();
extern "C" void TypeEntry_get_AssemblyName_m249907965 ();
extern "C" void TypeEntry_get_TypeName_m3730760050 ();
extern "C" void TypeInfo_get_TypeName_m3637299865 ();
extern "C" void WellKnownClientTypeEntry_ToString_m1119458503 ();
extern "C" void WellKnownClientTypeEntry_get_ApplicationUrl_m3926146748 ();
extern "C" void WellKnownClientTypeEntry_get_ObjectUrl_m2025814880 ();
extern "C" void WellKnownServiceTypeEntry_ToString_m1546833365 ();
extern "C" void WellKnownServiceTypeEntry_get_ObjectUri_m560402900 ();
extern "C" void FormatterConverter_ToString_m1584725205 ();
extern "C" void SerializationEntry_get_Name_m1530029541_AdjustorThunk ();
extern "C" void SerializationInfo_GetString_m3155282843 ();
extern "C" void SerializationInfo_get_AssemblyName_m3241199889 ();
extern "C" void SerializationInfo_get_FullTypeName_m558954005 ();
extern "C" void SerializationInfoEnumerator_get_Name_m4203920197 ();
extern "C" void SByte_ToString_m3584531119_AdjustorThunk ();
extern "C" void SByte_ToString_m1735624261_AdjustorThunk ();
extern "C" void SByte_ToString_m2762508873_AdjustorThunk ();
extern "C" void SByte_ToString_m2708934884_AdjustorThunk ();
extern "C" void CodeAccessPermission_ToString_m797953232 ();
extern "C" void AsnEncodedData_BasicConstraintsExtension_m181086136 ();
extern "C" void AsnEncodedData_Default_m4101664970 ();
extern "C" void AsnEncodedData_EnhancedKeyUsageExtension_m56921642 ();
extern "C" void AsnEncodedData_KeyUsageExtension_m1792651780 ();
extern "C" void AsnEncodedData_NetscapeCertType_m2976595233 ();
extern "C" void AsnEncodedData_SubjectAltName_m4049949414 ();
extern "C" void AsnEncodedData_SubjectKeyIdentifierExtension_m3216418117 ();
extern "C" void AsnEncodedData_ToString_m440213605 ();
extern "C" void CryptoConfig_MapNameToOID_m2044758263 ();
extern "C" void DSA_ToXmlString_m3836885162 ();
extern "C" void Oid_GetName_m195392578 ();
extern "C" void Oid_get_FriendlyName_m1299931775 ();
extern "C" void Oid_get_Value_m743416803 ();
extern "C" void RSA_ToXmlString_m2922661427 ();
extern "C" void X500DistinguishedName_Canonize_m2594679403 ();
extern "C" void X500DistinguishedName_Decode_m3521921960 ();
extern "C" void X500DistinguishedName_GetSeparator_m1336760642 ();
extern "C" void X509BasicConstraintsExtension_ToString_m1809935297 ();
extern "C" void X509Certificate2_GetNameInfo_m869719036 ();
extern "C" void X509Certificate2_GetValueAsString_m1348462142 ();
extern "C" void X509Certificate2_ToString_m3891217889 ();
extern "C" void X509Certificate2_ToString_m4246350784 ();
extern "C" void X509Certificate2_get_SerialNumber_m1315874713 ();
extern "C" void X509Certificate2_get_Thumbprint_m392121246 ();
extern "C" void X509Certificate_GetCertHashString_m3484127109 ();
extern "C" void X509Certificate_GetEffectiveDateString_m1666677721 ();
extern "C" void X509Certificate_GetExpirationDateString_m1253593872 ();
extern "C" void X509Certificate_GetIssuerName_m1601331538 ();
extern "C" void X509Certificate_GetName_m1060481339 ();
extern "C" void X509Certificate_ToString_m3415629710 ();
extern "C" void X509Certificate_ToString_m2340207075 ();
extern "C" void X509Certificate_get_Issuer_m2934704867 ();
extern "C" void X509Certificate_get_Subject_m2638144878 ();
extern "C" void X509Certificate_tostr_m197816703 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m614536199 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m4138418749 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m2237883181 ();
extern "C" void X509Chain_GetSubjectKeyIdentifier_m1349242905 ();
extern "C" void X509ChainStatus_GetInformation_m245493206 ();
extern "C" void X509EnhancedKeyUsageExtension_ToString_m350388564 ();
extern "C" void X509Extension_FormatUnkownData_m3636863676 ();
extern "C" void X509KeyUsageExtension_ToString_m3542316380 ();
extern "C" void X509SubjectKeyIdentifierExtension_ToString_m12089275 ();
extern "C" void X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3059478847 ();
extern "C" void StrongNamePublicKeyBlob_ToString_m724833278 ();
extern "C" void Hash_ToString_m1453919145 ();
extern "C" void StrongName_ToString_m3130222752 ();
extern "C" void StrongName_get_Name_m1932850490 ();
extern "C" void WindowsIdentity_GetTokenName_m2370798233 ();
extern "C" void SecurityAttribute_get_Name_m2543977264 ();
extern "C" void SecurityAttribute_get_Value_m2111064489 ();
extern "C" void SecurityElement_Escape_m1342311983 ();
extern "C" void SecurityElement_ToString_m1918878627 ();
extern "C" void SecurityElement_Unescape_m327386968 ();
extern "C" void SecurityElement_get_Tag_m2258014803 ();
extern "C" void SecurityException_ToString_m3228070608 ();
extern "C" void SecurityException_get_GrantedSet_m2643283539 ();
extern "C" void SecurityException_get_PermissionState_m3857825198 ();
extern "C" void SecurityException_get_RefusedSet_m2404284794 ();
extern "C" void SecurityFrame_ToString_m339310712_AdjustorThunk ();
extern "C" void Single_ToString_m3947131094_AdjustorThunk ();
extern "C" void Single_ToString_m3107811250_AdjustorThunk ();
extern "C" void Single_ToString_m543431371_AdjustorThunk ();
extern "C" void String_Concat_m904156431 ();
extern "C" void String_Concat_m1715369213 ();
extern "C" void String_Concat_m2971454694 ();
extern "C" void String_Concat_m3937257545 ();
extern "C" void String_Concat_m3755062657 ();
extern "C" void String_Concat_m2163913788 ();
extern "C" void String_Concat_m1809518182 ();
extern "C" void String_ConcatInternal_m190606771 ();
extern "C" void String_Copy_m3813992399 ();
extern "C" void String_CreateString_m3439913850 ();
extern "C" void String_CreateString_m3400201881 ();
extern "C" void String_CreateString_m1262864254 ();
extern "C" void String_CreateString_m2818852475 ();
extern "C" void String_CreateString_m860434552 ();
extern "C" void String_CreateString_m4016935005 ();
extern "C" void String_CreateString_m780602784 ();
extern "C" void String_CreateString_m2329023138 ();
extern "C" void String_Format_m1881875187 ();
extern "C" void String_Format_m2844511972 ();
extern "C" void String_Format_m2556382932 ();
extern "C" void String_Format_m3339413201 ();
extern "C" void String_Format_m630303134 ();
extern "C" void String_Insert_m3534971326 ();
extern "C" void String_InternalAllocateStr_m1198086868 ();
extern "C" void String_Join_m2050845953 ();
extern "C" void String_Join_m29736248 ();
extern "C" void String_JoinUnchecked_m3111386027 ();
extern "C" void String_PadRight_m50345030 ();
extern "C" void String_Remove_m562998446 ();
extern "C" void String_Replace_m3726209165 ();
extern "C" void String_Replace_m1273907647 ();
extern "C" void String_ReplaceFallback_m1061004996 ();
extern "C" void String_ReplaceUnchecked_m1381393810 ();
extern "C" void String_Substring_m2848979100 ();
extern "C" void String_Substring_m1610150815 ();
extern "C" void String_SubstringUnchecked_m1840487357 ();
extern "C" void String_ToLower_m2029374922 ();
extern "C" void String_ToLower_m3490221821 ();
extern "C" void String_ToLowerInvariant_m110751226 ();
extern "C" void String_ToString_m838249115 ();
extern "C" void String_ToString_m3872792296 ();
extern "C" void String_ToUpperInvariant_m2531236323 ();
extern "C" void String_Trim_m923598732 ();
extern "C" void String_Trim_m3384720403 ();
extern "C" void String_TrimEnd_m3824727301 ();
extern "C" void String_TrimStart_m1431283012 ();
extern "C" void ASCIIEncoding_GetString_m58523364 ();
extern "C" void DecoderReplacementFallback_get_DefaultString_m3355062503 ();
extern "C" void EncoderReplacementFallback_get_DefaultString_m3956016810 ();
extern "C" void Encoding_GetString_m4017112554 ();
extern "C" void Encoding_GetString_m144725032 ();
extern "C" void Encoding_InternalCodePage_m4154357846 ();
extern "C" void Encoding___m3765636185 ();
extern "C" void Latin1Encoding_GetString_m254210343 ();
extern "C" void Latin1Encoding_GetString_m838471821 ();
extern "C" void Capture_ToString_m2751919208 ();
extern "C" void Capture_get_Text_m3620583591 ();
extern "C" void Capture_get_Value_m3919646039 ();
extern "C" void Key_ToString_m1970072654 ();
extern "C" void Interpreter_GetString_m94448266 ();
extern "C" void Regex_ToString_m1548107455 ();
extern "C" void AnchorInfo_get_Substring_m1799385132 ();
extern "C" void CapturingGroup_get_Name_m3747712535 ();
extern "C" void Parser_ParseName_m2057792975 ();
extern "C" void Parser_ParseName_m1814604608 ();
extern "C" void StringBuilder_ToString_m3317489284 ();
extern "C" void StringBuilder_ToString_m774364392 ();
extern "C" void UTF32Encoding_GetString_m3737249548 ();
extern "C" void UTF7Encoding_GetString_m560035518 ();
extern "C" void UTF8Encoding_GetString_m3999408409 ();
extern "C" void UnicodeEncoding_GetString_m332467280 ();
extern "C" void TimeSpan_ToString_m1128692466_AdjustorThunk ();
extern "C" void Type_ToString_m3975981286 ();
extern "C" void TypeLoadException_get_Message_m2440738252 ();
extern "C" void UInt16_ToString_m355311020_AdjustorThunk ();
extern "C" void UInt16_ToString_m3020002356_AdjustorThunk ();
extern "C" void UInt16_ToString_m3056878594_AdjustorThunk ();
extern "C" void UInt16_ToString_m760649087_AdjustorThunk ();
extern "C" void UInt32_ToString_m2574561716_AdjustorThunk ();
extern "C" void UInt32_ToString_m4293943134_AdjustorThunk ();
extern "C" void UInt32_ToString_m2066897296_AdjustorThunk ();
extern "C" void UInt32_ToString_m2420423038_AdjustorThunk ();
extern "C" void UInt64_ToString_m1529093114_AdjustorThunk ();
extern "C" void UInt64_ToString_m2623377370_AdjustorThunk ();
extern "C" void UInt64_ToString_m2177233542_AdjustorThunk ();
extern "C" void UInt64_ToString_m1695188334_AdjustorThunk ();
extern "C" void UIntPtr_ToString_m984583492_AdjustorThunk ();
extern "C" void Uri_EscapeString_m2061933484 ();
extern "C" void Uri_EscapeString_m3864445955 ();
extern "C" void Uri_GetLeftPart_m3979111399 ();
extern "C" void Uri_GetOpaqueWiseSchemeDelimiter_m1909471550 ();
extern "C" void Uri_GetSchemeDelimiter_m2374610473 ();
extern "C" void Uri_HexEscape_m1589417657 ();
extern "C" void Uri_ParseAsWindowsAbsoluteFilePath_m708354183 ();
extern "C" void Uri_ParseNoExceptions_m4274141693 ();
extern "C" void Uri_Reduce_m3122437040 ();
extern "C" void Uri_ToString_m3742105950 ();
extern "C" void Uri_Unescape_m3373094076 ();
extern "C" void Uri_Unescape_m910903869 ();
extern "C" void Uri_get_AbsoluteUri_m2582056986 ();
extern "C" void Uri_get_Authority_m3816772302 ();
extern "C" void Uri_get_Host_m42857288 ();
extern "C" void Uri_get_OriginalString_m3715995233 ();
extern "C" void Uri_get_Scheme_m2109479391 ();
extern "C" void ValueType_ToString_m2292123621 ();
extern "C" void Version_ToString_m2279867705 ();
extern "C" void AnalyticsEventParam_get_groupID_m569309506 ();
extern "C" void AnalyticsEventParam_get_name_m708127086 ();
extern "C" void AnalyticsTracker_get_eventName_m2051345506 ();
extern "C" void StandardEventPayload_get_name_m1853779774 ();
extern "C" void FieldWithTarget_get_fieldPath_m341366840 ();
extern "C" void FieldWithTarget_get_paramName_m3501478659 ();
extern "C" void FieldWithTarget_get_staticString_m2597372683 ();
extern "C" void FieldWithTarget_get_typeString_m238478345 ();
extern "C" void ValueProperty_get_propertyValue_m3340090327 ();
extern "C" void ValueProperty_get_valueType_m2516961412 ();
extern "C" void AudioSettings_GetAmbisonicDecoderPluginName_m19603540 ();
extern "C" void AudioSettings_GetSpatializerPluginName_m1324100978 ();
extern "C" void ArgumentCache_get_stringArgument_m3872675090 ();
extern "C" void ArgumentCache_get_unityObjectArgumentAssemblyTypeName_m3450114170 ();
extern "C" void PersistentCall_get_methodName_m4214122315 ();
extern "C" void UnityEventBase_ToString_m1554306026 ();
extern "C" void Logger_GetString_m3669755330 ();
extern "C" void MonoBehaviour_GetScriptClassName_m1053457852 ();
extern "C" void Object_GetName_m4137306623 ();
extern "C" void Object_ToString_m3272709752 ();
extern "C" void Object_ToString_m1579850521 ();
extern "C" void Object_get_name_m4211327027 ();
extern "C" void PropertyName_ToString_m3328159423_AdjustorThunk ();
extern "C" void Quaternion_ToString_m2203056442_AdjustorThunk ();
extern "C" void Ray_ToString_m1732834890_AdjustorThunk ();
extern "C" void Rect_ToString_m447614148_AdjustorThunk ();
extern "C" void GameCenterPlatform_Internal_UserID_m2444628078 ();
extern "C" void GameCenterPlatform_Internal_UserName_m477057936 ();
extern "C" void Achievement_ToString_m3521250266 ();
extern "C" void Achievement_get_id_m89809597 ();
extern "C" void AchievementDescription_ToString_m2063334390 ();
extern "C" void AchievementDescription_get_achievedDescription_m387769685 ();
extern "C" void AchievementDescription_get_id_m985811184 ();
extern "C" void AchievementDescription_get_title_m417729785 ();
extern "C" void AchievementDescription_get_unachievedDescription_m690845291 ();
extern "C" void Leaderboard_ToString_m1544604165 ();
extern "C" void Leaderboard_get_id_m4258535896 ();
extern "C" void Score_ToString_m885507283 ();
extern "C" void Score_get_leaderboardID_m3645107971 ();
extern "C" void UserProfile_ToString_m2232825484 ();
extern "C" void UserProfile_get_id_m3178143816 ();
extern "C" void UserProfile_get_userName_m3063744753 ();
extern "C" void StackTraceUtility_ExtractFormattedStackTrace_m1281750362 ();
extern "C" void StackTraceUtility_ExtractStackTrace_m3279197967 ();
extern "C" void StackTraceUtility_PostprocessStacktrace_m1043256299 ();
extern "C" void UnityString_Format_m261690510 ();
extern "C" void Vector2_ToString_m1205609053_AdjustorThunk ();
extern "C" void Vector3_ToString_m759076600_AdjustorThunk ();
extern "C" void WebRequestUtils_RedirectTo_m55747000 ();
extern "C" void StringComparer_get_InvariantCultureIgnoreCase_m2404489191 ();
extern "C" void GeneralNames_get_DNSNames_m3788548987 ();
extern "C" void GeneralNames_get_IPAddresses_m4242915644 ();
extern "C" void SubjectAltNameExtension_get_DNSNames_m2346000460 ();
extern "C" void SubjectAltNameExtension_get_IPAddresses_m1641002124 ();
extern "C" void AttrListImpl_get_Names_m977594476 ();
extern "C" void AttrListImpl_get_Values_m3139810172 ();
extern "C" void DateTime_YearMonthDayFormats_m827415370 ();
extern "C" void Calendar_get_EraNames_m2754466818 ();
extern "C" void DateTimeFormatInfo_GetAllDateTimePatternsInternal_m1798077795 ();
extern "C" void DateTimeFormatInfo_GetAllRawDateTimePatterns_m4238261242 ();
extern "C" void DateTimeFormatInfo_PopulateCombinedList_m3446790622 ();
extern "C" void DateTimeFormatInfo_get_RawAbbreviatedDayNames_m1257850285 ();
extern "C" void DateTimeFormatInfo_get_RawAbbreviatedMonthNames_m2395953416 ();
extern "C" void DateTimeFormatInfo_get_RawDayNames_m3876370387 ();
extern "C" void DateTimeFormatInfo_get_RawMonthNames_m246920234 ();
extern "C" void Directory_GetFileSystemEntries_m1684188607 ();
extern "C" void Directory_GetFiles_m2624572368 ();
extern "C" void MonoIO_GetFileSystemEntries_m37351365 ();
extern "C" void String_InternalSplit_m1398300789 ();
extern "C" void String_Split_m3646115398 ();
extern "C" void String_Split_m2077324731 ();
extern "C" void String_Split_m3580120853 ();
extern "C" void String_Split_m2533743664 ();
extern "C" void String_Split_m4013853433 ();
extern "C" void InterpreterFactory_get_NamesMapping_m4228407820 ();
extern "C" void Regex_GetGroupNamesArray_m3575729002 ();
extern "C" void Leaderboard_GetUserFilter_m1077085961 ();
extern "C" void ASCIIEncoding_GetDecoder_m2247302044 ();
extern "C" void Encoding_GetDecoder_m1656450963 ();
extern "C" void UTF32Encoding_GetDecoder_m3364062151 ();
extern "C" void UTF7Encoding_GetDecoder_m3129254348 ();
extern "C" void UTF8Encoding_GetDecoder_m2951334655 ();
extern "C" void UnicodeEncoding_GetDecoder_m1504791895 ();
extern "C" void DecoderFallback_get_ExceptionFallback_m198794485 ();
extern "C" void DecoderFallback_get_ReplacementFallback_m3654210110 ();
extern "C" void DecoderFallback_get_StandardSafeFallback_m2130338133 ();
extern "C" void Encoding_get_DecoderFallback_m1525880676 ();
extern "C" void Decoder_get_FallbackBuffer_m2656621242 ();
extern "C" void DecoderExceptionFallback_CreateFallbackBuffer_m1133375601 ();
extern "C" void DecoderReplacementFallback_CreateFallbackBuffer_m2031816144 ();
extern "C" void EncoderFallback_get_ExceptionFallback_m3342076075 ();
extern "C" void EncoderFallback_get_ReplacementFallback_m818398284 ();
extern "C" void EncoderFallback_get_StandardSafeFallback_m2825654225 ();
extern "C" void Encoding_get_EncoderFallback_m4088593971 ();
extern "C" void EncoderExceptionFallback_CreateFallbackBuffer_m188459848 ();
extern "C" void EncoderReplacementFallback_CreateFallbackBuffer_m4038190929 ();
extern "C" void Encoding_GetEncoding_m2801244948 ();
extern "C" void Encoding_GetEncoding_m2599798446 ();
extern "C" void Encoding_get_ASCII_m3595602635 ();
extern "C" void Encoding_get_BigEndianUTF32_m2820363135 ();
extern "C" void Encoding_get_BigEndianUnicode_m684646764 ();
extern "C" void Encoding_get_Default_m1632902165 ();
extern "C" void Encoding_get_ISOLatin1_m2107621369 ();
extern "C" void Encoding_get_UTF32_m1591929079 ();
extern "C" void Encoding_get_UTF7_m1817790803 ();
extern "C" void Encoding_get_UTF8_m1008486739 ();
extern "C" void Encoding_get_UTF8Unmarked_m3350637783 ();
extern "C" void Encoding_get_UTF8UnmarkedUnsafe_m320312322 ();
extern "C" void Encoding_get_Unicode_m811213576 ();
extern "C" void Group_get_Captures_m1655762411 ();
extern "C" void CategoryUtils_CategoryFromName_m1352081402 ();
extern "C" void Parser_ParseUnicodeCategory_m100397645 ();
extern "C" void GroupCollection_get_Item_m723682197 ();
extern "C" void Match_get_Groups_m841244970 ();
extern "C" void InterpreterFactory_NewInstance_m2792693614 ();
extern "C" void Regex_CreateMachine_m334863819 ();
extern "C" void FactoryCache_Lookup_m2646822264 ();
extern "C" void PatternCompiler_GetMachineFactory_m3758869886 ();
extern "C" void Regex_CreateMachineFactory_m4274762546 ();
extern "C" void RepeatContext_get_Previous_m4220584810 ();
extern "C" void Interval_get_Empty_m3617514670 ();
extern "C" void IntervalCollection_get_Item_m3866640912 ();
extern "C" void AnchorInfo_GetInterval_m2808989035 ();
extern "C" void IntervalCollection_GetMetaCollection_m4029522214 ();
extern "C" void PatternCompiler_NewLink_m3699449496 ();
extern "C" void BaseMachine_Scan_m3315183438 ();
extern "C" void Interpreter_GenerateMatch_m2262987936 ();
extern "C" void Interpreter_Scan_m270890411 ();
extern "C" void Match_NextMatch_m366671308 ();
extern "C" void Match_get_Empty_m2060287462 ();
extern "C" void MatchCollection_get_Item_m3516666721 ();
extern "C" void Regex_Match_m4145799399 ();
extern "C" void Regex_Matches_m979395559 ();
extern "C" void Regex_Matches_m2080913806 ();
extern "C" void PatternCompiler_MakeFlags_m1977119795 ();
extern "C" void AnchorInfo_get_Position_m1133366486 ();
extern "C" void Match_get_Regex_m318048854 ();
extern "C" void Regex_get_Options_m3142641900 ();
extern "C" void Expression_GetAnchorInfo_m2996231682 ();
extern "C" void Group_GetAnchorInfo_m3730312864 ();
extern "C" void Literal_GetAnchorInfo_m810577400 ();
extern "C" void PositionAssertion_GetAnchorInfo_m32057718 ();
extern "C" void Repetition_GetAnchorInfo_m2615648496 ();
extern "C" void Reference_get_CapturingGroup_m3861468528 ();
extern "C" void Assertion_get_FalseExpression_m2609188285 ();
extern "C" void Assertion_get_TrueExpression_m2743006331 ();
extern "C" void ExpressionAssertion_get_TestExpression_m727356674 ();
extern "C" void ExpressionCollection_get_Item_m3510736379 ();
extern "C" void Parser_ParseCharacterClass_m4285351396 ();
extern "C" void Parser_ParseGroupingConstruct_m263270497 ();
extern "C" void Parser_ParseSpecial_m1961501104 ();
extern "C" void Repetition_get_Expression_m2673886232 ();
extern "C" void CaptureAssertion_get_Alternate_m4172691807 ();
extern "C" void Alternation_get_Alternatives_m1978796879 ();
extern "C" void CompositeExpression_get_Expressions_m2951105322 ();
extern "C" void Parser_ParseRegularExpression_m18398587 ();
extern "C" void String_FormatHelper_m3913915042 ();
extern "C" void StringBuilder_Append_m2383614642 ();
extern "C" void StringBuilder_Append_m2180175564 ();
extern "C" void StringBuilder_Append_m4089665817 ();
extern "C" void StringBuilder_Append_m890240332 ();
extern "C" void StringBuilder_Append_m3611229522 ();
extern "C" void StringBuilder_Append_m1640838743 ();
extern "C" void StringBuilder_Append_m1965104174 ();
extern "C" void StringBuilder_Append_m3214161208 ();
extern "C" void StringBuilder_AppendFormat_m4227532852 ();
extern "C" void StringBuilder_AppendFormat_m3016532472 ();
extern "C" void StringBuilder_AppendFormat_m3255666490 ();
extern "C" void StringBuilder_AppendFormat_m2403596038 ();
extern "C" void StringBuilder_AppendFormat_m921870684 ();
extern "C" void StringBuilder_Insert_m1076119876 ();
extern "C" void StringBuilder_Insert_m3039182437 ();
extern "C" void StringBuilder_Insert_m1991415059 ();
extern "C" void StringBuilder_Remove_m940064945 ();
extern "C" void StringBuilder_Replace_m1968561789 ();
extern "C" void StringBuilder_Replace_m1682610486 ();
extern "C" void SecurityContext_get_CompressedStack_m3401528670 ();
extern "C" void CompressedStack_Capture_m3327262890 ();
extern "C" void CompressedStack_CreateCopy_m2591279216 ();
extern "C" void Thread_GetCompressedStack_m2923422412 ();
extern "C" void ExecutionContext_Capture_m681135907 ();
extern "C" void Thread_get_ExecutionContext_m1861734668 ();
extern "C" void ThreadPool_RegisterWaitForSingleObject_m3828286853 ();
extern "C" void ThreadPool_RegisterWaitForSingleObject_m3011264028 ();
extern "C" void SynchronizationContext_get_Current_m3666546046 ();
extern "C" void Thread_CurrentThread_internal_m3271843036 ();
extern "C" void Thread_get_CurrentThread_m4142136012 ();
extern "C" void Scheduler_get_Instance_m2990168607 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncWaitHandle_m1781023438 ();
extern "C" void SendRecordAsyncResult_get_AsyncWaitHandle_m1466641472 ();
extern "C" void InternalAsyncResult_get_AsyncWaitHandle_m2580490319 ();
extern "C" void FileStreamAsyncResult_get_AsyncWaitHandle_m1811816191 ();
extern "C" void StreamAsyncResult_get_AsyncWaitHandle_m3390046559 ();
extern "C" void AsyncResult_get_AsyncWaitHandle_m1971359513 ();
extern "C" void CurrentSystemTimeZone_GetUtcOffset_m340358963 ();
extern "C" void DateTime_op_Subtraction_m3579235380 ();
extern "C" void DateTimeOffset_get_Offset_m2040541042_AdjustorThunk ();
extern "C" void DaylightTime_get_Delta_m2355462786 ();
extern "C" void ConfigHandler_ParseTime_m1787834288 ();
extern "C" void RenewalDelegate_EndInvoke_m250802919 ();
extern "C" void RenewalDelegate_Invoke_m3491491419 ();
extern "C" void Lease_Renew_m1703962644 ();
extern "C" void Lease_get_CurrentLeaseTime_m3433257884 ();
extern "C" void Lease_get_RenewOnCallTime_m1966809790 ();
extern "C" void LifetimeServices_get_LeaseManagerPollTime_m2374486473 ();
extern "C" void LifetimeServices_get_LeaseTime_m1675572716 ();
extern "C" void LifetimeServices_get_RenewOnCallTime_m4192398854 ();
extern "C" void LifetimeServices_get_SponsorshipTimeout_m1857544448 ();
extern "C" void TimeSpan_Add_m2350321904_AdjustorThunk ();
extern "C" void TimeSpan_Duration_m2963553230_AdjustorThunk ();
extern "C" void TimeSpan_From_m1575288640 ();
extern "C" void TimeSpan_FromDays_m3788741098 ();
extern "C" void TimeSpan_FromHours_m1109641064 ();
extern "C" void TimeSpan_FromMilliseconds_m579366253 ();
extern "C" void TimeSpan_FromMinutes_m1032812593 ();
extern "C" void TimeSpan_FromSeconds_m4219356874 ();
extern "C" void TimeSpan_Negate_m1889505500_AdjustorThunk ();
extern "C" void TimeSpan_Subtract_m1264203589_AdjustorThunk ();
extern "C" void TimeSpan_op_Addition_m672714982 ();
extern "C" void TimeSpan_op_Subtraction_m3592306516 ();
extern "C" void TimeZone_GetLocalTimeDiff_m4276408377 ();
extern "C" void TimeZone_GetLocalTimeDiff_m1937927810 ();
extern "C" void TimeZone_get_CurrentTimeZone_m2520313554 ();
extern "C" void Enum_GetUnderlyingType_m2480312097 ();
extern "C" void Enum_get_underlying_type_m267913430 ();
extern "C" void Exception_GetType_m2227967756 ();
extern "C" void MonoType_GetElementType_m170734600 ();
extern "C" void MonoType_GetGenericTypeDefinition_m3201894896 ();
extern "C" void MonoType_get_BaseType_m1098640416 ();
extern "C" void MonoType_get_DeclaringType_m90362326 ();
extern "C" void MonoType_get_ReflectedType_m3364880648 ();
extern "C" void MonoType_get_UnderlyingSystemType_m2447717099 ();
extern "C" void Object_GetType_m88164663 ();
extern "C" void Assembly_GetType_m2647029381 ();
extern "C" void Assembly_GetType_m1855422232 ();
extern "C" void Assembly_GetType_m3468564723 ();
extern "C" void Assembly_InternalGetType_m3065345470 ();
extern "C" void ConstructorBuilder_get_DeclaringType_m2098046507 ();
extern "C" void ConstructorBuilder_get_ReflectedType_m2642670880 ();
extern "C" void DynamicMethod_get_DeclaringType_m4003101913 ();
extern "C" void DynamicMethod_get_ReflectedType_m2748486053 ();
extern "C" void DynamicMethod_get_ReturnType_m4219951145 ();
extern "C" void EnumBuilder_GetElementType_m2534333387 ();
extern "C" void EnumBuilder_get_BaseType_m1707640163 ();
extern "C" void EnumBuilder_get_DeclaringType_m4266754303 ();
extern "C" void EnumBuilder_get_ReflectedType_m3155130643 ();
extern "C" void EnumBuilder_get_UnderlyingSystemType_m1095282781 ();
extern "C" void FieldBuilder_get_DeclaringType_m41087402 ();
extern "C" void FieldBuilder_get_FieldType_m1091288720 ();
extern "C" void FieldBuilder_get_ReflectedType_m4057589759 ();
extern "C" void GenericTypeParameterBuilder_GetElementType_m871345408 ();
extern "C" void GenericTypeParameterBuilder_GetGenericTypeDefinition_m1032780002 ();
extern "C" void GenericTypeParameterBuilder_MakeGenericType_m3048165991 ();
extern "C" void GenericTypeParameterBuilder_get_BaseType_m3389926280 ();
extern "C" void GenericTypeParameterBuilder_get_DeclaringType_m1741243224 ();
extern "C" void GenericTypeParameterBuilder_get_ReflectedType_m2178572472 ();
extern "C" void GenericTypeParameterBuilder_get_UnderlyingSystemType_m3450067685 ();
extern "C" void MethodBuilder_get_DeclaringType_m2226312865 ();
extern "C" void MethodBuilder_get_ReflectedType_m3038768129 ();
extern "C" void MethodBuilder_get_ReturnType_m3514670820 ();
extern "C" void ModuleBuilder_GetType_m2225679021 ();
extern "C" void ModuleBuilder_GetType_m813933439 ();
extern "C" void ModuleBuilder_create_modified_type_m3780542108 ();
extern "C" void PropertyBuilder_get_DeclaringType_m1411910527 ();
extern "C" void PropertyBuilder_get_PropertyType_m682373713 ();
extern "C" void PropertyBuilder_get_ReflectedType_m1888835465 ();
extern "C" void TypeBuilder_CreateType_m3375483507 ();
extern "C" void TypeBuilder_GetElementType_m1881206953 ();
extern "C" void TypeBuilder_GetGenericTypeDefinition_m1632720438 ();
extern "C" void TypeBuilder_MakeGenericType_m2799607032 ();
extern "C" void TypeBuilder_create_runtime_class_m2581270900 ();
extern "C" void TypeBuilder_get_BaseType_m3571781126 ();
extern "C" void TypeBuilder_get_DeclaringType_m4128305641 ();
extern "C" void TypeBuilder_get_ReflectedType_m3266505878 ();
extern "C" void TypeBuilder_get_UnderlyingSystemType_m4226811350 ();
extern "C" void EventInfo_get_EventHandlerType_m420690865 ();
extern "C" void MethodInfo_get_ReturnType_m3163894070 ();
extern "C" void Module_GetType_m1977604635 ();
extern "C" void Module_GetType_m3678256200 ();
extern "C" void MonoCMethod_get_DeclaringType_m3406114400 ();
extern "C" void MonoCMethod_get_ReflectedType_m3914411905 ();
extern "C" void MonoEvent_get_DeclaringType_m862221512 ();
extern "C" void MonoEvent_get_ReflectedType_m3664183825 ();
extern "C" void MonoField_GetParentType_m2478933781 ();
extern "C" void MonoField_get_DeclaringType_m2066594735 ();
extern "C" void MonoField_get_FieldType_m1670137202 ();
extern "C" void MonoField_get_ReflectedType_m471710812 ();
extern "C" void MonoGenericCMethod_get_ReflectedType_m1440479536 ();
extern "C" void MonoGenericMethod_get_ReflectedType_m3748461472 ();
extern "C" void MonoMethod_get_DeclaringType_m3539501442 ();
extern "C" void MonoMethod_get_ReflectedType_m18334703 ();
extern "C" void MonoMethod_get_ReturnType_m3656785830 ();
extern "C" void MonoMethodInfo_GetDeclaringType_m2924452727 ();
extern "C" void MonoMethodInfo_GetReturnType_m914391169 ();
extern "C" void MonoProperty_get_DeclaringType_m966464220 ();
extern "C" void MonoProperty_get_PropertyType_m4138957578 ();
extern "C" void MonoProperty_get_ReflectedType_m4009479510 ();
extern "C" void ParameterInfo_get_ParameterType_m4197803362 ();
extern "C" void TypeDelegator_GetElementType_m4265261164 ();
extern "C" void TypeDelegator_get_BaseType_m1404832719 ();
extern "C" void TypeDelegator_get_UnderlyingSystemType_m990164729 ();
extern "C" void FixedBufferAttribute_get_ElementType_m539172858 ();
extern "C" void ActivatedClientTypeEntry_get_ObjectType_m1969125393 ();
extern "C" void ActivatedServiceTypeEntry_get_ObjectType_m537376111 ();
extern "C" void ConstructionCall_get_ActivationType_m402163916 ();
extern "C" void MethodCall_CastTo_m1915249774 ();
extern "C" void ObjRef_get_ServerType_m4102914975 ();
extern "C" void RealProxy_GetProxiedType_m130698758 ();
extern "C" void RealProxy_InternalGetProxyType_m2154819545 ();
extern "C" void RemotingServices_GetServerTypeForUri_m1917852216 ();
extern "C" void ServerIdentity_get_ObjectType_m1709199788 ();
extern "C" void WellKnownClientTypeEntry_get_ObjectType_m1043664788 ();
extern "C" void WellKnownServiceTypeEntry_get_ObjectType_m3211195371 ();
extern "C" void BinaryCommon_GetTypeFromCode_m39036572 ();
extern "C" void CodeGenerator_EnumToUnderlying_m3778945530 ();
extern "C" void CodeGenerator_GenerateMetadataType_m649965872 ();
extern "C" void CodeGenerator_GenerateMetadataTypeInternal_m675242502 ();
extern "C" void ObjectReader_GetDeserializationType_m1493678790 ();
extern "C" void ObjectReader_ReadType_m1663843507 ();
extern "C" void SerializationEntry_get_ObjectType_m1155580012_AdjustorThunk ();
extern "C" void SerializationInfoEnumerator_get_ObjectType_m3505100851 ();
extern "C" void SecurityException_get_PermissionType_m2237538728 ();
extern "C" void Type_GetGenericTypeDefinition_m639345035 ();
extern "C" void Type_GetGenericTypeDefinition_impl_m1429894432 ();
extern "C" void Type_GetType_m1766533001 ();
extern "C" void Type_GetType_m1693760368 ();
extern "C" void Type_GetType_m3605423543 ();
extern "C" void Type_GetTypeFromHandle_m1620074514 ();
extern "C" void Type_MakeGenericType_m1462451309 ();
extern "C" void Type_MakeGenericType_m2479309691 ();
extern "C" void Type_get_DeclaringType_m1898067526 ();
extern "C" void Type_get_ReflectedType_m825170767 ();
extern "C" void Type_internal_from_handle_m3156085815 ();
extern "C" void Type_internal_from_name_m1721940673 ();
extern "C" void AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m681389990 ();
extern "C" void AudioExtensionDefinition_GetExtensionType_m1450823952 ();
extern "C" void Enum_GetTypeCode_m3381045179 ();
extern "C" void Type_GetTypeCode_m480753082 ();
extern "C" void Type_GetTypeCodeInternal_m1968182887 ();
extern "C" void MonoType_GetGenericArguments_m485413379 ();
extern "C" void MonoType_GetInterfaces_m878428211 ();
extern "C" void Assembly_GetTypes_m1237242249 ();
extern "C" void Assembly_GetTypes_m1724781913 ();
extern "C" void AssemblyBuilder_GetTypes_m3415680380 ();
extern "C" void EnumBuilder_GetInterfaces_m282127151 ();
extern "C" void GenericTypeParameterBuilder_GetGenericArguments_m2988765390 ();
extern "C" void GenericTypeParameterBuilder_GetInterfaces_m1692228685 ();
extern "C" void MethodBuilder_GetGenericArguments_m1765425737 ();
extern "C" void ModuleBuilder_GetTypes_m158355402 ();
extern "C" void TypeBuilder_GetGenericArguments_m2872156836 ();
extern "C" void TypeBuilder_GetInterfaces_m4067367903 ();
extern "C" void MethodBase_GetGenericArguments_m1292856952 ();
extern "C" void MethodInfo_GetGenericArguments_m98948877 ();
extern "C" void Module_GetTypes_m3756259854 ();
extern "C" void Module_InternalGetTypes_m4031912254 ();
extern "C" void MonoMethod_GetGenericArguments_m4278548385 ();
extern "C" void MonoProperty_GetOptionalCustomModifiers_m62958967 ();
extern "C" void MonoProperty_GetRequiredCustomModifiers_m306465896 ();
extern "C" void MonoPropertyInfo_GetTypeModifiers_m3090493443 ();
extern "C" void PropertyInfo_GetOptionalCustomModifiers_m2883850568 ();
extern "C" void PropertyInfo_GetRequiredCustomModifiers_m3241367329 ();
extern "C" void TypeDelegator_GetInterfaces_m1608820881 ();
extern "C" void CADMethodCallMessage_GetSignature_m841763657 ();
extern "C" void MethodCall_get_GenericArguments_m1010093584 ();
extern "C" void Type_GetGenericArguments_m3500465462 ();
extern "C" void AttributeHelperEngine_GetRequiredComponents_m568829708 ();
extern "C" void Boolean_System_IConvertible_ToUInt16_m3465173538_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt16_m1879180133_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt16_m2449138174_AdjustorThunk ();
extern "C" void Convert_ToUInt16_m3116648921 ();
extern "C" void Convert_ToUInt16_m4064261444 ();
extern "C" void Convert_ToUInt16_m2952781888 ();
extern "C" void Convert_ToUInt16_m867476252 ();
extern "C" void Convert_ToUInt16_m3523269149 ();
extern "C" void Convert_ToUInt16_m1147931813 ();
extern "C" void Convert_ToUInt16_m3515425647 ();
extern "C" void Convert_ToUInt16_m3902921832 ();
extern "C" void Convert_ToUInt16_m4211508274 ();
extern "C" void Convert_ToUInt16_m3736443170 ();
extern "C" void Convert_ToUInt16_m2185524030 ();
extern "C" void Convert_ToUInt16_m3216249716 ();
extern "C" void Convert_ToUInt16_m1480956416 ();
extern "C" void Convert_ToUInt16_m2672597498 ();
extern "C" void DBNull_System_IConvertible_ToUInt16_m643477279 ();
extern "C" void DateTime_System_IConvertible_ToUInt16_m4182197229_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt16_m1185974300_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m3716368008 ();
extern "C" void Double_System_IConvertible_ToUInt16_m4132603953_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToUInt16_m4216751959 ();
extern "C" void BinaryReader_ReadUInt16_m267781130 ();
extern "C" void Int16_System_IConvertible_ToUInt16_m3040688695_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt16_m943736619_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt16_m848637338_AdjustorThunk ();
extern "C" void IPv6Address_SwapUShort_m253384224 ();
extern "C" void SByte_System_IConvertible_ToUInt16_m1592743959_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToUInt16_m1263555070_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToUInt16_m2888090399 ();
extern "C" void PatternCompiler_EncodeOp_m3656975400 ();
extern "C" void UInt16_Parse_m3476925403 ();
extern "C" void UInt16_Parse_m1613088384 ();
extern "C" void UInt16_System_IConvertible_ToUInt16_m2455419819_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToUInt16_m3125657960_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToUInt16_m4165747038_AdjustorThunk ();
extern "C" void IPv6Address_get_Address_m1389170741 ();
extern "C" void MSCompatUnicodeTable_UInt32FromBytePtr_m2910318928 ();
extern "C" void Kernel_DwordMod_m4183681925 ();
extern "C" void Kernel_DwordMod_m3830036736 ();
extern "C" void Kernel_SingleByteDivideInPlace_m907158225 ();
extern "C" void Kernel_SingleByteDivideInPlace_m2393683267 ();
extern "C" void Kernel_modInverse_m668448880 ();
extern "C" void Kernel_modInverse_m4048046181 ();
extern "C" void BigInteger_op_Modulus_m3242311550 ();
extern "C" void BigInteger_op_Modulus_m1987692259 ();
extern "C" void CryptoConvert_ToUInt32LE_m1043410428 ();
extern "C" void MD4Managed_F_m2794461001 ();
extern "C" void MD4Managed_G_m2118206422 ();
extern "C" void MD4Managed_H_m213605525 ();
extern "C" void MD4Managed_ROL_m691796253 ();
extern "C" void Boolean_System_IConvertible_ToUInt32_m2723177447_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt32_m1049546902_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt32_m3901815580_AdjustorThunk ();
extern "C" void Convert_ToUInt32_m835119716 ();
extern "C" void Convert_ToUInt32_m360864467 ();
extern "C" void Convert_ToUInt32_m3188121845 ();
extern "C" void Convert_ToUInt32_m3622072499 ();
extern "C" void Convert_ToUInt32_m1453583008 ();
extern "C" void Convert_ToUInt32_m4142998738 ();
extern "C" void Convert_ToUInt32_m2215525276 ();
extern "C" void Convert_ToUInt32_m2194577773 ();
extern "C" void Convert_ToUInt32_m2061619287 ();
extern "C" void Convert_ToUInt32_m3592050311 ();
extern "C" void Convert_ToUInt32_m2045194461 ();
extern "C" void Convert_ToUInt32_m3920761395 ();
extern "C" void Convert_ToUInt32_m193615797 ();
extern "C" void Convert_ToUInt32_m1767593911 ();
extern "C" void DBNull_System_IConvertible_ToUInt32_m3784627971 ();
extern "C" void DateTime_System_IConvertible_ToUInt32_m3781235049_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt32_m4224836830_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m1639916169 ();
extern "C" void Double_System_IConvertible_ToUInt32_m271206838_AdjustorThunk ();
extern "C" void Enum_System_IConvertible_ToUInt32_m2421368233 ();
extern "C" void BinaryReader_ReadUInt32_m2210658763 ();
extern "C" void Int16_System_IConvertible_ToUInt32_m3410279543_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt32_m3557270157_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt32_m109903525_AdjustorThunk ();
extern "C" void NumberFormatter_AddOneToDecHex_m1662045257 ();
extern "C" void NumberFormatter_FastToDecHex_m699829267 ();
extern "C" void NumberFormatter_ToDecHex_m1238855594 ();
extern "C" void SByte_System_IConvertible_ToUInt32_m4275534457_AdjustorThunk ();
extern "C" void AesTransform_SubByte_m3350159546 ();
extern "C" void DESTransform_CipherFunct_m3527261721 ();
extern "C" void RIPEMD160Managed_F_m2051853483 ();
extern "C" void RIPEMD160Managed_G_m3625715749 ();
extern "C" void RIPEMD160Managed_H_m2707761209 ();
extern "C" void RIPEMD160Managed_I_m2107336345 ();
extern "C" void RIPEMD160Managed_J_m1336489154 ();
extern "C" void RIPEMD160Managed_ROL_m2647139887 ();
extern "C" void RijndaelTransform_SubByte_m3037693507 ();
extern "C" void Single_System_IConvertible_ToUInt32_m289030200_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToUInt32_m281099219 ();
extern "C" void UInt16_System_IConvertible_ToUInt32_m1074326139_AdjustorThunk ();
extern "C" void UInt32_Parse_m3755665066 ();
extern "C" void UInt32_Parse_m1373460382 ();
extern "C" void UInt32_System_IConvertible_ToUInt32_m1744564280_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToUInt32_m2784653358_AdjustorThunk ();
extern "C" void ConsumeSampleFramesNativeFunction_EndInvoke_m2143737533 ();
extern "C" void ConsumeSampleFramesNativeFunction_Invoke_m1773312795 ();
extern "C" void AudioSampleProvider_get_id_m2692334523 ();
extern "C" void Context_get_ReadSequenceNumber_m3883329199 ();
extern "C" void Context_get_WriteSequenceNumber_m1115956887 ();
extern "C" void Boolean_System_IConvertible_ToUInt64_m1739877596_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt64_m371883985_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt64_m3536560782_AdjustorThunk ();
extern "C" void Convert_ToUInt64_m2343585091 ();
extern "C" void Convert_ToUInt64_m2652538228 ();
extern "C" void Convert_ToUInt64_m3102114524 ();
extern "C" void Convert_ToUInt64_m92315402 ();
extern "C" void Convert_ToUInt64_m1433697267 ();
extern "C" void Convert_ToUInt64_m388601487 ();
extern "C" void Convert_ToUInt64_m786726853 ();
extern "C" void Convert_ToUInt64_m409548990 ();
extern "C" void Convert_ToUInt64_m1841050714 ();
extern "C" void Convert_ToUInt64_m3170916409 ();
extern "C" void Convert_ToUInt64_m473526756 ();
extern "C" void Convert_ToUInt64_m1627266664 ();
extern "C" void Convert_ToUInt64_m2629133713 ();
extern "C" void Convert_ToUInt64_m1362719450 ();
extern "C" void Convert_ToUInt64_m1745056470 ();
extern "C" void DBNull_System_IConvertible_ToUInt64_m4072736670 ();
extern "C" void DateTime_System_IConvertible_ToUInt64_m2275741153_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt64_m1323635232_AdjustorThunk ();
extern "C" void Decimal_op_Explicit_m1503081942 ();
extern "C" void Decimal_u64_m3374804932 ();
extern "C" void Double_System_IConvertible_ToUInt64_m3220586809_AdjustorThunk ();
extern "C" void Enum_GetValue_m3535945367 ();
extern "C" void Enum_System_IConvertible_ToUInt64_m2641010424 ();
extern "C" void GuidParser_ParseHex_m1764305333 ();
extern "C" void BinaryReader_ReadUInt64_m4059726988 ();
extern "C" void Int16_System_IConvertible_ToUInt64_m134975563_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt64_m2502338186_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt64_m2815650160_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToUInt64_m4151910932_AdjustorThunk ();
extern "C" void SHA512Managed_Ch_m213737293 ();
extern "C" void SHA512Managed_Maj_m3649014337 ();
extern "C" void SHA512Managed_Sigma0_m921579649 ();
extern "C" void SHA512Managed_Sigma1_m922902398 ();
extern "C" void SHA512Managed_Sum0_m1216661412 ();
extern "C" void SHA512Managed_Sum1_m4163780989 ();
extern "C" void SHA512Managed_rotateRight_m3393943223 ();
extern "C" void Single_System_IConvertible_ToUInt64_m3299129161_AdjustorThunk ();
extern "C" void String_System_IConvertible_ToUInt64_m4086947440 ();
extern "C" void UInt16_System_IConvertible_ToUInt64_m424720762_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToUInt64_m1094958903_AdjustorThunk ();
extern "C" void UInt64_Parse_m1485858293 ();
extern "C" void UInt64_Parse_m819899889 ();
extern "C" void UInt64_System_IConvertible_ToUInt64_m2135047981_AdjustorThunk ();
extern "C" void HttpWebRequest_get_Address_m1609525404 ();
extern "C" void ServicePoint_get_Address_m4189969258 ();
extern "C" void WebProxy_GetProxy_m3150838504 ();
extern "C" void Uri_CheckHostName_m2213216182 ();
extern "C" void Uri_get_Parser_m3737125102 ();
extern "C" void UriParser_GetParser_m544052729 ();
extern "C" void AssemblyName_get_Version_m538083430 ();
extern "C" void StrongName_get_Version_m4243032012 ();
extern "C" void Version_CreateFromString_m719054818 ();
extern "C" void SafeHandleZeroOrMinusOneIsInvalid__ctor_m2667299826 ();
extern "C" void SafeWaitHandle__ctor_m3710504225 ();
extern "C" void TableRange__ctor_m3039750162_AdjustorThunk ();
extern "C" void CodePointIndexer__ctor_m2813317897 ();
extern "C" void Contraction__ctor_m2731863112 ();
extern "C" void ContractionComparer__cctor_m1682260389 ();
extern "C" void ContractionComparer__ctor_m3439667810 ();
extern "C" void Level2Map__ctor_m3459390739 ();
extern "C" void Level2MapComparer__cctor_m1866197409 ();
extern "C" void Level2MapComparer__ctor_m1297087662 ();
extern "C" void MSCompatUnicodeTable__cctor_m2887118684 ();
extern "C" void MSCompatUnicodeTable_BuildTailoringTables_m1316979344 ();
extern "C" void MSCompatUnicodeTable_FillCJK_m1599013685 ();
extern "C" void MSCompatUnicodeTable_FillCJKCore_m2347268515 ();
extern "C" void MSCompatUnicodeTable_SetCJKReferences_m2637101499 ();
extern "C" void MSCompatUnicodeTableUtil__cctor_m3131017198 ();
extern "C" void Context__ctor_m2477370097_AdjustorThunk ();
extern "C" void PreviousInfo__ctor_m2284093748_AdjustorThunk ();
extern "C" void SimpleCollator__cctor_m4065707122 ();
extern "C" void SimpleCollator__ctor_m1587210019 ();
extern "C" void SimpleCollator_ClearBuffer_m2975394169 ();
extern "C" void SimpleCollator_FillSortKeyRaw_m2173916311 ();
extern "C" void SimpleCollator_FillSurrogateSortKeyRaw_m725998232 ();
extern "C" void SimpleCollator_GetSortKey_m2852528720 ();
extern "C" void SimpleCollator_SetCJKTable_m766339459 ();
extern "C" void SortKeyBuffer__ctor_m1384677558 ();
extern "C" void SortKeyBuffer_AppendBufferPrimitive_m3309814175 ();
extern "C" void SortKeyBuffer_AppendCJKExtension_m2591091991 ();
extern "C" void SortKeyBuffer_AppendKana_m2480356505 ();
extern "C" void SortKeyBuffer_AppendLevel5_m3963841125 ();
extern "C" void SortKeyBuffer_AppendNormal_m2338808729 ();
extern "C" void SortKeyBuffer_Initialize_m3786111493 ();
extern "C" void SortKeyBuffer_Reset_m1409351310 ();
extern "C" void TailoringInfo__ctor_m2283562302 ();
extern "C" void Kernel_MinusEq_m2152832554 ();
extern "C" void Kernel_MinusEq_m1955542202 ();
extern "C" void Kernel_Multiply_m1995233235 ();
extern "C" void Kernel_Multiply_m193213393 ();
extern "C" void Kernel_MultiplyMod2p32pmod_m451690680 ();
extern "C" void Kernel_MultiplyMod2p32pmod_m4241526284 ();
extern "C" void Kernel_PlusEq_m136676638 ();
extern "C" void Kernel_PlusEq_m1955533564 ();
extern "C" void ModulusRing__ctor_m2420310199 ();
extern "C" void ModulusRing__ctor_m2100816195 ();
extern "C" void ModulusRing_BarrettReduction_m167376748 ();
extern "C" void ModulusRing_BarrettReduction_m3024442734 ();
extern "C" void BigInteger__cctor_m562779619 ();
extern "C" void BigInteger__cctor_m102257529 ();
extern "C" void BigInteger__ctor_m1426225719 ();
extern "C" void BigInteger__ctor_m2108826647 ();
extern "C" void BigInteger__ctor_m224778556 ();
extern "C" void BigInteger__ctor_m2644482640 ();
extern "C" void BigInteger__ctor_m3473491062 ();
extern "C" void BigInteger__ctor_m397734603 ();
extern "C" void BigInteger__ctor_m3991350270 ();
extern "C" void BigInteger__ctor_m2601366464 ();
extern "C" void BigInteger__ctor_m3985126171 ();
extern "C" void BigInteger__ctor_m2474659844 ();
extern "C" void BigInteger_Clear_m2995574218 ();
extern "C" void BigInteger_Clear_m3104012800 ();
extern "C" void BigInteger_Incr2_m2179060417 ();
extern "C" void BigInteger_Incr2_m1531167978 ();
extern "C" void BigInteger_Normalize_m4163607703 ();
extern "C" void BigInteger_Normalize_m3021106862 ();
extern "C" void BigInteger_Randomize_m2194703121 ();
extern "C" void BigInteger_Randomize_m410563259 ();
extern "C" void BigInteger_SetBit_m1985185235 ();
extern "C" void BigInteger_SetBit_m1387902198 ();
extern "C" void BigInteger_SetBit_m337653943 ();
extern "C" void BigInteger_SetBit_m1723423691 ();
extern "C" void PrimeGeneratorBase__ctor_m2423671149 ();
extern "C" void PrimeGeneratorBase__ctor_m2973488305 ();
extern "C" void SequentialSearchPrimeGeneratorBase__ctor_m3077428553 ();
extern "C" void SequentialSearchPrimeGeneratorBase__ctor_m577913576 ();
extern "C" void PrimalityTest__ctor_m2228551695 ();
extern "C" void PrimalityTest__ctor_m763620166 ();
extern "C" void ASN1__ctor_m3727822613 ();
extern "C" void ASN1__ctor_m1239252869 ();
extern "C" void ASN1__ctor_m3193227595 ();
extern "C" void ASN1__ctor_m682794872 ();
extern "C" void ASN1__ctor_m1601690794 ();
extern "C" void ASN1__ctor_m1638893325 ();
extern "C" void ASN1_Decode_m1695284166 ();
extern "C" void ASN1_Decode_m1245286596 ();
extern "C" void ASN1_DecodeTLV_m1200977460 ();
extern "C" void ASN1_DecodeTLV_m3927350254 ();
extern "C" void ASN1_set_Value_m2803403806 ();
extern "C" void ASN1_set_Value_m647861841 ();
extern "C" void BitConverterLE_UIntFromBytes_m3974925535 ();
extern "C" void BitConverterLE_ULongFromBytes_m1677445591 ();
extern "C" void BitConverterLE_UShortFromBytes_m1253080092 ();
extern "C" void ARC4Managed__ctor_m2553537404 ();
extern "C" void ARC4Managed_CheckInput_m1562172012 ();
extern "C" void ARC4Managed_Dispose_m3340445210 ();
extern "C" void ARC4Managed_Finalize_m315143160 ();
extern "C" void ARC4Managed_GenerateIV_m2029637723 ();
extern "C" void ARC4Managed_GenerateKey_m1607343060 ();
extern "C" void ARC4Managed_KeySetup_m2449315676 ();
extern "C" void ARC4Managed_set_Key_m859266296 ();
extern "C" void BlockProcessor__ctor_m649794031 ();
extern "C" void BlockProcessor_Core_m189015002 ();
extern "C" void BlockProcessor_Core_m2138791525 ();
extern "C" void BlockProcessor_Finalize_m3954108481 ();
extern "C" void BlockProcessor_Initialize_m2263257456 ();
extern "C" void KeyGeneratedEventHandler__ctor_m3801024251 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m1628355235 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m4131555809 ();
extern "C" void DSAManaged__ctor_m962128842 ();
extern "C" void DSAManaged_Dispose_m757362415 ();
extern "C" void DSAManaged_Finalize_m2286724636 ();
extern "C" void DSAManaged_Generate_m1247561684 ();
extern "C" void DSAManaged_GenerateKeyPair_m2236915969 ();
extern "C" void DSAManaged_GenerateParams_m2848737814 ();
extern "C" void DSAManaged_ImportParameters_m2247591247 ();
extern "C" void DSAManaged_add_m1505525960 ();
extern "C" void DSAManaged_add_KeyGenerated_m2286864968 ();
extern "C" void DSAManaged_remove_KeyGenerated_m1781077002 ();
extern "C" void HMAC__ctor_m775015853 ();
extern "C" void HMAC_HashCore_m1045651335 ();
extern "C" void HMAC_Initialize_m4068357959 ();
extern "C" void HMAC_initializePad_m59014980 ();
extern "C" void HMAC_set_Key_m3535779141 ();
extern "C" void KeyPairPersistence__cctor_m1700962802 ();
extern "C" void KeyPairPersistence__ctor_m103880447 ();
extern "C" void KeyPairPersistence__ctor_m252166830 ();
extern "C" void KeyPairPersistence_FromXml_m746585742 ();
extern "C" void KeyPairPersistence_Remove_m1876145547 ();
extern "C" void KeyPairPersistence_Save_m3111435398 ();
extern "C" void KeyPairPersistence_set_KeyValue_m3459302102 ();
extern "C" void MACAlgorithm__ctor_m3608996594 ();
extern "C" void MACAlgorithm_Core_m83451446 ();
extern "C" void MACAlgorithm_Initialize_m1409947493 ();
extern "C" void MD2__ctor_m2402458789 ();
extern "C" void MD2Managed__cctor_m1915574725 ();
extern "C" void MD2Managed__ctor_m3243422744 ();
extern "C" void MD2Managed_HashCore_m1280598655 ();
extern "C" void MD2Managed_Initialize_m2341076836 ();
extern "C" void MD2Managed_MD2Transform_m3143426291 ();
extern "C" void MD4__ctor_m919379109 ();
extern "C" void MD4Managed__ctor_m2284724408 ();
extern "C" void MD4Managed_Decode_m4273685594 ();
extern "C" void MD4Managed_Encode_m386285215 ();
extern "C" void MD4Managed_FF_m3294771481 ();
extern "C" void MD4Managed_GG_m1845276249 ();
extern "C" void MD4Managed_HH_m2535673516 ();
extern "C" void MD4Managed_HashCore_m3384203071 ();
extern "C" void MD4Managed_Initialize_m469436465 ();
extern "C" void MD4Managed_MD4Transform_m1101832482 ();
extern "C" void MD5SHA1__ctor_m4081016482 ();
extern "C" void MD5SHA1_HashCore_m4171647335 ();
extern "C" void MD5SHA1_Initialize_m675470944 ();
extern "C" void PKCS1__cctor_m266708662 ();
extern "C" void PKCS1__cctor_m2848504824 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m3217539356 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m3415744930 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m25839594 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m3274704095 ();
extern "C" void EncryptedPrivateKeyInfo_Decode_m2516465782 ();
extern "C" void EncryptedPrivateKeyInfo_Decode_m3008916518 ();
extern "C" void PrivateKeyInfo__ctor_m2811023496 ();
extern "C" void PrivateKeyInfo__ctor_m3331475997 ();
extern "C" void PrivateKeyInfo__ctor_m2414235375 ();
extern "C" void PrivateKeyInfo__ctor_m2715455038 ();
extern "C" void PrivateKeyInfo_Decode_m986145117 ();
extern "C" void PrivateKeyInfo_Decode_m682813286 ();
extern "C" void RC4__cctor_m362546962 ();
extern "C" void RC4__ctor_m3531760091 ();
extern "C" void RC4_set_IV_m844219403 ();
extern "C" void KeyGeneratedEventHandler__ctor_m4032730305 ();
extern "C" void KeyGeneratedEventHandler__ctor_m1990062371 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m2862962495 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m3057317531 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m2527485594 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m99769071 ();
extern "C" void RSAManaged__ctor_m3504773110 ();
extern "C" void RSAManaged__ctor_m3394311431 ();
extern "C" void RSAManaged__ctor_m350841446 ();
extern "C" void RSAManaged_Dispose_m1863653890 ();
extern "C" void RSAManaged_Dispose_m2347279430 ();
extern "C" void RSAManaged_Finalize_m297255587 ();
extern "C" void RSAManaged_Finalize_m3915335854 ();
extern "C" void RSAManaged_GenerateKeyPair_m2221292703 ();
extern "C" void RSAManaged_GenerateKeyPair_m2364618953 ();
extern "C" void RSAManaged_ImportParameters_m1117427048 ();
extern "C" void RSAManaged_ImportParameters_m1844641996 ();
extern "C" void RSAManaged_add_KeyGenerated_m3688329863 ();
extern "C" void RSAManaged_remove_KeyGenerated_m2046909903 ();
extern "C" void SymmetricTransform__ctor_m25459519 ();
extern "C" void SymmetricTransform__ctor_m2693628991 ();
extern "C" void SymmetricTransform_CBC_m3648398454 ();
extern "C" void SymmetricTransform_CBC_m435753239 ();
extern "C" void SymmetricTransform_CFB_m1755507252 ();
extern "C" void SymmetricTransform_CFB_m1051508796 ();
extern "C" void SymmetricTransform_CTS_m2571643614 ();
extern "C" void SymmetricTransform_CTS_m764800021 ();
extern "C" void SymmetricTransform_CheckInput_m1829858759 ();
extern "C" void SymmetricTransform_CheckInput_m2092289040 ();
extern "C" void SymmetricTransform_Dispose_m375394407 ();
extern "C" void SymmetricTransform_Dispose_m3894715243 ();
extern "C" void SymmetricTransform_Finalize_m4129642865 ();
extern "C" void SymmetricTransform_Finalize_m1463466895 ();
extern "C" void SymmetricTransform_OFB_m3690147804 ();
extern "C" void SymmetricTransform_OFB_m3842617151 ();
extern "C" void SymmetricTransform_Random_m2004892672 ();
extern "C" void SymmetricTransform_Random_m3740038270 ();
extern "C" void SymmetricTransform_System_IDisposable_Dispose_m3676111272 ();
extern "C" void SymmetricTransform_System_IDisposable_Dispose_m3657987482 ();
extern "C" void SymmetricTransform_ThrowBadPaddingException_m2926778011 ();
extern "C" void SymmetricTransform_ThrowBadPaddingException_m2898061954 ();
extern "C" void SymmetricTransform_Transform_m1683494363 ();
extern "C" void SymmetricTransform_Transform_m3073016850 ();
extern "C" void ContentInfo__ctor_m1955840786 ();
extern "C" void ContentInfo__ctor_m28146633 ();
extern "C" void ContentInfo__ctor_m3397951412 ();
extern "C" void ContentInfo__ctor_m2639021892 ();
extern "C" void ContentInfo__ctor_m1888388023 ();
extern "C" void ContentInfo__ctor_m2928874476 ();
extern "C" void ContentInfo__ctor_m3072134336 ();
extern "C" void ContentInfo__ctor_m2855743200 ();
extern "C" void ContentInfo_set_Content_m2745521966 ();
extern "C" void ContentInfo_set_Content_m2581255245 ();
extern "C" void ContentInfo_set_ContentType_m3848100294 ();
extern "C" void ContentInfo_set_ContentType_m3961495440 ();
extern "C" void EncryptedData__ctor_m257803736 ();
extern "C" void EncryptedData__ctor_m3841552120 ();
extern "C" void EncryptedData__ctor_m2497911783 ();
extern "C" void EncryptedData__ctor_m4001546383 ();
extern "C" void Alert__ctor_m3135936936 ();
extern "C" void Alert__ctor_m2879739792 ();
extern "C" void Alert_inferAlertLevel_m151204576 ();
extern "C" void CertificateSelectionCallback__ctor_m3437537928 ();
extern "C" void CertificateValidationCallback2__ctor_m1685875113 ();
extern "C" void CertificateValidationCallback__ctor_m1962610296 ();
extern "C" void CipherSuite__cctor_m3668442490 ();
extern "C" void CipherSuite__ctor_m2440635082 ();
extern "C" void CipherSuite_DecryptRecord_m1495386860 ();
extern "C" void CipherSuite_InitializeCipher_m2397698608 ();
extern "C" void CipherSuite_Write_m1172814058 ();
extern "C" void CipherSuite_Write_m1841735015 ();
extern "C" void CipherSuite_createDecryptionCipher_m1176259509 ();
extern "C" void CipherSuite_createEncryptionCipher_m2533565116 ();
extern "C" void CipherSuite_set_Context_m1978767807 ();
extern "C" void CipherSuiteCollection__ctor_m384434353 ();
extern "C" void CipherSuiteCollection_Clear_m2642701260 ();
extern "C" void CipherSuiteCollection_CopyTo_m3857518994 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Insert_m1567261820 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Remove_m2463347416 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_RemoveAt_m2600067414 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_set_Item_m904255570 ();
extern "C" void CipherSuiteCollection_set_Item_m2392524001 ();
extern "C" void ClientContext__ctor_m3993227749 ();
extern "C" void ClientContext_Clear_m1774063253 ();
extern "C" void ClientContext_set_ClientHelloProtocol_m4189379912 ();
extern "C" void ClientRecordProtocol__ctor_m2839844778 ();
extern "C" void ClientRecordProtocol_ProcessHandshakeMessage_m1002991731 ();
extern "C" void ClientSessionCache__cctor_m1380704214 ();
extern "C" void ClientSessionCache_Add_m964342678 ();
extern "C" void ClientSessionInfo__cctor_m1143076802 ();
extern "C" void ClientSessionInfo__ctor_m2436192270 ();
extern "C" void ClientSessionInfo_CheckDisposed_m1172439856 ();
extern "C" void ClientSessionInfo_Dispose_m1535509451 ();
extern "C" void ClientSessionInfo_Dispose_m3253728296 ();
extern "C" void ClientSessionInfo_Finalize_m2165787049 ();
extern "C" void ClientSessionInfo_GetContext_m1679628259 ();
extern "C" void ClientSessionInfo_KeepAlive_m1020179566 ();
extern "C" void ClientSessionInfo_SetContext_m2115875186 ();
extern "C" void Context__ctor_m1288667393 ();
extern "C" void Context_ChangeProtocol_m2412635871 ();
extern "C" void Context_Clear_m2678836033 ();
extern "C" void Context_ClearKeyInfo_m1155154290 ();
extern "C" void Context_EndSwitchingSecurityParameters_m4148956166 ();
extern "C" void Context_StartSwitchingSecurityParameters_m28285865 ();
extern "C" void Context_set_AbbreviatedHandshake_m827173393 ();
extern "C" void Context_set_ClientRandom_m2974454575 ();
extern "C" void Context_set_ClientWriteIV_m3405909624 ();
extern "C" void Context_set_ClientWriteKey_m1601425248 ();
extern "C" void Context_set_CompressionMethod_m2054483993 ();
extern "C" void Context_set_HandshakeState_m1329976135 ();
extern "C" void Context_set_LastHandshakeMsg_m1770618067 ();
extern "C" void Context_set_MasterSecret_m3419105191 ();
extern "C" void Context_set_ProtocolNegotiated_m2904861662 ();
extern "C" void Context_set_RandomCS_m2687068745 ();
extern "C" void Context_set_RandomSC_m2364786761 ();
extern "C" void Context_set_ReadSequenceNumber_m2154909392 ();
extern "C" void Context_set_ReceivedConnectionEnd_m911334662 ();
extern "C" void Context_set_RecordProtocol_m3067654641 ();
extern "C" void Context_set_SecurityProtocol_m2833661610 ();
extern "C" void Context_set_SentConnectionEnd_m1367645582 ();
extern "C" void Context_set_ServerRandom_m2929894009 ();
extern "C" void Context_set_ServerWriteIV_m1007123427 ();
extern "C" void Context_set_ServerWriteKey_m3347272648 ();
extern "C" void Context_set_SessionId_m942328427 ();
extern "C" void Context_set_SupportedCiphers_m4238648387 ();
extern "C" void Context_set_WriteSequenceNumber_m942577065 ();
extern "C" void TlsClientCertificate__ctor_m101524132 ();
extern "C" void TlsClientCertificate_GetClientCertificate_m566867090 ();
extern "C" void TlsClientCertificate_ProcessAsSsl3_m3265529850 ();
extern "C" void TlsClientCertificate_ProcessAsTls1_m3232146441 ();
extern "C" void TlsClientCertificate_SendCertificates_m1965594186 ();
extern "C" void TlsClientCertificate_Update_m1882970209 ();
extern "C" void TlsClientCertificateVerify__ctor_m1589614281 ();
extern "C" void TlsClientCertificateVerify_ProcessAsSsl3_m1125097704 ();
extern "C" void TlsClientCertificateVerify_ProcessAsTls1_m1051495755 ();
extern "C" void TlsClientCertificateVerify_Update_m3046208881 ();
extern "C" void TlsClientFinished__cctor_m1023921005 ();
extern "C" void TlsClientFinished__ctor_m399357014 ();
extern "C" void TlsClientFinished_ProcessAsSsl3_m3094597606 ();
extern "C" void TlsClientFinished_ProcessAsTls1_m2429863130 ();
extern "C" void TlsClientFinished_Update_m2408925771 ();
extern "C" void TlsClientHello__ctor_m1986768336 ();
extern "C" void TlsClientHello_ProcessAsSsl3_m3427133094 ();
extern "C" void TlsClientHello_ProcessAsTls1_m2549285167 ();
extern "C" void TlsClientHello_Update_m3773127362 ();
extern "C" void TlsClientKeyExchange__ctor_m31786095 ();
extern "C" void TlsClientKeyExchange_ProcessAsSsl3_m2576462374 ();
extern "C" void TlsClientKeyExchange_ProcessAsTls1_m338960549 ();
extern "C" void TlsClientKeyExchange_ProcessCommon_m2327374157 ();
extern "C" void TlsServerCertificate__ctor_m389328097 ();
extern "C" void TlsServerCertificate_ProcessAsSsl3_m1306583193 ();
extern "C" void TlsServerCertificate_ProcessAsTls1_m819212276 ();
extern "C" void TlsServerCertificate_Update_m3204893479 ();
extern "C" void TlsServerCertificate_validateCertificates_m4242999387 ();
extern "C" void TlsServerCertificateRequest__ctor_m1334974076 ();
extern "C" void TlsServerCertificateRequest_ProcessAsSsl3_m1084200341 ();
extern "C" void TlsServerCertificateRequest_ProcessAsTls1_m3214041063 ();
extern "C" void TlsServerCertificateRequest_Update_m2763887540 ();
extern "C" void TlsServerFinished__cctor_m3102699406 ();
extern "C" void TlsServerFinished__ctor_m1445633918 ();
extern "C" void TlsServerFinished_ProcessAsSsl3_m2791932180 ();
extern "C" void TlsServerFinished_ProcessAsTls1_m173877572 ();
extern "C" void TlsServerFinished_Update_m4073404386 ();
extern "C" void TlsServerHello__ctor_m3887266572 ();
extern "C" void TlsServerHello_ProcessAsSsl3_m3146647238 ();
extern "C" void TlsServerHello_ProcessAsTls1_m3844152353 ();
extern "C" void TlsServerHello_Update_m3935081401 ();
extern "C" void TlsServerHello_processProtocol_m3969427189 ();
extern "C" void TlsServerHelloDone__ctor_m173627900 ();
extern "C" void TlsServerHelloDone_ProcessAsSsl3_m3042614798 ();
extern "C" void TlsServerHelloDone_ProcessAsTls1_m952337401 ();
extern "C" void TlsServerKeyExchange__ctor_m3572942737 ();
extern "C" void TlsServerKeyExchange_ProcessAsSsl3_m2880115419 ();
extern "C" void TlsServerKeyExchange_ProcessAsTls1_m49623614 ();
extern "C" void TlsServerKeyExchange_Update_m453798279 ();
extern "C" void TlsServerKeyExchange_verifySignature_m3412856769 ();
extern "C" void HandshakeMessage__ctor_m2692487706 ();
extern "C" void HandshakeMessage__ctor_m1353615444 ();
extern "C" void HandshakeMessage__ctor_m1555296807 ();
extern "C" void HandshakeMessage_Process_m810828609 ();
extern "C" void HandshakeMessage_Update_m2417837686 ();
extern "C" void HttpsClientStream__ctor_m3125726871 ();
extern "C" void PrivateKeySelectionCallback__ctor_m265141085 ();
extern "C" void RSASslSignatureDeformatter__ctor_m4026549112 ();
extern "C" void RSASslSignatureDeformatter_SetHashAlgorithm_m895570787 ();
extern "C" void RSASslSignatureDeformatter_SetKey_m2204705853 ();
extern "C" void RSASslSignatureFormatter__ctor_m1299283008 ();
extern "C" void RSASslSignatureFormatter_SetHashAlgorithm_m3864232300 ();
extern "C" void RSASslSignatureFormatter_SetKey_m979790541 ();
extern "C" void ReceiveRecordAsyncResult__ctor_m277637112 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m464469214 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m1568733499 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m1372905673 ();
extern "C" void SendRecordAsyncResult__ctor_m425551707 ();
extern "C" void SendRecordAsyncResult_SetComplete_m170417386 ();
extern "C" void SendRecordAsyncResult_SetComplete_m153213906 ();
extern "C" void RecordProtocol__cctor_m1280873827 ();
extern "C" void RecordProtocol__ctor_m1695232390 ();
extern "C" void RecordProtocol_EndSendRecord_m4264777321 ();
extern "C" void RecordProtocol_InternalReceiveRecordCallback_m1713318629 ();
extern "C" void RecordProtocol_InternalSendRecordCallback_m682661965 ();
extern "C" void RecordProtocol_ProcessAlert_m1036912531 ();
extern "C" void RecordProtocol_ProcessChangeCipherSpec_m15839975 ();
extern "C" void RecordProtocol_ProcessCipherSpecV2Buffer_m487045483 ();
extern "C" void RecordProtocol_SendAlert_m3736432480 ();
extern "C" void RecordProtocol_SendAlert_m1931708341 ();
extern "C" void RecordProtocol_SendAlert_m2670098001 ();
extern "C" void RecordProtocol_SendChangeCipherSpec_m464005157 ();
extern "C" void RecordProtocol_SendRecord_m927045752 ();
extern "C" void RecordProtocol_SendRecord_m515492272 ();
extern "C" void SecurityParameters__ctor_m3952189175 ();
extern "C" void SecurityParameters_Clear_m680574382 ();
extern "C" void SecurityParameters_set_Cipher_m588445085 ();
extern "C" void SecurityParameters_set_ClientWriteMAC_m2984527188 ();
extern "C" void SecurityParameters_set_ServerWriteMAC_m3003817350 ();
extern "C" void SslCipherSuite__ctor_m1470082018 ();
extern "C" void SslCipherSuite_ComputeKeys_m661027754 ();
extern "C" void SslCipherSuite_ComputeMasterSecret_m3963626850 ();
extern "C" void SslClientStream__ctor_m2402546929 ();
extern "C" void SslClientStream__ctor_m3478574780 ();
extern "C" void SslClientStream__ctor_m3351906728 ();
extern "C" void SslClientStream__ctor_m4190306291 ();
extern "C" void SslClientStream__ctor_m3745813135 ();
extern "C" void SslClientStream_Dispose_m232031134 ();
extern "C" void SslClientStream_Finalize_m1251363641 ();
extern "C" void SslClientStream_OnNegotiateHandshakeCallback_m4211921295 ();
extern "C" void SslClientStream_SafeReceiveRecord_m2217679740 ();
extern "C" void SslClientStream_add_ClientCertSelection_m1387948363 ();
extern "C" void SslClientStream_add_PrivateKeySelection_m1663125063 ();
extern "C" void SslClientStream_add_ServerCertValidation_m2218216724 ();
extern "C" void SslClientStream_add_ServerCertValidation2_m3943665702 ();
extern "C" void SslClientStream_remove_ClientCertSelection_m24681826 ();
extern "C" void SslClientStream_remove_PrivateKeySelection_m3637735463 ();
extern "C" void SslClientStream_remove_ServerCertValidation_m1143339871 ();
extern "C" void SslClientStream_remove_ServerCertValidation2_m4151895043 ();
extern "C" void SslClientStream_set_ClientCertSelectionDelegate_m1261530976 ();
extern "C" void SslClientStream_set_PrivateKeyCertSelectionDelegate_m4100936974 ();
extern "C" void SslClientStream_set_ServerCertValidationDelegate_m466396564 ();
extern "C" void SslHandshakeHash__ctor_m4169387017 ();
extern "C" void SslHandshakeHash_HashCore_m2801927991 ();
extern "C" void SslHandshakeHash_Initialize_m290045843 ();
extern "C" void SslHandshakeHash_initializePad_m1074089276 ();
extern "C" void InternalAsyncResult__ctor_m2194591319 ();
extern "C" void InternalAsyncResult_SetComplete_m544889140 ();
extern "C" void InternalAsyncResult_SetComplete_m693091794 ();
extern "C" void InternalAsyncResult_SetComplete_m3332189472 ();
extern "C" void InternalAsyncResult_SetComplete_m963842420 ();
extern "C" void SslStreamBase__cctor_m548992348 ();
extern "C" void SslStreamBase__ctor_m3009266308 ();
extern "C" void SslStreamBase_AsyncHandshakeCallback_m2936782521 ();
extern "C" void SslStreamBase_Close_m967013602 ();
extern "C" void SslStreamBase_Dispose_m3190415328 ();
extern "C" void SslStreamBase_EndNegotiateHandshake_m1124299797 ();
extern "C" void SslStreamBase_EndWrite_m4073224031 ();
extern "C" void SslStreamBase_Finalize_m3260913635 ();
extern "C" void SslStreamBase_Flush_m3601530442 ();
extern "C" void SslStreamBase_InternalBeginRead_m3419999901 ();
extern "C" void SslStreamBase_InternalBeginWrite_m1722032773 ();
extern "C" void SslStreamBase_InternalReadCallback_m3350299308 ();
extern "C" void SslStreamBase_InternalWriteCallback_m3466627959 ();
extern "C" void SslStreamBase_NegotiateHandshake_m2455724401 ();
extern "C" void SslStreamBase_SetLength_m844764688 ();
extern "C" void SslStreamBase_Write_m1052022549 ();
extern "C" void SslStreamBase_Write_m2024331816 ();
extern "C" void SslStreamBase_checkDisposed_m1981591244 ();
extern "C" void SslStreamBase_resetBuffer_m3910686848 ();
extern "C" void SslStreamBase_set_CheckCertRevocationStatus_m912861213 ();
extern "C" void SslStreamBase_set_Position_m1470736124 ();
extern "C" void TlsCipherSuite__ctor_m3580955828 ();
extern "C" void TlsCipherSuite_ComputeKeys_m1386728983 ();
extern "C" void TlsCipherSuite_ComputeMasterSecret_m362444953 ();
extern "C" void TlsClientSettings__ctor_m3220697265 ();
extern "C" void TlsClientSettings_UpdateCertificateRSA_m3878128853 ();
extern "C" void TlsClientSettings_set_Certificates_m3887201895 ();
extern "C" void TlsClientSettings_set_ClientCertificate_m3374228612 ();
extern "C" void TlsClientSettings_set_TargetHost_m3350021121 ();
extern "C" void TlsException__ctor_m818940807 ();
extern "C" void TlsException__ctor_m3242533711 ();
extern "C" void TlsException__ctor_m596254082 ();
extern "C" void TlsException__ctor_m3717683709 ();
extern "C" void TlsException__ctor_m2342093437 ();
extern "C" void TlsException__ctor_m3652817735 ();
extern "C" void TlsServerSettings__ctor_m373357120 ();
extern "C" void TlsServerSettings_UpdateCertificateRSA_m3985265846 ();
extern "C" void TlsServerSettings_set_CertificateRequest_m1039729760 ();
extern "C" void TlsServerSettings_set_CertificateTypes_m2047242411 ();
extern "C" void TlsServerSettings_set_Certificates_m3313375596 ();
extern "C" void TlsServerSettings_set_DistinguisedNames_m787752700 ();
extern "C" void TlsServerSettings_set_RsaParameters_m853026166 ();
extern "C" void TlsServerSettings_set_ServerKeyExchange_m3302765325 ();
extern "C" void TlsServerSettings_set_SignedParams_m3618693098 ();
extern "C" void TlsStream__ctor_m787793111 ();
extern "C" void TlsStream__ctor_m277557575 ();
extern "C" void TlsStream_Flush_m3793197834 ();
extern "C" void TlsStream_Reset_m369197964 ();
extern "C" void TlsStream_SetLength_m2444039643 ();
extern "C" void TlsStream_Write_m4246040664 ();
extern "C" void TlsStream_Write_m4133894341 ();
extern "C" void TlsStream_Write_m188217214 ();
extern "C" void TlsStream_Write_m1412844442 ();
extern "C" void TlsStream_Write_m1413106584 ();
extern "C" void TlsStream_WriteInt24_m58952549 ();
extern "C" void TlsStream_set_Position_m3867366920 ();
extern "C" void StrongName__cctor_m1246179561 ();
extern "C" void StrongName__ctor_m467142887 ();
extern "C" void StrongName__ctor_m3939359439 ();
extern "C" void StrongName_InvalidateCache_m4128978353 ();
extern "C" void StrongName_set_RSA_m3858265129 ();
extern "C" void AuthorityKeyIdentifierExtension__ctor_m373495498 ();
extern "C" void AuthorityKeyIdentifierExtension_Decode_m1082741678 ();
extern "C" void BasicConstraintsExtension__ctor_m3191645544 ();
extern "C" void BasicConstraintsExtension_Decode_m2935957709 ();
extern "C" void BasicConstraintsExtension_Encode_m2009213240 ();
extern "C" void ExtendedKeyUsageExtension__ctor_m3228998638 ();
extern "C" void ExtendedKeyUsageExtension_Decode_m2326833343 ();
extern "C" void ExtendedKeyUsageExtension_Encode_m2182457162 ();
extern "C" void GeneralNames__ctor_m3642449536 ();
extern "C" void KeyUsageExtension__ctor_m3414452076 ();
extern "C" void KeyUsageExtension_Decode_m1408685233 ();
extern "C" void KeyUsageExtension_Encode_m2561267096 ();
extern "C" void NetscapeCertTypeExtension__ctor_m323882095 ();
extern "C" void NetscapeCertTypeExtension_Decode_m251886799 ();
extern "C" void SubjectAltNameExtension__ctor_m1991362362 ();
extern "C" void SubjectAltNameExtension_Decode_m2617923884 ();
extern "C" void DeriveBytes__cctor_m3019062497 ();
extern "C" void DeriveBytes__cctor_m1212925033 ();
extern "C" void DeriveBytes__ctor_m2211845228 ();
extern "C" void DeriveBytes__ctor_m3611803810 ();
extern "C" void DeriveBytes_Adjust_m1814768799 ();
extern "C" void DeriveBytes_Adjust_m640796917 ();
extern "C" void DeriveBytes_set_HashName_m3612196732 ();
extern "C" void DeriveBytes_set_HashName_m3752780137 ();
extern "C" void DeriveBytes_set_IterationCount_m3824132378 ();
extern "C" void DeriveBytes_set_IterationCount_m3235108425 ();
extern "C" void DeriveBytes_set_Password_m3005258189 ();
extern "C" void DeriveBytes_set_Password_m4086840123 ();
extern "C" void DeriveBytes_set_Salt_m441577179 ();
extern "C" void DeriveBytes_set_Salt_m1400945044 ();
extern "C" void PKCS12__cctor_m2862471915 ();
extern "C" void PKCS12__cctor_m3271060407 ();
extern "C" void PKCS12__ctor_m2768693996 ();
extern "C" void PKCS12__ctor_m1854440921 ();
extern "C" void PKCS12__ctor_m2471257156 ();
extern "C" void PKCS12__ctor_m2089474062 ();
extern "C" void PKCS12__ctor_m1771540803 ();
extern "C" void PKCS12__ctor_m2483239261 ();
extern "C" void PKCS12_AddCertificate_m3857004455 ();
extern "C" void PKCS12_AddCertificate_m3679554094 ();
extern "C" void PKCS12_AddCertificate_m3820167082 ();
extern "C" void PKCS12_AddCertificate_m3618696508 ();
extern "C" void PKCS12_AddPrivateKey_m1542850936 ();
extern "C" void PKCS12_AddPrivateKey_m1877554254 ();
extern "C" void PKCS12_Decode_m163534693 ();
extern "C" void PKCS12_Decode_m1913457787 ();
extern "C" void PKCS12_Finalize_m507756088 ();
extern "C" void PKCS12_Finalize_m1390639705 ();
extern "C" void PKCS12_ReadSafeBag_m3435973087 ();
extern "C" void PKCS12_ReadSafeBag_m1585166574 ();
extern "C" void PKCS12_RemoveCertificate_m3555301339 ();
extern "C" void PKCS12_RemoveCertificate_m1177171903 ();
extern "C" void PKCS12_RemoveCertificate_m1421555398 ();
extern "C" void PKCS12_RemoveCertificate_m2774912578 ();
extern "C" void PKCS12_set_IterationCount_m1399630158 ();
extern "C" void PKCS12_set_IterationCount_m2605460921 ();
extern "C" void PKCS12_set_Password_m3259330454 ();
extern "C" void PKCS12_set_Password_m4088935795 ();
extern "C" void SafeBag__ctor_m3881032521 ();
extern "C" void SafeBag__ctor_m369012969 ();
extern "C" void X501__cctor_m1166912714 ();
extern "C" void X501__cctor_m2428304915 ();
extern "C" void X501_AppendEntry_m2470239841 ();
extern "C" void X501_AppendEntry_m2479013363 ();
extern "C" void X509Certificate__cctor_m198658613 ();
extern "C" void X509Certificate__cctor_m1746020738 ();
extern "C" void X509Certificate__ctor_m3656389950 ();
extern "C" void X509Certificate__ctor_m553243489 ();
extern "C" void X509Certificate_GetObjectData_m2952009451 ();
extern "C" void X509Certificate_GetObjectData_m2057262401 ();
extern "C" void X509Certificate_Parse_m1106379228 ();
extern "C" void X509Certificate_Parse_m54358579 ();
extern "C" void X509Certificate_set_DSA_m753722200 ();
extern "C" void X509Certificate_set_KeyAlgorithmParameters_m2010117999 ();
extern "C" void X509Certificate_set_RSA_m3534515075 ();
extern "C" void X509CertificateEnumerator__ctor_m3747779152 ();
extern "C" void X509CertificateEnumerator__ctor_m85694331 ();
extern "C" void X509CertificateEnumerator_Reset_m122774664 ();
extern "C" void X509CertificateEnumerator_Reset_m1825523691 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2039524926 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2928805663 ();
extern "C" void X509CertificateCollection__ctor_m2066277891 ();
extern "C" void X509CertificateCollection__ctor_m3365535796 ();
extern "C" void X509CertificateCollection__ctor_m3467061452 ();
extern "C" void X509CertificateCollection_AddRange_m2165814476 ();
extern "C" void X509CertificateCollection_Remove_m2199606504 ();
extern "C" void X509Chain__ctor_m3563800449 ();
extern "C" void X509Chain__ctor_m1084071882 ();
extern "C" void X509CrlEntry__ctor_m4013514048 ();
extern "C" void X509Crl__ctor_m1817187405 ();
extern "C" void X509Crl_Parse_m3164013387 ();
extern "C" void X509Extension__ctor_m1750445243 ();
extern "C" void X509Extension__ctor_m710637961 ();
extern "C" void X509Extension__ctor_m1474351312 ();
extern "C" void X509Extension_Decode_m833805412 ();
extern "C" void X509Extension_Decode_m3172373814 ();
extern "C" void X509Extension_Encode_m3152909591 ();
extern "C" void X509Extension_WriteLine_m1662885247 ();
extern "C" void X509Extension_WriteLine_m1400196767 ();
extern "C" void X509ExtensionCollection__ctor_m2416193357 ();
extern "C" void X509ExtensionCollection__ctor_m2474799343 ();
extern "C" void X509ExtensionCollection__ctor_m3315097415 ();
extern "C" void X509ExtensionCollection__ctor_m551870633 ();
extern "C" void X509Store__ctor_m2736551756 ();
extern "C" void X509Stores__ctor_m1786355972 ();
extern "C" void SecurityParser__ctor_m1786039976 ();
extern "C" void SecurityParser_LoadXml_m1638830459 ();
extern "C" void SecurityParser_OnChars_m396174937 ();
extern "C" void SecurityParser_OnEndElement_m2088612360 ();
extern "C" void SecurityParser_OnEndParsing_m2521892142 ();
extern "C" void SecurityParser_OnIgnorableWhitespace_m1130543143 ();
extern "C" void SecurityParser_OnProcessingInstruction_m2327827622 ();
extern "C" void SecurityParser_OnStartElement_m2534612579 ();
extern "C" void SecurityParser_OnStartParsing_m160443947 ();
extern "C" void AttrListImpl__ctor_m3844427077 ();
extern "C" void AttrListImpl_Add_m3378108236 ();
extern "C" void AttrListImpl_Clear_m2260362286 ();
extern "C" void SmallXmlParser__ctor_m202236734 ();
extern "C" void SmallXmlParser_Cleanup_m2310464878 ();
extern "C" void SmallXmlParser_Expect_m674880652 ();
extern "C" void SmallXmlParser_HandleBufferedContent_m3185158999 ();
extern "C" void SmallXmlParser_HandleWhitespaces_m549588711 ();
extern "C" void SmallXmlParser_Parse_m2140493703 ();
extern "C" void SmallXmlParser_ReadAttribute_m3518350607 ();
extern "C" void SmallXmlParser_ReadCDATASection_m138715165 ();
extern "C" void SmallXmlParser_ReadCharacters_m3318286261 ();
extern "C" void SmallXmlParser_ReadComment_m1578426707 ();
extern "C" void SmallXmlParser_ReadContent_m1631445300 ();
extern "C" void SmallXmlParser_ReadReference_m1750252339 ();
extern "C" void SmallXmlParser_SkipWhitespaces_m990960618 ();
extern "C" void SmallXmlParser_SkipWhitespaces_m4243606597 ();
extern "C" void SmallXmlParserException__ctor_m1976648878 ();
extern "C" void AccessViolationException__ctor_m459401853 ();
extern "C" void AccessViolationException__ctor_m506103991 ();
extern "C" void Action__ctor_m2994342681 ();
extern "C" void Action_EndInvoke_m1690492879 ();
extern "C" void Action_Invoke_m937035532 ();
extern "C" void ActivationContext_Dispose_m827530843 ();
extern "C" void ActivationContext_Dispose_m2038725770 ();
extern "C" void ActivationContext_Finalize_m1527946098 ();
extern "C" void ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m2821911612 ();
extern "C" void Activator_CheckAbstractType_m2015247896 ();
extern "C" void Activator_CheckType_m2787213785 ();
extern "C" void AppDomain__ctor_m900298256 ();
extern "C" void AppDomain_InternalPopDomainRef_m412593501 ();
extern "C" void AppDomain_InternalPushDomainRefByID_m1598870089 ();
extern "C" void AppDomain_ProcessMessageInDomain_m1871749965 ();
extern "C" void AppDomain_add_UnhandledException_m66698413 ();
extern "C" void AppDomain_remove_UnhandledException_m1144722992 ();
extern "C" void AppDomainInitializer__ctor_m804756664 ();
extern "C" void AppDomainInitializer_EndInvoke_m2095010821 ();
extern "C" void AppDomainInitializer_Invoke_m1036878490 ();
extern "C" void AppDomainSetup__ctor_m363420372 ();
extern "C" void ApplicationException__ctor_m2557611022 ();
extern "C" void ApplicationException__ctor_m1689533002 ();
extern "C" void ApplicationException__ctor_m2517758450 ();
extern "C" void ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m995105840 ();
extern "C" void ArgumentException__ctor_m3698743796 ();
extern "C" void ArgumentException__ctor_m3200406061 ();
extern "C" void ArgumentException__ctor_m1312628991 ();
extern "C" void ArgumentException__ctor_m1535060261 ();
extern "C" void ArgumentException__ctor_m1216717135 ();
extern "C" void ArgumentException__ctor_m3761792013 ();
extern "C" void ArgumentException_GetObjectData_m4122729010 ();
extern "C" void ArgumentNullException__ctor_m2751210921 ();
extern "C" void ArgumentNullException__ctor_m520761569 ();
extern "C" void ArgumentNullException__ctor_m1170824041 ();
extern "C" void ArgumentNullException__ctor_m2009621981 ();
extern "C" void ArgumentOutOfRangeException__ctor_m2047740448 ();
extern "C" void ArgumentOutOfRangeException__ctor_m769015475 ();
extern "C" void ArgumentOutOfRangeException__ctor_m3628145864 ();
extern "C" void ArgumentOutOfRangeException__ctor_m4164965325 ();
extern "C" void ArgumentOutOfRangeException__ctor_m282481429 ();
extern "C" void ArgumentOutOfRangeException_GetObjectData_m1344552880 ();
extern "C" void ArithmeticException__ctor_m479063094 ();
extern "C" void ArithmeticException__ctor_m1658426420 ();
extern "C" void ArithmeticException__ctor_m3551809662 ();
extern "C" void SimpleEnumerator__ctor_m353509656 ();
extern "C" void SimpleEnumerator_Reset_m2182001888 ();
extern "C" void Swapper__ctor_m3019156154 ();
extern "C" void Swapper_EndInvoke_m1804951082 ();
extern "C" void Swapper_Invoke_m2596472750 ();
extern "C" void Array__ctor_m2178462056 ();
extern "C" void Array_Clear_m2231608178 ();
extern "C" void Array_ClearInternal_m532048538 ();
extern "C" void Array_ConstrainedCopy_m3673290180 ();
extern "C" void Array_Copy_m1988217701 ();
extern "C" void Array_Copy_m1988610914 ();
extern "C" void Array_Copy_m344457298 ();
extern "C" void Array_Copy_m514679699 ();
extern "C" void Array_CopyTo_m225704097 ();
extern "C" void Array_CopyTo_m3358199659 ();
extern "C" void Array_Initialize_m3004991267 ();
extern "C" void Array_InternalArray__ICollection_Clear_m4058340337 ();
extern "C" void Array_InternalArray__RemoveAt_m616137314 ();
extern "C" void Array_Reverse_m3714848183 ();
extern "C" void Array_Reverse_m816310962 ();
extern "C" void Array_SetValue_m3412255035 ();
extern "C" void Array_SetValue_m3998268557 ();
extern "C" void Array_SetValue_m2601781200 ();
extern "C" void Array_SetValue_m1804138688 ();
extern "C" void Array_SetValue_m3412648248 ();
extern "C" void Array_SetValue_m394135409 ();
extern "C" void Array_SetValue_m282347242 ();
extern "C" void Array_SetValue_m1817114699 ();
extern "C" void Array_SetValueImpl_m2791230289 ();
extern "C" void Array_Sort_m3698291233 ();
extern "C" void Array_Sort_m459550270 ();
extern "C" void Array_Sort_m3145621264 ();
extern "C" void Array_Sort_m2147377746 ();
extern "C" void Array_Sort_m2934663614 ();
extern "C" void Array_Sort_m870838517 ();
extern "C" void Array_Sort_m3287581440 ();
extern "C" void Array_Sort_m182264525 ();
extern "C" void Array_System_Collections_IList_Clear_m1278271623 ();
extern "C" void Array_System_Collections_IList_Insert_m2476478913 ();
extern "C" void Array_System_Collections_IList_Remove_m1479535418 ();
extern "C" void Array_System_Collections_IList_RemoveAt_m41405158 ();
extern "C" void Array_System_Collections_IList_set_Item_m2667455393 ();
extern "C" void Array_combsort_m2745184932 ();
extern "C" void Array_combsort_m3017221499 ();
extern "C" void Array_combsort_m4052486289 ();
extern "C" void Array_double_swapper_m4135376022 ();
extern "C" void Array_int_swapper_m3830919681 ();
extern "C" void Array_obj_swapper_m472969017 ();
extern "C" void Array_qsort_m3156569874 ();
extern "C" void Array_slow_swapper_m4116724811 ();
extern "C" void Array_swap_m547389985 ();
extern "C" void ArrayTypeMismatchException__ctor_m3375008173 ();
extern "C" void ArrayTypeMismatchException__ctor_m2621976975 ();
extern "C" void ArrayTypeMismatchException__ctor_m231257638 ();
extern "C" void AssemblyLoadEventHandler__ctor_m896828968 ();
extern "C" void AssemblyLoadEventHandler_EndInvoke_m18714231 ();
extern "C" void AssemblyLoadEventHandler_Invoke_m1462077361 ();
extern "C" void AsyncCallback__ctor_m530647953 ();
extern "C" void AsyncCallback_EndInvoke_m1460833738 ();
extern "C" void AsyncCallback_Invoke_m3156993048 ();
extern "C" void Attribute__ctor_m1529526131 ();
extern "C" void Attribute_CheckParameters_m456532822 ();
extern "C" void AttributeUsageAttribute__ctor_m3683365572 ();
extern "C" void AttributeUsageAttribute_set_AllowMultiple_m625992462 ();
extern "C" void AttributeUsageAttribute_set_Inherited_m1799999820 ();
extern "C" void BitConverter__cctor_m3841343255 ();
extern "C" void BitConverter_PutBytes_m2614286581 ();
extern "C" void Boolean__cctor_m1091629305 ();
extern "C" void Buffer_BlockCopy_m2884209081 ();
extern "C" void CLSCompliantAttribute__ctor_m581760440 ();
extern "C" void Char__cctor_m2787437263 ();
extern "C" void Char_CheckParameter_m4114020212 ();
extern "C" void Char_GetDataTablePointers_m754571594 ();
extern "C" void CharEnumerator__ctor_m3465358752 ();
extern "C" void CharEnumerator_Reset_m2829582932 ();
extern "C" void CharEnumerator_System_IDisposable_Dispose_m1750532533 ();
extern "C" void ArrayListWrapper__ctor_m970192266 ();
extern "C" void ArrayListWrapper_AddRange_m2748690765 ();
extern "C" void ArrayListWrapper_Clear_m2625302714 ();
extern "C" void ArrayListWrapper_CopyTo_m2912068327 ();
extern "C" void ArrayListWrapper_CopyTo_m3756520478 ();
extern "C" void ArrayListWrapper_CopyTo_m498486826 ();
extern "C" void ArrayListWrapper_Insert_m121888774 ();
extern "C" void ArrayListWrapper_InsertRange_m3525676562 ();
extern "C" void ArrayListWrapper_Remove_m3759993909 ();
extern "C" void ArrayListWrapper_RemoveAt_m805762255 ();
extern "C" void ArrayListWrapper_Sort_m1587743350 ();
extern "C" void ArrayListWrapper_Sort_m876172478 ();
extern "C" void ArrayListWrapper_set_Capacity_m2373297383 ();
extern "C" void ArrayListWrapper_set_Item_m3849584877 ();
extern "C" void FixedSizeArrayListWrapper__ctor_m3150386652 ();
extern "C" void FixedSizeArrayListWrapper_AddRange_m413351014 ();
extern "C" void FixedSizeArrayListWrapper_Clear_m1544415003 ();
extern "C" void FixedSizeArrayListWrapper_Insert_m723948816 ();
extern "C" void FixedSizeArrayListWrapper_InsertRange_m1706982628 ();
extern "C" void FixedSizeArrayListWrapper_Remove_m3827525800 ();
extern "C" void FixedSizeArrayListWrapper_RemoveAt_m3591870267 ();
extern "C" void FixedSizeArrayListWrapper_set_Capacity_m4221053039 ();
extern "C" void ReadOnlyArrayListWrapper__ctor_m1527708879 ();
extern "C" void ReadOnlyArrayListWrapper_Sort_m2577012511 ();
extern "C" void ReadOnlyArrayListWrapper_Sort_m2022378864 ();
extern "C" void ReadOnlyArrayListWrapper_set_Item_m1909157432 ();
extern "C" void SimpleEnumerator__cctor_m2844299657 ();
extern "C" void SimpleEnumerator__ctor_m917940076 ();
extern "C" void SimpleEnumerator_Reset_m1520014659 ();
extern "C" void SynchronizedArrayListWrapper__ctor_m3368338124 ();
extern "C" void SynchronizedArrayListWrapper_AddRange_m4141530892 ();
extern "C" void SynchronizedArrayListWrapper_Clear_m2191301493 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m2886332653 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m4207791406 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m1305044270 ();
extern "C" void SynchronizedArrayListWrapper_Insert_m1867902338 ();
extern "C" void SynchronizedArrayListWrapper_InsertRange_m2374130561 ();
extern "C" void SynchronizedArrayListWrapper_Remove_m47731590 ();
extern "C" void SynchronizedArrayListWrapper_RemoveAt_m122715760 ();
extern "C" void SynchronizedArrayListWrapper_Sort_m275448700 ();
extern "C" void SynchronizedArrayListWrapper_Sort_m575592975 ();
extern "C" void SynchronizedArrayListWrapper_set_Capacity_m514089537 ();
extern "C" void SynchronizedArrayListWrapper_set_Item_m1979747874 ();
extern "C" void ArrayList__cctor_m3052737821 ();
extern "C" void ArrayList__ctor_m4254721275 ();
extern "C" void ArrayList__ctor_m2130986447 ();
extern "C" void ArrayList__ctor_m3828927650 ();
extern "C" void ArrayList__ctor_m2075768692 ();
extern "C" void ArrayList_AddRange_m3758299474 ();
extern "C" void ArrayList_Clear_m3564447992 ();
extern "C" void ArrayList_CopyTo_m3530931172 ();
extern "C" void ArrayList_CopyTo_m3962521159 ();
extern "C" void ArrayList_CopyTo_m3105450421 ();
extern "C" void ArrayList_EnsureCapacity_m3016383533 ();
extern "C" void ArrayList_Insert_m3524057793 ();
extern "C" void ArrayList_InsertRange_m1740766984 ();
extern "C" void ArrayList_Remove_m4274871153 ();
extern "C" void ArrayList_RemoveAt_m761734947 ();
extern "C" void ArrayList_Shift_m395607654 ();
extern "C" void ArrayList_Sort_m582560637 ();
extern "C" void ArrayList_Sort_m4234055499 ();
extern "C" void ArrayList_ThrowNewArgumentOutOfRangeException_m3110627888 ();
extern "C" void ArrayList_set_Capacity_m1058991803 ();
extern "C" void ArrayList_set_Item_m2003485935 ();
extern "C" void BitArrayEnumerator__ctor_m2359341397 ();
extern "C" void BitArrayEnumerator_Reset_m2256666019 ();
extern "C" void BitArrayEnumerator_checkVersion_m500404395 ();
extern "C" void BitArray__ctor_m2765908219 ();
extern "C" void BitArray__ctor_m52841262 ();
extern "C" void BitArray_CopyTo_m4205938202 ();
extern "C" void BitArray_Set_m2486900776 ();
extern "C" void BitArray_set_Item_m3453667491 ();
extern "C" void CaseInsensitiveComparer__cctor_m2727609021 ();
extern "C" void CaseInsensitiveComparer__ctor_m1508720200 ();
extern "C" void CaseInsensitiveComparer__ctor_m2101975011 ();
extern "C" void CaseInsensitiveHashCodeProvider__cctor_m3655208966 ();
extern "C" void CaseInsensitiveHashCodeProvider__ctor_m1410573049 ();
extern "C" void CaseInsensitiveHashCodeProvider__ctor_m3307631072 ();
extern "C" void CollectionBase__ctor_m3343513710 ();
extern "C" void CollectionBase_Clear_m1509125218 ();
extern "C" void CollectionBase_OnClear_m883003723 ();
extern "C" void CollectionBase_OnClearComplete_m4210220284 ();
extern "C" void CollectionBase_OnInsert_m120287429 ();
extern "C" void CollectionBase_OnInsertComplete_m1538306973 ();
extern "C" void CollectionBase_OnRemove_m3955998913 ();
extern "C" void CollectionBase_OnRemoveComplete_m1811247246 ();
extern "C" void CollectionBase_OnSet_m598471137 ();
extern "C" void CollectionBase_OnSetComplete_m2395939597 ();
extern "C" void CollectionBase_OnValidate_m1606907366 ();
extern "C" void CollectionBase_RemoveAt_m3336462814 ();
extern "C" void CollectionBase_System_Collections_ICollection_CopyTo_m2850099809 ();
extern "C" void CollectionBase_System_Collections_IList_Insert_m1955629979 ();
extern "C" void CollectionBase_System_Collections_IList_Remove_m1918979845 ();
extern "C" void CollectionBase_System_Collections_IList_set_Item_m1592328081 ();
extern "C" void Comparer__cctor_m3311686689 ();
extern "C" void Comparer__ctor_m2831654082 ();
extern "C" void Comparer__ctor_m2580215220 ();
extern "C" void Comparer_GetObjectData_m2064315569 ();
extern "C" void DictionaryEntry__ctor_m2585376310_AdjustorThunk ();
extern "C" void KeyNotFoundException__ctor_m541499307 ();
extern "C" void KeyNotFoundException__ctor_m813515407 ();
extern "C" void KeyNotFoundException__ctor_m2696589580 ();
extern "C" void Enumerator__cctor_m4169372056 ();
extern "C" void Enumerator__ctor_m3921352641 ();
extern "C" void Enumerator_FailFast_m3955249002 ();
extern "C" void Enumerator_Reset_m4274366540 ();
extern "C" void HashKeys__ctor_m2668698759 ();
extern "C" void HashKeys_CopyTo_m4219627824 ();
extern "C" void HashValues__ctor_m1651100305 ();
extern "C" void HashValues_CopyTo_m2621023127 ();
extern "C" void KeyMarker__cctor_m2590194914 ();
extern "C" void KeyMarker__ctor_m2295185526 ();
extern "C" void SyncHashtable__ctor_m988729399 ();
extern "C" void SyncHashtable__ctor_m2449935938 ();
extern "C" void SyncHashtable_Add_m3016107307 ();
extern "C" void SyncHashtable_Clear_m714964133 ();
extern "C" void SyncHashtable_CopyTo_m3934112540 ();
extern "C" void SyncHashtable_GetObjectData_m672594935 ();
extern "C" void SyncHashtable_Remove_m4179265271 ();
extern "C" void SyncHashtable_set_Item_m2451773607 ();
extern "C" void Hashtable__cctor_m4112166779 ();
extern "C" void Hashtable__ctor_m1815022027 ();
extern "C" void Hashtable__ctor_m3890751112 ();
extern "C" void Hashtable__ctor_m465544153 ();
extern "C" void Hashtable__ctor_m2421324048 ();
extern "C" void Hashtable__ctor_m2302711321 ();
extern "C" void Hashtable__ctor_m1684344284 ();
extern "C" void Hashtable__ctor_m3305570058 ();
extern "C" void Hashtable__ctor_m1763145853 ();
extern "C" void Hashtable__ctor_m3542198234 ();
extern "C" void Hashtable__ctor_m1820371784 ();
extern "C" void Hashtable__ctor_m3491720775 ();
extern "C" void Hashtable__ctor_m1941859523 ();
extern "C" void Hashtable_Add_m157116935 ();
extern "C" void Hashtable_AdjustThreshold_m3338727562 ();
extern "C" void Hashtable_Clear_m3112193608 ();
extern "C" void Hashtable_CopyTo_m2905447224 ();
extern "C" void Hashtable_CopyToArray_m320168007 ();
extern "C" void Hashtable_GetObjectData_m2584507417 ();
extern "C" void Hashtable_OnDeserialization_m1032066502 ();
extern "C" void Hashtable_PutImpl_m2485103604 ();
extern "C" void Hashtable_Rehash_m2389268722 ();
extern "C" void Hashtable_Remove_m4032631466 ();
extern "C" void Hashtable_SetTable_m1520626497 ();
extern "C" void Hashtable_set_Item_m1120781262 ();
extern "C" void Hashtable_set_comparer_m1969364857 ();
extern "C" void Hashtable_set_hcp_m2582686174 ();
extern "C" void QueueEnumerator__ctor_m611027847 ();
extern "C" void QueueEnumerator_Reset_m472154018 ();
extern "C" void Queue__ctor_m2030580699 ();
extern "C" void Queue__ctor_m3552486878 ();
extern "C" void Queue__ctor_m2226872579 ();
extern "C" void Queue__ctor_m2335855895 ();
extern "C" void Queue_Clear_m898976850 ();
extern "C" void Queue_CopyTo_m737385843 ();
extern "C" void Queue_Enqueue_m4206203487 ();
extern "C" void Queue_grow_m873349987 ();
extern "C" void Enumerator__cctor_m3377250123 ();
extern "C" void Enumerator__ctor_m4264210349 ();
extern "C" void Enumerator_Reset_m1367479817 ();
extern "C" void SortedList__cctor_m1247132 ();
extern "C" void SortedList__ctor_m1261191695 ();
extern "C" void SortedList__ctor_m449121548 ();
extern "C" void SortedList__ctor_m3676552745 ();
extern "C" void SortedList__ctor_m4140760769 ();
extern "C" void SortedList_Add_m810900317 ();
extern "C" void SortedList_CopyTo_m3001281572 ();
extern "C" void SortedList_EnsureCapacity_m1354099314 ();
extern "C" void SortedList_InitTable_m875730861 ();
extern "C" void SortedList_PutImpl_m3408406199 ();
extern "C" void SortedList_Remove_m2784369438 ();
extern "C" void SortedList_RemoveAt_m1767403850 ();
extern "C" void SortedList_set_Capacity_m509376950 ();
extern "C" void SortedList_set_Item_m32382988 ();
extern "C" void HybridDictionary__ctor_m2970901694 ();
extern "C" void HybridDictionary__ctor_m1681134385 ();
extern "C" void HybridDictionary_Add_m912320053 ();
extern "C" void HybridDictionary_CopyTo_m3592404936 ();
extern "C" void HybridDictionary_Remove_m2295600623 ();
extern "C" void HybridDictionary_Switch_m3818192922 ();
extern "C" void HybridDictionary_set_Item_m2997363718 ();
extern "C" void DictionaryNode__ctor_m1380016344 ();
extern "C" void DictionaryNodeEnumerator__ctor_m1005316675 ();
extern "C" void DictionaryNodeEnumerator_FailFast_m2494733641 ();
extern "C" void DictionaryNodeEnumerator_Reset_m2226320064 ();
extern "C" void ListDictionary__ctor_m2955211750 ();
extern "C" void ListDictionary__ctor_m438204031 ();
extern "C" void ListDictionary_Add_m3918308031 ();
extern "C" void ListDictionary_AddImpl_m3184792770 ();
extern "C" void ListDictionary_Clear_m125005380 ();
extern "C" void ListDictionary_CopyTo_m1633862866 ();
extern "C" void ListDictionary_Remove_m2440983361 ();
extern "C" void ListDictionary_set_Item_m1659493973 ();
extern "C" void KeysCollection__ctor_m3575458428 ();
extern "C" void KeysCollection_System_Collections_ICollection_CopyTo_m1205348167 ();
extern "C" void _Item__ctor_m4016463660 ();
extern "C" void _KeysEnumerator__ctor_m1664513423 ();
extern "C" void _KeysEnumerator_Reset_m2283582422 ();
extern "C" void NameObjectCollectionBase__ctor_m2090733912 ();
extern "C" void NameObjectCollectionBase__ctor_m1512146076 ();
extern "C" void NameObjectCollectionBase_BaseAdd_m3437748750 ();
extern "C" void NameObjectCollectionBase_GetObjectData_m199708727 ();
extern "C" void NameObjectCollectionBase_Init_m2525481323 ();
extern "C" void NameObjectCollectionBase_OnDeserialization_m619757901 ();
extern "C" void NameObjectCollectionBase_System_Collections_ICollection_CopyTo_m1225689553 ();
extern "C" void NameValueCollection__ctor_m1115358332 ();
extern "C" void NameValueCollection__ctor_m4090053322 ();
extern "C" void NameValueCollection_Add_m2418530856 ();
extern "C" void NameValueCollection_InvalidateCachedArrays_m194313763 ();
extern "C" void Enumerator__ctor_m3362421874 ();
extern "C" void Enumerator_Reset_m2459931042 ();
extern "C" void Stack__ctor_m2907601956 ();
extern "C" void Stack__ctor_m2602729586 ();
extern "C" void Stack__ctor_m3503577671 ();
extern "C" void Stack_Clear_m2010200235 ();
extern "C" void Stack_CopyTo_m953825709 ();
extern "C" void Stack_Push_m2529252115 ();
extern "C" void Stack_Resize_m3124769495 ();
extern "C" void EditorBrowsableAttribute__ctor_m4133080490 ();
extern "C" void TypeConverterAttribute__cctor_m2413733117 ();
extern "C" void TypeConverterAttribute__ctor_m1774069684 ();
extern "C" void TypeConverterAttribute__ctor_m2714055761 ();
extern "C" void Console__cctor_m1860305256 ();
extern "C" void Console_SetEncodings_m1501183766 ();
extern "C" void Console_SetOut_m286050082 ();
extern "C" void ContextBoundObject__ctor_m308624197 ();
extern "C" void Convert__cctor_m2847208289 ();
extern "C" void CultureAwareComparer__ctor_m3981913244 ();
extern "C" void CurrentSystemTimeZone__ctor_m4046394832 ();
extern "C" void CurrentSystemTimeZone__ctor_m4224169966 ();
extern "C" void CurrentSystemTimeZone_OnDeserialization_m3711380055 ();
extern "C" void CurrentSystemTimeZone_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3815140570 ();
extern "C" void DBNull__cctor_m1221711106 ();
extern "C" void DBNull__ctor_m3264522145 ();
extern "C" void DBNull__ctor_m3431698857 ();
extern "C" void DBNull_GetObjectData_m560064731 ();
extern "C" void DateTime__cctor_m1880035693 ();
extern "C" void DateTime__ctor_m2135476686_AdjustorThunk ();
extern "C" void DateTime__ctor_m12900168_AdjustorThunk ();
extern "C" void DateTime__ctor_m3895589019_AdjustorThunk ();
extern "C" void DateTime__ctor_m2956360140_AdjustorThunk ();
extern "C" void DateTime__ctor_m2030998145_AdjustorThunk ();
extern "C" void DateTime__ctor_m516789325_AdjustorThunk ();
extern "C" void DateTime__ctor_m1095105629_AdjustorThunk ();
extern "C" void DateTime_CheckDateTimeKind_m456577410_AdjustorThunk ();
extern "C" void DateTime_CheckStyle_m1392838900 ();
extern "C" void DateTimeOffset__cctor_m3610253033 ();
extern "C" void DateTimeOffset__ctor_m2084804982_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m74032857_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m1464148220_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m2611141592_AdjustorThunk ();
extern "C" void DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m592821093_AdjustorThunk ();
extern "C" void DateTimeOffset_System_Runtime_Serialization_ISerializable_GetObjectData_m738492442_AdjustorThunk ();
extern "C" void DateTimeUtils_ZeroPad_m1132893640 ();
extern "C" void Decimal__cctor_m834667025 ();
extern "C" void Decimal__ctor_m1842485920_AdjustorThunk ();
extern "C" void Decimal__ctor_m1256289983_AdjustorThunk ();
extern "C" void Decimal__ctor_m3650533794_AdjustorThunk ();
extern "C" void Decimal__ctor_m450048609_AdjustorThunk ();
extern "C" void Decimal__ctor_m1925875020_AdjustorThunk ();
extern "C" void Decimal__ctor_m572982025_AdjustorThunk ();
extern "C" void Decimal__ctor_m593929528_AdjustorThunk ();
extern "C" void Decimal_ThrowAtPos_m1170269346 ();
extern "C" void Decimal_ThrowInvalidExp_m818482357 ();
extern "C" void Decimal_decimalFloorAndTrunc_m3496207836 ();
extern "C" void DefaultUriParser__ctor_m2377995797 ();
extern "C" void DefaultUriParser__ctor_m2634681684 ();
extern "C" void Delegate_GetObjectData_m4107455684 ();
extern "C" void Delegate_SetMulticastInvoke_m342000618 ();
extern "C" void DelegateEntry__ctor_m1541339220 ();
extern "C" void DelegateSerializationHolder__ctor_m23226427 ();
extern "C" void DelegateSerializationHolder_GetDelegateData_m2109044103 ();
extern "C" void DelegateSerializationHolder_GetObjectData_m2622911689 ();
extern "C" void DebuggableAttribute__ctor_m3124850944 ();
extern "C" void DebuggerBrowsableAttribute__ctor_m28117720 ();
extern "C" void DebuggerDisplayAttribute__ctor_m2387841105 ();
extern "C" void DebuggerDisplayAttribute_set_Name_m615572732 ();
extern "C" void DebuggerHiddenAttribute__ctor_m2764625696 ();
extern "C" void DebuggerStepThroughAttribute__ctor_m2219434937 ();
extern "C" void DebuggerTypeProxyAttribute__ctor_m3663763196 ();
extern "C" void StackFrame__ctor_m343464319 ();
extern "C" void StackFrame__ctor_m2610717164 ();
extern "C" void StackTrace__ctor_m206492268 ();
extern "C" void StackTrace__ctor_m727500069 ();
extern "C" void StackTrace__ctor_m3410750278 ();
extern "C" void StackTrace__ctor_m2642163899 ();
extern "C" void StackTrace__ctor_m1685176557 ();
extern "C" void StackTrace_init_frames_m641783388 ();
extern "C" void DivideByZeroException__ctor_m3496959969 ();
extern "C" void DivideByZeroException__ctor_m3315083383 ();
extern "C" void DllNotFoundException__ctor_m3079838043 ();
extern "C" void DllNotFoundException__ctor_m1156705135 ();
extern "C" void EntryPointNotFoundException__ctor_m4137625441 ();
extern "C" void EntryPointNotFoundException__ctor_m1278765702 ();
extern "C" void Enum__cctor_m2925047542 ();
extern "C" void Enum__ctor_m3602080049 ();
extern "C" void EventArgs__cctor_m1889823314 ();
extern "C" void EventArgs__ctor_m32674013 ();
extern "C" void EventHandler__ctor_m3449229857 ();
extern "C" void EventHandler_EndInvoke_m269746120 ();
extern "C" void EventHandler_Invoke_m2047579917 ();
extern "C" void Exception__ctor_m213470898 ();
extern "C" void Exception__ctor_m2499432361 ();
extern "C" void Exception__ctor_m1152696503 ();
extern "C" void Exception__ctor_m1406832249 ();
extern "C" void Exception_GetFullNameForStackTrace_m2634641773 ();
extern "C" void Exception_GetObjectData_m1103241326 ();
extern "C" void Exception_set_HResult_m3489164646 ();
extern "C" void ExecutionEngineException__ctor_m4205817610 ();
extern "C" void ExecutionEngineException__ctor_m673563413 ();
extern "C" void ExecutionEngineException__ctor_m913194968 ();
extern "C" void FieldAccessException__ctor_m3583219052 ();
extern "C" void FieldAccessException__ctor_m2776896078 ();
extern "C" void FieldAccessException__ctor_m3482795704 ();
extern "C" void FlagsAttribute__ctor_m2686422840 ();
extern "C" void FormatException__ctor_m1479314061 ();
extern "C" void FormatException__ctor_m3747066592 ();
extern "C" void FormatException__ctor_m4049685996 ();
extern "C" void GC_SuppressFinalize_m1177400158 ();
extern "C" void CCGregorianCalendar_dmy_from_fixed_m494173177 ();
extern "C" void CCGregorianCalendar_my_from_fixed_m715151395 ();
extern "C" void Calendar__ctor_m106290643 ();
extern "C" void Calendar_CheckReadOnly_m519800900 ();
extern "C" void CompareInfo__cctor_m1837489679 ();
extern "C" void CompareInfo__ctor_m3782165035 ();
extern "C" void CompareInfo__ctor_m1655607648 ();
extern "C" void CompareInfo_Finalize_m404687489 ();
extern "C" void CompareInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m734465833 ();
extern "C" void CompareInfo_assign_sortkey_m2100240770 ();
extern "C" void CompareInfo_construct_compareinfo_m509660150 ();
extern "C" void CompareInfo_free_internal_collator_m2341193055 ();
extern "C" void CultureInfo__cctor_m1258429074 ();
extern "C" void CultureInfo__ctor_m1510335716 ();
extern "C" void CultureInfo__ctor_m2628215565 ();
extern "C" void CultureInfo__ctor_m3285927757 ();
extern "C" void CultureInfo__ctor_m385185322 ();
extern "C" void CultureInfo__ctor_m1132565265 ();
extern "C" void CultureInfo_CheckNeutral_m3648960231 ();
extern "C" void CultureInfo_Construct_m1572693873 ();
extern "C" void CultureInfo_ConstructInvariant_m3774343375 ();
extern "C" void CultureInfo_construct_datetime_format_m1928121315 ();
extern "C" void CultureInfo_construct_number_format_m3346478783 ();
extern "C" void CultureInfo_insert_into_shared_tables_m4239017467 ();
extern "C" void CultureInfo_set_DateTimeFormat_m1843682751 ();
extern "C" void CultureInfo_set_NumberFormat_m3501553660 ();
extern "C" void DateTimeFormatInfo__cctor_m4189929746 ();
extern "C" void DateTimeFormatInfo__ctor_m3284460055 ();
extern "C" void DateTimeFormatInfo__ctor_m3106345035 ();
extern "C" void DateTimeFormatInfo_FillAllDateTimePatterns_m2683124783 ();
extern "C" void DateTimeFormatInfo_FillInvariantPatterns_m3827540258 ();
extern "C" void DateTimeFormatInfo_set_Calendar_m4130265499 ();
extern "C" void DaylightTime__ctor_m1928120219 ();
extern "C" void GregorianCalendar__ctor_m3097541152 ();
extern "C" void GregorianCalendar__ctor_m979779718 ();
extern "C" void GregorianCalendar_set_CalendarType_m2253089143 ();
extern "C" void NumberFormatInfo__cctor_m2457328820 ();
extern "C" void NumberFormatInfo__ctor_m3445216119 ();
extern "C" void NumberFormatInfo__ctor_m702982685 ();
extern "C" void NumberFormatInfo__ctor_m2249665202 ();
extern "C" void NumberFormatInfo_set_NumberNegativePattern_m1999304795 ();
extern "C" void RegionInfo__ctor_m1212234622 ();
extern "C" void RegionInfo__ctor_m1348635004 ();
extern "C" void SortKey__ctor_m2034425682 ();
extern "C" void SortKey__ctor_m853383193 ();
extern "C" void TextInfo__ctor_m2985371296 ();
extern "C" void TextInfo__ctor_m1714721222 ();
extern "C" void TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1492046432 ();
extern "C" void GuidParser__ctor_m3982448124 ();
extern "C" void GuidParser_ParseChar_m2782779985 ();
extern "C" void GuidParser_ParseHexPrefix_m3148550086 ();
extern "C" void GuidParser_Reset_m2640004655 ();
extern "C" void GuidParser_ThrowFormatException_m3223388534 ();
extern "C" void Guid__cctor_m1202095334 ();
extern "C" void Guid__ctor_m3421080095_AdjustorThunk ();
extern "C" void Guid__ctor_m3562600567_AdjustorThunk ();
extern "C" void Guid__ctor_m2373660607_AdjustorThunk ();
extern "C" void Guid__ctor_m2423264394_AdjustorThunk ();
extern "C" void Guid_AppendByte_m4212783015 ();
extern "C" void Guid_AppendInt_m1995455822 ();
extern "C" void Guid_AppendShort_m791023083 ();
extern "C" void Guid_CheckArray_m921056615 ();
extern "C" void Guid_CheckLength_m1615712498 ();
extern "C" void Guid_CheckNull_m1870379983 ();
extern "C" void BinaryReader__ctor_m2602947653 ();
extern "C" void BinaryReader__ctor_m2266204403 ();
extern "C" void BinaryReader_CheckBuffer_m2636825055 ();
extern "C" void BinaryReader_Close_m3868286242 ();
extern "C" void BinaryReader_Dispose_m3769291377 ();
extern "C" void BinaryReader_FillBuffer_m1406780870 ();
extern "C" void BinaryReader_System_IDisposable_Dispose_m1578048464 ();
extern "C" void BinaryWriter__cctor_m874809665 ();
extern "C" void BinaryWriter__ctor_m3736305989 ();
extern "C" void BinaryWriter__ctor_m1874693998 ();
extern "C" void BinaryWriter__ctor_m2439641268 ();
extern "C" void BinaryWriter_Dispose_m1020700223 ();
extern "C" void BinaryWriter_Flush_m1376465554 ();
extern "C" void BinaryWriter_System_IDisposable_Dispose_m486394397 ();
extern "C" void BinaryWriter_Write_m2685067618 ();
extern "C" void BinaryWriter_Write_m973309864 ();
extern "C" void BinaryWriter_Write_m3614538606 ();
extern "C" void BinaryWriter_Write_m259663284 ();
extern "C" void BinaryWriter_Write_m2841350030 ();
extern "C" void BinaryWriter_Write_m340679106 ();
extern "C" void BinaryWriter_Write_m4277135253 ();
extern "C" void BinaryWriter_Write_m2081800750 ();
extern "C" void BinaryWriter_Write_m3941546326 ();
extern "C" void BinaryWriter_Write_m2414409956 ();
extern "C" void BinaryWriter_Write_m88942200 ();
extern "C" void BinaryWriter_Write_m3577537050 ();
extern "C" void BinaryWriter_Write_m3837784074 ();
extern "C" void BinaryWriter_Write_m3922404942 ();
extern "C" void BinaryWriter_Write_m3658027000 ();
extern "C" void BinaryWriter_Write_m1702572183 ();
extern "C" void BinaryWriter_Write_m1304446817 ();
extern "C" void BinaryWriter_Write_m162594906 ();
extern "C" void BinaryWriter_Write7BitEncodedInt_m3825472103 ();
extern "C" void DirectoryInfo__ctor_m481305441 ();
extern "C" void DirectoryInfo__ctor_m1000259829 ();
extern "C" void DirectoryInfo__ctor_m126519516 ();
extern "C" void DirectoryInfo_Create_m604858118 ();
extern "C" void DirectoryInfo_Initialize_m1389772934 ();
extern "C" void DirectoryNotFoundException__ctor_m4004339866 ();
extern "C" void DirectoryNotFoundException__ctor_m1689636868 ();
extern "C" void DirectoryNotFoundException__ctor_m3235664382 ();
extern "C" void EndOfStreamException__ctor_m2202021005 ();
extern "C" void EndOfStreamException__ctor_m1590165188 ();
extern "C" void File_Delete_m321251800 ();
extern "C" void FileLoadException__ctor_m3879680456 ();
extern "C" void FileLoadException__ctor_m3104411427 ();
extern "C" void FileLoadException_GetObjectData_m1844968812 ();
extern "C" void FileNotFoundException__ctor_m2359931775 ();
extern "C" void FileNotFoundException__ctor_m2477162036 ();
extern "C" void FileNotFoundException__ctor_m3252664930 ();
extern "C" void FileNotFoundException__ctor_m1953317719 ();
extern "C" void FileNotFoundException_GetObjectData_m3195845120 ();
extern "C" void ReadDelegate__ctor_m2067775798 ();
extern "C" void WriteDelegate__ctor_m760514430 ();
extern "C" void WriteDelegate_EndInvoke_m952736984 ();
extern "C" void WriteDelegate_Invoke_m1581737441 ();
extern "C" void FileStream__ctor_m3087090334 ();
extern "C" void FileStream__ctor_m3135402178 ();
extern "C" void FileStream__ctor_m2889718780 ();
extern "C" void FileStream__ctor_m1487083717 ();
extern "C" void FileStream__ctor_m3151488352 ();
extern "C" void FileStream_Dispose_m2599766137 ();
extern "C" void FileStream_EndWrite_m4002445354 ();
extern "C" void FileStream_Finalize_m1626396852 ();
extern "C" void FileStream_Flush_m948103572 ();
extern "C" void FileStream_FlushBuffer_m4115439312 ();
extern "C" void FileStream_FlushBuffer_m914568182 ();
extern "C" void FileStream_FlushBufferIfDirty_m4249802951 ();
extern "C" void FileStream_InitBuffer_m2135408785 ();
extern "C" void FileStream_RefillBuffer_m4186945278 ();
extern "C" void FileStream_SetLength_m99749826 ();
extern "C" void FileStream_Write_m2254426030 ();
extern "C" void FileStream_WriteByte_m3899504766 ();
extern "C" void FileStream_WriteInternal_m4028396817 ();
extern "C" void FileStream_set_Position_m196127886 ();
extern "C" void FileStreamAsyncResult__ctor_m3441988901 ();
extern "C" void FileStreamAsyncResult_CBWrapper_m1670848754 ();
extern "C" void FileSystemInfo__ctor_m3035148496 ();
extern "C" void FileSystemInfo__ctor_m3769019897 ();
extern "C" void FileSystemInfo_CheckPath_m1572836275 ();
extern "C" void FileSystemInfo_GetObjectData_m812231621 ();
extern "C" void FileSystemInfo_InternalRefresh_m1700260373 ();
extern "C" void FileSystemInfo_Refresh_m1497191506 ();
extern "C" void IOException__ctor_m971599150 ();
extern "C" void IOException__ctor_m58488270 ();
extern "C" void IOException__ctor_m3662782713 ();
extern "C" void IOException__ctor_m3246761956 ();
extern "C" void IOException__ctor_m2367100481 ();
extern "C" void IsolatedStorageException__ctor_m3554950159 ();
extern "C" void IsolatedStorageException__ctor_m3386787868 ();
extern "C" void IsolatedStorageException__ctor_m1022659452 ();
extern "C" void MemoryStream__ctor_m2678285228 ();
extern "C" void MemoryStream__ctor_m4100805873 ();
extern "C" void MemoryStream__ctor_m2128850779 ();
extern "C" void MemoryStream_CheckIfClosedThrowDisposed_m3740555627 ();
extern "C" void MemoryStream_Dispose_m3070412825 ();
extern "C" void MemoryStream_Expand_m3554752073 ();
extern "C" void MemoryStream_Flush_m404193925 ();
extern "C" void MemoryStream_InternalConstructor_m150311326 ();
extern "C" void MemoryStream_SetLength_m974389318 ();
extern "C" void MemoryStream_Write_m162543801 ();
extern "C" void MemoryStream_WriteByte_m4085656483 ();
extern "C" void MemoryStream_set_Capacity_m1773624579 ();
extern "C" void MemoryStream_set_Position_m3169779190 ();
extern "C" void MonoIO__cctor_m3715714639 ();
extern "C" void NullStream__ctor_m2992573138 ();
extern "C" void NullStream_Flush_m3382897993 ();
extern "C" void NullStream_SetLength_m1485742029 ();
extern "C" void NullStream_Write_m3898870979 ();
extern "C" void NullStream_WriteByte_m2819073019 ();
extern "C" void NullStream_set_Position_m4054051091 ();
extern "C" void Path__cctor_m3273994011 ();
extern "C" void PathTooLongException__ctor_m3265957480 ();
extern "C" void PathTooLongException__ctor_m3626892488 ();
extern "C" void PathTooLongException__ctor_m2026445941 ();
extern "C" void SearchPattern__cctor_m3525595274 ();
extern "C" void Stream__cctor_m3168732477 ();
extern "C" void Stream__ctor_m3881936881 ();
extern "C" void Stream_Close_m771352034 ();
extern "C" void Stream_Dispose_m2589290611 ();
extern "C" void Stream_Dispose_m874059170 ();
extern "C" void Stream_EndWrite_m1721488587 ();
extern "C" void Stream_WriteByte_m1519852120 ();
extern "C" void StreamAsyncResult__ctor_m3118856368 ();
extern "C" void StreamAsyncResult_SetComplete_m1247564615 ();
extern "C" void StreamAsyncResult_SetComplete_m1102187093 ();
extern "C" void StreamAsyncResult_set_Done_m376066337 ();
extern "C" void NullStreamReader__ctor_m3077615088 ();
extern "C" void StreamReader__cctor_m874052303 ();
extern "C" void StreamReader__ctor_m150050089 ();
extern "C" void StreamReader__ctor_m3941437302 ();
extern "C" void StreamReader__ctor_m2783219104 ();
extern "C" void StreamReader__ctor_m1616861391 ();
extern "C" void StreamReader__ctor_m2637382018 ();
extern "C" void StreamReader_Dispose_m156389394 ();
extern "C" void StreamReader_Initialize_m3160193871 ();
extern "C" void StreamWriter__cctor_m1229272693 ();
extern "C" void StreamWriter__ctor_m2310301218 ();
extern "C" void StreamWriter__ctor_m1245831116 ();
extern "C" void StreamWriter_Close_m3750270527 ();
extern "C" void StreamWriter_Decode_m2340149035 ();
extern "C" void StreamWriter_Dispose_m2818839127 ();
extern "C" void StreamWriter_Finalize_m1379860857 ();
extern "C" void StreamWriter_Flush_m3311572543 ();
extern "C" void StreamWriter_FlushBytes_m1531540244 ();
extern "C" void StreamWriter_Initialize_m3490883444 ();
extern "C" void StreamWriter_LowLevelWrite_m1318762026 ();
extern "C" void StreamWriter_LowLevelWrite_m1081676583 ();
extern "C" void StreamWriter_Write_m2487601391 ();
extern "C" void StreamWriter_Write_m2994525938 ();
extern "C" void StreamWriter_Write_m4109815652 ();
extern "C" void StreamWriter_Write_m1660535366 ();
extern "C" void StreamWriter_set_AutoFlush_m42112085 ();
extern "C" void StringReader__ctor_m126993932 ();
extern "C" void StringReader_CheckObjectDisposedException_m3796163530 ();
extern "C" void StringReader_Dispose_m1915799905 ();
extern "C" void SynchronizedReader__ctor_m322282529 ();
extern "C" void SynchronizedWriter__ctor_m495278869 ();
extern "C" void SynchronizedWriter_Close_m3632168889 ();
extern "C" void SynchronizedWriter_Flush_m1415610297 ();
extern "C" void SynchronizedWriter_Write_m1297715977 ();
extern "C" void SynchronizedWriter_Write_m2529550287 ();
extern "C" void SynchronizedWriter_Write_m301917713 ();
extern "C" void SynchronizedWriter_Write_m169417751 ();
extern "C" void SynchronizedWriter_WriteLine_m1552352268 ();
extern "C" void SynchronizedWriter_WriteLine_m2518863747 ();
extern "C" void NullTextReader__ctor_m2871254925 ();
extern "C" void TextReader__cctor_m322748985 ();
extern "C" void TextReader__ctor_m605064712 ();
extern "C" void TextReader_Dispose_m4253712522 ();
extern "C" void TextReader_Dispose_m2059554794 ();
extern "C" void NullTextWriter__ctor_m1544833104 ();
extern "C" void NullTextWriter_Write_m1671049200 ();
extern "C" void NullTextWriter_Write_m2752689351 ();
extern "C" void NullTextWriter_Write_m432139305 ();
extern "C" void TextWriter__cctor_m2707487510 ();
extern "C" void TextWriter__ctor_m2859954372 ();
extern "C" void TextWriter_Close_m1290111813 ();
extern "C" void TextWriter_Dispose_m2495808722 ();
extern "C" void TextWriter_Dispose_m368115211 ();
extern "C" void TextWriter_Flush_m4003695429 ();
extern "C" void TextWriter_Write_m164803641 ();
extern "C" void TextWriter_Write_m2638787064 ();
extern "C" void TextWriter_Write_m2937140664 ();
extern "C" void TextWriter_Write_m2252948084 ();
extern "C" void TextWriter_WriteLine_m524366243 ();
extern "C" void TextWriter_WriteLine_m526643693 ();
extern "C" void UnexceptionalStreamReader__cctor_m2018971657 ();
extern "C" void UnexceptionalStreamReader__ctor_m1568917069 ();
extern "C" void UnexceptionalStreamWriter__ctor_m1310404920 ();
extern "C" void UnexceptionalStreamWriter_Flush_m82278468 ();
extern "C" void UnexceptionalStreamWriter_Write_m1440243232 ();
extern "C" void UnexceptionalStreamWriter_Write_m1834931241 ();
extern "C" void UnexceptionalStreamWriter_Write_m4210473673 ();
extern "C" void UnexceptionalStreamWriter_Write_m363195622 ();
extern "C" void UnmanagedMemoryStream_Dispose_m2681886347 ();
extern "C" void UnmanagedMemoryStream_Flush_m1540584491 ();
extern "C" void UnmanagedMemoryStream_SetLength_m3752964620 ();
extern "C" void UnmanagedMemoryStream_Write_m930787521 ();
extern "C" void UnmanagedMemoryStream_WriteByte_m70460272 ();
extern "C" void UnmanagedMemoryStream_set_Position_m2304997845 ();
extern "C" void IndexOutOfRangeException__ctor_m2441337274 ();
extern "C" void IndexOutOfRangeException__ctor_m1384421447 ();
extern "C" void IndexOutOfRangeException__ctor_m3408750441 ();
extern "C" void Int32_FindCurrency_m3541026887 ();
extern "C" void Int32_FindSign_m3975667272 ();
extern "C" void IntPtr__ctor_m987082960_AdjustorThunk ();
extern "C" void IntPtr__ctor_m987476171_AdjustorThunk ();
extern "C" void IntPtr__ctor_m620280096_AdjustorThunk ();
extern "C" void IntPtr__ctor_m3384658186_AdjustorThunk ();
extern "C" void IntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m1980135475_AdjustorThunk ();
extern "C" void InvalidCastException__ctor_m1807554410 ();
extern "C" void InvalidCastException__ctor_m2551002860 ();
extern "C" void InvalidCastException__ctor_m318645277 ();
extern "C" void InvalidOperationException__ctor_m2734335978 ();
extern "C" void InvalidOperationException__ctor_m262609521 ();
extern "C" void InvalidOperationException__ctor_m237278729 ();
extern "C" void InvalidOperationException__ctor_m1685032583 ();
extern "C" void Check_Source_m4098695967 ();
extern "C" void Check_SourceAndPredicate_m2332465641 ();
extern "C" void LocalDataStoreSlot__cctor_m644942532 ();
extern "C" void LocalDataStoreSlot__ctor_m4104083971 ();
extern "C" void LocalDataStoreSlot_Finalize_m2831598515 ();
extern "C" void MarshalByRefObject__ctor_m3039543187 ();
extern "C" void MarshalByRefObject_set_ObjectIdentity_m2909674674 ();
extern "C" void MemberAccessException__ctor_m2501221062 ();
extern "C" void MemberAccessException__ctor_m3713703094 ();
extern "C" void MemberAccessException__ctor_m3059744007 ();
extern "C" void MethodAccessException__ctor_m3542088436 ();
extern "C" void MethodAccessException__ctor_m3411913042 ();
extern "C" void MissingFieldException__ctor_m3159172111 ();
extern "C" void MissingFieldException__ctor_m3742452630 ();
extern "C" void MissingFieldException__ctor_m4282575076 ();
extern "C" void MissingMemberException__ctor_m2683358432 ();
extern "C" void MissingMemberException__ctor_m1220732369 ();
extern "C" void MissingMemberException__ctor_m2571045846 ();
extern "C" void MissingMemberException__ctor_m2707802176 ();
extern "C" void MissingMemberException_GetObjectData_m2957220379 ();
extern "C" void MissingMethodException__ctor_m878219575 ();
extern "C" void MissingMethodException__ctor_m1207628821 ();
extern "C" void MissingMethodException__ctor_m3234469579 ();
extern "C" void MissingMethodException__ctor_m41689610 ();
extern "C" void MonoAsyncCall__ctor_m714441825 ();
extern "C" void AttributeInfo__ctor_m140304083 ();
extern "C" void MonoCustomAttrs__cctor_m4000462365 ();
extern "C" void MonoDocumentationNoteAttribute__ctor_m2247826418 ();
extern "C" void IntComparer__ctor_m2901422390 ();
extern "C" void LongComparer__ctor_m1468371684 ();
extern "C" void SByteComparer__ctor_m3477407026 ();
extern "C" void ShortComparer__ctor_m1243157417 ();
extern "C" void MonoEnumInfo__cctor_m2240570096 ();
extern "C" void MonoEnumInfo__ctor_m3350651181_AdjustorThunk ();
extern "C" void MonoEnumInfo_GetInfo_m1670492558 ();
extern "C" void MonoEnumInfo_get_enum_info_m1661176095 ();
extern "C" void MonoLimitationAttribute__ctor_m3979406774 ();
extern "C" void MonoTODOAttribute__ctor_m2269130449 ();
extern "C" void MonoTODOAttribute__ctor_m1351510135 ();
extern "C" void MonoTODOAttribute__ctor_m3050775643 ();
extern "C" void MonoTODOAttribute__ctor_m1298576268 ();
extern "C" void MonoTouchAOTHelper__cctor_m3508633665 ();
extern "C" void MonoType_GetObjectData_m3008014917 ();
extern "C" void MonoType_ReorderParamArrayArguments_m2458683451 ();
extern "C" void MonoTypeInfo__ctor_m3401216922 ();
extern "C" void MulticastDelegate_GetObjectData_m3957553424 ();
extern "C" void MulticastNotSupportedException__ctor_m2750561050 ();
extern "C" void MulticastNotSupportedException__ctor_m521229206 ();
extern "C" void MulticastNotSupportedException__ctor_m663960493 ();
extern "C" void DefaultCertificatePolicy__ctor_m1887337884 ();
extern "C" void FileWebRequest__ctor_m41755936 ();
extern "C" void FileWebRequest__ctor_m3189951510 ();
extern "C" void FileWebRequest_GetObjectData_m577359674 ();
extern "C" void FileWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1504466482 ();
extern "C" void FileWebRequestCreator__ctor_m2638763787 ();
extern "C" void FtpRequestCreator__ctor_m23058707 ();
extern "C" void FtpWebRequest__cctor_m699542155 ();
extern "C" void FtpWebRequest__ctor_m751131654 ();
extern "C" void HttpRequestCreator__ctor_m2389332355 ();
extern "C" void HttpVersion__cctor_m1653189495 ();
extern "C" void HttpWebRequest__cctor_m1467954389 ();
extern "C" void HttpWebRequest__ctor_m1789065007 ();
extern "C" void HttpWebRequest__ctor_m1376613083 ();
extern "C" void HttpWebRequest_GetObjectData_m1226445448 ();
extern "C" void HttpWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m900393946 ();
extern "C" void IPAddress__cctor_m3038355099 ();
extern "C" void IPAddress__ctor_m921977496 ();
extern "C" void IPAddress__ctor_m149476904 ();
extern "C" void IPv6Address__cctor_m2454563501 ();
extern "C" void IPv6Address__ctor_m4117281080 ();
extern "C" void IPv6Address__ctor_m2700673633 ();
extern "C" void IPv6Address__ctor_m3704187391 ();
extern "C" void IPv6Address_set_ScopeId_m3907190992 ();
extern "C" void RemoteCertificateValidationCallback__ctor_m1251969663 ();
extern "C" void ServicePoint__ctor_m4022457269 ();
extern "C" void ServicePoint_set_Expect100Continue_m1237635858 ();
extern "C" void ServicePoint_set_IdleSince_m608781505 ();
extern "C" void ServicePoint_set_SendContinue_m3004714502 ();
extern "C" void ServicePoint_set_UseConnect_m1377758489 ();
extern "C" void ServicePoint_set_UseNagleAlgorithm_m1374731041 ();
extern "C" void ServicePoint_set_UsesProxy_m2758604003 ();
extern "C" void SPKey__ctor_m3690819622 ();
extern "C" void ServicePointManager__cctor_m3222177795 ();
extern "C" void ServicePointManager_RecycleServicePoints_m1035558445 ();
extern "C" void WebHeaderCollection__cctor_m2093192431 ();
extern "C" void WebHeaderCollection__ctor_m896654210 ();
extern "C" void WebHeaderCollection__ctor_m1926872774 ();
extern "C" void WebHeaderCollection__ctor_m1308130075 ();
extern "C" void WebHeaderCollection_Add_m183143026 ();
extern "C" void WebHeaderCollection_AddWithoutValidate_m3120519792 ();
extern "C" void WebHeaderCollection_GetObjectData_m730985326 ();
extern "C" void WebHeaderCollection_OnDeserialization_m3998891408 ();
extern "C" void WebHeaderCollection_System_Runtime_Serialization_ISerializable_GetObjectData_m2698261559 ();
extern "C" void WebProxy__ctor_m4061043939 ();
extern "C" void WebProxy__ctor_m3723076346 ();
extern "C" void WebProxy__ctor_m3758467778 ();
extern "C" void WebProxy_CheckBypassList_m3657340229 ();
extern "C" void WebProxy_GetObjectData_m2475888157 ();
extern "C" void WebProxy_System_Runtime_Serialization_ISerializable_GetObjectData_m430220241 ();
extern "C" void WebRequest__cctor_m3940074084 ();
extern "C" void WebRequest__ctor_m3593280671 ();
extern "C" void WebRequest__ctor_m2895531935 ();
extern "C" void WebRequest_AddDynamicPrefix_m4246631209 ();
extern "C" void WebRequest_AddPrefix_m3187775913 ();
extern "C" void WebRequest_GetObjectData_m1299992613 ();
extern "C" void WebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m3856360037 ();
extern "C" void NonSerializedAttribute__ctor_m3763812670 ();
extern "C" void NotImplementedException__ctor_m3058704252 ();
extern "C" void NotImplementedException__ctor_m2408412972 ();
extern "C" void NotImplementedException__ctor_m3095902440 ();
extern "C" void NotSupportedException__ctor_m2730133172 ();
extern "C" void NotSupportedException__ctor_m922781896 ();
extern "C" void NotSupportedException__ctor_m2494070935 ();
extern "C" void NullReferenceException__ctor_m744513393 ();
extern "C" void NullReferenceException__ctor_m652863956 ();
extern "C" void NullReferenceException__ctor_m3076065613 ();
extern "C" void CustomInfo__ctor_m426096741 ();
extern "C" void CustomInfo_GetActiveSection_m2184507081 ();
extern "C" void NumberFormatter__cctor_m2992857932 ();
extern "C" void NumberFormatter__ctor_m2275142545 ();
extern "C" void NumberFormatter_AddOneToDecHex_m1501523650 ();
extern "C" void NumberFormatter_Append_m950227932 ();
extern "C" void NumberFormatter_Append_m1427178134 ();
extern "C" void NumberFormatter_Append_m269678094 ();
extern "C" void NumberFormatter_AppendDecimalString_m3239747480 ();
extern "C" void NumberFormatter_AppendDecimalString_m10636623 ();
extern "C" void NumberFormatter_AppendDigits_m3057727895 ();
extern "C" void NumberFormatter_AppendDigits_m4260798464 ();
extern "C" void NumberFormatter_AppendExponent_m1258666517 ();
extern "C" void NumberFormatter_AppendIntegerString_m2257376141 ();
extern "C" void NumberFormatter_AppendIntegerString_m2788337398 ();
extern "C" void NumberFormatter_AppendIntegerStringWithGroupSeparator_m86637181 ();
extern "C" void NumberFormatter_AppendNonNegativeNumber_m2729989692 ();
extern "C" void NumberFormatter_AppendOneDigit_m313720813 ();
extern "C" void NumberFormatter_Divide10_m114817904 ();
extern "C" void NumberFormatter_FastAppendDigits_m3294622153 ();
extern "C" void NumberFormatter_GetFormatterTables_m910057425 ();
extern "C" void NumberFormatter_Init_m3326584660 ();
extern "C" void NumberFormatter_Init_m1925374739 ();
extern "C" void NumberFormatter_Init_m3576155222 ();
extern "C" void NumberFormatter_Init_m1788236100 ();
extern "C" void NumberFormatter_Init_m2506227005 ();
extern "C" void NumberFormatter_Init_m190003953 ();
extern "C" void NumberFormatter_Init_m2982613221 ();
extern "C" void NumberFormatter_InitDecHexDigits_m829694854 ();
extern "C" void NumberFormatter_InitDecHexDigits_m2266082744 ();
extern "C" void NumberFormatter_InitDecHexDigits_m1992166588 ();
extern "C" void NumberFormatter_InitHex_m3573185377 ();
extern "C" void NumberFormatter_Multiply10_m1733956269 ();
extern "C" void NumberFormatter_Release_m1879004257 ();
extern "C" void NumberFormatter_RemoveTrailingZeros_m1055756375 ();
extern "C" void NumberFormatter_ResetCharBuf_m1098525658 ();
extern "C" void NumberFormatter_Resize_m3876336103 ();
extern "C" void NumberFormatter_RoundPos_m545168719 ();
extern "C" void NumberFormatter_SetThreadCurrentCulture_m910458896 ();
extern "C" void NumberFormatter_ZeroTrimEnd_m3065471008 ();
extern "C" void NumberFormatter_set_CurrentCulture_m1358228087 ();
extern "C" void Object__ctor_m297566312 ();
extern "C" void Object_FieldGetter_m1068044959 ();
extern "C" void Object_FieldSetter_m3873125190 ();
extern "C" void Object_Finalize_m3076187857 ();
extern "C" void ObjectDisposedException__ctor_m1894780688 ();
extern "C" void ObjectDisposedException__ctor_m3603759869 ();
extern "C" void ObjectDisposedException__ctor_m1034312941 ();
extern "C" void ObjectDisposedException_GetObjectData_m2330532076 ();
extern "C" void ObsoleteAttribute__ctor_m3594271519 ();
extern "C" void ObsoleteAttribute__ctor_m3834641885 ();
extern "C" void ObsoleteAttribute__ctor_m2274138402 ();
extern "C" void OperatingSystem__ctor_m1545635730 ();
extern "C" void OperatingSystem_GetObjectData_m1571196722 ();
extern "C" void OrdinalComparer__ctor_m1028789954 ();
extern "C" void OutOfMemoryException__ctor_m3893515912 ();
extern "C" void OutOfMemoryException__ctor_m584364909 ();
extern "C" void OutOfMemoryException__ctor_m1518469064 ();
extern "C" void OverflowException__ctor_m4029085969 ();
extern "C" void OverflowException__ctor_m2491207501 ();
extern "C" void OverflowException__ctor_m694321376 ();
extern "C" void ParamArrayAttribute__ctor_m2680615839 ();
extern "C" void PlatformNotSupportedException__ctor_m1787918017 ();
extern "C" void PlatformNotSupportedException__ctor_m1693043795 ();
extern "C" void RankException__ctor_m4082747811 ();
extern "C" void RankException__ctor_m3453633632 ();
extern "C" void RankException__ctor_m2226473861 ();
extern "C" void AmbiguousMatchException__ctor_m15419215 ();
extern "C" void AmbiguousMatchException__ctor_m3222545265 ();
extern "C" void AmbiguousMatchException__ctor_m2012725345 ();
extern "C" void ResolveEventHolder__ctor_m1522332934 ();
extern "C" void Assembly__ctor_m823291553 ();
extern "C" void Assembly_FillName_m1660001542 ();
extern "C" void AssemblyCompanyAttribute__ctor_m1270469981 ();
extern "C" void AssemblyCopyrightAttribute__ctor_m1842063359 ();
extern "C" void AssemblyDefaultAliasAttribute__ctor_m1809631251 ();
extern "C" void AssemblyDelaySignAttribute__ctor_m542336852 ();
extern "C" void AssemblyDescriptionAttribute__ctor_m3993445315 ();
extern "C" void AssemblyFileVersionAttribute__ctor_m3720707642 ();
extern "C" void AssemblyInformationalVersionAttribute__ctor_m4033947902 ();
extern "C" void AssemblyKeyFileAttribute__ctor_m535332047 ();
extern "C" void AssemblyName__ctor_m2786326352 ();
extern "C" void AssemblyName__ctor_m1753467291 ();
extern "C" void AssemblyName_GetObjectData_m1516383869 ();
extern "C" void AssemblyName_OnDeserialization_m3779987437 ();
extern "C" void AssemblyName_SetPublicKey_m1771377104 ();
extern "C" void AssemblyName_SetPublicKeyToken_m582470133 ();
extern "C" void AssemblyName_set_Name_m1981626655 ();
extern "C" void AssemblyName_set_Version_m1802337156 ();
extern "C" void AssemblyProductAttribute__ctor_m1203636347 ();
extern "C" void AssemblyTitleAttribute__ctor_m3257920016 ();
extern "C" void Default__ctor_m325526679 ();
extern "C" void Default_ReorderArgumentArray_m476258478 ();
extern "C" void Default_ReorderParameters_m2076271671 ();
extern "C" void Binder__cctor_m245494241 ();
extern "C" void Binder__ctor_m2821133715 ();
extern "C" void ConstructorInfo__cctor_m1016079270 ();
extern "C" void ConstructorInfo__ctor_m356047157 ();
extern "C" void CustomAttributeData__ctor_m2966233049 ();
extern "C" void DefaultMemberAttribute__ctor_m1410463653 ();
extern "C" void AssemblyBuilder__ctor_m3936521321 ();
extern "C" void AssemblyBuilder_basic_init_m1526438565 ();
extern "C" void AssemblyBuilder_check_name_and_filename_m4027240280 ();
extern "C" void ConstructorBuilder__ctor_m1580993362 ();
extern "C" void ConstructorBuilder_fixup_m3699998230 ();
extern "C" void DynamicMethod_CreateDynMethod_m3853278069 ();
extern "C" void DynamicMethod_Finalize_m3410343626 ();
extern "C" void DynamicMethod_create_dynamic_method_m1579875961 ();
extern "C" void DynamicMethod_destroy_dynamic_method_m2651031212 ();
extern "C" void FieldBuilder_SetValue_m828035213 ();
extern "C" void LabelData__ctor_m3949021681_AdjustorThunk ();
extern "C" void ILGenerator__cctor_m2934917055 ();
extern "C" void ILGenerator__ctor_m1540961053 ();
extern "C" void ILGenerator_Emit_m3982339419 ();
extern "C" void ILGenerator_Emit_m165992488 ();
extern "C" void ILGenerator_Emit_m990732443 ();
extern "C" void ILGenerator_Emit_m1785051522 ();
extern "C" void ILGenerator_Emit_m1401094534 ();
extern "C" void ILGenerator_Emit_m3083135129 ();
extern "C" void ILGenerator_Emit_m2655709959 ();
extern "C" void ILGenerator_Emit_m2239205197 ();
extern "C" void ILGenerator_Emit_m3803522508 ();
extern "C" void ILGenerator_Emit_m22313773 ();
extern "C" void ILGenerator_Emit_m3111835688 ();
extern "C" void ILGenerator_EmitCall_m2478864924 ();
extern "C" void ILGenerator_MarkLabel_m1160930839 ();
extern "C" void ILGenerator_add_token_fixup_m1816002840 ();
extern "C" void ILGenerator_emit_int_m2322014738 ();
extern "C" void ILGenerator_label_fixup_m1749904972 ();
extern "C" void ILGenerator_ll_emit_m2218983546 ();
extern "C" void ILGenerator_make_room_m2688251824 ();
extern "C" void Label__ctor_m4171632839_AdjustorThunk ();
extern "C" void LocalBuilder__ctor_m1650329351 ();
extern "C" void MethodBuilder__ctor_m3664913099 ();
extern "C" void MethodBuilder_check_override_m4226508046 ();
extern "C" void MethodBuilder_fixup_m1765890582 ();
extern "C" void MethodBuilder_set_override_m1765815453 ();
extern "C" void MethodToken__cctor_m2263526478 ();
extern "C" void MethodToken__ctor_m2100013302_AdjustorThunk ();
extern "C" void ModuleBuilder__cctor_m2163728271 ();
extern "C" void ModuleBuilder__ctor_m164976504 ();
extern "C" void ModuleBuilder_AddType_m4198050894 ();
extern "C" void ModuleBuilder_CreateGlobalType_m3933178429 ();
extern "C" void ModuleBuilder_RegisterToken_m4166846047 ();
extern "C" void ModuleBuilder_basic_init_m3240533393 ();
extern "C" void ModuleBuilder_set_wrappers_type_m2998401134 ();
extern "C" void ModuleBuilderTokenGenerator__ctor_m2360787210 ();
extern "C" void OpCode__ctor_m2823239373_AdjustorThunk ();
extern "C" void OpCodeNames__cctor_m4023020620 ();
extern "C" void OpCodes__cctor_m3821715395 ();
extern "C" void PropertyBuilder_SetValue_m3164486317 ();
extern "C" void PropertyBuilder_SetValue_m830166741 ();
extern "C" void TypeBuilder__ctor_m3644689907 ();
extern "C" void TypeBuilder__ctor_m3099050601 ();
extern "C" void TypeBuilder_DefineMethodOverride_m2703939108 ();
extern "C" void TypeBuilder_SetParent_m4101148229 ();
extern "C" void TypeBuilder_append_method_m751930812 ();
extern "C" void TypeBuilder_check_created_m3513163610 ();
extern "C" void TypeBuilder_check_name_m3505884515 ();
extern "C" void TypeBuilder_check_not_created_m3652863637 ();
extern "C" void TypeBuilder_create_generic_class_m3823884980 ();
extern "C" void TypeBuilder_setup_internal_class_m4067683076 ();
extern "C" void AddEventAdapter__ctor_m2428277574 ();
extern "C" void AddEventAdapter_EndInvoke_m3898366634 ();
extern "C" void AddEventAdapter_Invoke_m3665771100 ();
extern "C" void EventInfo__ctor_m3033129999 ();
extern "C" void FieldInfo__ctor_m3305575002 ();
extern "C" void FieldInfo_SetValue_m2460171138 ();
extern "C" void LocalVariableInfo__ctor_m818516327 ();
extern "C" void MemberFilter__ctor_m1555764023 ();
extern "C" void MemberInfo__ctor_m3258770133 ();
extern "C" void MemberInfoSerializationHolder__ctor_m709149403 ();
extern "C" void MemberInfoSerializationHolder_GetObjectData_m4141100434 ();
extern "C" void MemberInfoSerializationHolder_Serialize_m2002453739 ();
extern "C" void MemberInfoSerializationHolder_Serialize_m2491586031 ();
extern "C" void MethodBase__ctor_m1907868998 ();
extern "C" void MethodInfo__ctor_m2805780217 ();
extern "C" void Missing__cctor_m1154503959 ();
extern "C" void Missing__ctor_m1587294558 ();
extern "C" void Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3173502177 ();
extern "C" void Module__cctor_m3457500417 ();
extern "C" void Module__ctor_m2380079016 ();
extern "C" void Module_GetObjectData_m497094981 ();
extern "C" void MonoCMethod__ctor_m1867900682 ();
extern "C" void MonoCMethod_GetObjectData_m2489171292 ();
extern "C" void MonoEvent__ctor_m1690536578 ();
extern "C" void MonoEvent_GetObjectData_m3301761592 ();
extern "C" void MonoEventInfo_get_event_info_m583997560 ();
extern "C" void MonoField__ctor_m5376011 ();
extern "C" void MonoField_CheckGeneric_m453069507 ();
extern "C" void MonoField_GetObjectData_m1292125335 ();
extern "C" void MonoField_SetValue_m2338106905 ();
extern "C" void MonoField_SetValueInternal_m2352116743 ();
extern "C" void MonoGenericCMethod__ctor_m1374831274 ();
extern "C" void MonoGenericMethod__ctor_m2795356912 ();
extern "C" void MonoMethod__ctor_m2104049215 ();
extern "C" void MonoMethod__ctor_m3792454563 ();
extern "C" void MonoMethod_GetObjectData_m854317157 ();
extern "C" void MonoMethodInfo_get_method_info_m88651774 ();
extern "C" void GetterAdapter__ctor_m2389296347 ();
extern "C" void MonoProperty__ctor_m588439900 ();
extern "C" void MonoProperty_CachePropertyInfo_m2968057423 ();
extern "C" void MonoProperty_GetObjectData_m4077457866 ();
extern "C" void MonoProperty_SetValue_m342801444 ();
extern "C" void MonoPropertyInfo_get_property_info_m1599555644 ();
extern "C" void ParameterInfo__ctor_m2869882516 ();
extern "C" void ParameterInfo__ctor_m2779026345 ();
extern "C" void ParameterInfo__ctor_m3269320476 ();
extern "C" void Pointer__ctor_m2714841439 ();
extern "C" void Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m609897590 ();
extern "C" void PropertyInfo__ctor_m4235916625 ();
extern "C" void PropertyInfo_SetValue_m2777755129 ();
extern "C" void StrongNameKeyPair__ctor_m2394160001 ();
extern "C" void StrongNameKeyPair_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1665239530 ();
extern "C" void StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m2655882830 ();
extern "C" void TargetException__ctor_m4172127019 ();
extern "C" void TargetException__ctor_m3701535709 ();
extern "C" void TargetException__ctor_m1440702323 ();
extern "C" void TargetInvocationException__ctor_m3011316584 ();
extern "C" void TargetInvocationException__ctor_m2859292946 ();
extern "C" void TargetInvocationException__ctor_m1498620089 ();
extern "C" void TargetParameterCountException__ctor_m2135390327 ();
extern "C" void TargetParameterCountException__ctor_m400549751 ();
extern "C" void TargetParameterCountException__ctor_m4113674829 ();
extern "C" void TypeDelegator__ctor_m3613242258 ();
extern "C" void TypeFilter__ctor_m3644914440 ();
extern "C" void ResolveEventArgs__ctor_m1455935166 ();
extern "C" void ResolveEventHandler__ctor_m1911137231 ();
extern "C" void NeutralResourcesLanguageAttribute__ctor_m868478272 ();
extern "C" void ResourceManager__cctor_m3647223129 ();
extern "C" void ResourceManager__ctor_m4162875493 ();
extern "C" void ResourceCacheItem__ctor_m3279356314_AdjustorThunk ();
extern "C" void ResourceEnumerator__ctor_m3428592283 ();
extern "C" void ResourceEnumerator_FillCache_m1661715061 ();
extern "C" void ResourceEnumerator_Reset_m3754276504 ();
extern "C" void ResourceInfo__ctor_m1985704952_AdjustorThunk ();
extern "C" void ResourceReader__ctor_m204352998 ();
extern "C" void ResourceReader__ctor_m3853106506 ();
extern "C" void ResourceReader_Close_m3765232219 ();
extern "C" void ResourceReader_CreateResourceInfo_m1818330740 ();
extern "C" void ResourceReader_Dispose_m3597121875 ();
extern "C" void ResourceReader_LoadResourceValues_m104914612 ();
extern "C" void ResourceReader_ReadHeaders_m1190430799 ();
extern "C" void ResourceReader_System_IDisposable_Dispose_m3207991025 ();
extern "C" void ResourceSet__ctor_m3356376607 ();
extern "C" void ResourceSet__ctor_m153254307 ();
extern "C" void ResourceSet__ctor_m2006909906 ();
extern "C" void ResourceSet__ctor_m3618395942 ();
extern "C" void ResourceSet_Dispose_m2881303269 ();
extern "C" void ResourceSet_Dispose_m1823973062 ();
extern "C" void ResourceSet_ReadResources_m3663669011 ();
extern "C" void RuntimeResourceSet__ctor_m915567562 ();
extern "C" void RuntimeResourceSet__ctor_m1178110395 ();
extern "C" void RuntimeResourceSet__ctor_m2765575100 ();
extern "C" void SatelliteContractVersionAttribute__ctor_m3630863995 ();
extern "C" void CompilationRelaxationsAttribute__ctor_m2313138045 ();
extern "C" void CompilerGeneratedAttribute__ctor_m3151881902 ();
extern "C" void DecimalConstantAttribute__ctor_m3583301917 ();
extern "C" void DefaultDependencyAttribute__ctor_m502524668 ();
extern "C" void ExtensionAttribute__ctor_m1708143005 ();
extern "C" void FixedBufferAttribute__ctor_m2453309552 ();
extern "C" void InternalsVisibleToAttribute__ctor_m2564612584 ();
extern "C" void RuntimeCompatibilityAttribute__ctor_m1311107907 ();
extern "C" void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2506646892 ();
extern "C" void RuntimeHelpers_InitializeArray_m4077124945 ();
extern "C" void RuntimeHelpers_InitializeArray_m3117905507 ();
extern "C" void StringFreezingAttribute__ctor_m2350592359 ();
extern "C" void CriticalFinalizerObject__ctor_m3245424448 ();
extern "C" void CriticalFinalizerObject_Finalize_m2010384847 ();
extern "C" void ReliabilityContractAttribute__ctor_m2124570898 ();
extern "C" void COMException__ctor_m3707984232 ();
extern "C" void COMException__ctor_m1066143105 ();
extern "C" void ClassInterfaceAttribute__ctor_m637338123 ();
extern "C" void ComDefaultInterfaceAttribute__ctor_m332930853 ();
extern "C" void ComImportAttribute__ctor_m3468592294 ();
extern "C" void ComVisibleAttribute__ctor_m1596017997 ();
extern "C" void DispIdAttribute__ctor_m223675039 ();
extern "C" void DllImportAttribute__ctor_m1397784140 ();
extern "C" void ExternalException__ctor_m2877839282 ();
extern "C" void ExternalException__ctor_m4224477539 ();
extern "C" void FieldOffsetAttribute__ctor_m591213967 ();
extern "C" void GCHandle__ctor_m2690474163_AdjustorThunk ();
extern "C" void GCHandle_Free_m1457699368_AdjustorThunk ();
extern "C" void GCHandle_FreeHandle_m2765220421 ();
extern "C" void GuidAttribute__ctor_m3183273657 ();
extern "C" void InAttribute__ctor_m3499482504 ();
extern "C" void InterfaceTypeAttribute__ctor_m3307583035 ();
extern "C" void Marshal__cctor_m4007734770 ();
extern "C" void Marshal_Copy_m1222846562 ();
extern "C" void Marshal_Copy_m1714210296 ();
extern "C" void Marshal_WriteByte_m951096718 ();
extern "C" void Marshal_copy_from_unmanaged_m2834266824 ();
extern "C" void MarshalAsAttribute__ctor_m1885514494 ();
extern "C" void MarshalDirectiveException__ctor_m629358357 ();
extern "C" void MarshalDirectiveException__ctor_m636944700 ();
extern "C" void OptionalAttribute__ctor_m1218709376 ();
extern "C" void OutAttribute__ctor_m1231442694 ();
extern "C" void PreserveSigAttribute__ctor_m332009382 ();
extern "C" void SafeHandle__ctor_m124356559 ();
extern "C" void SafeHandle_Close_m1630741059 ();
extern "C" void SafeHandle_DangerousAddRef_m614714386 ();
extern "C" void SafeHandle_DangerousRelease_m190326290 ();
extern "C" void SafeHandle_Dispose_m817995135 ();
extern "C" void SafeHandle_Dispose_m4229010569 ();
extern "C" void SafeHandle_Finalize_m3866180675 ();
extern "C" void SafeHandle_SetHandle_m2809947802 ();
extern "C" void TypeLibImportClassAttribute__ctor_m2302178978 ();
extern "C" void TypeLibVersionAttribute__ctor_m2033697886 ();
extern "C" void UnmanagedFunctionPointerAttribute__ctor_m2291887142 ();
extern "C" void ActivatedClientTypeEntry__ctor_m1905793997 ();
extern "C" void ActivatedServiceTypeEntry__ctor_m3973743857 ();
extern "C" void ActivationServices_EnableProxyActivation_m1823951881 ();
extern "C" void AppDomainLevelActivator__ctor_m3990740325 ();
extern "C" void ConstructionLevelActivator__ctor_m3779412964 ();
extern "C" void ContextLevelActivator__ctor_m100091473 ();
extern "C" void RemoteActivationAttribute__ctor_m2149009645 ();
extern "C" void RemoteActivationAttribute_GetPropertiesForNewContext_m2023065452 ();
extern "C" void UrlAttribute_GetPropertiesForNewContext_m2281450996 ();
extern "C" void ChannelData__ctor_m3415426655 ();
extern "C" void ChannelData_CopyFrom_m727830216 ();
extern "C" void ChannelInfo__ctor_m1094732233 ();
extern "C" void ChannelInfo__ctor_m1024254061 ();
extern "C" void AsyncRequest__ctor_m492494552 ();
extern "C" void ChannelServices__cctor_m2475086854 ();
extern "C" void ChannelServices_RegisterChannel_m292045697 ();
extern "C" void ChannelServices_RegisterChannel_m2211869627 ();
extern "C" void ChannelServices_RegisterChannelConfig_m3525848799 ();
extern "C" void CrossAppDomainChannel__cctor_m2481165765 ();
extern "C" void CrossAppDomainChannel__ctor_m834919757 ();
extern "C" void CrossAppDomainChannel_RegisterCrossAppDomainChannel_m1413768602 ();
extern "C" void CrossAppDomainChannel_StartListening_m3738943719 ();
extern "C" void CrossAppDomainData__ctor_m1598366643 ();
extern "C" void CrossAppDomainSink__cctor_m1839450486 ();
extern "C" void CrossAppDomainSink__ctor_m1449849319 ();
extern "C" void CrossAppDomainSink_SendAsyncMessage_m1900004718 ();
extern "C" void SinkProviderData__ctor_m1624738837 ();
extern "C" void ClientActivatedIdentity__ctor_m20616531 ();
extern "C" void ClientActivatedIdentity_OnLifetimeExpired_m635240647 ();
extern "C" void ClientActivatedIdentity_SetClientProxy_m1934671808 ();
extern "C" void ClientIdentity__ctor_m3042435594 ();
extern "C" void ClientIdentity_set_ClientProxy_m3470388302 ();
extern "C" void ConfigHandler__ctor_m1707380160 ();
extern "C" void ConfigHandler_OnChars_m2375115779 ();
extern "C" void ConfigHandler_OnEndElement_m2712669221 ();
extern "C" void ConfigHandler_OnEndParsing_m3764034673 ();
extern "C" void ConfigHandler_OnIgnorableWhitespace_m278399491 ();
extern "C" void ConfigHandler_OnProcessingInstruction_m4212209262 ();
extern "C" void ConfigHandler_OnStartElement_m1487743489 ();
extern "C" void ConfigHandler_OnStartParsing_m3490329046 ();
extern "C" void ConfigHandler_ParseElement_m3124222564 ();
extern "C" void ConfigHandler_ReadChannel_m781299361 ();
extern "C" void ConfigHandler_ReadClientActivated_m2004035168 ();
extern "C" void ConfigHandler_ReadClientWellKnown_m2020621905 ();
extern "C" void ConfigHandler_ReadCustomProviderData_m3199409838 ();
extern "C" void ConfigHandler_ReadInteropXml_m2362675760 ();
extern "C" void ConfigHandler_ReadLifetine_m208994800 ();
extern "C" void ConfigHandler_ReadPreload_m1590193711 ();
extern "C" void ConfigHandler_ReadServiceActivated_m3103044384 ();
extern "C" void ConfigHandler_ReadServiceWellKnown_m3267506269 ();
extern "C" void ConfigHandler_ValidatePath_m3895556516 ();
extern "C" void Context__cctor_m416731170 ();
extern "C" void Context__ctor_m254302079 ();
extern "C" void Context_DoCallBack_m749197451 ();
extern "C" void Context_Finalize_m968260866 ();
extern "C" void Context_FreeNamedDataSlot_m2664298100 ();
extern "C" void Context_Freeze_m2594571993 ();
extern "C" void Context_NotifyDynamicSinks_m1841702879 ();
extern "C" void Context_NotifyGlobalDynamicSinks_m695341235 ();
extern "C" void Context_SetData_m3538804592 ();
extern "C" void Context_SetProperty_m3238063729 ();
extern "C" void ContextAttribute__ctor_m3271528688 ();
extern "C" void ContextAttribute_Freeze_m3288175579 ();
extern "C" void ContextAttribute_GetPropertiesForNewContext_m1632930262 ();
extern "C" void ContextCallbackObject__ctor_m3499682402 ();
extern "C" void ContextCallbackObject_DoCallBack_m3942380501 ();
extern "C" void ContextRestoreSink__ctor_m3837217860 ();
extern "C" void CrossContextChannel__ctor_m3755842292 ();
extern "C" void CrossContextDelegate__ctor_m2846080406 ();
extern "C" void CrossContextDelegate_EndInvoke_m3186232431 ();
extern "C" void CrossContextDelegate_Invoke_m3121381558 ();
extern "C" void DynamicPropertyReg__ctor_m2316273312 ();
extern "C" void DynamicPropertyCollection__ctor_m3168670804 ();
extern "C" void DynamicPropertyCollection_NotifyMessage_m1895207271 ();
extern "C" void SynchronizationAttribute__ctor_m1613804100 ();
extern "C" void SynchronizationAttribute__ctor_m399162031 ();
extern "C" void SynchronizationAttribute_AcquireLock_m776819619 ();
extern "C" void SynchronizationAttribute_EnterContext_m1660729920 ();
extern "C" void SynchronizationAttribute_ExitContext_m1981564947 ();
extern "C" void SynchronizationAttribute_GetPropertiesForNewContext_m3620327520 ();
extern "C" void SynchronizationAttribute_ReleaseLock_m1030353464 ();
extern "C" void SynchronizationAttribute_set_Locked_m2760363037 ();
extern "C" void SynchronizedClientContextSink__ctor_m4129963630 ();
extern "C" void SynchronizedContextReplySink__ctor_m1162999750 ();
extern "C" void SynchronizedServerContextSink__ctor_m3996826342 ();
extern "C" void DisposerReplySink__ctor_m2547952970 ();
extern "C" void EnvoyInfo__ctor_m276600651 ();
extern "C" void FormatterData__ctor_m3990517908 ();
extern "C" void Identity__ctor_m2221672896 ();
extern "C" void Identity_NotifyClientDynamicSinks_m1859963616 ();
extern "C" void Identity_NotifyServerDynamicSinks_m3451215395 ();
extern "C" void Identity_set_ChannelSink_m3085217742 ();
extern "C" void Identity_set_Disposed_m1049871465 ();
extern "C" void Identity_set_ObjectUri_m3158626967 ();
extern "C" void InternalRemotingServices__cctor_m1652165283 ();
extern "C" void RenewalDelegate__ctor_m3753117779 ();
extern "C" void Lease__ctor_m3269477734 ();
extern "C" void Lease_Activate_m1293019137 ();
extern "C" void Lease_CheckNextSponsor_m2023022816 ();
extern "C" void Lease_ProcessSponsorResponse_m3090612911 ();
extern "C" void Lease_Unregister_m186366095 ();
extern "C" void Lease_UpdateState_m2746833210 ();
extern "C" void Lease_set_InitialLeaseTime_m122297036 ();
extern "C" void Lease_set_RenewOnCallTime_m1737118470 ();
extern "C" void Lease_set_SponsorshipTimeout_m2290526220 ();
extern "C" void LeaseManager__ctor_m4015084757 ();
extern "C" void LeaseManager_ManageLeases_m421471288 ();
extern "C" void LeaseManager_SetPollTime_m3584231103 ();
extern "C" void LeaseManager_StartManager_m3152740510 ();
extern "C" void LeaseManager_StopManager_m2567480487 ();
extern "C" void LeaseManager_TrackLifetime_m1859704813 ();
extern "C" void LeaseSink__ctor_m2235463210 ();
extern "C" void LeaseSink_RenewLease_m578578728 ();
extern "C" void LifetimeServices__cctor_m2128864873 ();
extern "C" void LifetimeServices_TrackLifetime_m2415237423 ();
extern "C" void LifetimeServices_set_LeaseManagerPollTime_m3035471458 ();
extern "C" void LifetimeServices_set_LeaseTime_m4128883058 ();
extern "C" void LifetimeServices_set_RenewOnCallTime_m3218163665 ();
extern "C" void LifetimeServices_set_SponsorshipTimeout_m2538334028 ();
extern "C" void ArgInfo__ctor_m1950205784 ();
extern "C" void AsyncResult__ctor_m911358409 ();
extern "C" void AsyncResult_SetCompletedSynchronously_m3406063945 ();
extern "C" void AsyncResult_SetMessageCtrl_m2891069413 ();
extern "C" void AsyncResult_set_CallMessage_m2298693197 ();
extern "C" void AsyncResult_set_EndInvokeCalled_m130520183 ();
extern "C" void CADArgHolder__ctor_m993579695 ();
extern "C" void CADMessageBase__ctor_m2964311354 ();
extern "C" void CADMessageBase_SaveLogicalCallContext_m862853946 ();
extern "C" void CADMessageBase_UnmarshalProperties_m4178096524 ();
extern "C" void CADMethodCallMessage__ctor_m4205158101 ();
extern "C" void CADMethodReturnMessage__ctor_m2974228354 ();
extern "C" void CADObjRef__ctor_m2673939978 ();
extern "C" void CallContext__ctor_m383148220 ();
extern "C" void CallContext_RestoreCallContext_m271861767 ();
extern "C" void CallContextRemotingData__ctor_m1780036207 ();
extern "C" void ClientContextReplySink__ctor_m975656650 ();
extern "C" void ClientContextTerminatorSink__ctor_m3775290972 ();
extern "C" void ConstructionCall__ctor_m4256641225 ();
extern "C" void ConstructionCall__ctor_m3123819328 ();
extern "C" void ConstructionCall_GetObjectData_m1001686567 ();
extern "C" void ConstructionCall_InitDictionary_m2824447813 ();
extern "C" void ConstructionCall_InitMethodProperty_m2021094586 ();
extern "C" void ConstructionCall_SetActivationAttributes_m2210519374 ();
extern "C" void ConstructionCall_set_Activator_m1916046285 ();
extern "C" void ConstructionCall_set_IsContextOk_m2994486781 ();
extern "C" void ConstructionCallDictionary__cctor_m3953897917 ();
extern "C" void ConstructionCallDictionary__ctor_m2541174073 ();
extern "C" void ConstructionCallDictionary_SetMethodProperty_m3145285304 ();
extern "C" void ConstructionResponse__ctor_m131220658 ();
extern "C" void ConstructionResponse__ctor_m507689770 ();
extern "C" void ConstructionResponse__ctor_m746108047 ();
extern "C" void EnvoyTerminatorSink__cctor_m2182802076 ();
extern "C" void EnvoyTerminatorSink__ctor_m2835977419 ();
extern "C" void ErrorMessage__ctor_m4021425049 ();
extern "C" void Header__ctor_m1921907550 ();
extern "C" void Header__ctor_m3451012432 ();
extern "C" void Header__ctor_m2140843914 ();
extern "C" void HeaderHandler__ctor_m2052730798 ();
extern "C" void LogicalCallContext__ctor_m1263247987 ();
extern "C" void LogicalCallContext__ctor_m2167632604 ();
extern "C" void LogicalCallContext_GetObjectData_m841612502 ();
extern "C" void LogicalCallContext_SetData_m1808598347 ();
extern "C" void MethodCall__ctor_m3669645 ();
extern "C" void MethodCall__ctor_m2820791328 ();
extern "C" void MethodCall__ctor_m2176599175 ();
extern "C" void MethodCall__ctor_m3517356389 ();
extern "C" void MethodCall_GetObjectData_m3807460959 ();
extern "C" void MethodCall_Init_m86192062 ();
extern "C" void MethodCall_InitDictionary_m865799153 ();
extern "C" void MethodCall_InitMethodProperty_m1333573177 ();
extern "C" void MethodCall_ResolveMethod_m326183261 ();
extern "C" void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3258819983 ();
extern "C" void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m1919576807 ();
extern "C" void MethodCall_set_Uri_m3442466207 ();
extern "C" void MethodCallDictionary__cctor_m2213329406 ();
extern "C" void MethodCallDictionary__ctor_m2167303393 ();
extern "C" void DictionaryEnumerator__ctor_m713073424 ();
extern "C" void DictionaryEnumerator_Reset_m2916117190 ();
extern "C" void MethodDictionary__ctor_m4235342752 ();
extern "C" void MethodDictionary_Add_m1460237891 ();
extern "C" void MethodDictionary_CopyTo_m2912468790 ();
extern "C" void MethodDictionary_Remove_m2649551615 ();
extern "C" void MethodDictionary_SetMethodProperty_m3032369066 ();
extern "C" void MethodDictionary_set_Item_m489343035 ();
extern "C" void MethodDictionary_set_MethodKeys_m1451825752 ();
extern "C" void MethodResponse__ctor_m1914987550 ();
extern "C" void MethodResponse__ctor_m696083067 ();
extern "C" void MethodResponse__ctor_m2813895138 ();
extern "C" void MethodResponse__ctor_m604622297 ();
extern "C" void MethodResponse_GetObjectData_m1523088668 ();
extern "C" void MethodResponse_InitMethodProperty_m3208531417 ();
extern "C" void MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m661149313 ();
extern "C" void MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m1299782913 ();
extern "C" void MethodResponse_set_Uri_m700763379 ();
extern "C" void MethodReturnDictionary__cctor_m278392388 ();
extern "C" void MethodReturnDictionary__ctor_m3850821940 ();
extern "C" void MonoMethodMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3448319263 ();
extern "C" void MonoMethodMessage_set_Uri_m958867306 ();
extern "C" void ObjRefSurrogate__ctor_m455472707 ();
extern "C" void ObjRefSurrogate_GetObjectData_m4269947720 ();
extern "C" void RemotingSurrogate__ctor_m1062105321 ();
extern "C" void RemotingSurrogate_GetObjectData_m1446383768 ();
extern "C" void RemotingSurrogateSelector__cctor_m332560138 ();
extern "C" void RemotingSurrogateSelector__ctor_m1846610173 ();
extern "C" void ReturnMessage__ctor_m1555286069 ();
extern "C" void ReturnMessage__ctor_m2352989078 ();
extern "C" void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3799371543 ();
extern "C" void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m2462079058 ();
extern "C" void ReturnMessage_set_Uri_m3134200303 ();
extern "C" void ServerContextTerminatorSink__ctor_m2519287841 ();
extern "C" void ServerObjectReplySink__ctor_m3589614014 ();
extern "C" void ServerObjectTerminatorSink__ctor_m3974426286 ();
extern "C" void StackBuilderSink__ctor_m2065448592 ();
extern "C" void StackBuilderSink_CheckParameters_m707496278 ();
extern "C" void StackBuilderSink_ExecuteAsyncMessage_m277782655 ();
extern "C" void SoapAttribute__ctor_m1857608874 ();
extern "C" void SoapAttribute_SetReflectionObject_m4109300849 ();
extern "C" void SoapFieldAttribute__ctor_m790943423 ();
extern "C" void SoapFieldAttribute_SetReflectionObject_m1576380366 ();
extern "C" void SoapMethodAttribute__ctor_m1788265923 ();
extern "C" void SoapMethodAttribute_SetReflectionObject_m503748123 ();
extern "C" void SoapParameterAttribute__ctor_m2146835121 ();
extern "C" void SoapTypeAttribute__ctor_m4090878544 ();
extern "C" void SoapTypeAttribute_SetReflectionObject_m1691526413 ();
extern "C" void ObjRef__cctor_m1958474437 ();
extern "C" void ObjRef__ctor_m823137228 ();
extern "C" void ObjRef__ctor_m1843524090 ();
extern "C" void ObjRef__ctor_m4078135099 ();
extern "C" void ObjRef__ctor_m1449728429 ();
extern "C" void ObjRef_GetObjectData_m270012899 ();
extern "C" void ObjRef_UpdateChannelInfo_m871421559 ();
extern "C" void ObjRef_set_EnvoyInfo_m3653812956 ();
extern "C" void ObjRef_set_TypeInfo_m2180735217 ();
extern "C" void ObjRef_set_URI_m2491129464 ();
extern "C" void ProviderData__ctor_m2835711616 ();
extern "C" void ProviderData_CopyFrom_m3402276734 ();
extern "C" void ProxyAttribute_GetPropertiesForNewContext_m3751460645 ();
extern "C" void RealProxy__ctor_m1860285982 ();
extern "C" void RealProxy__ctor_m192642440 ();
extern "C" void RealProxy__ctor_m192459610 ();
extern "C" void RealProxy_AttachServer_m1185328196 ();
extern "C" void RealProxy_GetObjectData_m3709348912 ();
extern "C" void RealProxy_SetTargetDomain_m1886392211 ();
extern "C" void RealProxy_set_ObjectIdentity_m1045687518 ();
extern "C" void RemotingProxy__cctor_m4096951805 ();
extern "C" void RemotingProxy__ctor_m1504681762 ();
extern "C" void RemotingProxy__ctor_m2714995444 ();
extern "C" void RemotingProxy_AttachIdentity_m4004191225 ();
extern "C" void RemotingProxy_Finalize_m2695236116 ();
extern "C" void RemotingConfiguration__cctor_m2997734064 ();
extern "C" void RemotingConfiguration_LoadDefaultDelayedChannels_m1289761552 ();
extern "C" void RemotingConfiguration_RegisterActivatedClientType_m4212089575 ();
extern "C" void RemotingConfiguration_RegisterActivatedServiceType_m526187030 ();
extern "C" void RemotingConfiguration_RegisterChannelTemplate_m3105688054 ();
extern "C" void RemotingConfiguration_RegisterChannels_m1089224873 ();
extern "C" void RemotingConfiguration_RegisterClientProviderTemplate_m3950558786 ();
extern "C" void RemotingConfiguration_RegisterServerProviderTemplate_m2865814762 ();
extern "C" void RemotingConfiguration_RegisterTypes_m2378540395 ();
extern "C" void RemotingConfiguration_RegisterWellKnownClientType_m1237674062 ();
extern "C" void RemotingConfiguration_RegisterWellKnownServiceType_m4099334725 ();
extern "C" void RemotingConfiguration_SetCustomErrorsMode_m12233052 ();
extern "C" void RemotingConfiguration_set_ApplicationName_m2517000516 ();
extern "C" void RemotingException__ctor_m1814113852 ();
extern "C" void RemotingException__ctor_m1015537352 ();
extern "C" void RemotingException__ctor_m2916537666 ();
extern "C" void RemotingException__ctor_m3625866612 ();
extern "C" void RemotingServices__cctor_m4056345423 ();
extern "C" void RemotingServices_DisposeIdentity_m2605848806 ();
extern "C" void RemotingServices_GetObjectData_m3902019633 ();
extern "C" void RemotingServices_RegisterInternalChannels_m3803685582 ();
extern "C" void RemotingServices_RegisterServerIdentity_m196914637 ();
extern "C" void RemotingServices_SetMessageTargetIdentity_m4083751943 ();
extern "C" void ServerIdentity__ctor_m1627037015 ();
extern "C" void ServerIdentity_AttachServerObject_m3892044390 ();
extern "C" void ServerIdentity_DisposeServerObject_m1376146261 ();
extern "C" void ServerIdentity_OnLifetimeExpired_m3729485875 ();
extern "C" void ServerIdentity_StartTrackingLifetime_m861002296 ();
extern "C" void ServerIdentity_set_Context_m168811777 ();
extern "C" void TrackingServices__cctor_m2525949557 ();
extern "C" void TrackingServices_NotifyDisconnectedObject_m1755566214 ();
extern "C" void TrackingServices_NotifyMarshaledObject_m2850851267 ();
extern "C" void TrackingServices_NotifyUnmarshaledObject_m2784831802 ();
extern "C" void SingleCallIdentity__ctor_m512106477 ();
extern "C" void SingletonIdentity__ctor_m3846583373 ();
extern "C" void TypeInfo__ctor_m3177869375 ();
extern "C" void SoapServices__cctor_m3121621510 ();
extern "C" void SoapServices_PreLoad_m3694555274 ();
extern "C" void SoapServices_PreLoad_m1533129052 ();
extern "C" void SoapServices_RegisterInteropXmlElement_m2539810323 ();
extern "C" void SoapServices_RegisterInteropXmlType_m3725804773 ();
extern "C" void TypeEntry__ctor_m3850067423 ();
extern "C" void TypeEntry_set_AssemblyName_m740439947 ();
extern "C" void TypeEntry_set_TypeName_m2292673915 ();
extern "C" void TypeInfo__ctor_m3520353822 ();
extern "C" void WellKnownClientTypeEntry__ctor_m2471908952 ();
extern "C" void WellKnownServiceTypeEntry__ctor_m2390594423 ();
extern "C" void ArrayFixupRecord__ctor_m3071763795 ();
extern "C" void ArrayFixupRecord_FixupImpl_m4264567432 ();
extern "C" void BaseFixupRecord__ctor_m3105931241 ();
extern "C" void DelayedFixupRecord__ctor_m1500671818 ();
extern "C" void DelayedFixupRecord_FixupImpl_m521536759 ();
extern "C" void FixupRecord__ctor_m4156740480 ();
extern "C" void FixupRecord_FixupImpl_m2569366786 ();
extern "C" void FormatterConverter__ctor_m4071877133 ();
extern "C" void FormatterServices_GetFields_m2777940282 ();
extern "C" void BinaryCommon__cctor_m2978407547 ();
extern "C" void BinaryCommon_CheckSerializable_m3673092502 ();
extern "C" void BinaryCommon_SwapBytes_m3963737189 ();
extern "C" void BinaryFormatter__ctor_m971003555 ();
extern "C" void BinaryFormatter__ctor_m2620705134 ();
extern "C" void BinaryFormatter_ReadBinaryHeader_m2339643348 ();
extern "C" void BinaryFormatter_Serialize_m1744386044 ();
extern "C" void BinaryFormatter_Serialize_m2476455399 ();
extern "C" void BinaryFormatter_WriteBinaryHeader_m4239804844 ();
extern "C" void BinaryFormatter_set_AssemblyFormat_m1359106493 ();
extern "C" void BinaryFormatter_set_SurrogateSelector_m1467080126 ();
extern "C" void ClrTypeMetadata__ctor_m420857278 ();
extern "C" void CodeGenerator__cctor_m3167429173 ();
extern "C" void CodeGenerator_EmitLoadTypeAssembly_m1985536832 ();
extern "C" void CodeGenerator_EmitWrite_m1452031614 ();
extern "C" void CodeGenerator_EmitWritePrimitiveValue_m3054192573 ();
extern "C" void CodeGenerator_EmitWriteTypeSpec_m3265719084 ();
extern "C" void CodeGenerator_LoadFromPtr_m1784813519 ();
extern "C" void MemberTypeMetadata__ctor_m2376841411 ();
extern "C" void MemberTypeMetadata_WriteAssemblies_m881083943 ();
extern "C" void MemberTypeMetadata_WriteObjectData_m2840447988 ();
extern "C" void MemberTypeMetadata_WriteTypeData_m3992201821 ();
extern "C" void MessageFormatter_WriteMethodCall_m4240742925 ();
extern "C" void MessageFormatter_WriteMethodResponse_m514023078 ();
extern "C" void ArrayNullFiller__ctor_m1460935784 ();
extern "C" void TypeMetadata__ctor_m646635308 ();
extern "C" void ObjectReader__ctor_m2595396997 ();
extern "C" void ObjectReader_BlockRead_m304158408 ();
extern "C" void ObjectReader_ReadArrayOfObject_m671957184 ();
extern "C" void ObjectReader_ReadArrayOfPrimitiveType_m3374303005 ();
extern "C" void ObjectReader_ReadArrayOfString_m3550800559 ();
extern "C" void ObjectReader_ReadAssembly_m2963555857 ();
extern "C" void ObjectReader_ReadGenericArray_m1710471713 ();
extern "C" void ObjectReader_ReadObject_m540696579 ();
extern "C" void ObjectReader_ReadObjectContent_m1654577346 ();
extern "C" void ObjectReader_ReadObjectGraph_m340866276 ();
extern "C" void ObjectReader_ReadObjectGraph_m1689734232 ();
extern "C" void ObjectReader_ReadObjectInstance_m3952621118 ();
extern "C" void ObjectReader_ReadRefTypeObjectInstance_m3311150386 ();
extern "C" void ObjectReader_ReadSimpleArray_m428957657 ();
extern "C" void ObjectReader_ReadStringIntance_m1523916863 ();
extern "C" void ObjectReader_ReadValue_m3145979203 ();
extern "C" void ObjectReader_RecordFixup_m4125245357 ();
extern "C" void ObjectReader_RegisterObject_m1853376334 ();
extern "C" void ObjectReader_SetObjectValue_m2761159765 ();
extern "C" void MetadataReference__ctor_m15653650 ();
extern "C" void ObjectWriter__cctor_m2748224627 ();
extern "C" void ObjectWriter__ctor_m2586423995 ();
extern "C" void ObjectWriter_BlockWrite_m827549826 ();
extern "C" void ObjectWriter_GetObjectData_m2149519430 ();
extern "C" void ObjectWriter_QueueObject_m3487717536 ();
extern "C" void ObjectWriter_WriteArray_m1738497250 ();
extern "C" void ObjectWriter_WriteGenericArray_m1575646718 ();
extern "C" void ObjectWriter_WriteNullFiller_m2949512160 ();
extern "C" void ObjectWriter_WriteObject_m3639703743 ();
extern "C" void ObjectWriter_WriteObjectArray_m1109545282 ();
extern "C" void ObjectWriter_WriteObjectGraph_m1096671657 ();
extern "C" void ObjectWriter_WriteObjectInstance_m4123656775 ();
extern "C" void ObjectWriter_WriteObjectReference_m1459514019 ();
extern "C" void ObjectWriter_WritePrimitiveTypeArray_m3383767374 ();
extern "C" void ObjectWriter_WritePrimitiveValue_m3342686922 ();
extern "C" void ObjectWriter_WriteQueuedObjects_m502447341 ();
extern "C" void ObjectWriter_WriteSerializationEnd_m4228661922 ();
extern "C" void ObjectWriter_WriteSingleDimensionArrayElements_m3412300123 ();
extern "C" void ObjectWriter_WriteString_m2607199782 ();
extern "C" void ObjectWriter_WriteStringArray_m312537653 ();
extern "C" void ObjectWriter_WriteTypeCode_m1789140116 ();
extern "C" void ObjectWriter_WriteTypeSpec_m3700372600 ();
extern "C" void ObjectWriter_WriteValue_m3485076606 ();
extern "C" void SerializableTypeMetadata__ctor_m4102127793 ();
extern "C" void SerializableTypeMetadata_WriteAssemblies_m2027618830 ();
extern "C" void SerializableTypeMetadata_WriteObjectData_m2148012904 ();
extern "C" void SerializableTypeMetadata_WriteTypeData_m1099030367 ();
extern "C" void TypeMetadata__ctor_m3381216780 ();
extern "C" void MultiArrayFixupRecord__ctor_m1290009050 ();
extern "C" void MultiArrayFixupRecord_FixupImpl_m1721674130 ();
extern "C" void InstanceComparer__ctor_m2655670473 ();
extern "C" void ObjectIDGenerator__cctor_m2337609134 ();
extern "C" void ObjectIDGenerator__ctor_m2117120656 ();
extern "C" void ObjectManager__ctor_m1844334865 ();
extern "C" void ObjectManager_AddFixup_m2154325362 ();
extern "C" void ObjectManager_DoFixups_m3038765937 ();
extern "C" void ObjectManager_RaiseDeserializationEvent_m49333530 ();
extern "C" void ObjectManager_RaiseOnDeserializedEvent_m2281637371 ();
extern "C" void ObjectManager_RaiseOnDeserializingEvent_m964884748 ();
extern "C" void ObjectManager_RecordArrayElementFixup_m3896982476 ();
extern "C" void ObjectManager_RecordArrayElementFixup_m2171848602 ();
extern "C" void ObjectManager_RecordDelayedFixup_m337814852 ();
extern "C" void ObjectManager_RecordFixup_m290973772 ();
extern "C" void ObjectManager_RegisterObject_m2087328880 ();
extern "C" void ObjectManager_RegisterObjectInternal_m3473857785 ();
extern "C" void ObjectRecord__ctor_m2962775102 ();
extern "C" void ObjectRecord_ChainFixup_m1889316362 ();
extern "C" void ObjectRecord_RemoveFixup_m2598771603 ();
extern "C" void ObjectRecord_SetArrayValue_m2756856461 ();
extern "C" void ObjectRecord_SetMemberValue_m1045887821 ();
extern "C" void ObjectRecord_SetMemberValue_m4000081321 ();
extern "C" void ObjectRecord_UnchainFixup_m3191243952 ();
extern "C" void SerializationBinder__ctor_m1110997808 ();
extern "C" void CallbackHandler__ctor_m3390474190 ();
extern "C" void CallbackHandler_EndInvoke_m719226939 ();
extern "C" void CallbackHandler_Invoke_m3512549308 ();
extern "C" void SerializationCallbacks__cctor_m1674315180 ();
extern "C" void SerializationCallbacks__ctor_m3863304525 ();
extern "C" void SerializationCallbacks_Invoke_m4060432420 ();
extern "C" void SerializationCallbacks_RaiseOnDeserialized_m3761893080 ();
extern "C" void SerializationCallbacks_RaiseOnDeserializing_m3047111085 ();
extern "C" void SerializationCallbacks_RaiseOnSerialized_m2457587934 ();
extern "C" void SerializationCallbacks_RaiseOnSerializing_m563766125 ();
extern "C" void SerializationEntry__ctor_m1411687997_AdjustorThunk ();
extern "C" void SerializationException__ctor_m3772074258 ();
extern "C" void SerializationException__ctor_m3131447373 ();
extern "C" void SerializationException__ctor_m3862484944 ();
extern "C" void SerializationInfo__ctor_m2923079689 ();
extern "C" void SerializationInfo_AddValue_m3427199315 ();
extern "C" void SerializationInfo_AddValue_m1927057880 ();
extern "C" void SerializationInfo_AddValue_m2780248522 ();
extern "C" void SerializationInfo_AddValue_m412754688 ();
extern "C" void SerializationInfo_AddValue_m3963995439 ();
extern "C" void SerializationInfo_AddValue_m2872281893 ();
extern "C" void SerializationInfo_AddValue_m3906743584 ();
extern "C" void SerializationInfo_AddValue_m1803776749 ();
extern "C" void SerializationInfo_AddValue_m2020653395 ();
extern "C" void SerializationInfo_SetType_m3923964808 ();
extern "C" void SerializationInfoEnumerator__ctor_m2264653019 ();
extern "C" void SerializationInfoEnumerator_Reset_m1193994596 ();
extern "C" void U3CRegisterObjectU3Ec__AnonStorey3__ctor_m1338377904 ();
extern "C" void U3CRegisterObjectU3Ec__AnonStorey3_U3CU3Em__2_m1816853296 ();
extern "C" void SerializationObjectManager__ctor_m460008415 ();
extern "C" void SerializationObjectManager_RaiseOnSerializedEvent_m272248422 ();
extern "C" void SerializationObjectManager_RegisterObject_m951822324 ();
extern "C" void StreamingContext__ctor_m1072028025_AdjustorThunk ();
extern "C" void StreamingContext__ctor_m2604757771_AdjustorThunk ();
extern "C" void RuntimeFieldHandle__ctor_m984632319_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_GetObjectData_m95767031_AdjustorThunk ();
extern "C" void RuntimeMethodHandle__ctor_m2229201676_AdjustorThunk ();
extern "C" void RuntimeMethodHandle__ctor_m2867240657_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_GetObjectData_m2865437866_AdjustorThunk ();
extern "C" void RuntimeTypeHandle__ctor_m3315980708_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_GetObjectData_m1599302095_AdjustorThunk ();
extern "C" void AllowPartiallyTrustedCallersAttribute__ctor_m1248209229 ();
extern "C" void CodeAccessPermission__ctor_m1135661531 ();
extern "C" void CodeAccessPermission_ThrowInvalidPermission_m3890026412 ();
extern "C" void Aes__ctor_m178909601 ();
extern "C" void AesManaged__ctor_m1349486362 ();
extern "C" void AesManaged_Dispose_m615303088 ();
extern "C" void AesManaged_GenerateIV_m1368817386 ();
extern "C" void AesManaged_GenerateKey_m2004209814 ();
extern "C" void AesManaged_set_IV_m3705704588 ();
extern "C" void AesManaged_set_Key_m767972181 ();
extern "C" void AesManaged_set_KeySize_m1150692274 ();
extern "C" void AesTransform__cctor_m2567644034 ();
extern "C" void AesTransform__ctor_m3143546745 ();
extern "C" void AesTransform_Decrypt128_m3018534522 ();
extern "C" void AesTransform_ECB_m240244807 ();
extern "C" void AesTransform_Encrypt128_m424393011 ();
extern "C" void AsnEncodedData__ctor_m3792312694 ();
extern "C" void AsnEncodedData__ctor_m119764527 ();
extern "C" void AsnEncodedData__ctor_m726356132 ();
extern "C" void AsnEncodedData_CopyFrom_m3929882393 ();
extern "C" void AsnEncodedData_set_Oid_m351300829 ();
extern "C" void AsnEncodedData_set_RawData_m1598714608 ();
extern "C" void AsymmetricAlgorithm__ctor_m1554933721 ();
extern "C" void AsymmetricAlgorithm_Clear_m1528825448 ();
extern "C" void AsymmetricAlgorithm_System_IDisposable_Dispose_m4219596803 ();
extern "C" void AsymmetricAlgorithm_set_KeySize_m2163393617 ();
extern "C" void AsymmetricKeyExchangeFormatter__ctor_m1720558774 ();
extern "C" void AsymmetricSignatureDeformatter__ctor_m88114807 ();
extern "C" void AsymmetricSignatureFormatter__ctor_m3278494933 ();
extern "C" void Base64Constants__cctor_m1668117186 ();
extern "C" void CryptoConfig__cctor_m34707108 ();
extern "C" void CryptoConfig_Initialize_m168211670 ();
extern "C" void CryptographicException__ctor_m1391449859 ();
extern "C" void CryptographicException__ctor_m3486909073 ();
extern "C" void CryptographicException__ctor_m503735289 ();
extern "C" void CryptographicException__ctor_m1422015889 ();
extern "C" void CryptographicException__ctor_m3803155940 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m1394830404 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m69881930 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m2381988196 ();
extern "C" void CspParameters__ctor_m277845443 ();
extern "C" void CspParameters__ctor_m2741097571 ();
extern "C" void CspParameters__ctor_m1928090281 ();
extern "C" void CspParameters__ctor_m3852972821 ();
extern "C" void CspParameters_set_Flags_m397261363 ();
extern "C" void DES__cctor_m3576612725 ();
extern "C" void DES__ctor_m1833611161 ();
extern "C" void DES_set_Key_m2569946991 ();
extern "C" void DESCryptoServiceProvider__ctor_m3757531594 ();
extern "C" void DESCryptoServiceProvider_GenerateIV_m683687014 ();
extern "C" void DESCryptoServiceProvider_GenerateKey_m1810256255 ();
extern "C" void DESTransform__cctor_m244488330 ();
extern "C" void DESTransform__ctor_m878979107 ();
extern "C" void DESTransform_BSwap_m2723001589 ();
extern "C" void DESTransform_ECB_m1168033891 ();
extern "C" void DESTransform_Permutation_m252663723 ();
extern "C" void DESTransform_ProcessBlock_m2449315636 ();
extern "C" void DESTransform_SetKey_m3436155416 ();
extern "C" void DSA__ctor_m1979872003 ();
extern "C" void DSA_FromXmlString_m1479532250 ();
extern "C" void DSA_ZeroizePrivateKey_m1053698176 ();
extern "C" void DSACryptoServiceProvider__cctor_m3823760945 ();
extern "C" void DSACryptoServiceProvider__ctor_m517243624 ();
extern "C" void DSACryptoServiceProvider__ctor_m1139102382 ();
extern "C" void DSACryptoServiceProvider__ctor_m3949670084 ();
extern "C" void DSACryptoServiceProvider_Dispose_m1092393028 ();
extern "C" void DSACryptoServiceProvider_Finalize_m1286601265 ();
extern "C" void DSACryptoServiceProvider_ImportParameters_m611916501 ();
extern "C" void DSACryptoServiceProvider_OnKeyGenerated_m2274596916 ();
extern "C" void DSASignatureDeformatter__ctor_m2759753186 ();
extern "C" void DSASignatureDeformatter__ctor_m2889130126 ();
extern "C" void DSASignatureDeformatter_SetHashAlgorithm_m3186995552 ();
extern "C" void DSASignatureDeformatter_SetKey_m2999549245 ();
extern "C" void DSASignatureDescription__ctor_m2058525095 ();
extern "C" void DSASignatureFormatter__ctor_m2328815619 ();
extern "C" void DSASignatureFormatter_SetHashAlgorithm_m2004578631 ();
extern "C" void DSASignatureFormatter_SetKey_m3643725525 ();
extern "C" void HMAC__ctor_m97939284 ();
extern "C" void HMAC_Dispose_m3665032088 ();
extern "C" void HMAC_HashCore_m3684104066 ();
extern "C" void HMAC_Initialize_m3157696427 ();
extern "C" void HMAC_set_BlockSizeValue_m2639576659 ();
extern "C" void HMAC_set_HashName_m2561756873 ();
extern "C" void HMAC_set_Key_m2848363914 ();
extern "C" void HMACMD5__ctor_m3129799368 ();
extern "C" void HMACMD5__ctor_m3008609295 ();
extern "C" void HMACRIPEMD160__ctor_m4073272899 ();
extern "C" void HMACRIPEMD160__ctor_m2981281487 ();
extern "C" void HMACSHA1__ctor_m4144697316 ();
extern "C" void HMACSHA1__ctor_m446190279 ();
extern "C" void HMACSHA256__ctor_m346174875 ();
extern "C" void HMACSHA256__ctor_m3379531528 ();
extern "C" void HMACSHA384__cctor_m3009390673 ();
extern "C" void HMACSHA384__ctor_m82969736 ();
extern "C" void HMACSHA384__ctor_m1677515580 ();
extern "C" void HMACSHA384_set_ProduceLegacyHmacValues_m76936446 ();
extern "C" void HMACSHA512__cctor_m4155933671 ();
extern "C" void HMACSHA512__ctor_m2615612210 ();
extern "C" void HMACSHA512__ctor_m348055215 ();
extern "C" void HMACSHA512_set_ProduceLegacyHmacValues_m3961135292 ();
extern "C" void HashAlgorithm__ctor_m190815979 ();
extern "C" void HashAlgorithm_Dispose_m620242512 ();
extern "C" void HashAlgorithm_System_IDisposable_Dispose_m3925361195 ();
extern "C" void KeySizes__ctor_m3113946058 ();
extern "C" void KeyedHashAlgorithm__ctor_m4053775756 ();
extern "C" void KeyedHashAlgorithm_Dispose_m2325408902 ();
extern "C" void KeyedHashAlgorithm_Finalize_m3436068827 ();
extern "C" void KeyedHashAlgorithm_ZeroizeKey_m1611290675 ();
extern "C" void KeyedHashAlgorithm_set_Key_m711403901 ();
extern "C" void MACTripleDES__ctor_m1301195406 ();
extern "C" void MACTripleDES_Dispose_m3118990285 ();
extern "C" void MACTripleDES_Finalize_m3761305675 ();
extern "C" void MACTripleDES_HashCore_m2803969153 ();
extern "C" void MACTripleDES_Initialize_m3918381832 ();
extern "C" void MACTripleDES_Setup_m560957914 ();
extern "C" void MD5__ctor_m3848300604 ();
extern "C" void MD5CryptoServiceProvider__cctor_m2609586198 ();
extern "C" void MD5CryptoServiceProvider__ctor_m3271163125 ();
extern "C" void MD5CryptoServiceProvider_AddLength_m142725782 ();
extern "C" void MD5CryptoServiceProvider_Dispose_m3502499818 ();
extern "C" void MD5CryptoServiceProvider_Finalize_m950838019 ();
extern "C" void MD5CryptoServiceProvider_HashCore_m2558876268 ();
extern "C" void MD5CryptoServiceProvider_Initialize_m2402854924 ();
extern "C" void MD5CryptoServiceProvider_ProcessBlock_m3522014752 ();
extern "C" void MD5CryptoServiceProvider_ProcessFinalBlock_m2241588515 ();
extern "C" void Oid__ctor_m738937194 ();
extern "C" void Oid__ctor_m911618594 ();
extern "C" void Oid__ctor_m1869590876 ();
extern "C" void Oid__ctor_m3344148807 ();
extern "C" void OidCollection__ctor_m4001685071 ();
extern "C" void OidCollection_System_Collections_ICollection_CopyTo_m2400658497 ();
extern "C" void OidEnumerator__ctor_m257525176 ();
extern "C" void OidEnumerator_Reset_m2503707245 ();
extern "C" void RC2__ctor_m1146135664 ();
extern "C" void RC2_set_KeySize_m2968816949 ();
extern "C" void RC2CryptoServiceProvider__ctor_m420166935 ();
extern "C" void RC2CryptoServiceProvider_GenerateIV_m1412313176 ();
extern "C" void RC2CryptoServiceProvider_GenerateKey_m468082592 ();
extern "C" void RC2Transform__cctor_m4067495236 ();
extern "C" void RC2Transform__ctor_m1795280107 ();
extern "C" void RC2Transform_ECB_m1047445751 ();
extern "C" void RIPEMD160__ctor_m860963627 ();
extern "C" void RIPEMD160Managed__ctor_m1837600365 ();
extern "C" void RIPEMD160Managed_Compress_m126479169 ();
extern "C" void RIPEMD160Managed_CompressFinal_m497690796 ();
extern "C" void RIPEMD160Managed_FF_m738585160 ();
extern "C" void RIPEMD160Managed_FFF_m3692014807 ();
extern "C" void RIPEMD160Managed_Finalize_m2864487594 ();
extern "C" void RIPEMD160Managed_GG_m3020389474 ();
extern "C" void RIPEMD160Managed_GGG_m1715572318 ();
extern "C" void RIPEMD160Managed_HH_m90236373 ();
extern "C" void RIPEMD160Managed_HHH_m2839246531 ();
extern "C" void RIPEMD160Managed_HashCore_m2350629432 ();
extern "C" void RIPEMD160Managed_II_m1560285116 ();
extern "C" void RIPEMD160Managed_III_m3606824266 ();
extern "C" void RIPEMD160Managed_Initialize_m2173168986 ();
extern "C" void RIPEMD160Managed_JJ_m112143231 ();
extern "C" void RIPEMD160Managed_JJJ_m4161373884 ();
extern "C" void RIPEMD160Managed_ProcessBlock_m3304263146 ();
extern "C" void RNGCryptoServiceProvider__cctor_m3587754670 ();
extern "C" void RNGCryptoServiceProvider__ctor_m2355451105 ();
extern "C" void RNGCryptoServiceProvider_Check_m3453818294 ();
extern "C" void RNGCryptoServiceProvider_Finalize_m1304072372 ();
extern "C" void RNGCryptoServiceProvider_GetBytes_m918414272 ();
extern "C" void RNGCryptoServiceProvider_GetNonZeroBytes_m1918423726 ();
extern "C" void RNGCryptoServiceProvider_RngClose_m3915778345 ();
extern "C" void RSA__ctor_m2923348713 ();
extern "C" void RSA_FromXmlString_m2537913712 ();
extern "C" void RSA_ZeroizePrivateKey_m4052091611 ();
extern "C" void RSACryptoServiceProvider__cctor_m3113818354 ();
extern "C" void RSACryptoServiceProvider__ctor_m2288290917 ();
extern "C" void RSACryptoServiceProvider__ctor_m2378475222 ();
extern "C" void RSACryptoServiceProvider__ctor_m357386130 ();
extern "C" void RSACryptoServiceProvider_Common_m861233239 ();
extern "C" void RSACryptoServiceProvider_Dispose_m1199148535 ();
extern "C" void RSACryptoServiceProvider_Finalize_m1969564496 ();
extern "C" void RSACryptoServiceProvider_ImportParameters_m614616705 ();
extern "C" void RSACryptoServiceProvider_OnKeyGenerated_m863837376 ();
extern "C" void RSAPKCS1KeyExchangeFormatter__ctor_m1170240343 ();
extern "C" void RSAPKCS1KeyExchangeFormatter_SetRSAKey_m1477802943 ();
extern "C" void RSAPKCS1SHA1SignatureDescription__ctor_m621804060 ();
extern "C" void RSAPKCS1SignatureDeformatter__ctor_m3540701537 ();
extern "C" void RSAPKCS1SignatureDeformatter__ctor_m3706544163 ();
extern "C" void RSAPKCS1SignatureDeformatter_SetHashAlgorithm_m1602190713 ();
extern "C" void RSAPKCS1SignatureDeformatter_SetKey_m614724234 ();
extern "C" void RSAPKCS1SignatureFormatter__ctor_m1234483002 ();
extern "C" void RSAPKCS1SignatureFormatter_SetHashAlgorithm_m446605265 ();
extern "C" void RSAPKCS1SignatureFormatter_SetKey_m2935054088 ();
extern "C" void RandomNumberGenerator__ctor_m1589693309 ();
extern "C" void Rijndael__ctor_m4179966697 ();
extern "C" void RijndaelManaged__ctor_m1562735454 ();
extern "C" void RijndaelManaged_GenerateIV_m667430910 ();
extern "C" void RijndaelManaged_GenerateKey_m1736287430 ();
extern "C" void RijndaelManagedTransform__ctor_m1033522223 ();
extern "C" void RijndaelManagedTransform_System_IDisposable_Dispose_m539902307 ();
extern "C" void RijndaelTransform__cctor_m2439033240 ();
extern "C" void RijndaelTransform__ctor_m3424202476 ();
extern "C" void RijndaelTransform_Clear_m2609662851 ();
extern "C" void RijndaelTransform_Decrypt128_m4239115689 ();
extern "C" void RijndaelTransform_Decrypt192_m3453970103 ();
extern "C" void RijndaelTransform_Decrypt256_m4151308345 ();
extern "C" void RijndaelTransform_ECB_m670662322 ();
extern "C" void RijndaelTransform_Encrypt128_m1940909042 ();
extern "C" void RijndaelTransform_Encrypt192_m3191066202 ();
extern "C" void RijndaelTransform_Encrypt256_m2353669657 ();
extern "C" void SHA1__ctor_m2454864745 ();
extern "C" void SHA1CryptoServiceProvider__ctor_m4195188793 ();
extern "C" void SHA1CryptoServiceProvider_Dispose_m1653611664 ();
extern "C" void SHA1CryptoServiceProvider_Finalize_m1793183797 ();
extern "C" void SHA1CryptoServiceProvider_HashCore_m3575298072 ();
extern "C" void SHA1CryptoServiceProvider_Initialize_m1426968065 ();
extern "C" void SHA1Internal__ctor_m2437096624 ();
extern "C" void SHA1Internal_AddLength_m2737455899 ();
extern "C" void SHA1Internal_FillBuff_m3615718415 ();
extern "C" void SHA1Internal_HashCore_m1635242363 ();
extern "C" void SHA1Internal_InitialiseBuff_m2891366785 ();
extern "C" void SHA1Internal_Initialize_m499810128 ();
extern "C" void SHA1Internal_ProcessBlock_m1991889327 ();
extern "C" void SHA1Internal_ProcessFinalBlock_m1403775421 ();
extern "C" void SHA1Managed__ctor_m3689558429 ();
extern "C" void SHA1Managed_HashCore_m3836844037 ();
extern "C" void SHA1Managed_Initialize_m1494395538 ();
extern "C" void SHA256__ctor_m4000989288 ();
extern "C" void SHA256Managed__ctor_m2170017447 ();
extern "C" void SHA256Managed_AddLength_m1060552216 ();
extern "C" void SHA256Managed_HashCore_m329219284 ();
extern "C" void SHA256Managed_Initialize_m1787080315 ();
extern "C" void SHA256Managed_ProcessBlock_m2297835517 ();
extern "C" void SHA256Managed_ProcessFinalBlock_m3518004226 ();
extern "C" void SHA384__ctor_m202253083 ();
extern "C" void SHA384Managed__ctor_m3220477113 ();
extern "C" void SHA384Managed_HashCore_m3010817561 ();
extern "C" void SHA384Managed_Initialize_m703960418 ();
extern "C" void SHA384Managed_Initialize_m1661896576 ();
extern "C" void SHA384Managed_adjustByteCounts_m2921970088 ();
extern "C" void SHA384Managed_processBlock_m1272529332 ();
extern "C" void SHA384Managed_processLength_m1746354084 ();
extern "C" void SHA384Managed_processWord_m3832940157 ();
extern "C" void SHA384Managed_unpackWord_m785426507 ();
extern "C" void SHA384Managed_update_m2910797953 ();
extern "C" void SHA512__ctor_m84228937 ();
extern "C" void SHA512Managed__ctor_m330347986 ();
extern "C" void SHA512Managed_HashCore_m2377807474 ();
extern "C" void SHA512Managed_Initialize_m2478368867 ();
extern "C" void SHA512Managed_Initialize_m2527292789 ();
extern "C" void SHA512Managed_adjustByteCounts_m3003603904 ();
extern "C" void SHA512Managed_processBlock_m1725885004 ();
extern "C" void SHA512Managed_processLength_m2162821715 ();
extern "C" void SHA512Managed_processWord_m1015820257 ();
extern "C" void SHA512Managed_unpackWord_m3785560830 ();
extern "C" void SHA512Managed_update_m3202186042 ();
extern "C" void SHAConstants__cctor_m1699027474 ();
extern "C" void SignatureDescription__ctor_m3689246904 ();
extern "C" void SignatureDescription_set_DeformatterAlgorithm_m2634775062 ();
extern "C" void SignatureDescription_set_DigestAlgorithm_m1385003273 ();
extern "C" void SignatureDescription_set_FormatterAlgorithm_m3829972493 ();
extern "C" void SignatureDescription_set_KeyAlgorithm_m3497860189 ();
extern "C" void SymmetricAlgorithm__ctor_m467277132 ();
extern "C" void SymmetricAlgorithm_Clear_m3302238152 ();
extern "C" void SymmetricAlgorithm_Dispose_m1120980942 ();
extern "C" void SymmetricAlgorithm_Finalize_m2361523015 ();
extern "C" void SymmetricAlgorithm_System_IDisposable_Dispose_m3402297829 ();
extern "C" void SymmetricAlgorithm_set_BlockSize_m812732862 ();
extern "C" void SymmetricAlgorithm_set_IV_m3196220308 ();
extern "C" void SymmetricAlgorithm_set_Key_m1775642191 ();
extern "C" void SymmetricAlgorithm_set_KeySize_m3805756466 ();
extern "C" void SymmetricAlgorithm_set_Mode_m4060916368 ();
extern "C" void SymmetricAlgorithm_set_Padding_m1690860683 ();
extern "C" void ToBase64Transform_Dispose_m2199216182 ();
extern "C" void ToBase64Transform_Finalize_m4202114424 ();
extern "C" void ToBase64Transform_InternalTransformBlock_m3458782414 ();
extern "C" void ToBase64Transform_System_IDisposable_Dispose_m1701635576 ();
extern "C" void TripleDES__ctor_m4045412014 ();
extern "C" void TripleDES_set_Key_m3464715319 ();
extern "C" void TripleDESCryptoServiceProvider__ctor_m758388349 ();
extern "C" void TripleDESCryptoServiceProvider_GenerateIV_m3862928583 ();
extern "C" void TripleDESCryptoServiceProvider_GenerateKey_m1212686842 ();
extern "C" void TripleDESTransform__ctor_m3915497765 ();
extern "C" void TripleDESTransform_ECB_m731927780 ();
extern "C" void PublicKey__ctor_m1834139044 ();
extern "C" void X500DistinguishedName__ctor_m3469219344 ();
extern "C" void X500DistinguishedName_DecodeRawData_m3790804100 ();
extern "C" void X509BasicConstraintsExtension__ctor_m3136793028 ();
extern "C" void X509BasicConstraintsExtension__ctor_m3721156175 ();
extern "C" void X509BasicConstraintsExtension__ctor_m1244152959 ();
extern "C" void X509BasicConstraintsExtension_CopyFrom_m1931463033 ();
extern "C" void X509Certificate2__cctor_m4292326511 ();
extern "C" void X509Certificate2__ctor_m2370196240 ();
extern "C" void X509Certificate2_AppendBuffer_m445040858 ();
extern "C" void X509Certificate2_Import_m4026562329 ();
extern "C" void X509Certificate2_ImportPkcs12_m2042454190 ();
extern "C" void X509Certificate2_Reset_m3988214799 ();
extern "C" void X509Certificate2Collection__ctor_m1338914817 ();
extern "C" void X509Certificate2Collection__ctor_m3025547695 ();
extern "C" void X509Certificate2Collection_AddRange_m3206541680 ();
extern "C" void X509Certificate2Enumerator__ctor_m1083666285 ();
extern "C" void X509Certificate2Enumerator_Reset_m1308823525 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_Reset_m388172138 ();
extern "C" void X509Certificate__ctor_m1321742168 ();
extern "C" void X509Certificate__ctor_m1413707489 ();
extern "C" void X509Certificate__ctor_m1008109281 ();
extern "C" void X509Certificate__ctor_m4186241804 ();
extern "C" void X509Certificate_Import_m3563119820 ();
extern "C" void X509Certificate_Reset_m2350932593 ();
extern "C" void X509Certificate_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1836612204 ();
extern "C" void X509Certificate_System_Runtime_Serialization_ISerializable_GetObjectData_m1891910043 ();
extern "C" void X509CertificateEnumerator__ctor_m943731472 ();
extern "C" void X509CertificateEnumerator_Reset_m4026698923 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m1219650180 ();
extern "C" void X509CertificateCollection__ctor_m147081211 ();
extern "C" void X509CertificateCollection__ctor_m3178797723 ();
extern "C" void X509CertificateCollection_AddRange_m3683116910 ();
extern "C" void X509Chain__cctor_m993507223 ();
extern "C" void X509Chain__ctor_m2878811474 ();
extern "C" void X509Chain__ctor_m2674663382 ();
extern "C" void X509Chain_CheckRevocationOnChain_m1377635439 ();
extern "C" void X509Chain_PrepareForNextCertificate_m3691934993 ();
extern "C" void X509Chain_Process_m1119354891 ();
extern "C" void X509Chain_ProcessCertificateExtensions_m1468796745 ();
extern "C" void X509Chain_Reset_m1198177101 ();
extern "C" void X509Chain_ValidateChain_m1402813093 ();
extern "C" void X509Chain_WrapUp_m3160803936 ();
extern "C" void X509ChainElement__ctor_m252371420 ();
extern "C" void X509ChainElement_Set_m655180762 ();
extern "C" void X509ChainElement_UncompressFlags_m781553362 ();
extern "C" void X509ChainElement_set_StatusFlags_m2467275568 ();
extern "C" void X509ChainElementCollection__ctor_m3424079155 ();
extern "C" void X509ChainElementCollection_Add_m737054930 ();
extern "C" void X509ChainElementCollection_Clear_m2271223414 ();
extern "C" void X509ChainElementCollection_System_Collections_ICollection_CopyTo_m1179155153 ();
extern "C" void X509ChainElementEnumerator__ctor_m1674160564 ();
extern "C" void X509ChainElementEnumerator_Reset_m1416607221 ();
extern "C" void X509ChainPolicy__ctor_m852124469 ();
extern "C" void X509ChainPolicy_Reset_m1883700166 ();
extern "C" void X509ChainStatus__ctor_m4178125999_AdjustorThunk ();
extern "C" void X509ChainStatus_set_Status_m263715218_AdjustorThunk ();
extern "C" void X509ChainStatus_set_StatusInformation_m1638042991_AdjustorThunk ();
extern "C" void X509EnhancedKeyUsageExtension__ctor_m298908880 ();
extern "C" void X509EnhancedKeyUsageExtension_CopyFrom_m3750050754 ();
extern "C" void X509Extension__ctor_m1624259472 ();
extern "C" void X509Extension__ctor_m225879936 ();
extern "C" void X509Extension_CopyFrom_m474590450 ();
extern "C" void X509Extension_set_Critical_m1180944253 ();
extern "C" void X509ExtensionCollection__ctor_m1730716172 ();
extern "C" void X509ExtensionCollection_System_Collections_ICollection_CopyTo_m2505796149 ();
extern "C" void X509ExtensionEnumerator__ctor_m827820494 ();
extern "C" void X509ExtensionEnumerator_Reset_m2310001600 ();
extern "C" void X509KeyUsageExtension__ctor_m1098820427 ();
extern "C" void X509KeyUsageExtension__ctor_m1105912158 ();
extern "C" void X509KeyUsageExtension__ctor_m524748856 ();
extern "C" void X509KeyUsageExtension_CopyFrom_m186479533 ();
extern "C" void X509Store__ctor_m275383717 ();
extern "C" void X509Store_Close_m799536774 ();
extern "C" void X509Store_Open_m909451489 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m3160552652 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m2644971776 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m2055934916 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m3547362312 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m1397817642 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m201177607 ();
extern "C" void X509SubjectKeyIdentifierExtension_CopyFrom_m1588766981 ();
extern "C" void PermissionSet__ctor_m2328457660 ();
extern "C" void PermissionSet__ctor_m1880216441 ();
extern "C" void PermissionSet_set_DeclarativeSecurity_m858801747 ();
extern "C" void SecurityPermission__ctor_m1462427327 ();
extern "C" void SecurityPermission_set_Flags_m1503445204 ();
extern "C" void SecurityPermissionAttribute_set_SkipVerification_m4061350763 ();
extern "C" void ApplicationTrust__ctor_m515003198 ();
extern "C" void EvidenceEnumerator__ctor_m3211544433 ();
extern "C" void EvidenceEnumerator_Reset_m2337577119 ();
extern "C" void Evidence__ctor_m415538579 ();
extern "C" void Evidence_CopyTo_m872435527 ();
extern "C" void Hash__ctor_m1849242049 ();
extern "C" void Hash__ctor_m2891763106 ();
extern "C" void Hash_GetObjectData_m2136403986 ();
extern "C" void WindowsIdentity__cctor_m1315799505 ();
extern "C" void WindowsIdentity__ctor_m3086466707 ();
extern "C" void WindowsIdentity_Dispose_m3466258450 ();
extern "C" void WindowsIdentity_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3428853631 ();
extern "C" void WindowsIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2539658116 ();
extern "C" void SecurityContext__ctor_m3125602325 ();
extern "C" void SecurityContext__ctor_m1730177197 ();
extern "C" void SecurityCriticalAttribute__ctor_m2491468454 ();
extern "C" void SecurityAttribute__ctor_m1429827508 ();
extern "C" void SecurityElement__cctor_m3326869319 ();
extern "C" void SecurityElement__ctor_m6516005 ();
extern "C" void SecurityElement__ctor_m750466183 ();
extern "C" void SecurityElement_AddAttribute_m311510562 ();
extern "C" void SecurityElement_AddChild_m1606852781 ();
extern "C" void SecurityElement_ToXml_m3664345083 ();
extern "C" void SecurityElement_set_Text_m3975773934 ();
extern "C" void SecurityException__ctor_m836898292 ();
extern "C" void SecurityException__ctor_m254177942 ();
extern "C" void SecurityException__ctor_m1631242336 ();
extern "C" void SecurityException_GetObjectData_m1968030344 ();
extern "C" void SecurityFrame__ctor_m2140076703_AdjustorThunk ();
extern "C" void SecurityFrame_InitFromRuntimeFrame_m1714852458_AdjustorThunk ();
extern "C" void SecurityManager__cctor_m975553111 ();
extern "C" void SecuritySafeCriticalAttribute__ctor_m3038748144 ();
extern "C" void SuppressUnmanagedCodeSecurityAttribute__ctor_m1009318222 ();
extern "C" void UnverifiableCodeAttribute__ctor_m3990698597 ();
extern "C" void SerializableAttribute__ctor_m3782985861 ();
extern "C" void StackOverflowException__ctor_m592204071 ();
extern "C" void StackOverflowException__ctor_m3777153282 ();
extern "C" void StackOverflowException__ctor_m3139217097 ();
extern "C" void String__cctor_m261295518 ();
extern "C" void String__ctor_m1266423354 ();
extern "C" void String__ctor_m229724522 ();
extern "C" void String__ctor_m1800510039 ();
extern "C" void String__ctor_m1926862525 ();
extern "C" void String_CharCopy_m98228993 ();
extern "C" void String_CharCopy_m2254797373 ();
extern "C" void String_CharCopy_m3838781968 ();
extern "C" void String_CharCopyReverse_m1548661297 ();
extern "C" void String_CharCopyReverse_m692227313 ();
extern "C" void String_CopyTo_m2803757991 ();
extern "C" void String_InternalSetChar_m884839805 ();
extern "C" void String_InternalSetLength_m3661226516 ();
extern "C" void String_ParseFormatSpecifier_m3134189457 ();
extern "C" void String_memcpy_m2826223007 ();
extern "C" void String_memcpy1_m4209751456 ();
extern "C" void String_memcpy2_m2048375426 ();
extern "C" void String_memcpy4_m979367827 ();
extern "C" void StringComparer__cctor_m1626042071 ();
extern "C" void StringComparer__ctor_m621368542 ();
extern "C" void SystemException__ctor_m4274309232 ();
extern "C" void SystemException__ctor_m1515048899 ();
extern "C" void SystemException__ctor_m3298527747 ();
extern "C" void SystemException__ctor_m4132668650 ();
extern "C" void ASCIIEncoding__ctor_m1380190655 ();
extern "C" void Decoder__ctor_m4046021500 ();
extern "C" void Decoder_set_Fallback_m3834517714 ();
extern "C" void DecoderExceptionFallback__ctor_m4044614564 ();
extern "C" void DecoderExceptionFallbackBuffer__ctor_m3568925774 ();
extern "C" void DecoderFallback__cctor_m3250479635 ();
extern "C" void DecoderFallback__ctor_m1420784892 ();
extern "C" void DecoderFallbackBuffer__ctor_m2724858323 ();
extern "C" void DecoderFallbackBuffer_Reset_m3069554060 ();
extern "C" void DecoderFallbackException__ctor_m1480564942 ();
extern "C" void DecoderFallbackException__ctor_m2423399765 ();
extern "C" void DecoderFallbackException__ctor_m2882024994 ();
extern "C" void DecoderReplacementFallback__ctor_m449982280 ();
extern "C" void DecoderReplacementFallback__ctor_m2470322217 ();
extern "C" void DecoderReplacementFallbackBuffer__ctor_m1669699347 ();
extern "C" void DecoderReplacementFallbackBuffer_Reset_m3943028589 ();
extern "C" void EncoderExceptionFallback__ctor_m3745979420 ();
extern "C" void EncoderExceptionFallbackBuffer__ctor_m2042603395 ();
extern "C" void EncoderFallback__cctor_m3806755293 ();
extern "C" void EncoderFallback__ctor_m3732686580 ();
extern "C" void EncoderFallbackBuffer__ctor_m4249106511 ();
extern "C" void EncoderFallbackException__ctor_m4193543656 ();
extern "C" void EncoderFallbackException__ctor_m1643109704 ();
extern "C" void EncoderFallbackException__ctor_m1051987327 ();
extern "C" void EncoderFallbackException__ctor_m1920003269 ();
extern "C" void EncoderReplacementFallback__ctor_m2980727890 ();
extern "C" void EncoderReplacementFallback__ctor_m1483565116 ();
extern "C" void EncoderReplacementFallbackBuffer__ctor_m4044873320 ();
extern "C" void ForwardingDecoder__ctor_m335665988 ();
extern "C" void Encoding__cctor_m1936558127 ();
extern "C" void Encoding__ctor_m2997749867 ();
extern "C" void Encoding__ctor_m777655508 ();
extern "C" void Encoding_SetFallbackInternal_m3883046321 ();
extern "C" void Encoding_set_DecoderFallback_m148532738 ();
extern "C" void Latin1Encoding__ctor_m498920120 ();
extern "C" void BaseMachine__ctor_m1534760230 ();
extern "C" void Capture__ctor_m3103117740 ();
extern "C" void Capture__ctor_m539415522 ();
extern "C" void CaptureCollection__ctor_m357483405 ();
extern "C" void CaptureCollection_CopyTo_m3566922817 ();
extern "C" void CaptureCollection_SetValue_m89830704 ();
extern "C" void Key__ctor_m251888331 ();
extern "C" void FactoryCache__ctor_m206337971 ();
extern "C" void FactoryCache_Add_m1371573845 ();
extern "C" void FactoryCache_Cleanup_m308458843 ();
extern "C" void Group__cctor_m2230627219 ();
extern "C" void Group__ctor_m3285303650 ();
extern "C" void Group__ctor_m2495427790 ();
extern "C" void Group__ctor_m2243671333 ();
extern "C" void GroupCollection__ctor_m3775662598 ();
extern "C" void GroupCollection_CopyTo_m408257156 ();
extern "C" void GroupCollection_SetValue_m2707160733 ();
extern "C" void IntStack_Push_m1082581210_AdjustorThunk ();
extern "C" void IntStack_set_Count_m756607812_AdjustorThunk ();
extern "C" void RepeatContext__ctor_m2465637864 ();
extern "C" void RepeatContext_set_Count_m960350409 ();
extern "C" void RepeatContext_set_Start_m2870272657 ();
extern "C" void Interpreter__ctor_m2134836895 ();
extern "C" void Interpreter_Backtrack_m2828876822 ();
extern "C" void Interpreter_Close_m126356671 ();
extern "C" void Interpreter_GetGroupInfo_m2253622734 ();
extern "C" void Interpreter_Open_m900076395 ();
extern "C" void Interpreter_PopulateGroup_m4042796257 ();
extern "C" void Interpreter_Reset_m2774688020 ();
extern "C" void Interpreter_ResetGroups_m3595179625 ();
extern "C" void InterpreterFactory__ctor_m3950407360 ();
extern "C" void InterpreterFactory_set_Gap_m3029846199 ();
extern "C" void InterpreterFactory_set_Mapping_m1881043811 ();
extern "C" void InterpreterFactory_set_NamesMapping_m1853107228 ();
extern "C" void Interval__ctor_m4022869013_AdjustorThunk ();
extern "C" void Interval_Merge_m3454211016_AdjustorThunk ();
extern "C" void CostDelegate__ctor_m4027655829 ();
extern "C" void Enumerator__ctor_m1228633090 ();
extern "C" void Enumerator_Reset_m2498345483 ();
extern "C" void IntervalCollection__ctor_m758349803 ();
extern "C" void IntervalCollection_Add_m2115898256 ();
extern "C" void IntervalCollection_CopyTo_m2976848759 ();
extern "C" void IntervalCollection_Normalize_m1934892959 ();
extern "C" void IntervalCollection_Optimize_m161975983 ();
extern "C" void LinkRef__ctor_m3071983504 ();
extern "C" void LinkStack__ctor_m1458748896 ();
extern "C" void LinkStack_Push_m3081279930 ();
extern "C" void Node__ctor_m3885833051 ();
extern "C" void MRUList__ctor_m3064247590 ();
extern "C" void MRUList_Use_m110810900 ();
extern "C" void Match__cctor_m3511441780 ();
extern "C" void Match__ctor_m624429017 ();
extern "C" void Match__ctor_m2464595873 ();
extern "C" void Match__ctor_m2425511580 ();
extern "C" void Enumerator__ctor_m714733887 ();
extern "C" void Enumerator_System_Collections_IEnumerator_Reset_m24787251 ();
extern "C" void MatchCollection__ctor_m4138850022 ();
extern "C" void MatchCollection_CopyTo_m3807326147 ();
extern "C" void PatternLinkStack__ctor_m4175825564 ();
extern "C" void PatternLinkStack_SetCurrent_m366511098 ();
extern "C" void PatternLinkStack_set_BaseAddress_m1446738163 ();
extern "C" void PatternLinkStack_set_OffsetAddress_m2052096082 ();
extern "C" void PatternCompiler__ctor_m1221514440 ();
extern "C" void PatternCompiler_BeginLink_m1295557963 ();
extern "C" void PatternCompiler_Emit_m3022689557 ();
extern "C" void PatternCompiler_Emit_m1540115729 ();
extern "C" void PatternCompiler_Emit_m604664654 ();
extern "C" void PatternCompiler_EmitAlternationEnd_m2444359097 ();
extern "C" void PatternCompiler_EmitAnchor_m1950537976 ();
extern "C" void PatternCompiler_EmitBalance_m3442526123 ();
extern "C" void PatternCompiler_EmitBalanceStart_m3310909460 ();
extern "C" void PatternCompiler_EmitBranch_m3879973493 ();
extern "C" void PatternCompiler_EmitBranchEnd_m2845168300 ();
extern "C" void PatternCompiler_EmitCategory_m851169746 ();
extern "C" void PatternCompiler_EmitCharacter_m1434994858 ();
extern "C" void PatternCompiler_EmitClose_m2259636270 ();
extern "C" void PatternCompiler_EmitCount_m1087322477 ();
extern "C" void PatternCompiler_EmitFalse_m1347893438 ();
extern "C" void PatternCompiler_EmitFastRepeat_m3012952683 ();
extern "C" void PatternCompiler_EmitIfDefined_m2075050865 ();
extern "C" void PatternCompiler_EmitIn_m4131231439 ();
extern "C" void PatternCompiler_EmitInfo_m780326530 ();
extern "C" void PatternCompiler_EmitJump_m3915926156 ();
extern "C" void PatternCompiler_EmitLink_m1012034249 ();
extern "C" void PatternCompiler_EmitNotCategory_m2023580103 ();
extern "C" void PatternCompiler_EmitOpen_m3165174429 ();
extern "C" void PatternCompiler_EmitPosition_m2959691703 ();
extern "C" void PatternCompiler_EmitRange_m2566284920 ();
extern "C" void PatternCompiler_EmitReference_m2546735804 ();
extern "C" void PatternCompiler_EmitRepeat_m697083858 ();
extern "C" void PatternCompiler_EmitSet_m2815529224 ();
extern "C" void PatternCompiler_EmitString_m3605578155 ();
extern "C" void PatternCompiler_EmitSub_m193323684 ();
extern "C" void PatternCompiler_EmitTest_m764507779 ();
extern "C" void PatternCompiler_EmitTrue_m2226795800 ();
extern "C" void PatternCompiler_EmitUntil_m3644194775 ();
extern "C" void PatternCompiler_ResolveLink_m2545921107 ();
extern "C" void QuickSearch__cctor_m2494832544 ();
extern "C" void QuickSearch__ctor_m430910133 ();
extern "C" void QuickSearch_SetupShiftTable_m3696400592 ();
extern "C" void Regex__cctor_m3370093859 ();
extern "C" void Regex__ctor_m1255796137 ();
extern "C" void Regex__ctor_m4152689500 ();
extern "C" void Regex__ctor_m3948448025 ();
extern "C" void Regex__ctor_m1728442805 ();
extern "C" void Regex_Init_m289933770 ();
extern "C" void Regex_InitNewRegex_m3271185474 ();
extern "C" void Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m4061390789 ();
extern "C" void Regex_validate_options_m3221650569 ();
extern "C" void Alternation__ctor_m1629257642 ();
extern "C" void Alternation_AddAlternative_m3625038910 ();
extern "C" void Alternation_Compile_m944357616 ();
extern "C" void Alternation_GetWidth_m2955030832 ();
extern "C" void AnchorInfo__ctor_m3523994803 ();
extern "C" void AnchorInfo__ctor_m3869855453 ();
extern "C" void AnchorInfo__ctor_m46784903 ();
extern "C" void Assertion__ctor_m2128950829 ();
extern "C" void Assertion_GetWidth_m3431863255 ();
extern "C" void Assertion_set_FalseExpression_m468310168 ();
extern "C" void Assertion_set_TrueExpression_m530142558 ();
extern "C" void BackslashNumber__ctor_m3802423446 ();
extern "C" void BackslashNumber_Compile_m1825066804 ();
extern "C" void BalancingGroup__ctor_m2760700418 ();
extern "C" void BalancingGroup_Compile_m2575117193 ();
extern "C" void BalancingGroup_set_Balance_m3289053627 ();
extern "C" void CaptureAssertion__ctor_m1422197394 ();
extern "C" void CaptureAssertion_Compile_m1815624462 ();
extern "C" void CaptureAssertion_set_CapturingGroup_m2003123956 ();
extern "C" void CapturingGroup__ctor_m1932199154 ();
extern "C" void CapturingGroup_Compile_m1789150976 ();
extern "C" void CapturingGroup_set_Index_m1113018009 ();
extern "C" void CapturingGroup_set_Name_m3031988208 ();
extern "C" void CharacterClass__cctor_m443084915 ();
extern "C" void CharacterClass__ctor_m1294707193 ();
extern "C" void CharacterClass__ctor_m2417156412 ();
extern "C" void CharacterClass_AddCategory_m3505628817 ();
extern "C" void CharacterClass_AddCharacter_m2370152363 ();
extern "C" void CharacterClass_AddRange_m3500530626 ();
extern "C" void CharacterClass_Compile_m3296067317 ();
extern "C" void CharacterClass_GetWidth_m2503189403 ();
extern "C" void CompositeExpression__ctor_m2434860303 ();
extern "C" void CompositeExpression_GetWidth_m936348716 ();
extern "C" void Expression__ctor_m1600460087 ();
extern "C" void ExpressionAssertion__ctor_m2554412824 ();
extern "C" void ExpressionAssertion_Compile_m2166597834 ();
extern "C" void ExpressionAssertion_set_Negate_m1236561973 ();
extern "C" void ExpressionAssertion_set_Reverse_m4141031406 ();
extern "C" void ExpressionAssertion_set_TestExpression_m3544634251 ();
extern "C" void ExpressionCollection__ctor_m2806571689 ();
extern "C" void ExpressionCollection_Add_m41125344 ();
extern "C" void ExpressionCollection_OnValidate_m3555775570 ();
extern "C" void ExpressionCollection_set_Item_m2040804459 ();
extern "C" void Group__ctor_m2980794822 ();
extern "C" void Group_AppendExpression_m1633560475 ();
extern "C" void Group_Compile_m3355488790 ();
extern "C" void Group_GetWidth_m3299755715 ();
extern "C" void Literal__ctor_m1697110877 ();
extern "C" void Literal_Compile_m2228022079 ();
extern "C" void Literal_CompileLiteral_m4231400317 ();
extern "C" void Literal_GetWidth_m2673961846 ();
extern "C" void NonBacktrackingGroup__ctor_m2332797184 ();
extern "C" void NonBacktrackingGroup_Compile_m1731438724 ();
extern "C" void Parser__ctor_m3200411199 ();
extern "C" void Parser_ConsumeWhitespace_m3364496713 ();
extern "C" void Parser_HandleExplicitNumericGroups_m1412234891 ();
extern "C" void Parser_ParseGroup_m3186460488 ();
extern "C" void Parser_ParseOptions_m2606822689 ();
extern "C" void Parser_ResolveReferences_m1518052352 ();
extern "C" void PositionAssertion__ctor_m569003936 ();
extern "C" void PositionAssertion_Compile_m2500980346 ();
extern "C" void PositionAssertion_GetWidth_m856687117 ();
extern "C" void Reference__ctor_m1870245246 ();
extern "C" void Reference_Compile_m4195878675 ();
extern "C" void Reference_GetWidth_m3130781491 ();
extern "C" void Reference_set_CapturingGroup_m1130974240 ();
extern "C" void RegularExpression__ctor_m119502265 ();
extern "C" void RegularExpression_Compile_m2385682508 ();
extern "C" void RegularExpression_set_GroupCount_m3908887512 ();
extern "C" void Repetition__ctor_m1672362629 ();
extern "C" void Repetition_Compile_m988726715 ();
extern "C" void Repetition_GetWidth_m1827161831 ();
extern "C" void Repetition_set_Expression_m1234887071 ();
extern "C" void StringBuilder__ctor_m3121283359 ();
extern "C" void StringBuilder__ctor_m2367297767 ();
extern "C" void StringBuilder__ctor_m2625406916 ();
extern "C" void StringBuilder__ctor_m2989139009 ();
extern "C" void StringBuilder__ctor_m2502310956 ();
extern "C" void StringBuilder__ctor_m3797152686 ();
extern "C" void StringBuilder__ctor_m3504405255 ();
extern "C" void StringBuilder_InternalEnsureCapacity_m1976244425 ();
extern "C" void StringBuilder_System_Runtime_Serialization_ISerializable_GetObjectData_m4227593635 ();
extern "C" void StringBuilder_set_Capacity_m3366027632 ();
extern "C" void StringBuilder_set_Chars_m3548656617 ();
extern "C" void StringBuilder_set_Length_m1410065908 ();
extern "C" void UTF32Decoder__ctor_m1109508508 ();
extern "C" void UTF32Encoding__ctor_m1635603592 ();
extern "C" void UTF32Encoding__ctor_m2278531302 ();
extern "C" void UTF32Encoding__ctor_m3417652600 ();
extern "C" void UTF7Decoder__ctor_m546843796 ();
extern "C" void UTF7Encoding__cctor_m1116871411 ();
extern "C" void UTF7Encoding__ctor_m1257259578 ();
extern "C" void UTF7Encoding__ctor_m3592291633 ();
extern "C" void UTF8Decoder__ctor_m3811899787 ();
extern "C" void UTF8Encoding__ctor_m1224805231 ();
extern "C" void UTF8Encoding__ctor_m661806809 ();
extern "C" void UTF8Encoding__ctor_m1391509536 ();
extern "C" void UTF8Encoding_Fallback_m3793102142 ();
extern "C" void UnicodeDecoder__ctor_m3606046165 ();
extern "C" void UnicodeEncoding__ctor_m1074918879 ();
extern "C" void UnicodeEncoding__ctor_m3604373700 ();
extern "C" void UnicodeEncoding__ctor_m936764770 ();
extern "C" void UnicodeEncoding_CopyChars_m785272451 ();
extern "C" void ThreadStaticAttribute__ctor_m1099840517 ();
extern "C" void CompressedStack__ctor_m2442654875 ();
extern "C" void CompressedStack__ctor_m315468647 ();
extern "C" void CompressedStack_GetObjectData_m2451703776 ();
extern "C" void EventWaitHandle__ctor_m3773182490 ();
extern "C" void ExecutionContext__ctor_m3874209501 ();
extern "C" void ExecutionContext__ctor_m418421535 ();
extern "C" void ExecutionContext__ctor_m957177596 ();
extern "C" void ExecutionContext_GetObjectData_m3398518585 ();
extern "C" void ExecutionContext_set_SecurityContext_m3443205304 ();
extern "C" void ManualResetEvent__ctor_m4010886457 ();
extern "C" void Monitor_Enter_m2249409497 ();
extern "C" void Monitor_Exit_m3585316909 ();
extern "C" void Monitor_Monitor_pulse_m2491828136 ();
extern "C" void Monitor_Pulse_m82725344 ();
extern "C" void Mutex__ctor_m2825059899 ();
extern "C" void Mutex_ReleaseMutex_m3169074890 ();
extern "C" void NativeEventCalls_CloseEvent_internal_m2546122398 ();
extern "C" void RegisteredWaitHandle__ctor_m1645196847 ();
extern "C" void RegisteredWaitHandle_DoCallBack_m365365633 ();
extern "C" void RegisteredWaitHandle_Wait_m1429620915 ();
extern "C" void SendOrPostCallback__ctor_m1566534627 ();
extern "C" void SendOrPostCallback_EndInvoke_m2485163446 ();
extern "C" void SendOrPostCallback_Invoke_m937799800 ();
extern "C" void SynchronizationContext__ctor_m2514243817 ();
extern "C" void SynchronizationContext_SetSynchronizationContext_m1249070039 ();
extern "C" void SynchronizationLockException__ctor_m4154160957 ();
extern "C" void SynchronizationLockException__ctor_m2582325363 ();
extern "C" void SynchronizationLockException__ctor_m3407855920 ();
extern "C" void Thread__cctor_m817723615 ();
extern "C" void Thread__ctor_m777188137 ();
extern "C" void Thread_ClrState_m3379113724 ();
extern "C" void Thread_Finalize_m3446740003 ();
extern "C" void Thread_FreeLocalSlotValues_m1195763560 ();
extern "C" void Thread_SetCachedCurrentCulture_m2609530899 ();
extern "C" void Thread_SetCachedCurrentUICulture_m1729523031 ();
extern "C" void Thread_SetName_internal_m3162565917 ();
extern "C" void Thread_SetState_m3429987131 ();
extern "C" void Thread_Start_m2860771284 ();
extern "C" void Thread_Thread_free_internal_m333849022 ();
extern "C" void Thread_Thread_init_m3583989169 ();
extern "C" void Thread_set_IsBackground_m3868016371 ();
extern "C" void Thread_set_Name_m3537838048 ();
extern "C" void ThreadAbortException__ctor_m4260562921 ();
extern "C" void ThreadAbortException__ctor_m1955533141 ();
extern "C" void ThreadInterruptedException__ctor_m144467266 ();
extern "C" void ThreadInterruptedException__ctor_m4104953416 ();
extern "C" void ThreadStart__ctor_m3250019360 ();
extern "C" void ThreadStart_EndInvoke_m3768045394 ();
extern "C" void ThreadStart_Invoke_m1483406622 ();
extern "C" void ThreadStateException__ctor_m3372575002 ();
extern "C" void ThreadStateException__ctor_m2721596288 ();
extern "C" void Scheduler__cctor_m4042462055 ();
extern "C" void Scheduler__ctor_m3313141270 ();
extern "C" void Scheduler_Add_m21574731 ();
extern "C" void Scheduler_Change_m1742004650 ();
extern "C" void Scheduler_Remove_m3288162609 ();
extern "C" void Scheduler_SchedulerThread_m10185948 ();
extern "C" void Scheduler_ShrinkIfNeeded_m820085397 ();
extern "C" void TimerComparer__ctor_m1513620849 ();
extern "C" void Timer__cctor_m3385262259 ();
extern "C" void Timer__ctor_m3795312967 ();
extern "C" void Timer_Dispose_m671628881 ();
extern "C" void Timer_Init_m891735195 ();
extern "C" void TimerCallback__ctor_m3981479132 ();
extern "C" void TimerCallback_EndInvoke_m2599485055 ();
extern "C" void TimerCallback_Invoke_m1938221087 ();
extern "C" void WaitCallback__ctor_m1893321019 ();
extern "C" void WaitCallback_EndInvoke_m3047974377 ();
extern "C" void WaitCallback_Invoke_m1820972147 ();
extern "C" void WaitHandle__cctor_m4242752477 ();
extern "C" void WaitHandle__ctor_m1707080176 ();
extern "C" void WaitHandle_CheckArray_m4078006015 ();
extern "C" void WaitHandle_CheckDisposed_m303961449 ();
extern "C" void WaitHandle_Dispose_m738127030 ();
extern "C" void WaitHandle_Finalize_m2167095134 ();
extern "C" void WaitHandle_System_IDisposable_Dispose_m1791996204 ();
extern "C" void WaitHandle_set_Handle_m2472203672 ();
extern "C" void WaitOrTimerCallback__ctor_m2652598011 ();
extern "C" void WaitOrTimerCallback_EndInvoke_m1418086160 ();
extern "C" void WaitOrTimerCallback_Invoke_m3960825914 ();
extern "C" void TimeSpan__cctor_m3988022323 ();
extern "C" void TimeSpan__ctor_m3689759052_AdjustorThunk ();
extern "C" void TimeSpan__ctor_m2047388489_AdjustorThunk ();
extern "C" void TimeSpan__ctor_m1896986612_AdjustorThunk ();
extern "C" void TimeZone__cctor_m798292265 ();
extern "C" void TimeZone__ctor_m1831364098 ();
extern "C" void Type__cctor_m2371893800 ();
extern "C" void Type__ctor_m3795799013 ();
extern "C" void TypeInitializationException__ctor_m3546444694 ();
extern "C" void TypeInitializationException_GetObjectData_m583196803 ();
extern "C" void TypeLoadException__ctor_m1802671078 ();
extern "C" void TypeLoadException__ctor_m3040414142 ();
extern "C" void TypeLoadException__ctor_m2362330792 ();
extern "C" void TypeLoadException__ctor_m1154572625 ();
extern "C" void TypeLoadException_GetObjectData_m2127700107 ();
extern "C" void UIntPtr__cctor_m3513964473 ();
extern "C" void UIntPtr__ctor_m4250165422_AdjustorThunk ();
extern "C" void UIntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m1767630151_AdjustorThunk ();
extern "C" void UnauthorizedAccessException__ctor_m246605039 ();
extern "C" void UnauthorizedAccessException__ctor_m1652256089 ();
extern "C" void UnauthorizedAccessException__ctor_m40101894 ();
extern "C" void UnhandledExceptionEventArgs__ctor_m224348470 ();
extern "C" void UnhandledExceptionEventHandler__ctor_m626016213 ();
extern "C" void UnhandledExceptionEventHandler_EndInvoke_m2316153791 ();
extern "C" void UnhandledExceptionEventHandler_Invoke_m1545705626 ();
extern "C" void UnitySerializationHolder__ctor_m3869442095 ();
extern "C" void UnitySerializationHolder_GetDBNullData_m714211970 ();
extern "C" void UnitySerializationHolder_GetModuleData_m1550266881 ();
extern "C" void UnitySerializationHolder_GetObjectData_m3377455907 ();
extern "C" void UnitySerializationHolder_GetTypeData_m2453779479 ();
extern "C" void UriScheme__ctor_m1399779782_AdjustorThunk ();
extern "C" void Uri__cctor_m38080231 ();
extern "C" void Uri__ctor_m3848281005 ();
extern "C" void Uri__ctor_m800430703 ();
extern "C" void Uri__ctor_m3577021606 ();
extern "C" void Uri__ctor_m3040793867 ();
extern "C" void Uri__ctor_m253204164 ();
extern "C" void Uri_AppendQueryAndFragment_m3170766010 ();
extern "C" void Uri_EnsureAbsoluteUri_m2231483494 ();
extern "C" void Uri_Merge_m76373955 ();
extern "C" void Uri_Parse_m736300106 ();
extern "C" void Uri_ParseAsUnixAbsoluteFilePath_m1476768041 ();
extern "C" void Uri_ParseAsWindowsUNC_m2348878458 ();
extern "C" void Uri_ParseUri_m2150795567 ();
extern "C" void Uri_System_Runtime_Serialization_ISerializable_GetObjectData_m4023918416 ();
extern "C" void UriFormatException__ctor_m1115096473 ();
extern "C" void UriFormatException__ctor_m3466512970 ();
extern "C" void UriFormatException__ctor_m3083316541 ();
extern "C" void UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_m3030326401 ();
extern "C" void UriParser__cctor_m3655686731 ();
extern "C" void UriParser__ctor_m2454688443 ();
extern "C" void UriParser_CreateDefaults_m404296154 ();
extern "C" void UriParser_InitializeAndValidate_m2008117311 ();
extern "C" void UriParser_InternalRegister_m3643767086 ();
extern "C" void UriParser_OnRegister_m3283921560 ();
extern "C" void UriParser_set_DefaultPort_m4007715058 ();
extern "C" void UriParser_set_SchemeName_m266448765 ();
extern "C" void ValueType__ctor_m2036258423 ();
extern "C" void Version__ctor_m872301635 ();
extern "C" void Version__ctor_m3537335798 ();
extern "C" void Version__ctor_m1550720073 ();
extern "C" void Version__ctor_m417728625 ();
extern "C" void Version__ctor_m1394137037 ();
extern "C" void Version_CheckedSet_m654078179 ();
extern "C" void WeakReference__ctor_m24376735 ();
extern "C" void WeakReference__ctor_m2401547918 ();
extern "C" void WeakReference__ctor_m1054065938 ();
extern "C" void WeakReference__ctor_m1244067698 ();
extern "C" void WeakReference_AllocateHandle_m1478975559 ();
extern "C" void WeakReference_Finalize_m2841826116 ();
extern "C" void WeakReference_GetObjectData_m2192383095 ();
extern "C" void __Il2CppComDelegate_Finalize_m2460829410 ();
extern "C" void __Il2CppComObject_Finalize_m2923638372 ();
extern "C" void AddComponentMenu__ctor_m867138430 ();
extern "C" void AnalyticsEvent__cctor_m3994162614 ();
extern "C" void AnalyticsEvent_OnValidationFailed_m2609604624 ();
extern "C" void AnalyticsEventParam__ctor_m1888826734 ();
extern "C" void AnalyticsEventParamListContainer__ctor_m1995104893 ();
extern "C" void AnalyticsEventParamListContainer_set_parameters_m2253031841 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0__ctor_m375484522 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0_Dispose_m3542186276 ();
extern "C" void U3CTimedTriggerU3Ec__Iterator0_Reset_m1406161701 ();
extern "C" void AnalyticsEventTracker__ctor_m3064238498 ();
extern "C" void AnalyticsEventTracker_Awake_m2780522130 ();
extern "C" void AnalyticsEventTracker_OnApplicationPause_m2936008520 ();
extern "C" void AnalyticsEventTracker_OnDestroy_m3032713758 ();
extern "C" void AnalyticsEventTracker_OnDisable_m1553012800 ();
extern "C" void AnalyticsEventTracker_OnEnable_m1121905268 ();
extern "C" void AnalyticsEventTracker_Start_m1087627554 ();
extern "C" void AnalyticsEventTracker_TriggerEvent_m860167642 ();
extern "C" void AnalyticsEventTrackerSettings__cctor_m99217142 ();
extern "C" void SessionStateChanged__ctor_m2637910444 ();
extern "C" void SessionStateChanged_EndInvoke_m3581055289 ();
extern "C" void SessionStateChanged_Invoke_m4203746932 ();
extern "C" void AnalyticsSessionInfo_CallSessionStateChanged_m1270932408 ();
extern "C" void AnalyticsTracker__ctor_m3762295226 ();
extern "C" void AnalyticsTracker_Awake_m2774678677 ();
extern "C" void AnalyticsTracker_BuildParameters_m43920649 ();
extern "C" void AnalyticsTracker_OnApplicationPause_m2421888091 ();
extern "C" void AnalyticsTracker_OnDestroy_m3072032071 ();
extern "C" void AnalyticsTracker_OnDisable_m2584849643 ();
extern "C" void AnalyticsTracker_OnEnable_m175592117 ();
extern "C" void AnalyticsTracker_SendEvent_m2955089255 ();
extern "C" void AnalyticsTracker_Start_m3944341596 ();
extern "C" void AnalyticsTracker_TriggerEvent_m2244736785 ();
extern "C" void AnalyticsTracker_set_TP_m4206182699 ();
extern "C" void AnalyticsTracker_set_eventName_m370326070 ();
extern "C" void CustomEventData__ctor_m4146403782 ();
extern "C" void CustomEventData_Destroy_m2070199408 ();
extern "C" void CustomEventData_Dispose_m4023815755 ();
extern "C" void CustomEventData_Finalize_m1724721833 ();
extern "C" void CustomEventData_Internal_Destroy_m3916992396 ();
extern "C" void OnTrigger__ctor_m2072368789 ();
extern "C" void OnTrigger_EndInvoke_m1076439436 ();
extern "C" void OnTrigger_Invoke_m2120872091 ();
extern "C" void EventTrigger__ctor_m3931360164 ();
extern "C" void EventTrigger_AddRule_m2980113967 ();
extern "C" void EventTrigger_RemoveRule_m1596811726 ();
extern "C" void EventTrigger_set_initTime_m3128947762 ();
extern "C" void EventTrigger_set_repeatTime_m1188543944 ();
extern "C" void EventTrigger_set_repetitions_m1079340996 ();
extern "C" void StandardEventPayload__cctor_m3346303468 ();
extern "C" void StandardEventPayload__ctor_m1676969451 ();
extern "C" void StandardEventPayload_set_name_m549984672 ();
extern "C" void TrackableField__ctor_m3758796351 ();
extern "C" void FieldWithTarget__ctor_m583221563 ();
extern "C" void FieldWithTarget_set_doStatic_m3781634168 ();
extern "C" void FieldWithTarget_set_fieldPath_m2073198625 ();
extern "C" void FieldWithTarget_set_paramName_m2405671065 ();
extern "C" void FieldWithTarget_set_staticString_m3203090702 ();
extern "C" void FieldWithTarget_set_target_m875118251 ();
extern "C" void FieldWithTarget_set_typeString_m937652251 ();
extern "C" void TrackableProperty__ctor_m29288901 ();
extern "C" void TrackableProperty_set_fields_m1461281003 ();
extern "C" void TrackablePropertyBase__ctor_m2201057683 ();
extern "C" void TrackableTrigger__ctor_m4147744174 ();
extern "C" void TriggerListContainer__ctor_m1390596431 ();
extern "C" void TriggerListContainer_set_rules_m474815225 ();
extern "C" void TriggerMethod__ctor_m1863255651 ();
extern "C" void TriggerRule__ctor_m225466603 ();
extern "C" void UnityAnalyticsHandler__ctor_m2433349566 ();
extern "C" void UnityAnalyticsHandler_Destroy_m945739537 ();
extern "C" void UnityAnalyticsHandler_Dispose_m300860768 ();
extern "C" void UnityAnalyticsHandler_Finalize_m1527596444 ();
extern "C" void UnityAnalyticsHandler_Internal_Destroy_m2102025341 ();
extern "C" void ValueProperty__ctor_m2723448180 ();
extern "C" void ValueProperty_set_valueType_m3307530546 ();
extern "C" void AnimationCurve__ctor_m3000526466 ();
extern "C" void AnimationCurve__ctor_m1565662948 ();
extern "C" void AnimationCurve_Finalize_m2397002729 ();
extern "C" void AnimationCurve_Internal_Destroy_m3899747917 ();
extern "C" void LogCallback__ctor_m144650965 ();
extern "C" void LogCallback_EndInvoke_m2243211259 ();
extern "C" void LogCallback_Invoke_m1707963620 ();
extern "C" void LowMemoryCallback__ctor_m3675715235 ();
extern "C" void LowMemoryCallback_EndInvoke_m2581361171 ();
extern "C" void LowMemoryCallback_Invoke_m1926578529 ();
extern "C" void Application_CallLogCallback_m255562505 ();
extern "C" void Application_CallLowMemory_m2813539296 ();
extern "C" void Application_Internal_ApplicationQuit_m2936209313 ();
extern "C" void Application_InvokeOnBeforeRender_m2875673833 ();
extern "C" void AssetFileNameExtensionAttribute__ctor_m592302761 ();
extern "C" void AsyncOperation_Finalize_m1841265672 ();
extern "C" void AsyncOperation_InternalDestroy_m3592294443 ();
extern "C" void AsyncOperation_InvokeCompletionEvent_m1410305036 ();
extern "C" void AttributeHelperEngine__cctor_m1900959362 ();
extern "C" void PCMReaderCallback__ctor_m4269754975 ();
extern "C" void PCMReaderCallback_EndInvoke_m3916876196 ();
extern "C" void PCMReaderCallback_Invoke_m2948796957 ();
extern "C" void PCMSetPositionCallback__ctor_m2909837933 ();
extern "C" void PCMSetPositionCallback_EndInvoke_m1405765992 ();
extern "C" void PCMSetPositionCallback_Invoke_m2167694991 ();
extern "C" void AudioClip__ctor_m1211547677 ();
extern "C" void AudioClip_InvokePCMReaderCallback_Internal_m224395634 ();
extern "C" void AudioClip_InvokePCMSetPositionCallback_Internal_m3097960898 ();
extern "C" void AudioExtensionManager__cctor_m1361600190 ();
extern "C" void AudioExtensionManager_AddExtensionToManager_m3475649283 ();
extern "C" void AudioExtensionManager_GetReadyToPlay_m1557263244 ();
extern "C" void AudioExtensionManager_RegisterBuiltinDefinitions_m2742744104 ();
extern "C" void AudioExtensionManager_RemoveExtensionFromManager_m442924172 ();
extern "C" void AudioExtensionManager_Update_m3269307447 ();
extern "C" void AudioExtensionManager_WriteExtensionProperties_m3028464154 ();
extern "C" void AudioExtensionManager_WriteExtensionProperties_m1988587615 ();
extern "C" void AudioListener_ClearExtensionProperties_m3849891634 ();
extern "C" void AudioListener_INTERNAL_CALL_ClearExtensionProperties_m2036387607 ();
extern "C" void AudioListener_INTERNAL_CALL_ReadExtensionName_m4145804327 ();
extern "C" void AudioListener_INTERNAL_CALL_ReadExtensionPropertyName_m330480156 ();
extern "C" void AudioListenerExtension__ctor_m2046026665 ();
extern "C" void AudioListenerExtension_ExtensionUpdate_m1303405084 ();
extern "C" void AudioListenerExtension_WriteExtensionProperty_m4064727398 ();
extern "C" void AudioListenerExtension_set_audioListener_m3412289012 ();
extern "C" void AudioConfigurationChangeHandler__ctor_m1059338375 ();
extern "C" void AudioConfigurationChangeHandler_EndInvoke_m4175380841 ();
extern "C" void AudioConfigurationChangeHandler_Invoke_m1233557945 ();
extern "C" void AudioSettings_InvokeOnAudioConfigurationChanged_m3131294153 ();
extern "C" void AudioSettings_InvokeOnAudioManagerUpdate_m4044425648 ();
extern "C" void AudioSettings_InvokeOnAudioSourcePlay_m3298744573 ();
extern "C" void AudioSource_ClearExtensionProperties_m2116074582 ();
extern "C" void AudioSource_INTERNAL_CALL_ClearExtensionProperties_m2159298662 ();
extern "C" void AudioSource_INTERNAL_CALL_ReadExtensionName_m36001502 ();
extern "C" void AudioSource_INTERNAL_CALL_ReadExtensionPropertyName_m3643462071 ();
extern "C" void AudioSourceExtension__ctor_m3132593001 ();
extern "C" void AudioSourceExtension_ExtensionUpdate_m2790353999 ();
extern "C" void AudioSourceExtension_OnDestroy_m345467428 ();
extern "C" void AudioSourceExtension_Play_m420799475 ();
extern "C" void AudioSourceExtension_Stop_m387892536 ();
extern "C" void AudioSourceExtension_WriteExtensionProperty_m2866033202 ();
extern "C" void AudioSourceExtension_set_audioSource_m3729768988 ();
extern "C" void BeforeRenderHelper__cctor_m1834968278 ();
extern "C" void BeforeRenderHelper_Invoke_m50072094 ();
extern "C" void Behaviour__ctor_m346897018 ();
extern "C" void FreeFunctionAttribute__ctor_m225850777 ();
extern "C" void FreeFunctionAttribute__ctor_m3967403258 ();
extern "C" void FreeFunctionAttribute__ctor_m1198537781 ();
extern "C" void NativeConditionalAttribute__ctor_m1745668596 ();
extern "C" void NativeConditionalAttribute_set_Condition_m607771195 ();
extern "C" void NativeConditionalAttribute_set_Enabled_m2378894961 ();
extern "C" void NativeHeaderAttribute__ctor_m457462113 ();
extern "C" void NativeHeaderAttribute_set_Header_m3310668383 ();
extern "C" void NativeMethodAttribute__ctor_m3134540192 ();
extern "C" void NativeMethodAttribute__ctor_m2941746701 ();
extern "C" void NativeMethodAttribute__ctor_m3056337369 ();
extern "C" void NativeMethodAttribute__ctor_m2749818278 ();
extern "C" void NativeMethodAttribute_set_HasExplicitThis_m2961870915 ();
extern "C" void NativeMethodAttribute_set_IsFreeFunction_m1931350581 ();
extern "C" void NativeMethodAttribute_set_IsThreadSafe_m2457033065 ();
extern "C" void NativeMethodAttribute_set_Name_m1946475768 ();
extern "C" void NativeMethodAttribute_set_ThrowsException_m3369126807 ();
extern "C" void NativeNameAttribute__ctor_m3296876808 ();
extern "C" void NativeNameAttribute_set_Name_m3579254766 ();
extern "C" void NativePropertyAttribute__ctor_m1920537355 ();
extern "C" void NativePropertyAttribute__ctor_m2033094153 ();
extern "C" void NativeThrowsAttribute__ctor_m3216633458 ();
extern "C" void NativeThrowsAttribute_set_ThrowsException_m4039166389 ();
extern "C" void NativeTypeAttribute__ctor_m2993484825 ();
extern "C" void NativeTypeAttribute__ctor_m133676646 ();
extern "C" void NativeTypeAttribute__ctor_m1043629716 ();
extern "C" void NativeTypeAttribute__ctor_m1677513894 ();
extern "C" void NativeTypeAttribute_set_CodegenOptions_m3839252515 ();
extern "C" void NativeTypeAttribute_set_Header_m48420006 ();
extern "C" void NativeTypeAttribute_set_IntermediateScriptingStructName_m3613994509 ();
extern "C" void NotNullAttribute__ctor_m3740658540 ();
extern "C" void StaticAccessorAttribute__ctor_m2905272167 ();
extern "C" void StaticAccessorAttribute_set_Name_m2926172476 ();
extern "C" void StaticAccessorAttribute_set_Type_m2333258271 ();
extern "C" void ThreadSafeAttribute__ctor_m601575521 ();
extern "C" void UnmarshalledAttribute__ctor_m534761184 ();
extern "C" void VisibleToOtherModulesAttribute__ctor_m3491053854 ();
extern "C" void BootConfigData__ctor_m4255151374 ();
extern "C" void CameraCallback__ctor_m899467377 ();
extern "C" void CameraCallback_EndInvoke_m3846578433 ();
extern "C" void CameraCallback_Invoke_m3308824940 ();
extern "C" void Camera_FireOnPostRender_m1456255957 ();
extern "C" void Camera_FireOnPreCull_m2869588437 ();
extern "C" void Camera_FireOnPreRender_m3450823610 ();
extern "C" void Camera_ScreenPointToRay_Injected_m1162756571 ();
extern "C" void Camera_get_pixelRect_Injected_m2326986893 ();
extern "C" void ClassLibraryInitializer_Init_m988673678 ();
extern "C" void Component__ctor_m1928064382 ();
extern "C" void Component_GetComponentFastPath_m1180649031 ();
extern "C" void Coroutine__ctor_m1058504400 ();
extern "C" void Coroutine_Finalize_m1957108547 ();
extern "C" void Coroutine_ReleaseCoroutine_m947702340 ();
extern "C" void Cubemap__ctor_m1096546642 ();
extern "C" void Cubemap__ctor_m1814722504 ();
extern "C" void Cubemap__ctor_m1549386221 ();
extern "C" void Cubemap_Internal_Create_m3302016289 ();
extern "C" void StateChanged__ctor_m2759994044 ();
extern "C" void StateChanged_EndInvoke_m3313423087 ();
extern "C" void StateChanged_Invoke_m1925531365 ();
extern "C" void CullingGroup_Dispose_m782801025 ();
extern "C" void CullingGroup_DisposeInternal_m1966833260 ();
extern "C" void CullingGroup_Finalize_m2121330955 ();
extern "C" void CullingGroup_FinalizerFailure_m1165085675 ();
extern "C" void CullingGroup_SendEvents_m2491312335 ();
extern "C" void Debug__cctor_m1523394265 ();
extern "C" void Debug_Log_m4051431634 ();
extern "C" void Debug_LogError_m2850623458 ();
extern "C" void Debug_LogError_m1665621915 ();
extern "C" void Debug_LogErrorFormat_m575266265 ();
extern "C" void Debug_LogException_m2207318968 ();
extern "C" void Debug_LogFormat_m309087137 ();
extern "C" void Debug_LogWarningFormat_m2535776735 ();
extern "C" void DebugLogHandler__ctor_m3380237231 ();
extern "C" void DebugLogHandler_Internal_Log_m4175774469 ();
extern "C" void DebugLogHandler_Internal_LogException_m4213045108 ();
extern "C" void DebugLogHandler_LogException_m302830419 ();
extern "C" void DebugLogHandler_LogFormat_m487864506 ();
extern "C" void DisplaysUpdatedDelegate__ctor_m2116638722 ();
extern "C" void DisplaysUpdatedDelegate_EndInvoke_m3857124817 ();
extern "C" void DisplaysUpdatedDelegate_Invoke_m3203573844 ();
extern "C" void Display__cctor_m1972153728 ();
extern "C" void Display__ctor_m501911701 ();
extern "C" void Display__ctor_m3105658851 ();
extern "C" void Display_FireDisplaysUpdated_m41210855 ();
extern "C" void Display_GetSystemExtImpl_m2808197389 ();
extern "C" void Display_RecreateDisplayList_m4040831261 ();
extern "C" void ArgumentCache__ctor_m2732653802 ();
extern "C" void ArgumentCache_OnAfterDeserialize_m1256813518 ();
extern "C" void ArgumentCache_OnBeforeSerialize_m659261798 ();
extern "C" void ArgumentCache_TidyAssemblyTypeName_m3234393930 ();
extern "C" void BaseInvokableCall__ctor_m768115019 ();
extern "C" void BaseInvokableCall__ctor_m2110966014 ();
extern "C" void InvokableCall__ctor_m1303836326 ();
extern "C" void InvokableCall_Invoke_m1437964737 ();
extern "C" void InvokableCall_Invoke_m999392415 ();
extern "C" void InvokableCall_add_Delegate_m491308793 ();
extern "C" void InvokableCall_remove_Delegate_m1376110510 ();
extern "C" void InvokableCallList__ctor_m829480958 ();
extern "C" void InvokableCallList_AddListener_m230402324 ();
extern "C" void InvokableCallList_AddPersistentInvokableCall_m778853773 ();
extern "C" void InvokableCallList_ClearPersistent_m1904264973 ();
extern "C" void InvokableCallList_RemoveListener_m1769379719 ();
extern "C" void PersistentCall__ctor_m1217622171 ();
extern "C" void PersistentCallGroup__ctor_m1525263635 ();
extern "C" void PersistentCallGroup_Initialize_m4253175514 ();
extern "C" void UnityAction__ctor_m772160306 ();
extern "C" void UnityAction_EndInvoke_m2754068291 ();
extern "C" void UnityAction_Invoke_m893829196 ();
extern "C" void UnityEvent__ctor_m431206565 ();
extern "C" void UnityEventBase__ctor_m1851535676 ();
extern "C" void UnityEventBase_AddCall_m3539965410 ();
extern "C" void UnityEventBase_DirtyPersistentCalls_m3575963459 ();
extern "C" void UnityEventBase_RebuildPersistentCallsIfNeeded_m216788690 ();
extern "C" void UnityEventBase_RemoveListener_m3326364145 ();
extern "C" void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m3212312200 ();
extern "C" void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m3869333132 ();
extern "C" void ExcludeFromObjectFactoryAttribute__ctor_m3758218116 ();
extern "C" void ExcludeFromPresetAttribute__ctor_m3043931884 ();
extern "C" void ConsumeSampleFramesNativeFunction__ctor_m144532415 ();
extern "C" void SampleFramesHandler__ctor_m3908528909 ();
extern "C" void SampleFramesHandler_EndInvoke_m3715791887 ();
extern "C" void SampleFramesHandler_Invoke_m544261268 ();
extern "C" void AudioSampleProvider_Dispose_m1993565764 ();
extern "C" void AudioSampleProvider_Finalize_m18935654 ();
extern "C" void AudioSampleProvider_InternalSetScriptingPtr_m3742743270 ();
extern "C" void AudioSampleProvider_InvokeSampleFramesAvailable_m3478252833 ();
extern "C" void AudioSampleProvider_InvokeSampleFramesOverflow_m2840062631 ();
extern "C" void AudioSampleProvider_set_id_m4177090282 ();
extern "C" void UpdateFunction__ctor_m1238640540 ();
extern "C" void UpdateFunction_EndInvoke_m3485575773 ();
extern "C" void UpdateFunction_Invoke_m3360475851 ();
extern "C" void RenderPipelineManager_CleanupRenderPipeline_m3545163046 ();
extern "C" void RenderPipelineManager_DoRenderLoop_Internal_m3799666479 ();
extern "C" void RenderPipelineManager_PrepareRenderPipeline_m4184225229 ();
extern "C" void RenderPipelineManager_set_currentPipeline_m3492857006 ();
extern "C" void ScriptableRenderContext__ctor_m172989033_AdjustorThunk ();
extern "C" void SupportedRenderingFeatures__cctor_m146778484 ();
extern "C" void SupportedRenderingFeatures__ctor_m2713823667 ();
extern "C" void SupportedRenderingFeatures_FallbackMixedLightingModeByRef_m3859171964 ();
extern "C" void SupportedRenderingFeatures_IsLightmapBakeTypeSupportedByRef_m2970279241 ();
extern "C" void SupportedRenderingFeatures_IsLightmapsModeSupportedByRef_m3859475728 ();
extern "C" void SupportedRenderingFeatures_IsMixedLightingModeSupportedByRef_m2282093837 ();
extern "C" void SupportedRenderingFeatures_set_active_m3446087961 ();
extern "C" void GUIElement__ctor_m3257342989 ();
extern "C" void GameObject__ctor_m3707688467 ();
extern "C" void GameObject_Internal_CreateGameObject_m2533291801 ();
extern "C" void GameObject_SendMessage_m3720186693 ();
extern "C" void Gradient__ctor_m173848750 ();
extern "C" void Gradient_Cleanup_m3422458828 ();
extern "C" void Gradient_Finalize_m3995355035 ();
extern "C" void Input__cctor_m325696046 ();
extern "C" void Input_INTERNAL_get_mousePosition_m1805263023 ();
extern "C" void DefaultValueAttribute__ctor_m1514328230 ();
extern "C" void ExcludeFromDocsAttribute__ctor_m1509941807 ();
extern "C" void Logger__ctor_m439059923 ();
extern "C" void Logger_Log_m969976427 ();
extern "C" void Logger_Log_m2585387088 ();
extern "C" void Logger_LogException_m4285204825 ();
extern "C" void Logger_LogFormat_m3030796110 ();
extern "C" void Logger_LogFormat_m3300686007 ();
extern "C" void Logger_set_filterLogType_m3622751173 ();
extern "C" void Logger_set_logEnabled_m1180597166 ();
extern "C" void Logger_set_logHandler_m4059005946 ();
extern "C" void LowerResBlitTexture_LowerResBlitTextureDontStripMe_m2024164512 ();
extern "C" void ManagedStreamHelpers_ManagedStreamLength_m2930872960 ();
extern "C" void ManagedStreamHelpers_ManagedStreamRead_m481666286 ();
extern "C" void ManagedStreamHelpers_ManagedStreamSeek_m3158782053 ();
extern "C" void ManagedStreamHelpers_ValidateLoadFromStream_m580138133 ();
extern "C" void Material__ctor_m2433149719 ();
extern "C" void Material__ctor_m249231841 ();
extern "C" void Material__ctor_m1662457592 ();
extern "C" void Material_CreateWithMaterial_m2373088899 ();
extern "C" void Material_CreateWithShader_m1270998153 ();
extern "C" void Material_CreateWithString_m4283839020 ();
extern "C" void Mathf__cctor_m1175545152 ();
extern "C" void Mesh__ctor_m2533762929 ();
extern "C" void Mesh_Internal_Create_m2853543051 ();
extern "C" void MeshFilter_DontStripMeshFilter_m2877155929 ();
extern "C" void MeshRenderer_DontStripMeshRenderer_m3387425681 ();
extern "C" void MonoBehaviour__ctor_m1579109191 ();
extern "C" void MonoBehaviour_CancelInvoke_m4090783926 ();
extern "C" void MonoBehaviour_CancelInvoke_m2180046661 ();
extern "C" void MonoBehaviour_CancelInvoke_m3252264575 ();
extern "C" void MonoBehaviour_Internal_CancelInvokeAll_m3703850945 ();
extern "C" void MonoBehaviour_Invoke_m4227543964 ();
extern "C" void MonoBehaviour_InvokeDelayed_m3352484957 ();
extern "C" void MonoBehaviour_InvokeRepeating_m650519629 ();
extern "C" void MonoBehaviour_StopAllCoroutines_m3328507247 ();
extern "C" void MonoBehaviour_StopCoroutine_m615723318 ();
extern "C" void MonoBehaviour_StopCoroutine_m1962070247 ();
extern "C" void MonoBehaviour_StopCoroutine_m907039165 ();
extern "C" void MonoBehaviour_StopCoroutineFromEnumeratorManaged_m3390002661 ();
extern "C" void MonoBehaviour_StopCoroutineManaged_m3194025768 ();
extern "C" void MonoBehaviour_print_m330341231 ();
extern "C" void MonoBehaviour_set_useGUILayout_m3492031340 ();
extern "C" void NativeClassAttribute__ctor_m3911617424 ();
extern "C" void NativeClassAttribute__ctor_m4136257185 ();
extern "C" void NativeClassAttribute_set_Declaration_m1218368926 ();
extern "C" void NativeClassAttribute_set_QualifiedNativeName_m801351239 ();
extern "C" void CertificateHandler_Dispose_m2100863831 ();
extern "C" void CertificateHandler_Finalize_m2289088740 ();
extern "C" void CertificateHandler_Release_m648790222 ();
extern "C" void MessageEventArgs__ctor_m14798785 ();
extern "C" void U3CBlockUntilRecvMsgU3Ec__AnonStorey2__ctor_m1575056730 ();
extern "C" void U3CBlockUntilRecvMsgU3Ec__AnonStorey2_U3CU3Em__0_m2225790220 ();
extern "C" void U3CRegisterU3Ec__AnonStorey0__ctor_m1879208136 ();
extern "C" void U3CUnregisterU3Ec__AnonStorey1__ctor_m1684143015 ();
extern "C" void PlayerConnection__ctor_m2639507345 ();
extern "C" void PlayerConnection_ConnectedCallbackInternal_m1706913195 ();
extern "C" void PlayerConnection_DisconnectAll_m2907137535 ();
extern "C" void PlayerConnection_DisconnectedCallback_m1697017309 ();
extern "C" void PlayerConnection_MessageCallbackInternal_m1914517467 ();
extern "C" void PlayerConnection_OnEnable_m4286555589 ();
extern "C" void PlayerConnection_Register_m2197766869 ();
extern "C" void PlayerConnection_RegisterConnection_m141514498 ();
extern "C" void PlayerConnection_RegisterDisconnection_m2618599213 ();
extern "C" void PlayerConnection_Send_m3929969666 ();
extern "C" void PlayerConnection_Unregister_m262505929 ();
extern "C" void U3CAddAndCreateU3Ec__AnonStorey1__ctor_m1186055370 ();
extern "C" void U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0__ctor_m2486500792 ();
extern "C" void U3CUnregisterManagedCallbackU3Ec__AnonStorey2__ctor_m299200807 ();
extern "C" void ConnectionChangeEvent__ctor_m764126802 ();
extern "C" void MessageEvent__ctor_m1231650089 ();
extern "C" void MessageTypeSubscribers__ctor_m1543468991 ();
extern "C" void MessageTypeSubscribers_set_MessageTypeId_m841325789 ();
extern "C" void PlayerEditorConnectionEvents__ctor_m3177489832 ();
extern "C" void PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_m2094591713 ();
extern "C" void PlayerEditorConnectionEvents_UnregisterManagedCallback_m400366024 ();
extern "C" void Object__cctor_m2398773973 ();
extern "C" void Object__ctor_m1087895580 ();
extern "C" void Object_set_hideFlags_m1648752846 ();
extern "C" void Playable__cctor_m464525928 ();
extern "C" void Playable__ctor_m3175303195_AdjustorThunk ();
extern "C" void PlayableAsset__ctor_m2395156306 ();
extern "C" void PlayableAsset_Internal_CreatePlayable_m2550417712 ();
extern "C" void PlayableAsset_Internal_GetPlayableAssetDuration_m2090502339 ();
extern "C" void PlayableBehaviour__ctor_m3891915003 ();
extern "C" void CreateOutputMethod__ctor_m3884516706 ();
extern "C" void PlayableBinding__cctor_m2159960528 ();
extern "C" void PlayableOutput__cctor_m2348686299 ();
extern "C" void PlayableOutput__ctor_m3330119218_AdjustorThunk ();
extern "C" void PlayerConnectionInternal__ctor_m2406218802 ();
extern "C" void PlayerConnectionInternal_DisconnectAll_m4073996061 ();
extern "C" void PlayerConnectionInternal_Initialize_m103452032 ();
extern "C" void PlayerConnectionInternal_PollInternal_m3759016321 ();
extern "C" void PlayerConnectionInternal_RegisterInternal_m3800897166 ();
extern "C" void PlayerConnectionInternal_SendMessage_m2378413408 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_DisconnectAll_m2071255904 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Initialize_m2565175798 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Poll_m4148886575 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_RegisterInternal_m1817895617 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_SendMessage_m389985885 ();
extern "C" void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_UnregisterInternal_m2713195108 ();
extern "C" void PlayerConnectionInternal_UnregisterInternal_m477908195 ();
extern "C" void PreloadData_PreloadDataDontStripMe_m1119277139 ();
extern "C" void PropertyName__ctor_m912660408_AdjustorThunk ();
extern "C" void PropertyName__ctor_m1858502781_AdjustorThunk ();
extern "C" void PropertyName__ctor_m3511806171_AdjustorThunk ();
extern "C" void PropertyNameUtils_PropertyNameFromString_Injected_m1259736140 ();
extern "C" void Quaternion__cctor_m2965965177 ();
extern "C" void Quaternion__ctor_m435141806_AdjustorThunk ();
extern "C" void ReapplyDrivenProperties__ctor_m836366652 ();
extern "C" void ReapplyDrivenProperties_EndInvoke_m700307436 ();
extern "C" void ReapplyDrivenProperties_Invoke_m1151937880 ();
extern "C" void RectTransform_SendReapplyDrivenProperties_m187867097 ();
extern "C" void ReflectionProbe_CallReflectionProbeEvent_m1520775591 ();
extern "C" void ReflectionProbe_CallSetDefaultReflection_m2835659734 ();
extern "C" void RemoteConfigSettings_Destroy_m1854335118 ();
extern "C" void RemoteConfigSettings_Dispose_m2083915538 ();
extern "C" void RemoteConfigSettings_Finalize_m2805990196 ();
extern "C" void RemoteConfigSettings_Internal_Destroy_m1072151938 ();
extern "C" void RemoteConfigSettings_RemoteConfigSettingsUpdated_m2409101234 ();
extern "C" void UpdatedEventHandler__ctor_m3406570235 ();
extern "C" void UpdatedEventHandler_EndInvoke_m3714202114 ();
extern "C" void UpdatedEventHandler_Invoke_m3026613363 ();
extern "C" void RemoteSettings_RemoteSettingsBeforeFetchFromServer_m4228537265 ();
extern "C" void RemoteSettings_RemoteSettingsUpdateCompleted_m2956290507 ();
extern "C" void RemoteSettings_RemoteSettingsUpdated_m1182006011 ();
extern "C" void RenderTexture__ctor_m3368882316 ();
extern "C" void RenderTexture__ctor_m769234016 ();
extern "C" void RenderTexture__ctor_m1155694963 ();
extern "C" void RenderTexture__ctor_m2187158709 ();
extern "C" void RenderTexture__ctor_m1464033784 ();
extern "C" void RenderTexture__ctor_m2281969544 ();
extern "C" void RenderTexture__ctor_m339910950 ();
extern "C" void RenderTexture_INTERNAL_CALL_GetDescriptor_m317084978 ();
extern "C" void RenderTexture_INTERNAL_CALL_SetRenderTextureDescriptor_m1959074794 ();
extern "C" void RenderTexture_Internal_Create_m347030155 ();
extern "C" void RenderTexture_SetRenderTextureDescriptor_m735607607 ();
extern "C" void RenderTexture_SetSRGBReadWrite_m2270512694 ();
extern "C" void RenderTexture_ValidateRenderTextureDesc_m1651269986 ();
extern "C" void RenderTexture_set_depth_m936447630 ();
extern "C" void RenderTexture_set_format_m2479999990 ();
extern "C" void RenderTexture_set_height_m1102706773 ();
extern "C" void RenderTexture_set_width_m410512079 ();
extern "C" void RenderTextureDescriptor__cctor_m3115061957 ();
extern "C" void RequireComponent__ctor_m886241599 ();
extern "C" void SceneManager_Internal_ActiveSceneChanged_m3676176255 ();
extern "C" void SceneManager_Internal_SceneLoaded_m2694652025 ();
extern "C" void SceneManager_Internal_SceneUnloaded_m3247148570 ();
extern "C" void ScriptableObject__ctor_m1310743131 ();
extern "C" void ScriptableObject_CreateScriptableObject_m3504774547 ();
extern "C" void GeneratedByOldBindingsGeneratorAttribute__ctor_m3683043001 ();
extern "C" void RequiredByNativeCodeAttribute__ctor_m119855101 ();
extern "C" void RequiredByNativeCodeAttribute_set_GenerateProxy_m2819488747 ();
extern "C" void RequiredByNativeCodeAttribute_set_Optional_m1276771824 ();
extern "C" void UsedByNativeCodeAttribute__ctor_m2647015777 ();
extern "C" void HitInfo_SendMessage_m1343099429_AdjustorThunk ();
extern "C" void SendMouseEvents__cctor_m2378365934 ();
extern "C" void SendMouseEvents_DoSendMouseEvents_m2140870850 ();
extern "C" void SendMouseEvents_HitTestLegacyGUI_m579942228 ();
extern "C" void SendMouseEvents_SendEvents_m1956471769 ();
extern "C" void SendMouseEvents_SetMouseMoved_m2822596724 ();
extern "C" void FormerlySerializedAsAttribute__ctor_m520861771 ();
extern "C" void SerializeField__ctor_m808862924 ();
extern "C" void SetupCoroutine_InvokeMoveNext_m3199342729 ();
extern "C" void U3CUnityEngine_SocialPlatforms_ISocialPlatform_AuthenticateU3Ec__AnonStorey0__ctor_m917935746 ();
extern "C" void U3CUnityEngine_SocialPlatforms_ISocialPlatform_AuthenticateU3Ec__AnonStorey0_U3CU3Em__0_m2063879487 ();
extern "C" void GameCenterPlatform__cctor_m2996229915 ();
extern "C" void GameCenterPlatform__ctor_m3480810288 ();
extern "C" void GameCenterPlatform_AchievementCallbackWrapper_m2338913583 ();
extern "C" void GameCenterPlatform_Authenticate_m2003613329 ();
extern "C" void GameCenterPlatform_AuthenticateCallbackWrapper_m4011908437 ();
extern "C" void GameCenterPlatform_ClearAchievementDescriptions_m3199616787 ();
extern "C" void GameCenterPlatform_ClearFriends_m2665387026 ();
extern "C" void GameCenterPlatform_ClearUsers_m1079725881 ();
extern "C" void GameCenterPlatform_InternalLoadAchievementDescriptions_m2154800288 ();
extern "C" void GameCenterPlatform_InternalLoadAchievements_m858095906 ();
extern "C" void GameCenterPlatform_InternalLoadScores_m542421317 ();
extern "C" void GameCenterPlatform_InternalReportProgress_m52275066 ();
extern "C" void GameCenterPlatform_InternalReportScore_m2330670912 ();
extern "C" void GameCenterPlatform_Internal_LoadUsers_m1208837786 ();
extern "C" void GameCenterPlatform_Internal_ShowAchievementsUI_m3176553150 ();
extern "C" void GameCenterPlatform_Internal_ShowLeaderboardUI_m3245064684 ();
extern "C" void GameCenterPlatform_LeaderboardCallbackWrapper_m3412260669 ();
extern "C" void GameCenterPlatform_LoadAchievementDescriptions_m1319531997 ();
extern "C" void GameCenterPlatform_LoadAchievements_m1317357678 ();
extern "C" void GameCenterPlatform_LoadFriends_m1431418758 ();
extern "C" void GameCenterPlatform_LoadScores_m3157018272 ();
extern "C" void GameCenterPlatform_LoadScores_m256327074 ();
extern "C" void GameCenterPlatform_LoadUsers_m1469846403 ();
extern "C" void GameCenterPlatform_PopulateLocalUser_m1862420460 ();
extern "C" void GameCenterPlatform_ProgressCallbackWrapper_m3465714225 ();
extern "C" void GameCenterPlatform_ReportProgress_m1060252293 ();
extern "C" void GameCenterPlatform_ReportScore_m3808549820 ();
extern "C" void GameCenterPlatform_ResetAllAchievements_m1516414240 ();
extern "C" void GameCenterPlatform_ResetAllAchievements_m157050371 ();
extern "C" void GameCenterPlatform_SafeClearArray_m2305618285 ();
extern "C" void GameCenterPlatform_SafeSetUserImage_m1839197851 ();
extern "C" void GameCenterPlatform_ScoreCallbackWrapper_m3923626712 ();
extern "C" void GameCenterPlatform_ScoreLoaderCallbackWrapper_m1077077857 ();
extern "C" void GameCenterPlatform_SetAchievementDescription_m2719524812 ();
extern "C" void GameCenterPlatform_SetAchievementDescriptionImage_m2009264244 ();
extern "C" void GameCenterPlatform_SetFriendImage_m1493682250 ();
extern "C" void GameCenterPlatform_SetFriends_m2547098207 ();
extern "C" void GameCenterPlatform_SetUser_m898357462 ();
extern "C" void GameCenterPlatform_SetUserImage_m4005778020 ();
extern "C" void GameCenterPlatform_ShowAchievementsUI_m3491114525 ();
extern "C" void GameCenterPlatform_ShowDefaultAchievementBanner_m619858364 ();
extern "C" void GameCenterPlatform_ShowDefaultAchievementCompletionBanner_m2497844455 ();
extern "C" void GameCenterPlatform_ShowLeaderboardUI_m7770043 ();
extern "C" void GameCenterPlatform_ShowLeaderboardUI_m2045709011 ();
extern "C" void GameCenterPlatform_ShowSpecificLeaderboardUI_m533216100 ();
extern "C" void GameCenterPlatform_TriggerAchievementDescriptionCallback_m1287503847 ();
extern "C" void GameCenterPlatform_TriggerFriendsCallbackWrapper_m361081277 ();
extern "C" void GameCenterPlatform_TriggerResetAchievementCallback_m3410354914 ();
extern "C" void GameCenterPlatform_TriggerUsersCallbackWrapper_m3887512651 ();
extern "C" void GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_Authenticate_m218097008 ();
extern "C" void GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_Authenticate_m2367877202 ();
extern "C" void GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_LoadFriends_m3748446850 ();
extern "C" void GcLeaderboard__ctor_m3682449037 ();
extern "C" void GcLeaderboard_Dispose_m2785609281 ();
extern "C" void GcLeaderboard_Finalize_m2458217293 ();
extern "C" void GcLeaderboard_GcLeaderboard_Dispose_m540559132 ();
extern "C" void GcLeaderboard_Internal_LoadScores_m1159036535 ();
extern "C" void GcLeaderboard_SetLocalScore_m58125728 ();
extern "C" void GcLeaderboard_SetMaxRange_m2107263614 ();
extern "C" void GcLeaderboard_SetScores_m1580490387 ();
extern "C" void GcLeaderboard_SetTitle_m3468474500 ();
extern "C" void GcUserProfileData_AddToArray_m4269441263_AdjustorThunk ();
extern "C" void Achievement__ctor_m3081548999 ();
extern "C" void Achievement__ctor_m2441923414 ();
extern "C" void Achievement__ctor_m2166901798 ();
extern "C" void Achievement_set_id_m2790336588 ();
extern "C" void Achievement_set_percentCompleted_m1653565997 ();
extern "C" void AchievementDescription__ctor_m2104645942 ();
extern "C" void AchievementDescription_SetImage_m2442437087 ();
extern "C" void AchievementDescription_set_id_m751528388 ();
extern "C" void Leaderboard__ctor_m1030108446 ();
extern "C" void Leaderboard_SetLocalUserScore_m3569886016 ();
extern "C" void Leaderboard_SetMaxRange_m629679481 ();
extern "C" void Leaderboard_SetScores_m2163784072 ();
extern "C" void Leaderboard_SetTitle_m459905577 ();
extern "C" void Leaderboard_set_id_m3990768853 ();
extern "C" void Leaderboard_set_range_m1868499957 ();
extern "C" void Leaderboard_set_timeScope_m3468042286 ();
extern "C" void Leaderboard_set_userScope_m4131851828 ();
extern "C" void LocalUser__ctor_m4260307073 ();
extern "C" void LocalUser_SetAuthenticated_m3352566618 ();
extern "C" void LocalUser_SetFriends_m298063769 ();
extern "C" void LocalUser_SetUnderage_m1848352351 ();
extern "C" void Score__ctor_m2390363112 ();
extern "C" void Score__ctor_m1554947855 ();
extern "C" void Score_set_leaderboardID_m268558918 ();
extern "C" void Score_set_value_m935893699 ();
extern "C" void UserProfile__ctor_m3353918255 ();
extern "C" void UserProfile__ctor_m2409346676 ();
extern "C" void UserProfile_SetImage_m418239758 ();
extern "C" void UserProfile_SetUserID_m1137218839 ();
extern "C" void UserProfile_SetUserName_m1732526939 ();
extern "C" void Range__ctor_m3975982763_AdjustorThunk ();
extern "C" void Sprite__ctor_m332781120 ();
extern "C" void StackTraceUtility__cctor_m1981266436 ();
extern "C" void StackTraceUtility_ExtractStringFromExceptionInternal_m2686726792 ();
extern "C" void StackTraceUtility_SetProjectFolder_m830524047 ();
extern "C" void Texture2D__ctor_m373113269 ();
extern "C" void Texture2D__ctor_m3176621650 ();
extern "C" void Texture2D_Internal_Create_m3592711635 ();
extern "C" void Texture2DArray__ctor_m1759046501 ();
extern "C" void Texture2DArray__ctor_m4056612996 ();
extern "C" void Texture2DArray__ctor_m2627654179 ();
extern "C" void Texture2DArray_Internal_Create_m2217927355 ();
extern "C" void Texture3D__ctor_m1599887784 ();
extern "C" void Texture3D__ctor_m448815750 ();
extern "C" void Texture3D_Internal_Create_m4250388922 ();
extern "C" void Texture__ctor_m3554519797 ();
extern "C" void Texture_set_height_m589028641 ();
extern "C" void Texture_set_width_m1057761909 ();
extern "C" void ThreadAndSerializationSafeAttribute__ctor_m3739981144 ();
extern "C" void Enumerator__ctor_m1351041375 ();
extern "C" void Enumerator_Reset_m39541243 ();
extern "C" void Transform__ctor_m3470711880 ();
extern "C" void RequestAtlasCallback__ctor_m3023745648 ();
extern "C" void RequestAtlasCallback_EndInvoke_m2592639818 ();
extern "C" void RequestAtlasCallback_Invoke_m378128467 ();
extern "C" void SpriteAtlasManager__cctor_m3642741753 ();
extern "C" void SpriteAtlasManager_PostRegisteredAtlas_m3806600148 ();
extern "C" void SpriteAtlasManager_Register_m2413332465 ();
extern "C" void UnhandledExceptionHandler_HandleUnhandledException_m2430609357 ();
extern "C" void UnhandledExceptionHandler_NativeUnhandledExceptionHandler_m2534568686 ();
extern "C" void UnhandledExceptionHandler_PrintException_m385608237 ();
extern "C" void UnhandledExceptionHandler_RegisterUECatcher_m1350255469 ();
extern "C" void UnityEngineModuleAssembly__ctor_m242195730 ();
extern "C" void UnityException__ctor_m1456865679 ();
extern "C" void UnityException__ctor_m170038890 ();
extern "C" void UnityException__ctor_m872329880 ();
extern "C" void UnityLogWriter__ctor_m1834616883 ();
extern "C" void UnityLogWriter_Init_m3866572946 ();
extern "C" void UnityLogWriter_Write_m3542862483 ();
extern "C" void UnityLogWriter_Write_m3864776786 ();
extern "C" void UnityLogWriter_Write_m345199408 ();
extern "C" void UnityLogWriter_WriteStringToUnityLog_m2695353836 ();
extern "C" void UnityLogWriter_WriteStringToUnityLogImpl_m2026412198 ();
extern "C" void WorkRequest_Invoke_m3488164927_AdjustorThunk ();
extern "C" void UnitySynchronizationContext__ctor_m1707488257 ();
extern "C" void UnitySynchronizationContext_Exec_m3359802660 ();
extern "C" void UnitySynchronizationContext_ExecuteTasks_m1310741010 ();
extern "C" void UnitySynchronizationContext_InitializeSynchronizationContext_m3217591031 ();
extern "C" void Vector2__cctor_m2108982652 ();
extern "C" void Vector2__ctor_m3970636864_AdjustorThunk ();
extern "C" void Vector3__cctor_m2599650684 ();
extern "C" void Vector3__ctor_m3353183577_AdjustorThunk ();
extern "C" void WaitForSeconds__ctor_m2199082655 ();
extern "C" void WritableAttribute__ctor_m1991076220 ();
extern "C" void YieldInstruction__ctor_m1498450609 ();
extern "C" void LocalNotification__cctor_m2450334404 ();
extern "C" void LocalNotification_Finalize_m4237923715 ();
extern "C" void NotificationHelper_DestroyLocal_m2248823824 ();
extern "C" void NotificationHelper_DestroyRemote_m3390574007 ();
extern "C" void RemoteNotification_Finalize_m1702910735 ();
extern "C" void MathfInternal__cctor_m2622893686 ();
extern "C" void WebRequestUtils__cctor_m4190982137 ();
extern "C" void IntPtr_ToPointer_m4157623054_AdjustorThunk ();
extern "C" void IntPtr_op_Explicit_m2520637223 ();
extern "C" void AnalyticsEventParam_get_requirementType_m1268059884 ();
extern "C" void StandardEventPayload_get_parameters_m4209814697 ();
extern "C" void Analytics_CustomEvent_m692224174 ();
extern "C" void Analytics_CustomEvent_m3835919949 ();
extern "C" void AnalyticsEvent_Custom_m227997836 ();
extern "C" void AnalyticsEventTracker_SendEvent_m1365958832 ();
extern "C" void StandardEventPayload_Send_m3454575092 ();
extern "C" void UnityAnalyticsHandler_SendCustomEvent_m1223269116 ();
extern "C" void UnityAnalyticsHandler_SendCustomEventName_m839221434 ();
extern "C" void AnalyticsEventTracker_get_payload_m308762692 ();
extern "C" void ValueProperty_get_target_m1728151320 ();
extern "C" void AnalyticsTracker_get_TP_m2800669040 ();
extern "C" void EventTrigger_get_lifecycleEvent_m3324346053 ();
extern "C" void EventTrigger_get_triggerType_m4159785260 ();
extern "C" void Analytics_GetUnityAnalyticsHandler_m2772482435 ();
extern "C" void AnalyticsEventParam_get_valueProperty_m583328026 ();
extern "C" void AudioSource_get_clip_m1234340632 ();
extern "C" void AudioListenerExtension_get_audioListener_m3597041395 ();
extern "C" void AudioExtensionManager_AddSpatializerExtension_m3915849352 ();
extern "C" void AudioListener_AddExtension_m994751216 ();
extern "C" void AudioSourceExtension_get_audioSource_m1465006871 ();
extern "C" void AudioExtensionManager_AddAmbisonicDecoderExtension_m3197702864 ();
extern "C" void AudioExtensionManager_AddSpatializerExtension_m820561940 ();
extern "C" void AudioSource_AddAmbisonicExtension_m304476911 ();
extern "C" void AudioSource_AddSpatializerExtension_m2560794359 ();
extern "C" void BootConfigData_WrapBootConfigData_m329603588 ();
extern "C" void Camera_get_clearFlags_m992534691 ();
extern "C" void QualitySettings_get_activeColorSpace_m2902748248 ();
extern "C" void MonoBehaviour_StartCoroutine_m3411253000 ();
extern "C" void MonoBehaviour_StartCoroutine_m2618285814 ();
extern "C" void MonoBehaviour_StartCoroutine_m1654577315 ();
extern "C" void MonoBehaviour_StartCoroutineManaged_m1730988625 ();
extern "C" void MonoBehaviour_StartCoroutineManaged2_m3584675188 ();
extern "C" void MonoBehaviour_StartCoroutine_Auto_m594129169 ();
extern "C" void PersistentCall_get_arguments_m3144105308 ();
extern "C" void PersistentCall_GetObjectCall_m4041241444 ();
extern "C" void PersistentCall_GetRuntimeCall_m3976533158 ();
extern "C" void UnityEvent_GetDelegate_m3669208949 ();
extern "C" void PersistentCall_get_mode_m483997668 ();
extern "C" void PlayerEditorConnectionEvents_AddAndCreate_m3046878154 ();
extern "C" void GraphicsFormatUtility_GetGraphicsFormat_m3445248969 ();
extern "C" void GraphicsFormatUtility_GetGraphicsFormat_Native_TextureFormat_m433736368 ();
extern "C" void RenderPipelineManager_get_currentPipeline_m1638613344 ();
extern "C" void SupportedRenderingFeatures_get_active_m2140763039 ();
extern "C" void SupportedRenderingFeatures_get_defaultMixedLightingMode_m301083500 ();
extern "C" void SupportedRenderingFeatures_get_supportedMixedLightingModes_m2613534515 ();
extern "C" void GUILayer_HitTest_m2079012401 ();
extern "C" void GUILayer_HitTest_m512928460 ();
extern "C" void GUILayer_HitTest_Injected_m3662865982 ();
extern "C" void Camera_RaycastTry_m3913529496 ();
extern "C" void Camera_RaycastTry2D_m2460696262 ();
extern "C" void Camera_RaycastTry2D_Injected_m85653607 ();
extern "C" void Camera_RaycastTry_Injected_m3801956476 ();
extern "C" void Component_get_gameObject_m442555142 ();
extern "C" void Logger_get_logHandler_m1335645353 ();
extern "C" void Debug_get_unityLogger_m2239795986 ();
extern "C" void PlayerConnection_GetConnectionNativeApi_m3116196780 ();
extern "C" void SupportedRenderingFeatures_get_supportedLightmapBakeTypes_m1596512019 ();
extern "C" void SupportedRenderingFeatures_get_supportedLightmapsModes_m141329491 ();
extern "C" void Logger_get_filterLogType_m1177392786 ();
extern "C" void PlayerConnection_CreateInstance_m902052006 ();
extern "C" void PlayerConnection_get_instance_m1750121257 ();
extern "C" void FieldWithTarget_get_target_m2252597932 ();
extern "C" void AudioExtensionManager_GetAudioListener_m817760607 ();
extern "C" void ArgumentCache_get_unityObjectArgument_m3434100 ();
extern "C" void PersistentCall_get_target_m830923650 ();
extern "C" void Playable_get_Null_m3556999077 ();
extern "C" void AudioClipPlayable_GetHandle_m1762771314_AdjustorThunk ();
extern "C" void AudioMixerPlayable_GetHandle_m57919556_AdjustorThunk ();
extern "C" void CameraPlayable_GetHandle_m1459651790_AdjustorThunk ();
extern "C" void MaterialEffectPlayable_GetHandle_m4279427933_AdjustorThunk ();
extern "C" void TextureMixerPlayable_GetHandle_m2203457785_AdjustorThunk ();
extern "C" void Playable_GetHandle_m98909670_AdjustorThunk ();
extern "C" void PlayableHandle_get_Null_m218234861 ();
extern "C" void CreateOutputMethod_EndInvoke_m325504645 ();
extern "C" void CreateOutputMethod_Invoke_m549607425 ();
extern "C" void PlayableOutput_GetHandle_m777137769_AdjustorThunk ();
extern "C" void PlayableOutputHandle_get_Null_m1200584339 ();
extern "C" void AudioListener_ReadExtensionName_m929423100 ();
extern "C" void AudioListener_ReadExtensionPropertyName_m3416271339 ();
extern "C" void AudioSource_ReadExtensionName_m725112169 ();
extern "C" void AudioSource_ReadExtensionPropertyName_m2761820692 ();
extern "C" void PropertyName_op_Implicit_m114733813 ();
extern "C" void PropertyName_op_Implicit_m1633828199 ();
extern "C" void PropertyNameUtils_PropertyNameFromString_m3719796130 ();
extern "C" void Camera_ScreenPointToRay_m3401628776 ();
extern "C" void Camera_ScreenPointToRay_m3764635188 ();
extern "C" void Camera_ScreenPointToRay_m2119345216 ();
extern "C" void Camera_get_pixelRect_m2283183456 ();
extern "C" void Camera_get_targetTexture_m2278634983 ();
extern "C" void RenderTexture_GetDescriptor_m2430275682 ();
extern "C" void RenderTexture_get_descriptor_m722729156 ();
extern "C" void GraphicsFormatUtility_GetRenderTextureFormat_m2347522639 ();
extern "C" void ScriptableObject_CreateInstance_m2611081756 ();
extern "C" void ScriptableObject_CreateScriptableObjectInstanceFromType_m2783367459 ();
extern "C" void GameCenterPlatform_CreateAchievement_m1439743707 ();
extern "C" void GameCenterPlatform_CreateLeaderboard_m2947842674 ();
extern "C" void GameCenterPlatform_get_localUser_m479829000 ();
extern "C" void GcAchievementData_ToAchievement_m891470019_AdjustorThunk ();
extern "C" void GcAchievementDescriptionData_ToAchievementDescription_m1622571845_AdjustorThunk ();
extern "C" void GcScoreData_ToScore_m2448550203_AdjustorThunk ();
extern "C" void GcUserProfileData_ToUserProfile_m3948549088_AdjustorThunk ();
extern "C" void Leaderboard_get_range_m167968592 ();
extern "C" void Leaderboard_get_timeScope_m4226979676 ();
extern "C" void Leaderboard_get_userScope_m4090697307 ();
extern "C" void UserProfile_get_state_m3340793320 ();
extern "C" void GameCenterPlatform_GetUserImage_m1487654451 ();
extern "C" void Transform_GetChild_m1092972975 ();
extern "C" void Vector2_op_Implicit_m4260192859 ();
extern "C" void Display_RelativeMouseAt_m1648644586 ();
extern "C" void Input_get_mousePosition_m1616496925 ();
extern "C" void Ray_get_direction_m761601601_AdjustorThunk ();
extern "C" void Vector3_get_zero_m1409827619 ();
extern "C" void Vector3_op_Subtraction_m3073674971 ();
extern const Il2CppMethodPointer g_MethodPointers[8936] = 
{
	Locale_GetText_m3374010885,
	Locale_GetText_m1601577974,
	SafeHandleZeroOrMinusOneIsInvalid__ctor_m2667299826,
	SafeHandleZeroOrMinusOneIsInvalid_get_IsInvalid_m1185299356,
	SafeWaitHandle__ctor_m3710504225,
	SafeWaitHandle_ReleaseHandle_m2890681297,
	CodePointIndexer__ctor_m2813317897,
	CodePointIndexer_ToIndex_m1008730487,
	TableRange__ctor_m3039750162_AdjustorThunk,
	Contraction__ctor_m2731863112,
	ContractionComparer__ctor_m3439667810,
	ContractionComparer__cctor_m1682260389,
	ContractionComparer_Compare_m732151595,
	Level2Map__ctor_m3459390739,
	Level2MapComparer__ctor_m1297087662,
	Level2MapComparer__cctor_m1866197409,
	Level2MapComparer_Compare_m2874495629,
	MSCompatUnicodeTable__cctor_m2887118684,
	MSCompatUnicodeTable_GetTailoringInfo_m1575560208,
	MSCompatUnicodeTable_BuildTailoringTables_m1316979344,
	MSCompatUnicodeTable_SetCJKReferences_m2637101499,
	MSCompatUnicodeTable_Category_m1834196420,
	MSCompatUnicodeTable_Level1_m18730923,
	MSCompatUnicodeTable_Level2_m3823292331,
	MSCompatUnicodeTable_Level3_m1870873670,
	MSCompatUnicodeTable_IsIgnorable_m3957534007,
	MSCompatUnicodeTable_IsIgnorableNonSpacing_m47098938,
	MSCompatUnicodeTable_ToKanaTypeInsensitive_m2886449430,
	MSCompatUnicodeTable_ToWidthCompat_m3110108204,
	MSCompatUnicodeTable_HasSpecialWeight_m1621324272,
	MSCompatUnicodeTable_IsHalfWidthKana_m4030661976,
	MSCompatUnicodeTable_IsHiragana_m3884380055,
	MSCompatUnicodeTable_IsJapaneseSmallLetter_m2666144582,
	MSCompatUnicodeTable_get_IsReady_m366684638,
	MSCompatUnicodeTable_GetResource_m731831298,
	MSCompatUnicodeTable_UInt32FromBytePtr_m2910318928,
	MSCompatUnicodeTable_FillCJK_m1599013685,
	MSCompatUnicodeTable_FillCJKCore_m2347268515,
	MSCompatUnicodeTableUtil__cctor_m3131017198,
	SimpleCollator__ctor_m1587210019,
	SimpleCollator__cctor_m4065707122,
	SimpleCollator_SetCJKTable_m766339459,
	SimpleCollator_GetNeutralCulture_m3694654043,
	SimpleCollator_Category_m119590608,
	SimpleCollator_Level1_m634954506,
	SimpleCollator_Level2_m2830638875,
	SimpleCollator_IsHalfKana_m3959736042,
	SimpleCollator_GetContraction_m3383256934,
	SimpleCollator_GetContraction_m2205549079,
	SimpleCollator_GetTailContraction_m2377844406,
	SimpleCollator_GetTailContraction_m2107754083,
	SimpleCollator_FilterOptions_m4183839400,
	SimpleCollator_GetExtenderType_m407776429,
	SimpleCollator_ToDashTypeValue_m6184468,
	SimpleCollator_FilterExtender_m72900315,
	SimpleCollator_IsIgnorable_m2840693628,
	SimpleCollator_IsSafe_m310268646,
	SimpleCollator_GetSortKey_m3181176421,
	SimpleCollator_GetSortKey_m1483713513,
	SimpleCollator_GetSortKey_m2852528720,
	SimpleCollator_FillSortKeyRaw_m2173916311,
	SimpleCollator_FillSurrogateSortKeyRaw_m725998232,
	SimpleCollator_CompareOrdinal_m1829915258,
	SimpleCollator_CompareQuick_m3272475794,
	SimpleCollator_CompareOrdinalIgnoreCase_m2749548392,
	SimpleCollator_Compare_m809124712,
	SimpleCollator_ClearBuffer_m2975394169,
	SimpleCollator_QuickCheckPossible_m649925260,
	SimpleCollator_CompareInternal_m3938174601,
	SimpleCollator_CompareFlagPair_m3270665809,
	SimpleCollator_IsPrefix_m3581642267,
	SimpleCollator_IsPrefix_m3884753235,
	SimpleCollator_IsPrefix_m3601454628,
	SimpleCollator_IsSuffix_m1548422615,
	SimpleCollator_IsSuffix_m1291687763,
	SimpleCollator_QuickIndexOf_m2519071357,
	SimpleCollator_IndexOf_m2273655786,
	SimpleCollator_IndexOfOrdinal_m2995071964,
	SimpleCollator_IndexOfOrdinalIgnoreCase_m2647969565,
	SimpleCollator_IndexOfSortKey_m481945176,
	SimpleCollator_IndexOf_m3396932533,
	SimpleCollator_LastIndexOf_m3026739976,
	SimpleCollator_LastIndexOfOrdinal_m388102249,
	SimpleCollator_LastIndexOfOrdinalIgnoreCase_m2984667899,
	SimpleCollator_LastIndexOfSortKey_m2864365168,
	SimpleCollator_LastIndexOf_m2130553617,
	SimpleCollator_MatchesForward_m541234454,
	SimpleCollator_MatchesForwardCore_m850743967,
	SimpleCollator_MatchesPrimitive_m3079388596,
	SimpleCollator_MatchesBackward_m485433520,
	SimpleCollator_MatchesBackwardCore_m3441733084,
	Context__ctor_m2477370097_AdjustorThunk,
	PreviousInfo__ctor_m2284093748_AdjustorThunk,
	SortKeyBuffer__ctor_m1384677558,
	SortKeyBuffer_Reset_m1409351310,
	SortKeyBuffer_Initialize_m3786111493,
	SortKeyBuffer_AppendCJKExtension_m2591091991,
	SortKeyBuffer_AppendKana_m2480356505,
	SortKeyBuffer_AppendNormal_m2338808729,
	SortKeyBuffer_AppendLevel5_m3963841125,
	SortKeyBuffer_AppendBufferPrimitive_m3309814175,
	SortKeyBuffer_GetResultAndReset_m1300773060,
	SortKeyBuffer_GetOptimizedLength_m1735248204,
	SortKeyBuffer_GetResult_m3043958424,
	TailoringInfo__ctor_m2283562302,
	BigInteger__ctor_m397734603,
	BigInteger__ctor_m1426225719,
	BigInteger__ctor_m224778556,
	BigInteger__ctor_m3991350270,
	BigInteger__ctor_m3985126171,
	BigInteger__cctor_m562779619,
	BigInteger_get_Rng_m4216817480,
	BigInteger_GenerateRandom_m3141592944,
	BigInteger_GenerateRandom_m2556426062,
	BigInteger_Randomize_m410563259,
	BigInteger_Randomize_m2194703121,
	BigInteger_BitCount_m3710900808,
	BigInteger_TestBit_m1365094736,
	BigInteger_TestBit_m1507066813,
	BigInteger_SetBit_m1985185235,
	BigInteger_SetBit_m337653943,
	BigInteger_LowestSetBit_m3082714978,
	BigInteger_GetBytes_m997192583,
	BigInteger_ToString_m570257729,
	BigInteger_ToString_m3475000413,
	BigInteger_Normalize_m4163607703,
	BigInteger_Clear_m3104012800,
	BigInteger_GetHashCode_m1262812797,
	BigInteger_ToString_m3278248272,
	BigInteger_Equals_m1948500455,
	BigInteger_ModInverse_m3469244086,
	BigInteger_ModPow_m2277842115,
	BigInteger_IsProbablePrime_m567194283,
	BigInteger_GeneratePseudoPrime_m1941064930,
	BigInteger_Incr2_m2179060417,
	BigInteger_op_Implicit_m378428706,
	BigInteger_op_Implicit_m2847009755,
	BigInteger_op_Addition_m2544206388,
	BigInteger_op_Subtraction_m1575155386,
	BigInteger_op_Modulus_m1987692259,
	BigInteger_op_Modulus_m3223754023,
	BigInteger_op_Division_m2437128540,
	BigInteger_op_Multiply_m3801644593,
	BigInteger_op_Multiply_m3854773313,
	BigInteger_op_LeftShift_m1192375522,
	BigInteger_op_RightShift_m2934036419,
	BigInteger_op_Equality_m970226143,
	BigInteger_op_Inequality_m2239968970,
	BigInteger_op_Equality_m3263851871,
	BigInteger_op_Inequality_m2365536750,
	BigInteger_op_GreaterThan_m2062805246,
	BigInteger_op_LessThan_m798881406,
	BigInteger_op_GreaterThanOrEqual_m700865613,
	BigInteger_op_LessThanOrEqual_m2553515144,
	Kernel_AddSameSign_m1676432471,
	Kernel_Subtract_m657044818,
	Kernel_MinusEq_m1955542202,
	Kernel_PlusEq_m1955533564,
	Kernel_Compare_m1530940716,
	Kernel_SingleByteDivideInPlace_m907158225,
	Kernel_DwordMod_m4183681925,
	Kernel_DwordDivMod_m631886101,
	Kernel_multiByteDivide_m4249920547,
	Kernel_LeftShift_m3302851050,
	Kernel_RightShift_m2207393597,
	Kernel_MultiplyByDword_m1266935086,
	Kernel_Multiply_m1995233235,
	Kernel_MultiplyMod2p32pmod_m4241526284,
	Kernel_modInverse_m668448880,
	Kernel_modInverse_m3523342258,
	ModulusRing__ctor_m2100816195,
	ModulusRing_BarrettReduction_m167376748,
	ModulusRing_Multiply_m343333088,
	ModulusRing_Difference_m1345688434,
	ModulusRing_Pow_m83007704,
	ModulusRing_Pow_m317016278,
	PrimeGeneratorBase__ctor_m2973488305,
	PrimeGeneratorBase_get_Confidence_m359324283,
	PrimeGeneratorBase_get_PrimalityTest_m2131070257,
	PrimeGeneratorBase_get_TrialDivisionBounds_m349266641,
	SequentialSearchPrimeGeneratorBase__ctor_m3077428553,
	SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m3595783982,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m1689384666,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m533229219,
	SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m3637196143,
	PrimalityTest__ctor_m2228551695,
	PrimalityTest_Invoke_m476975163,
	PrimalityTest_BeginInvoke_m1203148458,
	PrimalityTest_EndInvoke_m1454743433,
	PrimalityTests_GetSPPRounds_m228447904,
	PrimalityTests_Test_m2932837908,
	PrimalityTests_RabinMillerTest_m1471415870,
	PrimalityTests_SmallPrimeSppTest_m1224130639,
	Runtime_GetDisplayName_m2773861196,
	ASN1__ctor_m3727822613,
	ASN1__ctor_m3193227595,
	ASN1__ctor_m1601690794,
	ASN1_get_Count_m3580979881,
	ASN1_get_Tag_m1032367219,
	ASN1_get_Length_m1923878580,
	ASN1_get_Value_m1857007406,
	ASN1_set_Value_m2803403806,
	ASN1_CompareArray_m448994814,
	ASN1_CompareValue_m251306338,
	ASN1_Add_m3468571571,
	ASN1_GetBytes_m3305539297,
	ASN1_Decode_m1695284166,
	ASN1_DecodeTLV_m1200977460,
	ASN1_get_Item_m3901126023,
	ASN1_Element_m2680269109,
	ASN1_ToString_m1340204511,
	ASN1Convert_FromInt32_m2935389061,
	ASN1Convert_FromOid_m3740816339,
	ASN1Convert_ToInt32_m254930636,
	ASN1Convert_ToOid_m1223840396,
	ASN1Convert_ToDateTime_m3103388320,
	BitConverterLE_GetUIntBytes_m949779219,
	BitConverterLE_GetULongBytes_m1393773100,
	BitConverterLE_GetBytes_m4130646282,
	BitConverterLE_GetBytes_m2590852453,
	BitConverterLE_GetBytes_m3350143782,
	BitConverterLE_UShortFromBytes_m1253080092,
	BitConverterLE_UIntFromBytes_m3974925535,
	BitConverterLE_ULongFromBytes_m1677445591,
	BitConverterLE_ToInt16_m1855092160,
	BitConverterLE_ToInt32_m1510163321,
	BitConverterLE_ToSingle_m1153793442,
	BitConverterLE_ToDouble_m1601000678,
	BlockProcessor__ctor_m649794031,
	BlockProcessor_Finalize_m3954108481,
	BlockProcessor_Initialize_m2263257456,
	BlockProcessor_Core_m189015002,
	BlockProcessor_Core_m2138791525,
	BlockProcessor_Final_m3350443194,
	CryptoConvert_ToInt32LE_m3340980429,
	CryptoConvert_ToUInt32LE_m1043410428,
	CryptoConvert_GetBytesLE_m3076458968,
	CryptoConvert_Trim_m3900804798,
	CryptoConvert_FromCapiPrivateKeyBlob_m73613828,
	CryptoConvert_ToCapiPrivateKeyBlob_m2502515575,
	CryptoConvert_FromCapiPublicKeyBlob_m184006806,
	CryptoConvert_FromCapiPublicKeyBlob_m4073029974,
	CryptoConvert_ToCapiPublicKeyBlob_m1931330842,
	CryptoConvert_FromCapiKeyBlob_m2655899792,
	CryptoConvert_FromCapiKeyBlob_m1201868338,
	CryptoConvert_ToCapiKeyBlob_m3371450375,
	DSAManaged__ctor_m962128842,
	DSAManaged_add_KeyGenerated_m2286864968,
	DSAManaged_remove_KeyGenerated_m1781077002,
	DSAManaged_Finalize_m2286724636,
	DSAManaged_Generate_m1247561684,
	DSAManaged_GenerateKeyPair_m2236915969,
	DSAManaged_add_m1505525960,
	DSAManaged_GenerateParams_m2848737814,
	DSAManaged_get_Random_m923751780,
	DSAManaged_get_KeySize_m2738463749,
	DSAManaged_get_PublicOnly_m3575594967,
	DSAManaged_NormalizeArray_m3285505169,
	DSAManaged_ExportParameters_m1426347745,
	DSAManaged_ImportParameters_m2247591247,
	DSAManaged_CreateSignature_m2233977444,
	DSAManaged_VerifySignature_m2909094577,
	DSAManaged_Dispose_m757362415,
	KeyGeneratedEventHandler__ctor_m3801024251,
	KeyGeneratedEventHandler_Invoke_m4131555809,
	KeyGeneratedEventHandler_BeginInvoke_m3949196697,
	KeyGeneratedEventHandler_EndInvoke_m1628355235,
	KeyBuilder_get_Rng_m1353817187,
	KeyBuilder_Key_m876696100,
	KeyBuilder_IV_m2230195376,
	KeyPairPersistence__ctor_m103880447,
	KeyPairPersistence__ctor_m252166830,
	KeyPairPersistence__cctor_m1700962802,
	KeyPairPersistence_get_Filename_m2760692036,
	KeyPairPersistence_get_KeyValue_m2994490605,
	KeyPairPersistence_set_KeyValue_m3459302102,
	KeyPairPersistence_Load_m2518737071,
	KeyPairPersistence_Save_m3111435398,
	KeyPairPersistence_Remove_m1876145547,
	KeyPairPersistence_get_UserPath_m610275969,
	KeyPairPersistence_get_MachinePath_m3812267291,
	KeyPairPersistence__CanSecure_m3516574278,
	KeyPairPersistence__ProtectUser_m3263950383,
	KeyPairPersistence__ProtectMachine_m813172390,
	KeyPairPersistence__IsUserProtected_m438961964,
	KeyPairPersistence__IsMachineProtected_m2170750712,
	KeyPairPersistence_CanSecure_m3598829533,
	KeyPairPersistence_ProtectUser_m2715637552,
	KeyPairPersistence_ProtectMachine_m1313131097,
	KeyPairPersistence_IsUserProtected_m2000878920,
	KeyPairPersistence_IsMachineProtected_m644209340,
	KeyPairPersistence_get_CanChange_m4275265699,
	KeyPairPersistence_get_UseDefaultKeyContainer_m1646107069,
	KeyPairPersistence_get_UseMachineKeyStore_m3206839918,
	KeyPairPersistence_get_ContainerName_m4274536094,
	KeyPairPersistence_Copy_m2577206651,
	KeyPairPersistence_FromXml_m746585742,
	KeyPairPersistence_ToXml_m812591779,
	MACAlgorithm__ctor_m3608996594,
	MACAlgorithm_Initialize_m1409947493,
	MACAlgorithm_Core_m83451446,
	MACAlgorithm_Final_m3756738689,
	PKCS1__cctor_m266708662,
	PKCS1_Compare_m2442824967,
	PKCS1_I2OSP_m1314988212,
	PKCS1_OS2IP_m65970018,
	PKCS1_RSAEP_m594928261,
	PKCS1_RSASP1_m3912327535,
	PKCS1_RSAVP1_m2014482508,
	PKCS1_Encrypt_v15_m1016948107,
	PKCS1_Sign_v15_m2719206817,
	PKCS1_Verify_v15_m2816868480,
	PKCS1_Verify_v15_m3708133908,
	PKCS1_Encode_v15_m3116793121,
	EncryptedPrivateKeyInfo__ctor_m3217539356,
	EncryptedPrivateKeyInfo__ctor_m3274704095,
	EncryptedPrivateKeyInfo_get_Algorithm_m2142585301,
	EncryptedPrivateKeyInfo_get_EncryptedData_m1695265614,
	EncryptedPrivateKeyInfo_get_Salt_m3453455261,
	EncryptedPrivateKeyInfo_get_IterationCount_m2389157423,
	EncryptedPrivateKeyInfo_Decode_m2516465782,
	PrivateKeyInfo__ctor_m2811023496,
	PrivateKeyInfo__ctor_m2414235375,
	PrivateKeyInfo_get_PrivateKey_m2768243057,
	PrivateKeyInfo_Decode_m682813286,
	PrivateKeyInfo_RemoveLeadingZero_m3921889925,
	PrivateKeyInfo_Normalize_m1855800471,
	PrivateKeyInfo_DecodeRSA_m2889346634,
	PrivateKeyInfo_DecodeDSA_m771724585,
	RSAManaged__ctor_m3394311431,
	RSAManaged_add_KeyGenerated_m3688329863,
	RSAManaged_remove_KeyGenerated_m2046909903,
	RSAManaged_Finalize_m3915335854,
	RSAManaged_GenerateKeyPair_m2221292703,
	RSAManaged_get_KeySize_m1420503080,
	RSAManaged_get_PublicOnly_m595121416,
	RSAManaged_DecryptValue_m1864805746,
	RSAManaged_EncryptValue_m799827583,
	RSAManaged_ExportParameters_m280454101,
	RSAManaged_ImportParameters_m1844641996,
	RSAManaged_Dispose_m1863653890,
	RSAManaged_ToXmlString_m645792083,
	RSAManaged_get_IsCrtPossible_m3949564681,
	RSAManaged_GetPaddedValue_m2104792084,
	KeyGeneratedEventHandler__ctor_m1990062371,
	KeyGeneratedEventHandler_Invoke_m2527485594,
	KeyGeneratedEventHandler_BeginInvoke_m1299225259,
	KeyGeneratedEventHandler_EndInvoke_m3057317531,
	SymmetricTransform__ctor_m25459519,
	SymmetricTransform_System_IDisposable_Dispose_m3676111272,
	SymmetricTransform_Finalize_m1463466895,
	SymmetricTransform_Dispose_m3894715243,
	SymmetricTransform_get_CanReuseTransform_m3947311416,
	SymmetricTransform_Transform_m3073016850,
	SymmetricTransform_CBC_m435753239,
	SymmetricTransform_CFB_m1051508796,
	SymmetricTransform_OFB_m3842617151,
	SymmetricTransform_CTS_m2571643614,
	SymmetricTransform_CheckInput_m1829858759,
	SymmetricTransform_TransformBlock_m2339552481,
	SymmetricTransform_get_KeepLastBlock_m3105157421,
	SymmetricTransform_InternalTransformBlock_m946892271,
	SymmetricTransform_Random_m2004892672,
	SymmetricTransform_ThrowBadPaddingException_m2926778011,
	SymmetricTransform_FinalEncrypt_m69518647,
	SymmetricTransform_FinalDecrypt_m1677319445,
	SymmetricTransform_TransformFinalBlock_m4059448527,
	ContentInfo__ctor_m28146633,
	ContentInfo__ctor_m3072134336,
	ContentInfo__ctor_m1888388023,
	ContentInfo__ctor_m2639021892,
	ContentInfo_get_ASN1_m1776225219,
	ContentInfo_get_Content_m1945593776,
	ContentInfo_set_Content_m2745521966,
	ContentInfo_get_ContentType_m275324816,
	ContentInfo_set_ContentType_m3961495440,
	ContentInfo_GetASN1_m3665489137,
	EncryptedData__ctor_m3841552120,
	EncryptedData__ctor_m2497911783,
	EncryptedData_get_EncryptionAlgorithm_m1297902161,
	EncryptedData_get_EncryptedContent_m4211024111,
	StrongName__ctor_m467142887,
	StrongName__ctor_m3939359439,
	StrongName__cctor_m1246179561,
	StrongName_InvalidateCache_m4128978353,
	StrongName_set_RSA_m3858265129,
	StrongName_get_PublicKey_m1841537984,
	StrongName_get_PublicKeyToken_m2115276552,
	StrongName_get_TokenAlgorithm_m1794722022,
	PKCS12__ctor_m2768693996,
	PKCS12__ctor_m2089474062,
	PKCS12__ctor_m1771540803,
	PKCS12__cctor_m2862471915,
	PKCS12_Decode_m1913457787,
	PKCS12_Finalize_m1390639705,
	PKCS12_set_Password_m3259330454,
	PKCS12_get_IterationCount_m626423090,
	PKCS12_set_IterationCount_m1399630158,
	PKCS12_get_Certificates_m1630860723,
	PKCS12_get_RNG_m2649456600,
	PKCS12_Compare_m2975811353,
	PKCS12_GetSymmetricAlgorithm_m1390440284,
	PKCS12_Decrypt_m2241300865,
	PKCS12_Decrypt_m3310864946,
	PKCS12_Encrypt_m2617413749,
	PKCS12_GetExistingParameters_m3511027613,
	PKCS12_AddPrivateKey_m1542850936,
	PKCS12_ReadSafeBag_m1585166574,
	PKCS12_CertificateSafeBag_m3469173172,
	PKCS12_MAC_m3401183837,
	PKCS12_GetBytes_m3933153476,
	PKCS12_EncryptedContentInfo_m1012097402,
	PKCS12_AddCertificate_m3857004455,
	PKCS12_AddCertificate_m3618696508,
	PKCS12_RemoveCertificate_m1177171903,
	PKCS12_RemoveCertificate_m1421555398,
	PKCS12_Clone_m93617975,
	PKCS12_get_MaximumPasswordLength_m883183191,
	DeriveBytes__ctor_m3611803810,
	DeriveBytes__cctor_m1212925033,
	DeriveBytes_set_HashName_m3752780137,
	DeriveBytes_set_IterationCount_m3235108425,
	DeriveBytes_set_Password_m3005258189,
	DeriveBytes_set_Salt_m441577179,
	DeriveBytes_Adjust_m640796917,
	DeriveBytes_Derive_m408582823,
	DeriveBytes_DeriveKey_m2238010581,
	DeriveBytes_DeriveIV_m3639813821,
	DeriveBytes_DeriveMAC_m694919248,
	SafeBag__ctor_m369012969,
	SafeBag_get_BagOID_m2165567310,
	SafeBag_get_ASN1_m3167501969,
	X501__cctor_m1166912714,
	X501_ToString_m4186311521,
	X501_ToString_m2278029064,
	X501_AppendEntry_m2470239841,
	X509Certificate__ctor_m3656389950,
	X509Certificate__cctor_m198658613,
	X509Certificate_Parse_m1106379228,
	X509Certificate_GetUnsignedBigInteger_m1025066663,
	X509Certificate_get_DSA_m1760272844,
	X509Certificate_get_IssuerName_m605048065,
	X509Certificate_get_KeyAlgorithmParameters_m681676289,
	X509Certificate_get_PublicKey_m1627137142,
	X509Certificate_get_RawData_m2387471414,
	X509Certificate_get_SubjectName_m3160893681,
	X509Certificate_get_ValidFrom_m1469376000,
	X509Certificate_get_ValidUntil_m678342786,
	X509Certificate_GetIssuerName_m4238857993,
	X509Certificate_GetSubjectName_m584504796,
	X509Certificate_GetObjectData_m2057262401,
	X509Certificate_PEM_m1177570576,
	X509CertificateCollection__ctor_m3365535796,
	X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m279447643,
	X509CertificateCollection_get_Item_m3219599455,
	X509CertificateCollection_Add_m3136524580,
	X509CertificateCollection_GetEnumerator_m4229251522,
	X509CertificateCollection_GetHashCode_m324533873,
	X509CertificateEnumerator__ctor_m3747779152,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m418791713,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m708500216,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2928805663,
	X509CertificateEnumerator_get_Current_m3041233561,
	X509CertificateEnumerator_MoveNext_m2269241175,
	X509CertificateEnumerator_Reset_m122774664,
	X509Extension__ctor_m1750445243,
	X509Extension_Decode_m833805412,
	X509Extension_Equals_m1222951829,
	X509Extension_GetHashCode_m2866442052,
	X509Extension_WriteLine_m1400196767,
	X509Extension_ToString_m3664524823,
	X509ExtensionCollection__ctor_m2416193357,
	X509ExtensionCollection__ctor_m3315097415,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m2696143383,
	SecurityParser__ctor_m1786039976,
	SecurityParser_LoadXml_m1638830459,
	SecurityParser_ToXml_m3880004309,
	SecurityParser_OnStartParsing_m160443947,
	SecurityParser_OnProcessingInstruction_m2327827622,
	SecurityParser_OnIgnorableWhitespace_m1130543143,
	SecurityParser_OnStartElement_m2534612579,
	SecurityParser_OnEndElement_m2088612360,
	SecurityParser_OnChars_m396174937,
	SecurityParser_OnEndParsing_m2521892142,
	SmallXmlParser__ctor_m202236734,
	SmallXmlParser_Error_m3899025466,
	SmallXmlParser_UnexpectedEndError_m1914362401,
	SmallXmlParser_IsNameChar_m2946368541,
	SmallXmlParser_IsWhitespace_m156831381,
	SmallXmlParser_SkipWhitespaces_m990960618,
	SmallXmlParser_HandleWhitespaces_m549588711,
	SmallXmlParser_SkipWhitespaces_m4243606597,
	SmallXmlParser_Peek_m1303779789,
	SmallXmlParser_Read_m3485223434,
	SmallXmlParser_Expect_m674880652,
	SmallXmlParser_ReadUntil_m2715581630,
	SmallXmlParser_ReadName_m3409228522,
	SmallXmlParser_Parse_m2140493703,
	SmallXmlParser_Cleanup_m2310464878,
	SmallXmlParser_ReadContent_m1631445300,
	SmallXmlParser_HandleBufferedContent_m3185158999,
	SmallXmlParser_ReadCharacters_m3318286261,
	SmallXmlParser_ReadReference_m1750252339,
	SmallXmlParser_ReadCharacterReference_m548953186,
	SmallXmlParser_ReadAttribute_m3518350607,
	SmallXmlParser_ReadCDATASection_m138715165,
	SmallXmlParser_ReadComment_m1578426707,
	AttrListImpl__ctor_m3844427077,
	AttrListImpl_get_Length_m1163071530,
	AttrListImpl_GetName_m2880551319,
	AttrListImpl_GetValue_m3657391095,
	AttrListImpl_GetValue_m215192361,
	AttrListImpl_get_Names_m977594476,
	AttrListImpl_get_Values_m3139810172,
	AttrListImpl_Clear_m2260362286,
	AttrListImpl_Add_m3378108236,
	SmallXmlParserException__ctor_m1976648878,
	AccessViolationException__ctor_m459401853,
	AccessViolationException__ctor_m506103991,
	ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m2821911612,
	ActivationContext_Finalize_m1527946098,
	ActivationContext_Dispose_m827530843,
	ActivationContext_Dispose_m2038725770,
	Activator_CreateInstance_m3631483688,
	Activator_CreateInstance_m94526014,
	Activator_CreateInstance_m3736402505,
	Activator_CreateInstance_m2998273980,
	Activator_CreateInstance_m2597605935,
	Activator_CheckType_m2787213785,
	Activator_CheckAbstractType_m2015247896,
	Activator_CreateInstanceInternal_m1337209899,
	AppDomain__ctor_m900298256,
	AppDomain_add_UnhandledException_m66698413,
	AppDomain_remove_UnhandledException_m1144722992,
	AppDomain_getFriendlyName_m248495153,
	AppDomain_getCurDomain_m1005431575,
	AppDomain_get_CurrentDomain_m182766250,
	AppDomain_DefineInternalDynamicAssembly_m3889239439,
	AppDomain_InitializeLifetimeService_m1122536350,
	AppDomain_LoadAssembly_m1557889794,
	AppDomain_Load_m4174353770,
	AppDomain_Load_m2969998014,
	AppDomain_InternalSetDomainByID_m560451773,
	AppDomain_InternalSetDomain_m3622943898,
	AppDomain_InternalPushDomainRefByID_m1598870089,
	AppDomain_InternalPopDomainRef_m412593501,
	AppDomain_InternalSetContext_m139827955,
	AppDomain_InternalGetContext_m114897961,
	AppDomain_InternalGetDefaultContext_m1679027951,
	AppDomain_InternalGetProcessGuid_m1352630171,
	AppDomain_InvokeInDomainByID_m1902345728,
	AppDomain_GetProcessGuid_m3316193837,
	AppDomain_ToString_m1389451889,
	AppDomain_DoTypeResolve_m1335093328,
	AppDomain_ProcessMessageInDomain_m1871749965,
	AppDomainInitializer__ctor_m804756664,
	AppDomainInitializer_Invoke_m1036878490,
	AppDomainInitializer_BeginInvoke_m2460927216,
	AppDomainInitializer_EndInvoke_m2095010821,
	AppDomainSetup__ctor_m363420372,
	ApplicationException__ctor_m2557611022,
	ApplicationException__ctor_m2517758450,
	ApplicationException__ctor_m1689533002,
	ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m995105840,
	ApplicationIdentity_ToString_m2074887951,
	ArgIterator_Equals_m4289772452_AdjustorThunk,
	ArgIterator_GetHashCode_m2630206016_AdjustorThunk,
	ArgumentException__ctor_m3698743796,
	ArgumentException__ctor_m1312628991,
	ArgumentException__ctor_m1535060261,
	ArgumentException__ctor_m1216717135,
	ArgumentException__ctor_m3761792013,
	ArgumentException__ctor_m3200406061,
	ArgumentException_get_ParamName_m2556126651,
	ArgumentException_get_Message_m520762021,
	ArgumentException_GetObjectData_m4122729010,
	ArgumentNullException__ctor_m2751210921,
	ArgumentNullException__ctor_m1170824041,
	ArgumentNullException__ctor_m2009621981,
	ArgumentNullException__ctor_m520761569,
	ArgumentOutOfRangeException__ctor_m2047740448,
	ArgumentOutOfRangeException__ctor_m3628145864,
	ArgumentOutOfRangeException__ctor_m282481429,
	ArgumentOutOfRangeException__ctor_m4164965325,
	ArgumentOutOfRangeException__ctor_m769015475,
	ArgumentOutOfRangeException_get_Message_m1913926628,
	ArgumentOutOfRangeException_GetObjectData_m1344552880,
	ArithmeticException__ctor_m479063094,
	ArithmeticException__ctor_m3551809662,
	ArithmeticException__ctor_m1658426420,
	Array__ctor_m2178462056,
	Array_System_Collections_IList_get_Item_m631337679,
	Array_System_Collections_IList_set_Item_m2667455393,
	Array_System_Collections_IList_Add_m1063688101,
	Array_System_Collections_IList_Clear_m1278271623,
	Array_System_Collections_IList_Contains_m3297693594,
	Array_System_Collections_IList_IndexOf_m3301661616,
	Array_System_Collections_IList_Insert_m2476478913,
	Array_System_Collections_IList_Remove_m1479535418,
	Array_System_Collections_IList_RemoveAt_m41405158,
	Array_System_Collections_ICollection_get_Count_m415154915,
	Array_InternalArray__ICollection_get_Count_m2423031222,
	Array_InternalArray__ICollection_get_IsReadOnly_m4276975044,
	Array_InternalArray__ICollection_Clear_m4058340337,
	Array_InternalArray__RemoveAt_m616137314,
	Array_get_Length_m21610649,
	Array_get_LongLength_m978104875,
	Array_get_Rank_m3448755881,
	Array_GetRank_m2893148338,
	Array_GetLength_m2178203778,
	Array_GetLongLength_m561139708,
	Array_GetLowerBound_m2045984623,
	Array_GetValue_m120423883,
	Array_SetValue_m1804138688,
	Array_GetValueImpl_m3048550958,
	Array_SetValueImpl_m2791230289,
	Array_FastCopy_m1662204957,
	Array_CreateInstanceImpl_m1073152296,
	Array_get_IsSynchronized_m3066873806,
	Array_get_SyncRoot_m1984189992,
	Array_get_IsFixedSize_m433207027,
	Array_get_IsReadOnly_m1420176977,
	Array_GetEnumerator_m4277730612,
	Array_GetUpperBound_m4018715963,
	Array_GetValue_m2528546681,
	Array_GetValue_m352525925,
	Array_GetValue_m793801589,
	Array_GetValue_m2528415604,
	Array_GetValue_m4249310555,
	Array_GetValue_m1062368071,
	Array_SetValue_m3412648248,
	Array_SetValue_m394135409,
	Array_SetValue_m282347242,
	Array_SetValue_m3412255035,
	Array_SetValue_m3998268557,
	Array_SetValue_m2601781200,
	Array_CreateInstance_m2750085942,
	Array_CreateInstance_m1740754882,
	Array_CreateInstance_m2696293787,
	Array_CreateInstance_m2175520447,
	Array_CreateInstance_m3395539612,
	Array_GetIntArray_m1205726566,
	Array_CreateInstance_m1027597705,
	Array_GetValue_m116098292,
	Array_SetValue_m1817114699,
	Array_BinarySearch_m687718979,
	Array_BinarySearch_m157235616,
	Array_BinarySearch_m3171087170,
	Array_BinarySearch_m1987924169,
	Array_DoBinarySearch_m3657328456,
	Array_Clear_m2231608178,
	Array_ClearInternal_m532048538,
	Array_Clone_m2672907798,
	Array_Copy_m1988217701,
	Array_Copy_m344457298,
	Array_Copy_m514679699,
	Array_Copy_m1988610914,
	Array_IndexOf_m1714973386,
	Array_IndexOf_m2527777724,
	Array_IndexOf_m2805394078,
	Array_Initialize_m3004991267,
	Array_LastIndexOf_m1426784917,
	Array_LastIndexOf_m3999123122,
	Array_LastIndexOf_m707980579,
	Array_get_swapper_m3428716670,
	Array_Reverse_m3714848183,
	Array_Reverse_m816310962,
	Array_Sort_m3698291233,
	Array_Sort_m459550270,
	Array_Sort_m870838517,
	Array_Sort_m3287581440,
	Array_Sort_m3145621264,
	Array_Sort_m2147377746,
	Array_Sort_m182264525,
	Array_Sort_m2934663614,
	Array_int_swapper_m3830919681,
	Array_obj_swapper_m472969017,
	Array_slow_swapper_m4116724811,
	Array_double_swapper_m4135376022,
	Array_new_gap_m262136975,
	Array_combsort_m3017221499,
	Array_combsort_m4052486289,
	Array_combsort_m2745184932,
	Array_qsort_m3156569874,
	Array_swap_m547389985,
	Array_compare_m2837221808,
	Array_CopyTo_m225704097,
	Array_CopyTo_m3358199659,
	Array_ConstrainedCopy_m3673290180,
	SimpleEnumerator__ctor_m353509656,
	SimpleEnumerator_get_Current_m72361444,
	SimpleEnumerator_MoveNext_m3097336207,
	SimpleEnumerator_Reset_m2182001888,
	SimpleEnumerator_Clone_m1890729616,
	Swapper__ctor_m3019156154,
	Swapper_Invoke_m2596472750,
	Swapper_BeginInvoke_m1688449973,
	Swapper_EndInvoke_m1804951082,
	ArrayTypeMismatchException__ctor_m3375008173,
	ArrayTypeMismatchException__ctor_m231257638,
	ArrayTypeMismatchException__ctor_m2621976975,
	AssemblyLoadEventHandler__ctor_m896828968,
	AssemblyLoadEventHandler_Invoke_m1462077361,
	AssemblyLoadEventHandler_BeginInvoke_m1281107466,
	AssemblyLoadEventHandler_EndInvoke_m18714231,
	AsyncCallback__ctor_m530647953,
	AsyncCallback_Invoke_m3156993048,
	AsyncCallback_BeginInvoke_m2710486612,
	AsyncCallback_EndInvoke_m1460833738,
	Attribute__ctor_m1529526131,
	Attribute_CheckParameters_m456532822,
	Attribute_GetCustomAttribute_m4034845276,
	Attribute_GetCustomAttribute_m1244111375,
	Attribute_GetHashCode_m2508706224,
	Attribute_IsDefined_m4069052474,
	Attribute_IsDefined_m3363303722,
	Attribute_IsDefined_m1430686743,
	Attribute_IsDefined_m3355705882,
	Attribute_Equals_m710241514,
	AttributeUsageAttribute__ctor_m3683365572,
	AttributeUsageAttribute_get_AllowMultiple_m2247746686,
	AttributeUsageAttribute_set_AllowMultiple_m625992462,
	AttributeUsageAttribute_get_Inherited_m2911062450,
	AttributeUsageAttribute_set_Inherited_m1799999820,
	BitConverter__cctor_m3841343255,
	BitConverter_AmILittleEndian_m4092412670,
	BitConverter_DoubleWordsAreSwapped_m1474345095,
	BitConverter_DoubleToInt64Bits_m3574395137,
	BitConverter_GetBytes_m2120707223,
	BitConverter_GetBytes_m3693159656,
	BitConverter_PutBytes_m2614286581,
	BitConverter_ToInt64_m349022421,
	BitConverter_ToString_m3464863163,
	BitConverter_ToString_m3439099539,
	Boolean__cctor_m1091629305,
	Boolean_System_IConvertible_ToType_m2078828242_AdjustorThunk,
	Boolean_System_IConvertible_ToBoolean_m422934902_AdjustorThunk,
	Boolean_System_IConvertible_ToByte_m3917074947_AdjustorThunk,
	Boolean_System_IConvertible_ToChar_m4279513009_AdjustorThunk,
	Boolean_System_IConvertible_ToDateTime_m603510836_AdjustorThunk,
	Boolean_System_IConvertible_ToDecimal_m3176932461_AdjustorThunk,
	Boolean_System_IConvertible_ToDouble_m2859188631_AdjustorThunk,
	Boolean_System_IConvertible_ToInt16_m973746887_AdjustorThunk,
	Boolean_System_IConvertible_ToInt32_m1127498050_AdjustorThunk,
	Boolean_System_IConvertible_ToInt64_m2059204559_AdjustorThunk,
	Boolean_System_IConvertible_ToSByte_m806999_AdjustorThunk,
	Boolean_System_IConvertible_ToSingle_m1524606222_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt16_m3465173538_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt32_m2723177447_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt64_m1739877596_AdjustorThunk,
	Boolean_CompareTo_m3665076258_AdjustorThunk,
	Boolean_Equals_m2410333903_AdjustorThunk,
	Boolean_CompareTo_m3774767002_AdjustorThunk,
	Boolean_Equals_m535526264_AdjustorThunk,
	Boolean_GetHashCode_m3167312162_AdjustorThunk,
	Boolean_Parse_m2370352694,
	Boolean_ToString_m2664721875_AdjustorThunk,
	Boolean_ToString_m663098404_AdjustorThunk,
	Buffer_ByteLength_m2639516074,
	Buffer_BlockCopy_m2884209081,
	Buffer_ByteLengthInternal_m1388208719,
	Buffer_BlockCopyInternal_m418318694,
	Byte_System_IConvertible_ToType_m2251112646_AdjustorThunk,
	Byte_System_IConvertible_ToBoolean_m2888023769_AdjustorThunk,
	Byte_System_IConvertible_ToByte_m162267264_AdjustorThunk,
	Byte_System_IConvertible_ToChar_m2173687830_AdjustorThunk,
	Byte_System_IConvertible_ToDateTime_m3654084722_AdjustorThunk,
	Byte_System_IConvertible_ToDecimal_m3746192770_AdjustorThunk,
	Byte_System_IConvertible_ToDouble_m1540319472_AdjustorThunk,
	Byte_System_IConvertible_ToInt16_m4136764794_AdjustorThunk,
	Byte_System_IConvertible_ToInt32_m3495522413_AdjustorThunk,
	Byte_System_IConvertible_ToInt64_m285584218_AdjustorThunk,
	Byte_System_IConvertible_ToSByte_m1869482168_AdjustorThunk,
	Byte_System_IConvertible_ToSingle_m324484566_AdjustorThunk,
	Byte_System_IConvertible_ToUInt16_m1879180133_AdjustorThunk,
	Byte_System_IConvertible_ToUInt32_m1049546902_AdjustorThunk,
	Byte_System_IConvertible_ToUInt64_m371883985_AdjustorThunk,
	Byte_CompareTo_m4285128861_AdjustorThunk,
	Byte_Equals_m1161982810_AdjustorThunk,
	Byte_GetHashCode_m850171870_AdjustorThunk,
	Byte_CompareTo_m4207847027_AdjustorThunk,
	Byte_Equals_m2522165325_AdjustorThunk,
	Byte_Parse_m2607942050,
	Byte_Parse_m3200377149,
	Byte_Parse_m678312347,
	Byte_TryParse_m1615417784,
	Byte_TryParse_m1467448483,
	Byte_ToString_m721125428_AdjustorThunk,
	Byte_ToString_m3735479648_AdjustorThunk,
	Byte_ToString_m2335342258_AdjustorThunk,
	Byte_ToString_m4063101981_AdjustorThunk,
	CLSCompliantAttribute__ctor_m581760440,
	Char__cctor_m2787437263,
	Char_System_IConvertible_ToType_m4138905176_AdjustorThunk,
	Char_System_IConvertible_ToBoolean_m309214875_AdjustorThunk,
	Char_System_IConvertible_ToByte_m2347554595_AdjustorThunk,
	Char_System_IConvertible_ToChar_m3578899883_AdjustorThunk,
	Char_System_IConvertible_ToDateTime_m3564102661_AdjustorThunk,
	Char_System_IConvertible_ToDecimal_m3534906463_AdjustorThunk,
	Char_System_IConvertible_ToDouble_m3575321888_AdjustorThunk,
	Char_System_IConvertible_ToInt16_m975497224_AdjustorThunk,
	Char_System_IConvertible_ToInt32_m1777243200_AdjustorThunk,
	Char_System_IConvertible_ToInt64_m1630543716_AdjustorThunk,
	Char_System_IConvertible_ToSByte_m973063527_AdjustorThunk,
	Char_System_IConvertible_ToSingle_m2690985411_AdjustorThunk,
	Char_System_IConvertible_ToUInt16_m2449138174_AdjustorThunk,
	Char_System_IConvertible_ToUInt32_m3901815580_AdjustorThunk,
	Char_System_IConvertible_ToUInt64_m3536560782_AdjustorThunk,
	Char_GetDataTablePointers_m754571594,
	Char_CompareTo_m42489266_AdjustorThunk,
	Char_Equals_m1279957088_AdjustorThunk,
	Char_CompareTo_m1035527789_AdjustorThunk,
	Char_Equals_m198757577_AdjustorThunk,
	Char_GetHashCode_m2163065211_AdjustorThunk,
	Char_GetUnicodeCategory_m57882613,
	Char_IsDigit_m3646673943,
	Char_IsLetter_m3996985877,
	Char_IsLetterOrDigit_m3494175785,
	Char_IsLower_m3108076820,
	Char_IsSurrogate_m3686972571,
	Char_IsWhiteSpace_m2148390798,
	Char_IsWhiteSpace_m3213701995,
	Char_CheckParameter_m4114020212,
	Char_Parse_m82218915,
	Char_ToLower_m844856331,
	Char_ToLowerInvariant_m1926695830,
	Char_ToLower_m3999837485,
	Char_ToUpper_m3999570441,
	Char_ToUpperInvariant_m3658711221,
	Char_ToString_m3588025615_AdjustorThunk,
	Char_ToString_m954857583,
	Char_ToString_m278452217_AdjustorThunk,
	CharEnumerator__ctor_m3465358752,
	CharEnumerator_System_Collections_IEnumerator_get_Current_m1328529384,
	CharEnumerator_System_IDisposable_Dispose_m1750532533,
	CharEnumerator_get_Current_m525608209,
	CharEnumerator_Clone_m1884400089,
	CharEnumerator_MoveNext_m599189179,
	CharEnumerator_Reset_m2829582932,
	ArrayList__ctor_m4254721275,
	ArrayList__ctor_m2130986447,
	ArrayList__ctor_m3828927650,
	ArrayList__ctor_m2075768692,
	ArrayList__cctor_m3052737821,
	ArrayList_get_Item_m3820278660,
	ArrayList_set_Item_m2003485935,
	ArrayList_get_Count_m1015046493,
	ArrayList_get_Capacity_m431818936,
	ArrayList_set_Capacity_m1058991803,
	ArrayList_get_IsReadOnly_m913775115,
	ArrayList_get_IsSynchronized_m854316597,
	ArrayList_get_SyncRoot_m2222042655,
	ArrayList_EnsureCapacity_m3016383533,
	ArrayList_Shift_m395607654,
	ArrayList_Add_m730026926,
	ArrayList_Clear_m3564447992,
	ArrayList_Contains_m974354901,
	ArrayList_IndexOf_m771193320,
	ArrayList_IndexOf_m305368842,
	ArrayList_IndexOf_m1052788661,
	ArrayList_Insert_m3524057793,
	ArrayList_InsertRange_m1740766984,
	ArrayList_Remove_m4274871153,
	ArrayList_RemoveAt_m761734947,
	ArrayList_CopyTo_m3530931172,
	ArrayList_CopyTo_m3962521159,
	ArrayList_CopyTo_m3105450421,
	ArrayList_GetEnumerator_m3176119603,
	ArrayList_AddRange_m3758299474,
	ArrayList_Sort_m582560637,
	ArrayList_Sort_m4234055499,
	ArrayList_ToArray_m3827492363,
	ArrayList_ToArray_m3439706433,
	ArrayList_Clone_m2682741233,
	ArrayList_ThrowNewArgumentOutOfRangeException_m3110627888,
	ArrayList_Synchronized_m1327684267,
	ArrayList_ReadOnly_m1905796817,
	ArrayListWrapper__ctor_m970192266,
	ArrayListWrapper_get_Item_m1313829881,
	ArrayListWrapper_set_Item_m3849584877,
	ArrayListWrapper_get_Count_m3954826285,
	ArrayListWrapper_get_Capacity_m51087796,
	ArrayListWrapper_set_Capacity_m2373297383,
	ArrayListWrapper_get_IsReadOnly_m322171850,
	ArrayListWrapper_get_IsSynchronized_m877742690,
	ArrayListWrapper_get_SyncRoot_m3460954073,
	ArrayListWrapper_Add_m1926015631,
	ArrayListWrapper_Clear_m2625302714,
	ArrayListWrapper_Contains_m2641184447,
	ArrayListWrapper_IndexOf_m4166445051,
	ArrayListWrapper_IndexOf_m3692065720,
	ArrayListWrapper_IndexOf_m3995939336,
	ArrayListWrapper_Insert_m121888774,
	ArrayListWrapper_InsertRange_m3525676562,
	ArrayListWrapper_Remove_m3759993909,
	ArrayListWrapper_RemoveAt_m805762255,
	ArrayListWrapper_CopyTo_m2912068327,
	ArrayListWrapper_CopyTo_m3756520478,
	ArrayListWrapper_CopyTo_m498486826,
	ArrayListWrapper_GetEnumerator_m2336495952,
	ArrayListWrapper_AddRange_m2748690765,
	ArrayListWrapper_Clone_m1058391593,
	ArrayListWrapper_Sort_m1587743350,
	ArrayListWrapper_Sort_m876172478,
	ArrayListWrapper_ToArray_m1192575409,
	ArrayListWrapper_ToArray_m3192696690,
	FixedSizeArrayListWrapper__ctor_m3150386652,
	FixedSizeArrayListWrapper_get_ErrorMessage_m3049061776,
	FixedSizeArrayListWrapper_get_Capacity_m484550855,
	FixedSizeArrayListWrapper_set_Capacity_m4221053039,
	FixedSizeArrayListWrapper_Add_m4066213493,
	FixedSizeArrayListWrapper_AddRange_m413351014,
	FixedSizeArrayListWrapper_Clear_m1544415003,
	FixedSizeArrayListWrapper_Insert_m723948816,
	FixedSizeArrayListWrapper_InsertRange_m1706982628,
	FixedSizeArrayListWrapper_Remove_m3827525800,
	FixedSizeArrayListWrapper_RemoveAt_m3591870267,
	ReadOnlyArrayListWrapper__ctor_m1527708879,
	ReadOnlyArrayListWrapper_get_ErrorMessage_m1121552994,
	ReadOnlyArrayListWrapper_get_IsReadOnly_m2332097348,
	ReadOnlyArrayListWrapper_get_Item_m2341088672,
	ReadOnlyArrayListWrapper_set_Item_m1909157432,
	ReadOnlyArrayListWrapper_Sort_m2577012511,
	ReadOnlyArrayListWrapper_Sort_m2022378864,
	SimpleEnumerator__ctor_m917940076,
	SimpleEnumerator__cctor_m2844299657,
	SimpleEnumerator_Clone_m936565740,
	SimpleEnumerator_MoveNext_m3113120129,
	SimpleEnumerator_get_Current_m2439519409,
	SimpleEnumerator_Reset_m1520014659,
	SynchronizedArrayListWrapper__ctor_m3368338124,
	SynchronizedArrayListWrapper_get_Item_m4084958564,
	SynchronizedArrayListWrapper_set_Item_m1979747874,
	SynchronizedArrayListWrapper_get_Count_m527215081,
	SynchronizedArrayListWrapper_get_Capacity_m603836496,
	SynchronizedArrayListWrapper_set_Capacity_m514089537,
	SynchronizedArrayListWrapper_get_IsReadOnly_m2240310664,
	SynchronizedArrayListWrapper_get_IsSynchronized_m3380436820,
	SynchronizedArrayListWrapper_get_SyncRoot_m3862302789,
	SynchronizedArrayListWrapper_Add_m1623408305,
	SynchronizedArrayListWrapper_Clear_m2191301493,
	SynchronizedArrayListWrapper_Contains_m3809499313,
	SynchronizedArrayListWrapper_IndexOf_m666666436,
	SynchronizedArrayListWrapper_IndexOf_m1028529531,
	SynchronizedArrayListWrapper_IndexOf_m3642674350,
	SynchronizedArrayListWrapper_Insert_m1867902338,
	SynchronizedArrayListWrapper_InsertRange_m2374130561,
	SynchronizedArrayListWrapper_Remove_m47731590,
	SynchronizedArrayListWrapper_RemoveAt_m122715760,
	SynchronizedArrayListWrapper_CopyTo_m2886332653,
	SynchronizedArrayListWrapper_CopyTo_m4207791406,
	SynchronizedArrayListWrapper_CopyTo_m1305044270,
	SynchronizedArrayListWrapper_GetEnumerator_m1579424644,
	SynchronizedArrayListWrapper_AddRange_m4141530892,
	SynchronizedArrayListWrapper_Clone_m1959734504,
	SynchronizedArrayListWrapper_Sort_m275448700,
	SynchronizedArrayListWrapper_Sort_m575592975,
	SynchronizedArrayListWrapper_ToArray_m2419932249,
	SynchronizedArrayListWrapper_ToArray_m1519105559,
	BitArray__ctor_m2765908219,
	BitArray__ctor_m52841262,
	BitArray_getByte_m2467886923,
	BitArray_get_Count_m3250012040,
	BitArray_get_Item_m2970562587,
	BitArray_set_Item_m3453667491,
	BitArray_get_Length_m3181964206,
	BitArray_get_SyncRoot_m680463907,
	BitArray_Clone_m3537018332,
	BitArray_CopyTo_m4205938202,
	BitArray_Get_m1610855460,
	BitArray_Set_m2486900776,
	BitArray_GetEnumerator_m1964744199,
	BitArrayEnumerator__ctor_m2359341397,
	BitArrayEnumerator_Clone_m2928080346,
	BitArrayEnumerator_get_Current_m4220391712,
	BitArrayEnumerator_MoveNext_m3806676766,
	BitArrayEnumerator_Reset_m2256666019,
	BitArrayEnumerator_checkVersion_m500404395,
	CaseInsensitiveComparer__ctor_m1508720200,
	CaseInsensitiveComparer__ctor_m2101975011,
	CaseInsensitiveComparer__cctor_m2727609021,
	CaseInsensitiveComparer_get_DefaultInvariant_m2155614047,
	CaseInsensitiveComparer_Compare_m1224120810,
	CaseInsensitiveHashCodeProvider__ctor_m1410573049,
	CaseInsensitiveHashCodeProvider__ctor_m3307631072,
	CaseInsensitiveHashCodeProvider__cctor_m3655208966,
	CaseInsensitiveHashCodeProvider_AreEqual_m1790260777,
	CaseInsensitiveHashCodeProvider_AreEqual_m3534448780,
	CaseInsensitiveHashCodeProvider_get_DefaultInvariant_m4264275163,
	CaseInsensitiveHashCodeProvider_GetHashCode_m2168170016,
	CollectionBase__ctor_m3343513710,
	CollectionBase_System_Collections_ICollection_CopyTo_m2850099809,
	CollectionBase_System_Collections_ICollection_get_SyncRoot_m1463722401,
	CollectionBase_System_Collections_IList_Add_m3784093852,
	CollectionBase_System_Collections_IList_Contains_m2994901969,
	CollectionBase_System_Collections_IList_IndexOf_m3655834224,
	CollectionBase_System_Collections_IList_Insert_m1955629979,
	CollectionBase_System_Collections_IList_Remove_m1918979845,
	CollectionBase_System_Collections_IList_get_Item_m3743372945,
	CollectionBase_System_Collections_IList_set_Item_m1592328081,
	CollectionBase_get_Count_m1708965601,
	CollectionBase_GetEnumerator_m654829872,
	CollectionBase_Clear_m1509125218,
	CollectionBase_RemoveAt_m3336462814,
	CollectionBase_get_InnerList_m132195395,
	CollectionBase_get_List_m490744407,
	CollectionBase_OnClear_m883003723,
	CollectionBase_OnClearComplete_m4210220284,
	CollectionBase_OnInsert_m120287429,
	CollectionBase_OnInsertComplete_m1538306973,
	CollectionBase_OnRemove_m3955998913,
	CollectionBase_OnRemoveComplete_m1811247246,
	CollectionBase_OnSet_m598471137,
	CollectionBase_OnSetComplete_m2395939597,
	CollectionBase_OnValidate_m1606907366,
	Comparer__ctor_m2831654082,
	Comparer__ctor_m2580215220,
	Comparer__cctor_m3311686689,
	Comparer_Compare_m3984347512,
	Comparer_GetObjectData_m2064315569,
	DictionaryEntry__ctor_m2585376310_AdjustorThunk,
	DictionaryEntry_get_Key_m3117378551_AdjustorThunk,
	DictionaryEntry_get_Value_m618120527_AdjustorThunk,
	KeyNotFoundException__ctor_m541499307,
	KeyNotFoundException__ctor_m2696589580,
	KeyNotFoundException__ctor_m813515407,
	Hashtable__ctor_m1815022027,
	Hashtable__ctor_m3491720775,
	Hashtable__ctor_m3542198234,
	Hashtable__ctor_m1684344284,
	Hashtable__ctor_m3890751112,
	Hashtable__ctor_m1763145853,
	Hashtable__ctor_m2421324048,
	Hashtable__ctor_m465544153,
	Hashtable__ctor_m2302711321,
	Hashtable__ctor_m1941859523,
	Hashtable__ctor_m3305570058,
	Hashtable__ctor_m1820371784,
	Hashtable__cctor_m4112166779,
	Hashtable_System_Collections_IEnumerable_GetEnumerator_m2751657639,
	Hashtable_set_comparer_m1969364857,
	Hashtable_set_hcp_m2582686174,
	Hashtable_get_Count_m3541651130,
	Hashtable_get_SyncRoot_m2370273929,
	Hashtable_get_Keys_m625158339,
	Hashtable_get_Values_m1643322147,
	Hashtable_get_Item_m2003685141,
	Hashtable_set_Item_m1120781262,
	Hashtable_CopyTo_m2905447224,
	Hashtable_Add_m157116935,
	Hashtable_Clear_m3112193608,
	Hashtable_Contains_m2145146412,
	Hashtable_GetEnumerator_m4240267690,
	Hashtable_Remove_m4032631466,
	Hashtable_ContainsKey_m2963904694,
	Hashtable_Clone_m3078962909,
	Hashtable_GetObjectData_m2584507417,
	Hashtable_OnDeserialization_m1032066502,
	Hashtable_Synchronized_m2228653257,
	Hashtable_GetHash_m3068611952,
	Hashtable_KeyEquals_m2549637027,
	Hashtable_AdjustThreshold_m3338727562,
	Hashtable_SetTable_m1520626497,
	Hashtable_Find_m1835111773,
	Hashtable_Rehash_m2389268722,
	Hashtable_PutImpl_m2485103604,
	Hashtable_CopyToArray_m320168007,
	Hashtable_TestPrime_m3839319309,
	Hashtable_CalcPrime_m550773117,
	Hashtable_ToPrime_m33531354,
	Enumerator__ctor_m3921352641,
	Enumerator__cctor_m4169372056,
	Enumerator_FailFast_m3955249002,
	Enumerator_Reset_m4274366540,
	Enumerator_MoveNext_m1474126172,
	Enumerator_get_Entry_m2184304359,
	Enumerator_get_Key_m2288024554,
	Enumerator_get_Value_m1047280424,
	Enumerator_get_Current_m2763018784,
	HashKeys__ctor_m2668698759,
	HashKeys_get_Count_m4206343425,
	HashKeys_get_SyncRoot_m3757723936,
	HashKeys_CopyTo_m4219627824,
	HashKeys_GetEnumerator_m3432430781,
	HashValues__ctor_m1651100305,
	HashValues_get_Count_m1050845476,
	HashValues_get_SyncRoot_m337642017,
	HashValues_CopyTo_m2621023127,
	HashValues_GetEnumerator_m2924783834,
	KeyMarker__ctor_m2295185526,
	KeyMarker__cctor_m2590194914,
	SyncHashtable__ctor_m988729399,
	SyncHashtable__ctor_m2449935938,
	SyncHashtable_System_Collections_IEnumerable_GetEnumerator_m1325482064,
	SyncHashtable_GetObjectData_m672594935,
	SyncHashtable_get_Count_m3689832098,
	SyncHashtable_get_SyncRoot_m2724224665,
	SyncHashtable_get_Keys_m1469437863,
	SyncHashtable_get_Values_m3820929471,
	SyncHashtable_get_Item_m2686606216,
	SyncHashtable_set_Item_m2451773607,
	SyncHashtable_CopyTo_m3934112540,
	SyncHashtable_Add_m3016107307,
	SyncHashtable_Clear_m714964133,
	SyncHashtable_Contains_m2292068165,
	SyncHashtable_GetEnumerator_m4254656826,
	SyncHashtable_Remove_m4179265271,
	SyncHashtable_ContainsKey_m4051091192,
	SyncHashtable_Clone_m3726939774,
	Queue__ctor_m2030580699,
	Queue__ctor_m2226872579,
	Queue__ctor_m3552486878,
	Queue__ctor_m2335855895,
	Queue_get_Count_m2065247734,
	Queue_get_SyncRoot_m3475037374,
	Queue_CopyTo_m737385843,
	Queue_GetEnumerator_m3623929043,
	Queue_Clone_m178259971,
	Queue_Clear_m898976850,
	Queue_Dequeue_m2397857002,
	Queue_Enqueue_m4206203487,
	Queue_Peek_m2705722908,
	Queue_grow_m873349987,
	QueueEnumerator__ctor_m611027847,
	QueueEnumerator_Clone_m1475796429,
	QueueEnumerator_get_Current_m2177760484,
	QueueEnumerator_MoveNext_m386897816,
	QueueEnumerator_Reset_m472154018,
	SortedList__ctor_m1261191695,
	SortedList__ctor_m4140760769,
	SortedList__ctor_m449121548,
	SortedList__ctor_m3676552745,
	SortedList__cctor_m1247132,
	SortedList_System_Collections_IEnumerable_GetEnumerator_m2738760439,
	SortedList_get_Count_m3860639970,
	SortedList_get_SyncRoot_m914428425,
	SortedList_get_IsFixedSize_m2192379219,
	SortedList_get_IsReadOnly_m1554442113,
	SortedList_get_Item_m3673863299,
	SortedList_set_Item_m32382988,
	SortedList_get_Capacity_m919184864,
	SortedList_set_Capacity_m509376950,
	SortedList_Add_m810900317,
	SortedList_Contains_m559482983,
	SortedList_GetEnumerator_m772783392,
	SortedList_Remove_m2784369438,
	SortedList_CopyTo_m3001281572,
	SortedList_Clone_m928094797,
	SortedList_RemoveAt_m1767403850,
	SortedList_IndexOfKey_m91331983,
	SortedList_ContainsKey_m2883715045,
	SortedList_GetByIndex_m3848565786,
	SortedList_EnsureCapacity_m1354099314,
	SortedList_PutImpl_m3408406199,
	SortedList_GetImpl_m3689246167,
	SortedList_InitTable_m875730861,
	SortedList_Find_m3363512987,
	Enumerator__ctor_m4264210349,
	Enumerator__cctor_m3377250123,
	Enumerator_Reset_m1367479817,
	Enumerator_MoveNext_m635366482,
	Enumerator_get_Entry_m3561948123,
	Enumerator_get_Key_m1796421380,
	Enumerator_get_Value_m3071982030,
	Enumerator_get_Current_m3370609987,
	Enumerator_Clone_m1942171085,
	Stack__ctor_m2907601956,
	Stack__ctor_m2602729586,
	Stack__ctor_m3503577671,
	Stack_Resize_m3124769495,
	Stack_get_Count_m2258661097,
	Stack_get_SyncRoot_m2243371357,
	Stack_Clear_m2010200235,
	Stack_Clone_m2625073663,
	Stack_CopyTo_m953825709,
	Stack_GetEnumerator_m2673437525,
	Stack_Peek_m2216191248,
	Stack_Pop_m4248134981,
	Stack_Push_m2529252115,
	Enumerator__ctor_m3362421874,
	Enumerator_Clone_m1203486474,
	Enumerator_get_Current_m2520471220,
	Enumerator_MoveNext_m3995713679,
	Enumerator_Reset_m2459931042,
	Console__cctor_m1860305256,
	Console_SetEncodings_m1501183766,
	Console_get_Error_m1839879495,
	Console_Open_m3077673205,
	Console_OpenStandardError_m294613724,
	Console_OpenStandardInput_m3262421490,
	Console_OpenStandardOutput_m1257556731,
	Console_SetOut_m286050082,
	ContextBoundObject__ctor_m308624197,
	Convert__cctor_m2847208289,
	Convert_InternalFromBase64String_m918800179,
	Convert_FromBase64String_m3685135396,
	Convert_ToBase64String_m3839334935,
	Convert_ToBase64String_m1959325926,
	Convert_ToBoolean_m2984378204,
	Convert_ToBoolean_m2694598181,
	Convert_ToBoolean_m4098720762,
	Convert_ToBoolean_m4244349331,
	Convert_ToBoolean_m2833489984,
	Convert_ToBoolean_m2833621053,
	Convert_ToBoolean_m40300963,
	Convert_ToBoolean_m2833752130,
	Convert_ToBoolean_m3588715767,
	Convert_ToBoolean_m2807110707,
	Convert_ToBoolean_m3613483153,
	Convert_ToBoolean_m481380807,
	Convert_ToBoolean_m2072772931,
	Convert_ToBoolean_m4120735400,
	Convert_ToByte_m306367912,
	Convert_ToByte_m143827699,
	Convert_ToByte_m4214436835,
	Convert_ToByte_m3824130483,
	Convert_ToByte_m4146281512,
	Convert_ToByte_m1734770211,
	Convert_ToByte_m2122266396,
	Convert_ToByte_m1442000130,
	Convert_ToByte_m1336644845,
	Convert_ToByte_m1779682469,
	Convert_ToByte_m3367409178,
	Convert_ToByte_m1993550870,
	Convert_ToByte_m3567528984,
	Convert_ToByte_m2375887898,
	Convert_ToByte_m3527805587,
	Convert_ToChar_m2532412511,
	Convert_ToChar_m4189066566,
	Convert_ToChar_m4210014069,
	Convert_ToChar_m2522572389,
	Convert_ToChar_m3776556379,
	Convert_ToChar_m2261593104,
	Convert_ToChar_m1442101407,
	Convert_ToChar_m2796006345,
	Convert_ToChar_m1604365259,
	Convert_ToChar_m3178343373,
	Convert_ToChar_m3757390865,
	Convert_ToDateTime_m3802186295,
	Convert_ToDateTime_m626620011,
	Convert_ToDateTime_m228494645,
	Convert_ToDateTime_m2616935982,
	Convert_ToDateTime_m1800003024,
	Convert_ToDateTime_m1567637286,
	Convert_ToDateTime_m296553984,
	Convert_ToDateTime_m649137482,
	Convert_ToDateTime_m1031474510,
	Convert_ToDateTime_m3752463692,
	Convert_ToDecimal_m2233265097,
	Convert_ToDecimal_m3209124080,
	Convert_ToDecimal_m1783778724,
	Convert_ToDecimal_m841368097,
	Convert_ToDecimal_m3508035522,
	Convert_ToDecimal_m1284148187,
	Convert_ToDecimal_m1284279264,
	Convert_ToDecimal_m996138310,
	Convert_ToDecimal_m1284410333,
	Convert_ToDecimal_m1233667008,
	Convert_ToDecimal_m889385228,
	Convert_ToDecimal_m1695757674,
	Convert_ToDecimal_m2858622624,
	Convert_ToDecimal_m3815908452,
	Convert_ToDouble_m954895424,
	Convert_ToDouble_m3124823876,
	Convert_ToDouble_m1177445661,
	Convert_ToDouble_m278900635,
	Convert_ToDouble_m217737046,
	Convert_ToDouble_m2924063577,
	Convert_ToDouble_m2180337032,
	Convert_ToDouble_m2949593046,
	Convert_ToDouble_m996590115,
	Convert_ToDouble_m2291761709,
	Convert_ToDouble_m2222536920,
	Convert_ToDouble_m1030895834,
	Convert_ToDouble_m1840199900,
	Convert_ToDouble_m4017511472,
	Convert_ToInt16_m3324557887,
	Convert_ToInt16_m701474428,
	Convert_ToInt16_m3018161032,
	Convert_ToInt16_m2763665794,
	Convert_ToInt16_m2780199356,
	Convert_ToInt16_m1336719169,
	Convert_ToInt16_m4174308322,
	Convert_ToInt16_m4174439391,
	Convert_ToInt16_m155265449,
	Convert_ToInt16_m4174570464,
	Convert_ToInt16_m3185404879,
	Convert_ToInt16_m571189957,
	Convert_ToInt16_m1733792763,
	Convert_ToInt16_m2896657713,
	Convert_ToInt16_m198393465,
	Convert_ToInt16_m1223489986,
	Convert_ToInt32_m2100527582,
	Convert_ToInt32_m2505564049,
	Convert_ToInt32_m1876369743,
	Convert_ToInt32_m3048308591,
	Convert_ToInt32_m2880498116,
	Convert_ToInt32_m1613163543,
	Convert_ToInt32_m1085875835,
	Convert_ToInt32_m1405693041,
	Convert_ToInt32_m1085744762,
	Convert_ToInt32_m2128774575,
	Convert_ToInt32_m3956995719,
	Convert_ToInt32_m825155517,
	Convert_ToInt32_m1987758323,
	Convert_ToInt32_m2608095889,
	Convert_ToInt32_m3211312035,
	Convert_ToInt64_m2812720657,
	Convert_ToInt64_m395638860,
	Convert_ToInt64_m3122543124,
	Convert_ToInt64_m4082637156,
	Convert_ToInt64_m3758262873,
	Convert_ToInt64_m658295522,
	Convert_ToInt64_m2075293963,
	Convert_ToInt64_m2075162888,
	Convert_ToInt64_m3916071102,
	Convert_ToInt64_m2075031821,
	Convert_ToInt64_m4087101237,
	Convert_ToInt64_m2849840611,
	Convert_ToInt64_m3392013556,
	Convert_ToInt64_m260173354,
	Convert_ToInt64_m1422776160,
	Convert_ToInt64_m3240678588,
	Convert_ToInt64_m2643251823,
	Convert_ToSByte_m3284376536,
	Convert_ToSByte_m717245755,
	Convert_ToSByte_m1350241137,
	Convert_ToSByte_m2991657475,
	Convert_ToSByte_m3796870839,
	Convert_ToSByte_m3472794164,
	Convert_ToSByte_m2653418303,
	Convert_ToSByte_m2653811524,
	Convert_ToSByte_m2653680449,
	Convert_ToSByte_m4075629912,
	Convert_ToSByte_m2486156346,
	Convert_ToSByte_m1679390684,
	Convert_ToSByte_m516918950,
	Convert_ToSByte_m4061885981,
	Convert_ToSingle_m1386109941,
	Convert_ToSingle_m2769033141,
	Convert_ToSingle_m1389817074,
	Convert_ToSingle_m3227075028,
	Convert_ToSingle_m835189399,
	Convert_ToSingle_m3635698920,
	Convert_ToSingle_m2891972375,
	Convert_ToSingle_m164367433,
	Convert_ToSingle_m4033824286,
	Convert_ToSingle_m2533452644,
	Convert_ToSingle_m3983149863,
	Convert_ToSingle_m2791508777,
	Convert_ToSingle_m3600812843,
	Convert_ToSingle_m3605848385,
	Convert_ToString_m2219349533,
	Convert_ToString_m1854379141,
	Convert_ToUInt16_m3116648921,
	Convert_ToUInt16_m4064261444,
	Convert_ToUInt16_m2952781888,
	Convert_ToUInt16_m867476252,
	Convert_ToUInt16_m3523269149,
	Convert_ToUInt16_m2185524030,
	Convert_ToUInt16_m3515425647,
	Convert_ToUInt16_m3902921832,
	Convert_ToUInt16_m3736443170,
	Convert_ToUInt16_m1147931813,
	Convert_ToUInt16_m3216249716,
	Convert_ToUInt16_m1480956416,
	Convert_ToUInt16_m2672597498,
	Convert_ToUInt16_m4211508274,
	Convert_ToUInt32_m835119716,
	Convert_ToUInt32_m360864467,
	Convert_ToUInt32_m3188121845,
	Convert_ToUInt32_m3622072499,
	Convert_ToUInt32_m1453583008,
	Convert_ToUInt32_m2045194461,
	Convert_ToUInt32_m2215525276,
	Convert_ToUInt32_m2194577773,
	Convert_ToUInt32_m3592050311,
	Convert_ToUInt32_m4142998738,
	Convert_ToUInt32_m3920761395,
	Convert_ToUInt32_m1767593911,
	Convert_ToUInt32_m193615797,
	Convert_ToUInt32_m2061619287,
	Convert_ToUInt64_m2343585091,
	Convert_ToUInt64_m2652538228,
	Convert_ToUInt64_m3102114524,
	Convert_ToUInt64_m92315402,
	Convert_ToUInt64_m1433697267,
	Convert_ToUInt64_m1627266664,
	Convert_ToUInt64_m786726853,
	Convert_ToUInt64_m409548990,
	Convert_ToUInt64_m473526756,
	Convert_ToUInt64_m388601487,
	Convert_ToUInt64_m2629133713,
	Convert_ToUInt64_m1745056470,
	Convert_ToUInt64_m1362719450,
	Convert_ToUInt64_m1841050714,
	Convert_ToUInt64_m3170916409,
	Convert_ChangeType_m739676612,
	Convert_ToType_m2406080310,
	CultureAwareComparer__ctor_m3981913244,
	CultureAwareComparer_Compare_m1644833365,
	CultureAwareComparer_Equals_m710929189,
	CultureAwareComparer_GetHashCode_m1902485640,
	CurrentSystemTimeZone__ctor_m4046394832,
	CurrentSystemTimeZone__ctor_m4224169966,
	CurrentSystemTimeZone_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3815140570,
	CurrentSystemTimeZone_GetTimeZoneData_m2641861607,
	CurrentSystemTimeZone_GetDaylightChanges_m2394763749,
	CurrentSystemTimeZone_GetUtcOffset_m340358963,
	CurrentSystemTimeZone_OnDeserialization_m3711380055,
	CurrentSystemTimeZone_GetDaylightTimeFromData_m2196414210,
	DBNull__ctor_m3264522145,
	DBNull__ctor_m3431698857,
	DBNull__cctor_m1221711106,
	DBNull_System_IConvertible_ToBoolean_m702787761,
	DBNull_System_IConvertible_ToByte_m3625770190,
	DBNull_System_IConvertible_ToChar_m4140628367,
	DBNull_System_IConvertible_ToDateTime_m3633350356,
	DBNull_System_IConvertible_ToDecimal_m1883582283,
	DBNull_System_IConvertible_ToDouble_m150664744,
	DBNull_System_IConvertible_ToInt16_m4228856009,
	DBNull_System_IConvertible_ToInt32_m4178834757,
	DBNull_System_IConvertible_ToInt64_m3889862579,
	DBNull_System_IConvertible_ToSByte_m3533624679,
	DBNull_System_IConvertible_ToSingle_m13713620,
	DBNull_System_IConvertible_ToType_m145027518,
	DBNull_System_IConvertible_ToUInt16_m643477279,
	DBNull_System_IConvertible_ToUInt32_m3784627971,
	DBNull_System_IConvertible_ToUInt64_m4072736670,
	DBNull_GetObjectData_m560064731,
	DBNull_ToString_m3638608738,
	DBNull_ToString_m1318017576,
	DateTime__ctor_m516789325_AdjustorThunk,
	DateTime__ctor_m12900168_AdjustorThunk,
	DateTime__ctor_m3895589019_AdjustorThunk,
	DateTime__ctor_m2030998145_AdjustorThunk,
	DateTime__ctor_m2135476686_AdjustorThunk,
	DateTime__ctor_m1095105629_AdjustorThunk,
	DateTime__ctor_m2956360140_AdjustorThunk,
	DateTime__cctor_m1880035693,
	DateTime_System_IConvertible_ToBoolean_m3229932458_AdjustorThunk,
	DateTime_System_IConvertible_ToByte_m3025810066_AdjustorThunk,
	DateTime_System_IConvertible_ToChar_m197318076_AdjustorThunk,
	DateTime_System_IConvertible_ToDateTime_m616366890_AdjustorThunk,
	DateTime_System_IConvertible_ToDecimal_m1044850612_AdjustorThunk,
	DateTime_System_IConvertible_ToDouble_m2116720007_AdjustorThunk,
	DateTime_System_IConvertible_ToInt16_m3239820399_AdjustorThunk,
	DateTime_System_IConvertible_ToInt32_m340560789_AdjustorThunk,
	DateTime_System_IConvertible_ToInt64_m850544508_AdjustorThunk,
	DateTime_System_IConvertible_ToSByte_m4130251280_AdjustorThunk,
	DateTime_System_IConvertible_ToSingle_m2193708681_AdjustorThunk,
	DateTime_System_IConvertible_ToType_m1242864300_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt16_m4182197229_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt32_m3781235049_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt64_m2275741153_AdjustorThunk,
	DateTime_AbsoluteDays_m4235097773,
	DateTime_FromTicks_m4059645178_AdjustorThunk,
	DateTime_get_Month_m1566006993_AdjustorThunk,
	DateTime_get_Day_m1623500273_AdjustorThunk,
	DateTime_get_DayOfWeek_m2326490739_AdjustorThunk,
	DateTime_get_Hour_m4153505178_AdjustorThunk,
	DateTime_get_Minute_m87527789_AdjustorThunk,
	DateTime_get_Second_m2686182256_AdjustorThunk,
	DateTime_GetTimeMonotonic_m2320662727,
	DateTime_GetNow_m1268643815,
	DateTime_get_Now_m1277138875,
	DateTime_get_Ticks_m1550640881_AdjustorThunk,
	DateTime_get_Today_m2788644320,
	DateTime_get_UtcNow_m1393945741,
	DateTime_get_Year_m1184003812_AdjustorThunk,
	DateTime_get_Kind_m2154871796_AdjustorThunk,
	DateTime_Add_m2995894549_AdjustorThunk,
	DateTime_AddTicks_m3396580426_AdjustorThunk,
	DateTime_AddMilliseconds_m3713972790_AdjustorThunk,
	DateTime_AddSeconds_m332574389_AdjustorThunk,
	DateTime_Compare_m2855073242,
	DateTime_CompareTo_m3687348273_AdjustorThunk,
	DateTime_CompareTo_m3889078633_AdjustorThunk,
	DateTime_Equals_m4001498422_AdjustorThunk,
	DateTime_ToBinary_m1193069875_AdjustorThunk,
	DateTime_FromBinary_m2489276715,
	DateTime_SpecifyKind_m3332658812,
	DateTime_DaysInMonth_m2587936260,
	DateTime_Equals_m611432332_AdjustorThunk,
	DateTime_CheckDateTimeKind_m456577410_AdjustorThunk,
	DateTime_GetHashCode_m2261847002_AdjustorThunk,
	DateTime_IsLeapYear_m1852497299,
	DateTime_Parse_m3729096069,
	DateTime_Parse_m1070804416,
	DateTime_CoreParse_m428043272,
	DateTime_YearMonthDayFormats_m827415370,
	DateTime__ParseNumber_m1240316250,
	DateTime__ParseEnum_m253019513,
	DateTime__ParseString_m2913931606,
	DateTime__ParseAmPm_m3478436123,
	DateTime__ParseTimeSeparator_m2659275695,
	DateTime__ParseDateSeparator_m1803046501,
	DateTime_IsLetter_m156019844,
	DateTime__DoParse_m552486664,
	DateTime_ParseExact_m2711902273,
	DateTime_ParseExact_m1132380469,
	DateTime_CheckStyle_m1392838900,
	DateTime_ParseExact_m317338046,
	DateTime_Subtract_m3522513701_AdjustorThunk,
	DateTime_ToString_m884486936_AdjustorThunk,
	DateTime_ToString_m1916142975_AdjustorThunk,
	DateTime_ToString_m2992030064_AdjustorThunk,
	DateTime_ToLocalTime_m3134475597_AdjustorThunk,
	DateTime_ToUniversalTime_m1945318289_AdjustorThunk,
	DateTime_op_Addition_m1857121695,
	DateTime_op_Equality_m1022058599,
	DateTime_op_GreaterThan_m3768590082,
	DateTime_op_GreaterThanOrEqual_m674703316,
	DateTime_op_Inequality_m1382517918,
	DateTime_op_LessThan_m2497205152,
	DateTime_op_LessThanOrEqual_m2360948759,
	DateTime_op_Subtraction_m3579235380,
	DateTime_op_Subtraction_m529926081,
	DateTimeOffset__ctor_m2084804982_AdjustorThunk,
	DateTimeOffset__ctor_m74032857_AdjustorThunk,
	DateTimeOffset__ctor_m1464148220_AdjustorThunk,
	DateTimeOffset__ctor_m2611141592_AdjustorThunk,
	DateTimeOffset__cctor_m3610253033,
	DateTimeOffset_System_IComparable_CompareTo_m176229495_AdjustorThunk,
	DateTimeOffset_System_Runtime_Serialization_ISerializable_GetObjectData_m738492442_AdjustorThunk,
	DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m592821093_AdjustorThunk,
	DateTimeOffset_CompareTo_m1350732322_AdjustorThunk,
	DateTimeOffset_Equals_m605268013_AdjustorThunk,
	DateTimeOffset_Equals_m3030958070_AdjustorThunk,
	DateTimeOffset_GetHashCode_m2209105223_AdjustorThunk,
	DateTimeOffset_ToString_m3536563014_AdjustorThunk,
	DateTimeOffset_ToString_m3985341516_AdjustorThunk,
	DateTimeOffset_get_DateTime_m620985777_AdjustorThunk,
	DateTimeOffset_get_Offset_m2040541042_AdjustorThunk,
	DateTimeOffset_get_UtcDateTime_m1021718282_AdjustorThunk,
	DateTimeUtils_CountRepeat_m3396693018,
	DateTimeUtils_ZeroPad_m1132893640,
	DateTimeUtils_ParseQuotedString_m2573610321,
	DateTimeUtils_GetStandardPattern_m728910817,
	DateTimeUtils_GetStandardPattern_m813010822,
	DateTimeUtils_ToString_m93951406,
	DateTimeUtils_ToString_m1782212840,
	Decimal__ctor_m3650533794_AdjustorThunk,
	Decimal__ctor_m1256289983_AdjustorThunk,
	Decimal__ctor_m572982025_AdjustorThunk,
	Decimal__ctor_m450048609_AdjustorThunk,
	Decimal__ctor_m593929528_AdjustorThunk,
	Decimal__ctor_m1925875020_AdjustorThunk,
	Decimal__ctor_m1842485920_AdjustorThunk,
	Decimal__cctor_m834667025,
	Decimal_System_IConvertible_ToType_m2919262279_AdjustorThunk,
	Decimal_System_IConvertible_ToBoolean_m1123794670_AdjustorThunk,
	Decimal_System_IConvertible_ToByte_m1059182322_AdjustorThunk,
	Decimal_System_IConvertible_ToChar_m2248324273_AdjustorThunk,
	Decimal_System_IConvertible_ToDateTime_m106179626_AdjustorThunk,
	Decimal_System_IConvertible_ToDecimal_m2403239382_AdjustorThunk,
	Decimal_System_IConvertible_ToDouble_m3125524987_AdjustorThunk,
	Decimal_System_IConvertible_ToInt16_m1574696763_AdjustorThunk,
	Decimal_System_IConvertible_ToInt32_m1488426794_AdjustorThunk,
	Decimal_System_IConvertible_ToInt64_m1446427516_AdjustorThunk,
	Decimal_System_IConvertible_ToSByte_m1299038473_AdjustorThunk,
	Decimal_System_IConvertible_ToSingle_m1019108991_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt16_m1185974300_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt32_m4224836830_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt64_m1323635232_AdjustorThunk,
	Decimal_GetBits_m453754410,
	Decimal_Add_m114360190,
	Decimal_Subtract_m835601464,
	Decimal_GetHashCode_m2838600885_AdjustorThunk,
	Decimal_u64_m3374804932,
	Decimal_s64_m309158181,
	Decimal_Equals_m3759456653,
	Decimal_Equals_m2592017260_AdjustorThunk,
	Decimal_IsZero_m4250358244_AdjustorThunk,
	Decimal_Floor_m1786329488,
	Decimal_Multiply_m462893147,
	Decimal_Divide_m3489391442,
	Decimal_Compare_m3062820418,
	Decimal_CompareTo_m3345610437_AdjustorThunk,
	Decimal_CompareTo_m3502307243_AdjustorThunk,
	Decimal_Equals_m2486655999_AdjustorThunk,
	Decimal_Parse_m4154418249,
	Decimal_ThrowAtPos_m1170269346,
	Decimal_ThrowInvalidExp_m818482357,
	Decimal_stripStyles_m1823381019,
	Decimal_Parse_m942471224,
	Decimal_PerformParse_m1679987175,
	Decimal_ToString_m14270257_AdjustorThunk,
	Decimal_ToString_m4018746482_AdjustorThunk,
	Decimal_ToString_m1815393864_AdjustorThunk,
	Decimal_ToString_m3653216873_AdjustorThunk,
	Decimal_decimal2UInt64_m3460477816,
	Decimal_decimal2Int64_m2102545213,
	Decimal_decimalIncr_m1887017143,
	Decimal_string2decimal_m207208267,
	Decimal_decimalSetExponent_m3707787243,
	Decimal_decimal2double_m2573538823,
	Decimal_decimalFloorAndTrunc_m3496207836,
	Decimal_decimalMult_m3812462972,
	Decimal_decimalDiv_m3235226503,
	Decimal_decimalCompare_m3796132203,
	Decimal_op_Increment_m2045993911,
	Decimal_op_Subtraction_m2530510375,
	Decimal_op_Multiply_m2389849621,
	Decimal_op_Division_m2407964042,
	Decimal_op_Explicit_m2848387298,
	Decimal_op_Explicit_m1824467517,
	Decimal_op_Explicit_m4231101593,
	Decimal_op_Explicit_m3716368008,
	Decimal_op_Explicit_m1842265407,
	Decimal_op_Explicit_m1639916169,
	Decimal_op_Explicit_m438967917,
	Decimal_op_Explicit_m1503081942,
	Decimal_op_Implicit_m29414198,
	Decimal_op_Implicit_m1920400487,
	Decimal_op_Implicit_m3696395396,
	Decimal_op_Implicit_m4256234411,
	Decimal_op_Implicit_m1328901562,
	Decimal_op_Implicit_m3873897383,
	Decimal_op_Implicit_m1349849065,
	Decimal_op_Implicit_m2299919277,
	Decimal_op_Explicit_m2070069477,
	Decimal_op_Explicit_m2433293820,
	Decimal_op_Explicit_m3488287464,
	Decimal_op_Explicit_m2816896069,
	Decimal_op_Inequality_m3543190500,
	Decimal_op_Equality_m77262825,
	Decimal_op_GreaterThan_m627311519,
	Decimal_op_LessThan_m1273833514,
	Delegate_get_Method_m3071622864,
	Delegate_get_Target_m2361978888,
	Delegate_CreateDelegate_internal_m2845516975,
	Delegate_SetMulticastInvoke_m342000618,
	Delegate_arg_type_match_m870692501,
	Delegate_return_type_match_m2309328069,
	Delegate_CreateDelegate_m2386636647,
	Delegate_CreateDelegate_m995503480,
	Delegate_CreateDelegate_m1051651521,
	Delegate_CreateDelegate_m1406740088,
	Delegate_GetCandidateMethod_m640765260,
	Delegate_CreateDelegate_m466794306,
	Delegate_CreateDelegate_m441173131,
	Delegate_CreateDelegate_m819160572,
	Delegate_CreateDelegate_m4052969428,
	Delegate_Clone_m4001596073,
	Delegate_Equals_m821895546,
	Delegate_GetHashCode_m2102814970,
	Delegate_GetObjectData_m4107455684,
	Delegate_GetInvocationList_m592727217,
	Delegate_Combine_m1859655160,
	Delegate_Combine_m558799649,
	Delegate_CombineImpl_m3572135514,
	Delegate_Remove_m334097152,
	Delegate_RemoveImpl_m1108247463,
	DelegateSerializationHolder__ctor_m23226427,
	DelegateSerializationHolder_GetDelegateData_m2109044103,
	DelegateSerializationHolder_GetObjectData_m2622911689,
	DelegateSerializationHolder_GetRealObject_m3777783762,
	DelegateEntry__ctor_m1541339220,
	DelegateEntry_DeserializeDelegate_m691980016,
	DebuggableAttribute__ctor_m3124850944,
	DebuggerBrowsableAttribute__ctor_m28117720,
	DebuggerDisplayAttribute__ctor_m2387841105,
	DebuggerDisplayAttribute_set_Name_m615572732,
	DebuggerHiddenAttribute__ctor_m2764625696,
	DebuggerStepThroughAttribute__ctor_m2219434937,
	DebuggerTypeProxyAttribute__ctor_m3663763196,
	StackFrame__ctor_m343464319,
	StackFrame__ctor_m2610717164,
	StackFrame_get_frame_info_m2312611643,
	StackFrame_GetFileLineNumber_m1986974137,
	StackFrame_GetFileName_m3683503392,
	StackFrame_GetSecureFileName_m1124504902,
	StackFrame_GetILOffset_m1850960982,
	StackFrame_GetMethod_m1395840764,
	StackFrame_GetNativeOffset_m4140370738,
	StackFrame_GetInternalMethodName_m1232559961,
	StackFrame_ToString_m431970945,
	StackTrace__ctor_m206492268,
	StackTrace__ctor_m1685176557,
	StackTrace__ctor_m727500069,
	StackTrace__ctor_m3410750278,
	StackTrace__ctor_m2642163899,
	StackTrace_init_frames_m641783388,
	StackTrace_get_trace_m1194606084,
	StackTrace_get_FrameCount_m344690939,
	StackTrace_GetFrame_m3844938190,
	StackTrace_ToString_m1758556626,
	DivideByZeroException__ctor_m3496959969,
	DivideByZeroException__ctor_m3315083383,
	DllNotFoundException__ctor_m3079838043,
	DllNotFoundException__ctor_m1156705135,
	Double_System_IConvertible_ToType_m1438630475_AdjustorThunk,
	Double_System_IConvertible_ToBoolean_m652944629_AdjustorThunk,
	Double_System_IConvertible_ToByte_m410894149_AdjustorThunk,
	Double_System_IConvertible_ToChar_m285688079_AdjustorThunk,
	Double_System_IConvertible_ToDateTime_m2414543049_AdjustorThunk,
	Double_System_IConvertible_ToDecimal_m2316246766_AdjustorThunk,
	Double_System_IConvertible_ToDouble_m3692611612_AdjustorThunk,
	Double_System_IConvertible_ToInt16_m3591921965_AdjustorThunk,
	Double_System_IConvertible_ToInt32_m2896275711_AdjustorThunk,
	Double_System_IConvertible_ToInt64_m3968660899_AdjustorThunk,
	Double_System_IConvertible_ToSByte_m341638588_AdjustorThunk,
	Double_System_IConvertible_ToSingle_m4088557181_AdjustorThunk,
	Double_System_IConvertible_ToUInt16_m4132603953_AdjustorThunk,
	Double_System_IConvertible_ToUInt32_m271206838_AdjustorThunk,
	Double_System_IConvertible_ToUInt64_m3220586809_AdjustorThunk,
	Double_CompareTo_m2275617179_AdjustorThunk,
	Double_Equals_m1674752021_AdjustorThunk,
	Double_CompareTo_m3151899116_AdjustorThunk,
	Double_Equals_m2309369974_AdjustorThunk,
	Double_GetHashCode_m2295714610_AdjustorThunk,
	Double_IsInfinity_m820013146,
	Double_IsNaN_m649024406,
	Double_IsNegativeInfinity_m538614603,
	Double_IsPositiveInfinity_m1245619811,
	Double_Parse_m4153729520,
	Double_Parse_m3456374109,
	Double_Parse_m1135962389,
	Double_Parse_m2152196909,
	Double_TryParseStringConstant_m3290212599,
	Double_ParseImpl_m3514935432,
	Double_ToString_m1229922074_AdjustorThunk,
	Double_ToString_m3828879243_AdjustorThunk,
	Double_ToString_m1051753975_AdjustorThunk,
	EntryPointNotFoundException__ctor_m4137625441,
	EntryPointNotFoundException__ctor_m1278765702,
	Enum__ctor_m3602080049,
	Enum__cctor_m2925047542,
	Enum_System_IConvertible_ToBoolean_m1977632688,
	Enum_System_IConvertible_ToByte_m1219166845,
	Enum_System_IConvertible_ToChar_m3901971946,
	Enum_System_IConvertible_ToDateTime_m3823814707,
	Enum_System_IConvertible_ToDecimal_m3435237785,
	Enum_System_IConvertible_ToDouble_m440464077,
	Enum_System_IConvertible_ToInt16_m2887101011,
	Enum_System_IConvertible_ToInt32_m2383479183,
	Enum_System_IConvertible_ToInt64_m3491891092,
	Enum_System_IConvertible_ToSByte_m779472798,
	Enum_System_IConvertible_ToSingle_m1234919892,
	Enum_System_IConvertible_ToType_m2699994218,
	Enum_System_IConvertible_ToUInt16_m4216751959,
	Enum_System_IConvertible_ToUInt32_m2421368233,
	Enum_System_IConvertible_ToUInt64_m2641010424,
	Enum_GetTypeCode_m3381045179,
	Enum_get_value_m3943994903,
	Enum_get_Value_m3943993911,
	Enum_FindPosition_m1093426213,
	Enum_GetName_m2151614395,
	Enum_IsDefined_m1442314461,
	Enum_get_underlying_type_m267913430,
	Enum_GetUnderlyingType_m2480312097,
	Enum_FindName_m293338090,
	Enum_GetValue_m3535945367,
	Enum_Parse_m1579637477,
	Enum_compare_value_to_m1105953270,
	Enum_CompareTo_m4158304618,
	Enum_ToString_m2240012010,
	Enum_ToString_m3124963174,
	Enum_ToString_m2477889358,
	Enum_ToString_m3248653065,
	Enum_ToObject_m1949662789,
	Enum_ToObject_m3092348831,
	Enum_ToObject_m2710011811,
	Enum_ToObject_m1136033697,
	Enum_ToObject_m1628250250,
	Enum_ToObject_m26687919,
	Enum_ToObject_m121962870,
	Enum_ToObject_m122225012,
	Enum_ToObject_m121831801,
	Enum_Equals_m3617313991,
	Enum_get_hashcode_m902175016,
	Enum_GetHashCode_m2848082716,
	Enum_FormatSpecifier_X_m2932245600,
	Enum_FormatFlags_m102703041,
	Enum_Format_m2588135982,
	Environment_get_SocketSecurityEnabled_m190813817,
	Environment_get_NewLine_m3211016485,
	Environment_get_Platform_m520224871,
	Environment_GetOSVersionString_m407782784,
	Environment_get_OSVersion_m961136977,
	Environment_get_TickCount_m2088073110,
	Environment_internalGetEnvironmentVariable_m3668851860,
	Environment_GetEnvironmentVariable_m394552009,
	Environment_GetWindowsFolderPath_m1738399646,
	Environment_GetFolderPath_m327623990,
	Environment_ReadXdgUserDir_m2654856189,
	Environment_InternalGetFolderPath_m468390978,
	Environment_get_IsRunningOnWindows_m1804804030,
	Environment_GetMachineConfigPath_m43519138,
	Environment_internalGetHome_m2575860206,
	EventArgs__ctor_m32674013,
	EventArgs__cctor_m1889823314,
	EventHandler__ctor_m3449229857,
	EventHandler_Invoke_m2047579917,
	EventHandler_BeginInvoke_m829877076,
	EventHandler_EndInvoke_m269746120,
	Exception__ctor_m213470898,
	Exception__ctor_m1152696503,
	Exception__ctor_m2499432361,
	Exception__ctor_m1406832249,
	Exception_get_InnerException_m3836775,
	Exception_get_HResult_m1877758991,
	Exception_set_HResult_m3489164646,
	Exception_get_ClassName_m2428844642,
	Exception_get_Message_m3320461627,
	Exception_get_Source_m2777609286,
	Exception_get_StackTrace_m1954706653,
	Exception_GetObjectData_m1103241326,
	Exception_ToString_m1413572637,
	Exception_GetFullNameForStackTrace_m2634641773,
	Exception_GetType_m2227967756,
	ExecutionEngineException__ctor_m4205817610,
	ExecutionEngineException__ctor_m913194968,
	ExecutionEngineException__ctor_m673563413,
	FieldAccessException__ctor_m3583219052,
	FieldAccessException__ctor_m3482795704,
	FieldAccessException__ctor_m2776896078,
	FlagsAttribute__ctor_m2686422840,
	FormatException__ctor_m1479314061,
	FormatException__ctor_m4049685996,
	FormatException__ctor_m3747066592,
	GC_SuppressFinalize_m1177400158,
	CCFixed_FromDateTime_m3894190577,
	CCFixed_day_of_week_m674639858,
	CCGregorianCalendar_is_leap_year_m2193335769,
	CCGregorianCalendar_fixed_from_dmy_m806432533,
	CCGregorianCalendar_year_from_fixed_m463929682,
	CCGregorianCalendar_my_from_fixed_m715151395,
	CCGregorianCalendar_dmy_from_fixed_m494173177,
	CCGregorianCalendar_month_from_fixed_m4268992710,
	CCGregorianCalendar_day_from_fixed_m1674702403,
	CCGregorianCalendar_GetDayOfMonth_m1578922674,
	CCGregorianCalendar_GetMonth_m1547203696,
	CCGregorianCalendar_GetYear_m1605108522,
	CCMath_div_m3792567336,
	CCMath_mod_m3631663509,
	CCMath_div_mod_m348500398,
	Calendar__ctor_m106290643,
	Calendar_Clone_m1356182658,
	Calendar_CheckReadOnly_m519800900,
	Calendar_get_EraNames_m2754466818,
	CompareInfo__ctor_m3782165035,
	CompareInfo__ctor_m1655607648,
	CompareInfo__cctor_m1837489679,
	CompareInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m734465833,
	CompareInfo_get_UseManagedCollation_m3599558938,
	CompareInfo_construct_compareinfo_m509660150,
	CompareInfo_free_internal_collator_m2341193055,
	CompareInfo_internal_compare_m2522722857,
	CompareInfo_assign_sortkey_m2100240770,
	CompareInfo_internal_index_m2592793775,
	CompareInfo_Finalize_m404687489,
	CompareInfo_internal_compare_managed_m718834345,
	CompareInfo_internal_compare_switch_m1882891666,
	CompareInfo_Compare_m894311506,
	CompareInfo_Compare_m1980361250,
	CompareInfo_Compare_m1030179556,
	CompareInfo_Equals_m1257808801,
	CompareInfo_GetHashCode_m912891044,
	CompareInfo_GetSortKey_m1915852346,
	CompareInfo_IndexOf_m2631915198,
	CompareInfo_internal_index_managed_m2912760462,
	CompareInfo_internal_index_switch_m2232588269,
	CompareInfo_IndexOf_m667936183,
	CompareInfo_IsPrefix_m796715920,
	CompareInfo_IsSuffix_m1571711387,
	CompareInfo_LastIndexOf_m2688553706,
	CompareInfo_LastIndexOf_m3774208875,
	CompareInfo_ToString_m2684143229,
	CompareInfo_get_LCID_m2851766819,
	CultureInfo__ctor_m2628215565,
	CultureInfo__ctor_m3285927757,
	CultureInfo__ctor_m385185322,
	CultureInfo__ctor_m1132565265,
	CultureInfo__ctor_m1510335716,
	CultureInfo__cctor_m1258429074,
	CultureInfo_get_InvariantCulture_m3532445182,
	CultureInfo_get_CurrentCulture_m1632690660,
	CultureInfo_get_CurrentUICulture_m959203371,
	CultureInfo_ConstructCurrentCulture_m2704365233,
	CultureInfo_ConstructCurrentUICulture_m3439838233,
	CultureInfo_get_Territory_m3971126713,
	CultureInfo_get_LCID_m3475551012,
	CultureInfo_get_Name_m3662098416,
	CultureInfo_get_Parent_m672689885,
	CultureInfo_get_TextInfo_m2342840448,
	CultureInfo_get_IcuName_m2258611679,
	CultureInfo_Clone_m2597938387,
	CultureInfo_Equals_m1360976324,
	CultureInfo_GetHashCode_m4280654343,
	CultureInfo_ToString_m2909304639,
	CultureInfo_get_CompareInfo_m2930343429,
	CultureInfo_get_IsNeutralCulture_m3370126681,
	CultureInfo_CheckNeutral_m3648960231,
	CultureInfo_get_NumberFormat_m1244033732,
	CultureInfo_set_NumberFormat_m3501553660,
	CultureInfo_get_DateTimeFormat_m1982351742,
	CultureInfo_set_DateTimeFormat_m1843682751,
	CultureInfo_get_IsReadOnly_m3799952118,
	CultureInfo_GetFormat_m732021304,
	CultureInfo_Construct_m1572693873,
	CultureInfo_ConstructInternalLocaleFromName_m4012802696,
	CultureInfo_ConstructInternalLocaleFromLcid_m2304903600,
	CultureInfo_ConstructInternalLocaleFromCurrentLocale_m3684789125,
	CultureInfo_construct_internal_locale_from_lcid_m2668301444,
	CultureInfo_construct_internal_locale_from_name_m3254739477,
	CultureInfo_construct_internal_locale_from_current_locale_m2484355412,
	CultureInfo_construct_datetime_format_m1928121315,
	CultureInfo_construct_number_format_m3346478783,
	CultureInfo_ConstructInvariant_m3774343375,
	CultureInfo_CreateTextInfo_m1222487997,
	CultureInfo_insert_into_shared_tables_m4239017467,
	CultureInfo_GetCultureInfo_m630276874,
	CultureInfo_GetCultureInfo_m56098747,
	CultureInfo_CreateCulture_m1493441763,
	DateTimeFormatInfo__ctor_m3106345035,
	DateTimeFormatInfo__ctor_m3284460055,
	DateTimeFormatInfo__cctor_m4189929746,
	DateTimeFormatInfo_GetInstance_m684998497,
	DateTimeFormatInfo_get_IsReadOnly_m1173781646,
	DateTimeFormatInfo_ReadOnly_m890935083,
	DateTimeFormatInfo_Clone_m335051388,
	DateTimeFormatInfo_GetFormat_m3537254402,
	DateTimeFormatInfo_GetAbbreviatedMonthName_m364480624,
	DateTimeFormatInfo_GetEraName_m3151483707,
	DateTimeFormatInfo_GetMonthName_m2034512315,
	DateTimeFormatInfo_get_RawAbbreviatedDayNames_m1257850285,
	DateTimeFormatInfo_get_RawAbbreviatedMonthNames_m2395953416,
	DateTimeFormatInfo_get_RawDayNames_m3876370387,
	DateTimeFormatInfo_get_RawMonthNames_m246920234,
	DateTimeFormatInfo_get_AMDesignator_m1610196743,
	DateTimeFormatInfo_get_PMDesignator_m1609519124,
	DateTimeFormatInfo_get_DateSeparator_m3346695364,
	DateTimeFormatInfo_get_TimeSeparator_m1179730581,
	DateTimeFormatInfo_get_LongDatePattern_m2180875608,
	DateTimeFormatInfo_get_ShortDatePattern_m2502330401,
	DateTimeFormatInfo_get_ShortTimePattern_m453440268,
	DateTimeFormatInfo_get_LongTimePattern_m1595254249,
	DateTimeFormatInfo_get_MonthDayPattern_m4068069839,
	DateTimeFormatInfo_get_YearMonthPattern_m2258041482,
	DateTimeFormatInfo_get_FullDateTimePattern_m2611794812,
	DateTimeFormatInfo_get_CurrentInfo_m2315174029,
	DateTimeFormatInfo_get_InvariantInfo_m2329875772,
	DateTimeFormatInfo_get_Calendar_m2815249551,
	DateTimeFormatInfo_set_Calendar_m4130265499,
	DateTimeFormatInfo_get_RFC1123Pattern_m1428703602,
	DateTimeFormatInfo_get_RoundtripPattern_m796050488,
	DateTimeFormatInfo_get_SortableDateTimePattern_m1596151441,
	DateTimeFormatInfo_get_UniversalSortableDateTimePattern_m205892812,
	DateTimeFormatInfo_GetAllDateTimePatternsInternal_m1798077795,
	DateTimeFormatInfo_FillAllDateTimePatterns_m2683124783,
	DateTimeFormatInfo_GetAllRawDateTimePatterns_m4238261242,
	DateTimeFormatInfo_GetDayName_m2279787668,
	DateTimeFormatInfo_GetAbbreviatedDayName_m1307320526,
	DateTimeFormatInfo_FillInvariantPatterns_m3827540258,
	DateTimeFormatInfo_PopulateCombinedList_m3446790622,
	DaylightTime__ctor_m1928120219,
	DaylightTime_get_Start_m2228394704,
	DaylightTime_get_End_m724819253,
	DaylightTime_get_Delta_m2355462786,
	GregorianCalendar__ctor_m979779718,
	GregorianCalendar__ctor_m3097541152,
	GregorianCalendar_get_Eras_m3930946427,
	GregorianCalendar_set_CalendarType_m2253089143,
	GregorianCalendar_GetDayOfMonth_m3068119146,
	GregorianCalendar_GetDayOfWeek_m3823546942,
	GregorianCalendar_GetEra_m2369958449,
	GregorianCalendar_GetMonth_m3359423849,
	GregorianCalendar_GetYear_m854131864,
	NumberFormatInfo__ctor_m2249665202,
	NumberFormatInfo__ctor_m702982685,
	NumberFormatInfo__ctor_m3445216119,
	NumberFormatInfo__cctor_m2457328820,
	NumberFormatInfo_get_CurrencyDecimalDigits_m4006331471,
	NumberFormatInfo_get_CurrencyDecimalSeparator_m2685056987,
	NumberFormatInfo_get_CurrencyGroupSeparator_m1514324779,
	NumberFormatInfo_get_RawCurrencyGroupSizes_m815972208,
	NumberFormatInfo_get_CurrencyNegativePattern_m2134016253,
	NumberFormatInfo_get_CurrencyPositivePattern_m2327563925,
	NumberFormatInfo_get_CurrencySymbol_m5935691,
	NumberFormatInfo_get_CurrentInfo_m2605582008,
	NumberFormatInfo_get_InvariantInfo_m349577018,
	NumberFormatInfo_get_NaNSymbol_m2562844481,
	NumberFormatInfo_get_NegativeInfinitySymbol_m3630938097,
	NumberFormatInfo_get_NegativeSign_m2757109362,
	NumberFormatInfo_get_NumberDecimalDigits_m4271638382,
	NumberFormatInfo_get_NumberDecimalSeparator_m33502788,
	NumberFormatInfo_get_NumberGroupSeparator_m3292795925,
	NumberFormatInfo_get_RawNumberGroupSizes_m1148947207,
	NumberFormatInfo_get_NumberNegativePattern_m1699547496,
	NumberFormatInfo_set_NumberNegativePattern_m1999304795,
	NumberFormatInfo_get_PercentDecimalDigits_m4236240374,
	NumberFormatInfo_get_PercentDecimalSeparator_m2449367000,
	NumberFormatInfo_get_PercentGroupSeparator_m1849673260,
	NumberFormatInfo_get_RawPercentGroupSizes_m97703232,
	NumberFormatInfo_get_PercentNegativePattern_m1304634118,
	NumberFormatInfo_get_PercentPositivePattern_m1800841633,
	NumberFormatInfo_get_PercentSymbol_m2021660345,
	NumberFormatInfo_get_PerMilleSymbol_m1360140831,
	NumberFormatInfo_get_PositiveInfinitySymbol_m1141345134,
	NumberFormatInfo_get_PositiveSign_m240350949,
	NumberFormatInfo_GetFormat_m1699707893,
	NumberFormatInfo_Clone_m3276284539,
	NumberFormatInfo_GetInstance_m2833078205,
	RegionInfo__ctor_m1212234622,
	RegionInfo__ctor_m1348635004,
	RegionInfo_get_CurrentRegion_m3443163374,
	RegionInfo_GetByTerritory_m2536737365,
	RegionInfo_construct_internal_region_from_name_m1315402456,
	RegionInfo_get_CurrencyEnglishName_m1706473630,
	RegionInfo_get_CurrencySymbol_m1879783455,
	RegionInfo_get_DisplayName_m3679349812,
	RegionInfo_get_EnglishName_m4080324067,
	RegionInfo_get_GeoId_m945815123,
	RegionInfo_get_IsMetric_m254276301,
	RegionInfo_get_ISOCurrencySymbol_m441808484,
	RegionInfo_get_NativeName_m2676336050,
	RegionInfo_get_CurrencyNativeName_m2071178612,
	RegionInfo_get_Name_m834510569,
	RegionInfo_get_ThreeLetterISORegionName_m3727404172,
	RegionInfo_get_ThreeLetterWindowsRegionName_m3055965132,
	RegionInfo_get_TwoLetterISORegionName_m168656244,
	RegionInfo_Equals_m2499055654,
	RegionInfo_GetHashCode_m1608374012,
	RegionInfo_ToString_m1243674882,
	SortKey__ctor_m853383193,
	SortKey__ctor_m2034425682,
	SortKey_Compare_m1705990888,
	SortKey_get_OriginalString_m1428586816,
	SortKey_get_KeyData_m3446923386,
	SortKey_Equals_m3124075298,
	SortKey_GetHashCode_m3547067087,
	SortKey_ToString_m3992814724,
	TextInfo__ctor_m2985371296,
	TextInfo__ctor_m1714721222,
	TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1492046432,
	TextInfo_get_ListSeparator_m1628160079,
	TextInfo_get_CultureName_m3892243949,
	TextInfo_Equals_m3029092201,
	TextInfo_GetHashCode_m4032637166,
	TextInfo_ToString_m3431897261,
	TextInfo_ToLower_m2744057472,
	TextInfo_ToUpper_m4031511609,
	TextInfo_ToLower_m2989196362,
	TextInfo_Clone_m3838580862,
	Guid__ctor_m3421080095_AdjustorThunk,
	Guid__ctor_m2423264394_AdjustorThunk,
	Guid__ctor_m2373660607_AdjustorThunk,
	Guid__ctor_m3562600567_AdjustorThunk,
	Guid__cctor_m1202095334,
	Guid_CheckNull_m1870379983,
	Guid_CheckLength_m1615712498,
	Guid_CheckArray_m921056615,
	Guid_Compare_m231009821,
	Guid_CompareTo_m243656946_AdjustorThunk,
	Guid_Equals_m1866984197_AdjustorThunk,
	Guid_CompareTo_m2129361928_AdjustorThunk,
	Guid_Equals_m3683678873_AdjustorThunk,
	Guid_GetHashCode_m3042133858_AdjustorThunk,
	Guid_ToHex_m2592644778,
	Guid_NewGuid_m923091018,
	Guid_FastNewGuidArray_m920913610,
	Guid_AppendInt_m1995455822,
	Guid_AppendShort_m791023083,
	Guid_AppendByte_m4212783015,
	Guid_BaseToString_m3600006650_AdjustorThunk,
	Guid_ToString_m3279186591_AdjustorThunk,
	Guid_ToString_m4056316049_AdjustorThunk,
	Guid_ToString_m2120285561_AdjustorThunk,
	Guid_op_Equality_m4289903222,
	GuidParser__ctor_m3982448124,
	GuidParser_Reset_m2640004655,
	GuidParser_AtEnd_m3409982497,
	GuidParser_ThrowFormatException_m3223388534,
	GuidParser_ParseHex_m1764305333,
	GuidParser_ParseOptChar_m1342400948,
	GuidParser_ParseChar_m2782779985,
	GuidParser_ParseGuid1_m348754878,
	GuidParser_ParseHexPrefix_m3148550086,
	GuidParser_ParseGuid2_m1914838819,
	GuidParser_Parse_m3524913675,
	BinaryReader__ctor_m2602947653,
	BinaryReader__ctor_m2266204403,
	BinaryReader_System_IDisposable_Dispose_m1578048464,
	BinaryReader_get_BaseStream_m3993550412,
	BinaryReader_Close_m3868286242,
	BinaryReader_Dispose_m3769291377,
	BinaryReader_FillBuffer_m1406780870,
	BinaryReader_Read_m1362176249,
	BinaryReader_Read_m763986032,
	BinaryReader_Read_m3708759962,
	BinaryReader_ReadCharBytes_m2668665998,
	BinaryReader_Read7BitEncodedInt_m3079148249,
	BinaryReader_ReadBoolean_m3271855799,
	BinaryReader_ReadByte_m2842288049,
	BinaryReader_ReadBytes_m2025629328,
	BinaryReader_ReadChar_m3380594564,
	BinaryReader_ReadDecimal_m272106980,
	BinaryReader_ReadDouble_m2513998176,
	BinaryReader_ReadInt16_m816003668,
	BinaryReader_ReadInt32_m2994982418,
	BinaryReader_ReadInt64_m939370142,
	BinaryReader_ReadSByte_m3736742795,
	BinaryReader_ReadString_m2204259855,
	BinaryReader_ReadSingle_m3384287259,
	BinaryReader_ReadUInt16_m267781130,
	BinaryReader_ReadUInt32_m2210658763,
	BinaryReader_ReadUInt64_m4059726988,
	BinaryReader_CheckBuffer_m2636825055,
	BinaryWriter__ctor_m3736305989,
	BinaryWriter__ctor_m1874693998,
	BinaryWriter__ctor_m2439641268,
	BinaryWriter__cctor_m874809665,
	BinaryWriter_System_IDisposable_Dispose_m486394397,
	BinaryWriter_Dispose_m1020700223,
	BinaryWriter_Flush_m1376465554,
	BinaryWriter_Write_m2685067618,
	BinaryWriter_Write_m973309864,
	BinaryWriter_Write_m3614538606,
	BinaryWriter_Write_m259663284,
	BinaryWriter_Write_m2841350030,
	BinaryWriter_Write_m340679106,
	BinaryWriter_Write_m4277135253,
	BinaryWriter_Write_m2081800750,
	BinaryWriter_Write_m3941546326,
	BinaryWriter_Write_m2414409956,
	BinaryWriter_Write_m88942200,
	BinaryWriter_Write_m3577537050,
	BinaryWriter_Write_m3837784074,
	BinaryWriter_Write_m3922404942,
	BinaryWriter_Write_m3658027000,
	BinaryWriter_Write_m1702572183,
	BinaryWriter_Write_m1304446817,
	BinaryWriter_Write_m162594906,
	BinaryWriter_Write7BitEncodedInt_m3825472103,
	Directory_CreateDirectory_m751642867,
	Directory_CreateDirectoriesInternal_m3735342319,
	Directory_Exists_m1484791558,
	Directory_GetCurrentDirectory_m219218555,
	Directory_GetFiles_m2624572368,
	Directory_GetFileSystemEntries_m1684188607,
	DirectoryInfo__ctor_m1000259829,
	DirectoryInfo__ctor_m126519516,
	DirectoryInfo__ctor_m481305441,
	DirectoryInfo_Initialize_m1389772934,
	DirectoryInfo_get_Exists_m3142069876,
	DirectoryInfo_get_Parent_m3736638393,
	DirectoryInfo_Create_m604858118,
	DirectoryInfo_ToString_m330992229,
	DirectoryNotFoundException__ctor_m4004339866,
	DirectoryNotFoundException__ctor_m3235664382,
	DirectoryNotFoundException__ctor_m1689636868,
	EndOfStreamException__ctor_m2202021005,
	EndOfStreamException__ctor_m1590165188,
	File_Delete_m321251800,
	File_Exists_m3943585060,
	File_Open_m664439378,
	File_OpenRead_m2936789020,
	File_OpenText_m196858847,
	FileLoadException__ctor_m3879680456,
	FileLoadException__ctor_m3104411427,
	FileLoadException_get_Message_m1316268913,
	FileLoadException_GetObjectData_m1844968812,
	FileLoadException_ToString_m2989457882,
	FileNotFoundException__ctor_m2359931775,
	FileNotFoundException__ctor_m3252664930,
	FileNotFoundException__ctor_m1953317719,
	FileNotFoundException__ctor_m2477162036,
	FileNotFoundException_get_Message_m2807351025,
	FileNotFoundException_GetObjectData_m3195845120,
	FileNotFoundException_ToString_m3487423565,
	FileStream__ctor_m3087090334,
	FileStream__ctor_m3135402178,
	FileStream__ctor_m2889718780,
	FileStream__ctor_m1487083717,
	FileStream__ctor_m3151488352,
	FileStream_get_CanRead_m860786786,
	FileStream_get_CanWrite_m1199612770,
	FileStream_get_CanSeek_m331583577,
	FileStream_get_Length_m426703983,
	FileStream_get_Position_m3002807042,
	FileStream_set_Position_m196127886,
	FileStream_ReadByte_m2651547500,
	FileStream_WriteByte_m3899504766,
	FileStream_Read_m3303017364,
	FileStream_ReadInternal_m2099474616,
	FileStream_BeginRead_m2419864669,
	FileStream_EndRead_m3904255625,
	FileStream_Write_m2254426030,
	FileStream_WriteInternal_m4028396817,
	FileStream_BeginWrite_m626715259,
	FileStream_EndWrite_m4002445354,
	FileStream_Seek_m2017853129,
	FileStream_SetLength_m99749826,
	FileStream_Flush_m948103572,
	FileStream_Finalize_m1626396852,
	FileStream_Dispose_m2599766137,
	FileStream_ReadSegment_m3875398069,
	FileStream_WriteSegment_m4018885935,
	FileStream_FlushBuffer_m914568182,
	FileStream_FlushBuffer_m4115439312,
	FileStream_FlushBufferIfDirty_m4249802951,
	FileStream_RefillBuffer_m4186945278,
	FileStream_ReadData_m1637551634,
	FileStream_InitBuffer_m2135408785,
	FileStream_GetSecureFileName_m449783930,
	FileStream_GetSecureFileName_m2419304749,
	ReadDelegate__ctor_m2067775798,
	ReadDelegate_Invoke_m853483996,
	ReadDelegate_BeginInvoke_m3697522094,
	ReadDelegate_EndInvoke_m1567259657,
	WriteDelegate__ctor_m760514430,
	WriteDelegate_Invoke_m1581737441,
	WriteDelegate_BeginInvoke_m39624777,
	WriteDelegate_EndInvoke_m952736984,
	FileStreamAsyncResult__ctor_m3441988901,
	FileStreamAsyncResult_CBWrapper_m1670848754,
	FileStreamAsyncResult_get_AsyncState_m3919989221,
	FileStreamAsyncResult_get_AsyncWaitHandle_m1811816191,
	FileStreamAsyncResult_get_IsCompleted_m2730893434,
	FileSystemInfo__ctor_m3035148496,
	FileSystemInfo__ctor_m3769019897,
	FileSystemInfo_GetObjectData_m812231621,
	FileSystemInfo_get_FullName_m3468398407,
	FileSystemInfo_Refresh_m1497191506,
	FileSystemInfo_InternalRefresh_m1700260373,
	FileSystemInfo_CheckPath_m1572836275,
	IOException__ctor_m971599150,
	IOException__ctor_m3662782713,
	IOException__ctor_m3246761956,
	IOException__ctor_m58488270,
	IOException__ctor_m2367100481,
	IsolatedStorageException__ctor_m3554950159,
	IsolatedStorageException__ctor_m1022659452,
	IsolatedStorageException__ctor_m3386787868,
	MemoryStream__ctor_m2678285228,
	MemoryStream__ctor_m2128850779,
	MemoryStream__ctor_m4100805873,
	MemoryStream_InternalConstructor_m150311326,
	MemoryStream_CheckIfClosedThrowDisposed_m3740555627,
	MemoryStream_get_CanRead_m1639425566,
	MemoryStream_get_CanSeek_m2835368013,
	MemoryStream_get_CanWrite_m3127242210,
	MemoryStream_set_Capacity_m1773624579,
	MemoryStream_get_Length_m1064991453,
	MemoryStream_get_Position_m3733941202,
	MemoryStream_set_Position_m3169779190,
	MemoryStream_Dispose_m3070412825,
	MemoryStream_Flush_m404193925,
	MemoryStream_GetBuffer_m1167568916,
	MemoryStream_Read_m337792459,
	MemoryStream_ReadByte_m881980848,
	MemoryStream_Seek_m3459579537,
	MemoryStream_CalculateNewCapacity_m30466263,
	MemoryStream_Expand_m3554752073,
	MemoryStream_SetLength_m974389318,
	MemoryStream_ToArray_m3911744835,
	MemoryStream_Write_m162543801,
	MemoryStream_WriteByte_m4085656483,
	MonoIO__cctor_m3715714639,
	MonoIO_GetException_m865954703,
	MonoIO_GetException_m1522387862,
	MonoIO_CreateDirectory_m120522531,
	MonoIO_GetFileSystemEntries_m37351365,
	MonoIO_GetCurrentDirectory_m762333289,
	MonoIO_DeleteFile_m3839141322,
	MonoIO_GetFileAttributes_m2086493016,
	MonoIO_GetFileType_m101289143,
	MonoIO_ExistsFile_m812572516,
	MonoIO_ExistsDirectory_m2182482658,
	MonoIO_GetFileStat_m678141354,
	MonoIO_Open_m2245605962,
	MonoIO_Close_m3406045462,
	MonoIO_Read_m1129074620,
	MonoIO_Write_m3999708352,
	MonoIO_Seek_m390267705,
	MonoIO_GetLength_m2300093603,
	MonoIO_SetLength_m2811105392,
	MonoIO_get_ConsoleOutput_m1601613425,
	MonoIO_get_ConsoleInput_m610865495,
	MonoIO_get_ConsoleError_m1156784591,
	MonoIO_get_VolumeSeparatorChar_m3246170182,
	MonoIO_get_DirectorySeparatorChar_m820086465,
	MonoIO_get_AltDirectorySeparatorChar_m563952479,
	MonoIO_get_PathSeparator_m4045322458,
	MonoIO_RemapPath_m1142466502,
	NullStream__ctor_m2992573138,
	NullStream_get_CanRead_m1034149266,
	NullStream_get_CanSeek_m500620687,
	NullStream_get_CanWrite_m1245688616,
	NullStream_get_Length_m3184233382,
	NullStream_get_Position_m4048431226,
	NullStream_set_Position_m4054051091,
	NullStream_Flush_m3382897993,
	NullStream_Read_m3464254343,
	NullStream_ReadByte_m3043548024,
	NullStream_Seek_m1914924606,
	NullStream_SetLength_m1485742029,
	NullStream_Write_m3898870979,
	NullStream_WriteByte_m2819073019,
	Path__cctor_m3273994011,
	Path_Combine_m3389272516,
	Path_CleanPath_m3974596557,
	Path_GetDirectoryName_m3496866581,
	Path_GetExtension_m1021339115,
	Path_GetFileName_m1354558116,
	Path_GetFullPath_m4142135635,
	Path_WindowsDriveAdjustment_m3256426255,
	Path_InsecureGetFullPath_m129101154,
	Path_IsDsc_m138487241,
	Path_GetPathRoot_m3499444155,
	Path_IsPathRooted_m3515805419,
	Path_GetInvalidPathChars_m3959874485,
	Path_findExtension_m910255017,
	Path_GetServerAndShare_m2640882202,
	Path_SameRoot_m1518354096,
	Path_CanonicalizePath_m620086118,
	PathTooLongException__ctor_m3265957480,
	PathTooLongException__ctor_m2026445941,
	PathTooLongException__ctor_m3626892488,
	SearchPattern__cctor_m3525595274,
	Stream__ctor_m3881936881,
	Stream__cctor_m3168732477,
	Stream_Dispose_m2589290611,
	Stream_Dispose_m874059170,
	Stream_Close_m771352034,
	Stream_ReadByte_m4291052673,
	Stream_WriteByte_m1519852120,
	Stream_BeginRead_m2233539237,
	Stream_BeginWrite_m1696564506,
	Stream_EndRead_m1896469262,
	Stream_EndWrite_m1721488587,
	StreamAsyncResult__ctor_m3118856368,
	StreamAsyncResult_SetComplete_m1247564615,
	StreamAsyncResult_SetComplete_m1102187093,
	StreamAsyncResult_get_AsyncState_m3822420114,
	StreamAsyncResult_get_AsyncWaitHandle_m3390046559,
	StreamAsyncResult_get_IsCompleted_m2732733162,
	StreamAsyncResult_get_Exception_m4050930077,
	StreamAsyncResult_get_NBytes_m548041729,
	StreamAsyncResult_get_Done_m3405983634,
	StreamAsyncResult_set_Done_m376066337,
	StreamReader__ctor_m150050089,
	StreamReader__ctor_m3941437302,
	StreamReader__ctor_m2783219104,
	StreamReader__ctor_m1616861391,
	StreamReader__ctor_m2637382018,
	StreamReader__cctor_m874052303,
	StreamReader_Initialize_m3160193871,
	StreamReader_Dispose_m156389394,
	StreamReader_DoChecks_m1235625723,
	StreamReader_ReadBuffer_m761134843,
	StreamReader_Peek_m2272511193,
	StreamReader_Read_m2554901735,
	StreamReader_Read_m830111915,
	StreamReader_FindNextEOL_m2574298119,
	StreamReader_ReadLine_m1468498645,
	StreamReader_ReadToEnd_m371831293,
	NullStreamReader__ctor_m3077615088,
	NullStreamReader_Peek_m1755552867,
	NullStreamReader_Read_m3851775014,
	NullStreamReader_Read_m4144924479,
	NullStreamReader_ReadLine_m1951583843,
	NullStreamReader_ReadToEnd_m785591460,
	StreamWriter__ctor_m2310301218,
	StreamWriter__ctor_m1245831116,
	StreamWriter__cctor_m1229272693,
	StreamWriter_Initialize_m3490883444,
	StreamWriter_set_AutoFlush_m42112085,
	StreamWriter_Dispose_m2818839127,
	StreamWriter_Flush_m3311572543,
	StreamWriter_FlushBytes_m1531540244,
	StreamWriter_Decode_m2340149035,
	StreamWriter_Write_m4109815652,
	StreamWriter_LowLevelWrite_m1318762026,
	StreamWriter_LowLevelWrite_m1081676583,
	StreamWriter_Write_m2487601391,
	StreamWriter_Write_m2994525938,
	StreamWriter_Write_m1660535366,
	StreamWriter_Close_m3750270527,
	StreamWriter_Finalize_m1379860857,
	StringReader__ctor_m126993932,
	StringReader_Dispose_m1915799905,
	StringReader_Peek_m3605235793,
	StringReader_Read_m3322058819,
	StringReader_Read_m478895463,
	StringReader_ReadLine_m2337102945,
	StringReader_ReadToEnd_m2679201613,
	StringReader_CheckObjectDisposedException_m3796163530,
	SynchronizedReader__ctor_m322282529,
	SynchronizedReader_Peek_m148942882,
	SynchronizedReader_ReadLine_m2411238064,
	SynchronizedReader_ReadToEnd_m2160105378,
	SynchronizedReader_Read_m2047574604,
	SynchronizedReader_Read_m1388613247,
	SynchronizedWriter__ctor_m495278869,
	SynchronizedWriter_Close_m3632168889,
	SynchronizedWriter_Flush_m1415610297,
	SynchronizedWriter_Write_m1297715977,
	SynchronizedWriter_Write_m2529550287,
	SynchronizedWriter_Write_m169417751,
	SynchronizedWriter_Write_m301917713,
	SynchronizedWriter_WriteLine_m1552352268,
	SynchronizedWriter_WriteLine_m2518863747,
	TextReader__ctor_m605064712,
	TextReader__cctor_m322748985,
	TextReader_Dispose_m4253712522,
	TextReader_Dispose_m2059554794,
	TextReader_Peek_m4032451740,
	TextReader_Read_m2044559986,
	TextReader_Read_m4213268240,
	TextReader_ReadLine_m2549275032,
	TextReader_ReadToEnd_m2648397074,
	TextReader_Synchronized_m3004980758,
	NullTextReader__ctor_m2871254925,
	NullTextReader_ReadLine_m2308083993,
	TextWriter__ctor_m2859954372,
	TextWriter__cctor_m2707487510,
	TextWriter_Close_m1290111813,
	TextWriter_Dispose_m368115211,
	TextWriter_Dispose_m2495808722,
	TextWriter_Flush_m4003695429,
	TextWriter_Synchronized_m904006265,
	TextWriter_Write_m164803641,
	TextWriter_Write_m2638787064,
	TextWriter_Write_m2252948084,
	TextWriter_Write_m2937140664,
	TextWriter_WriteLine_m524366243,
	TextWriter_WriteLine_m526643693,
	NullTextWriter__ctor_m1544833104,
	NullTextWriter_Write_m432139305,
	NullTextWriter_Write_m1671049200,
	NullTextWriter_Write_m2752689351,
	UnexceptionalStreamReader__ctor_m1568917069,
	UnexceptionalStreamReader__cctor_m2018971657,
	UnexceptionalStreamReader_Peek_m1842169584,
	UnexceptionalStreamReader_Read_m16956299,
	UnexceptionalStreamReader_Read_m39696771,
	UnexceptionalStreamReader_CheckEOL_m187999544,
	UnexceptionalStreamReader_ReadLine_m3663173848,
	UnexceptionalStreamReader_ReadToEnd_m920589220,
	UnexceptionalStreamWriter__ctor_m1310404920,
	UnexceptionalStreamWriter_Flush_m82278468,
	UnexceptionalStreamWriter_Write_m4210473673,
	UnexceptionalStreamWriter_Write_m1440243232,
	UnexceptionalStreamWriter_Write_m1834931241,
	UnexceptionalStreamWriter_Write_m363195622,
	UnmanagedMemoryStream_get_CanRead_m3770815400,
	UnmanagedMemoryStream_get_CanSeek_m2636857629,
	UnmanagedMemoryStream_get_CanWrite_m2913951513,
	UnmanagedMemoryStream_get_Length_m3699800948,
	UnmanagedMemoryStream_get_Position_m3800945932,
	UnmanagedMemoryStream_set_Position_m2304997845,
	UnmanagedMemoryStream_Read_m3982577147,
	UnmanagedMemoryStream_ReadByte_m4248453739,
	UnmanagedMemoryStream_Seek_m541442656,
	UnmanagedMemoryStream_SetLength_m3752964620,
	UnmanagedMemoryStream_Flush_m1540584491,
	UnmanagedMemoryStream_Dispose_m2681886347,
	UnmanagedMemoryStream_Write_m930787521,
	UnmanagedMemoryStream_WriteByte_m70460272,
	IndexOutOfRangeException__ctor_m2441337274,
	IndexOutOfRangeException__ctor_m3408750441,
	IndexOutOfRangeException__ctor_m1384421447,
	Int16_System_IConvertible_ToBoolean_m1656400658_AdjustorThunk,
	Int16_System_IConvertible_ToByte_m3161982419_AdjustorThunk,
	Int16_System_IConvertible_ToChar_m1265932681_AdjustorThunk,
	Int16_System_IConvertible_ToDateTime_m3080274979_AdjustorThunk,
	Int16_System_IConvertible_ToDecimal_m660016172_AdjustorThunk,
	Int16_System_IConvertible_ToDouble_m1661805412_AdjustorThunk,
	Int16_System_IConvertible_ToInt16_m2224134411_AdjustorThunk,
	Int16_System_IConvertible_ToInt32_m172369210_AdjustorThunk,
	Int16_System_IConvertible_ToInt64_m4101803559_AdjustorThunk,
	Int16_System_IConvertible_ToSByte_m4128424691_AdjustorThunk,
	Int16_System_IConvertible_ToSingle_m3569332870_AdjustorThunk,
	Int16_System_IConvertible_ToType_m3672347013_AdjustorThunk,
	Int16_System_IConvertible_ToUInt16_m3040688695_AdjustorThunk,
	Int16_System_IConvertible_ToUInt32_m3410279543_AdjustorThunk,
	Int16_System_IConvertible_ToUInt64_m134975563_AdjustorThunk,
	Int16_CompareTo_m2285977076_AdjustorThunk,
	Int16_Equals_m82811458_AdjustorThunk,
	Int16_GetHashCode_m2858888309_AdjustorThunk,
	Int16_CompareTo_m3705372115_AdjustorThunk,
	Int16_Equals_m1479112859_AdjustorThunk,
	Int16_Parse_m2276856944,
	Int16_Parse_m138525169,
	Int16_Parse_m3641256939,
	Int16_TryParse_m1675418240,
	Int16_ToString_m1270547562_AdjustorThunk,
	Int16_ToString_m2013897809_AdjustorThunk,
	Int16_ToString_m2072232391_AdjustorThunk,
	Int16_ToString_m1931491687_AdjustorThunk,
	Int32_System_IConvertible_ToBoolean_m2787524506_AdjustorThunk,
	Int32_System_IConvertible_ToByte_m3832391412_AdjustorThunk,
	Int32_System_IConvertible_ToChar_m2005926864_AdjustorThunk,
	Int32_System_IConvertible_ToDateTime_m1824716955_AdjustorThunk,
	Int32_System_IConvertible_ToDecimal_m2190376994_AdjustorThunk,
	Int32_System_IConvertible_ToDouble_m1464782260_AdjustorThunk,
	Int32_System_IConvertible_ToInt16_m453278239_AdjustorThunk,
	Int32_System_IConvertible_ToInt32_m265310525_AdjustorThunk,
	Int32_System_IConvertible_ToInt64_m3520470966_AdjustorThunk,
	Int32_System_IConvertible_ToSByte_m3133688512_AdjustorThunk,
	Int32_System_IConvertible_ToSingle_m896140682_AdjustorThunk,
	Int32_System_IConvertible_ToType_m3009233912_AdjustorThunk,
	Int32_System_IConvertible_ToUInt16_m943736619_AdjustorThunk,
	Int32_System_IConvertible_ToUInt32_m3557270157_AdjustorThunk,
	Int32_System_IConvertible_ToUInt64_m2502338186_AdjustorThunk,
	Int32_CompareTo_m2864982090_AdjustorThunk,
	Int32_Equals_m3996243976_AdjustorThunk,
	Int32_GetHashCode_m1876651407_AdjustorThunk,
	Int32_CompareTo_m4284770383_AdjustorThunk,
	Int32_Equals_m2976157357_AdjustorThunk,
	Int32_ProcessTrailingWhitespace_m220059206,
	Int32_Parse_m2309670223,
	Int32_Parse_m2087562008,
	Int32_CheckStyle_m3421319992,
	Int32_JumpOverWhite_m208298144,
	Int32_FindSign_m3975667272,
	Int32_FindCurrency_m3541026887,
	Int32_FindExponent_m2938219441,
	Int32_FindOther_m3593812441,
	Int32_ValidDigit_m1059003769,
	Int32_GetFormatException_m519586683,
	Int32_Parse_m3020773399,
	Int32_Parse_m1033611559,
	Int32_Parse_m3682462547,
	Int32_TryParse_m2404707562,
	Int32_TryParse_m135955795,
	Int32_ToString_m141394615_AdjustorThunk,
	Int32_ToString_m1760361794_AdjustorThunk,
	Int32_ToString_m372259452_AdjustorThunk,
	Int32_ToString_m2507389746_AdjustorThunk,
	Int64_System_IConvertible_ToBoolean_m2413769966_AdjustorThunk,
	Int64_System_IConvertible_ToByte_m375085029_AdjustorThunk,
	Int64_System_IConvertible_ToChar_m1509243576_AdjustorThunk,
	Int64_System_IConvertible_ToDateTime_m2535842508_AdjustorThunk,
	Int64_System_IConvertible_ToDecimal_m70934849_AdjustorThunk,
	Int64_System_IConvertible_ToDouble_m99143002_AdjustorThunk,
	Int64_System_IConvertible_ToInt16_m4062196970_AdjustorThunk,
	Int64_System_IConvertible_ToInt32_m772105781_AdjustorThunk,
	Int64_System_IConvertible_ToInt64_m1560218307_AdjustorThunk,
	Int64_System_IConvertible_ToSByte_m267591194_AdjustorThunk,
	Int64_System_IConvertible_ToSingle_m1368636517_AdjustorThunk,
	Int64_System_IConvertible_ToType_m3223988955_AdjustorThunk,
	Int64_System_IConvertible_ToUInt16_m848637338_AdjustorThunk,
	Int64_System_IConvertible_ToUInt32_m109903525_AdjustorThunk,
	Int64_System_IConvertible_ToUInt64_m2815650160_AdjustorThunk,
	Int64_CompareTo_m1928360444_AdjustorThunk,
	Int64_Equals_m858582563_AdjustorThunk,
	Int64_GetHashCode_m703091690_AdjustorThunk,
	Int64_CompareTo_m3345789408_AdjustorThunk,
	Int64_Equals_m680137412_AdjustorThunk,
	Int64_Parse_m3309897583,
	Int64_Parse_m1331690076,
	Int64_Parse_m1800613309,
	Int64_Parse_m662659148,
	Int64_Parse_m3250361603,
	Int64_TryParse_m2208578514,
	Int64_TryParse_m3606398488,
	Int64_ToString_m2986581816_AdjustorThunk,
	Int64_ToString_m623640997_AdjustorThunk,
	Int64_ToString_m414616559_AdjustorThunk,
	Int64_ToString_m2085073918_AdjustorThunk,
	IntPtr__ctor_m987082960_AdjustorThunk,
	IntPtr__ctor_m987476171_AdjustorThunk,
	IntPtr__ctor_m3384658186_AdjustorThunk,
	IntPtr__ctor_m620280096_AdjustorThunk,
	IntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m1980135475_AdjustorThunk,
	IntPtr_get_Size_m370911744,
	IntPtr_Equals_m3408989655_AdjustorThunk,
	IntPtr_GetHashCode_m3588219647_AdjustorThunk,
	IntPtr_ToInt64_m192765549_AdjustorThunk,
	IntPtr_ToPointer_m4157623054_AdjustorThunk,
	IntPtr_ToString_m1831665121_AdjustorThunk,
	IntPtr_ToString_m900170569_AdjustorThunk,
	IntPtr_op_Equality_m408849716,
	IntPtr_op_Inequality_m3063970704,
	IntPtr_op_Explicit_m1593216315,
	IntPtr_op_Explicit_m1593085246,
	IntPtr_op_Explicit_m536245531,
	IntPtr_op_Explicit_m4220076518,
	IntPtr_op_Explicit_m2520637223,
	InvalidCastException__ctor_m1807554410,
	InvalidCastException__ctor_m318645277,
	InvalidCastException__ctor_m2551002860,
	InvalidOperationException__ctor_m2734335978,
	InvalidOperationException__ctor_m237278729,
	InvalidOperationException__ctor_m1685032583,
	InvalidOperationException__ctor_m262609521,
	LocalDataStoreSlot__ctor_m4104083971,
	LocalDataStoreSlot__cctor_m644942532,
	LocalDataStoreSlot_Finalize_m2831598515,
	MarshalByRefObject__ctor_m3039543187,
	MarshalByRefObject_get_ObjectIdentity_m186877036,
	MarshalByRefObject_set_ObjectIdentity_m2909674674,
	MarshalByRefObject_CreateObjRef_m2444885068,
	MarshalByRefObject_InitializeLifetimeService_m3972547550,
	Math_Abs_m3912393749,
	Math_Abs_m3353607971,
	Math_Abs_m1208936174,
	Math_Abs_m2270691510,
	Math_Floor_m1840375750,
	Math_Max_m1873195862,
	Math_Min_m3468062251,
	Math_Round_m3018379666,
	Math_Round_m101670467,
	Math_Pow_m754227594,
	Math_Sqrt_m1297338011,
	MemberAccessException__ctor_m2501221062,
	MemberAccessException__ctor_m3059744007,
	MemberAccessException__ctor_m3713703094,
	MethodAccessException__ctor_m3542088436,
	MethodAccessException__ctor_m3411913042,
	MissingFieldException__ctor_m3159172111,
	MissingFieldException__ctor_m4282575076,
	MissingFieldException__ctor_m3742452630,
	MissingFieldException_get_Message_m2809639043,
	MissingMemberException__ctor_m2683358432,
	MissingMemberException__ctor_m2571045846,
	MissingMemberException__ctor_m1220732369,
	MissingMemberException__ctor_m2707802176,
	MissingMemberException_GetObjectData_m2957220379,
	MissingMemberException_get_Message_m54658002,
	MissingMethodException__ctor_m878219575,
	MissingMethodException__ctor_m3234469579,
	MissingMethodException__ctor_m1207628821,
	MissingMethodException__ctor_m41689610,
	MissingMethodException_get_Message_m3161775487,
	MonoAsyncCall__ctor_m714441825,
	MonoCustomAttrs__cctor_m4000462365,
	MonoCustomAttrs_IsUserCattrProvider_m2878058089,
	MonoCustomAttrs_GetCustomAttributesInternal_m648304078,
	MonoCustomAttrs_GetPseudoCustomAttributes_m765345333,
	MonoCustomAttrs_GetCustomAttributesBase_m287804314,
	MonoCustomAttrs_GetCustomAttribute_m1568487577,
	MonoCustomAttrs_GetCustomAttributes_m1347331976,
	MonoCustomAttrs_GetCustomAttributes_m1775925192,
	MonoCustomAttrs_GetCustomAttributesDataInternal_m2195433393,
	MonoCustomAttrs_GetCustomAttributesData_m3138951217,
	MonoCustomAttrs_IsDefined_m2996012389,
	MonoCustomAttrs_IsDefinedInternal_m2193933235,
	MonoCustomAttrs_GetBasePropertyDefinition_m1562543378,
	MonoCustomAttrs_GetBase_m624536374,
	MonoCustomAttrs_RetrieveAttributeUsage_m2717094301,
	AttributeInfo__ctor_m140304083,
	AttributeInfo_get_Usage_m3705131115,
	AttributeInfo_get_InheritanceLevel_m1477952822,
	MonoDocumentationNoteAttribute__ctor_m2247826418,
	MonoEnumInfo__ctor_m3350651181_AdjustorThunk,
	MonoEnumInfo__cctor_m2240570096,
	MonoEnumInfo_get_enum_info_m1661176095,
	MonoEnumInfo_get_Cache_m752167006,
	MonoEnumInfo_GetInfo_m1670492558,
	IntComparer__ctor_m2901422390,
	IntComparer_Compare_m1224674392,
	IntComparer_Compare_m3469594474,
	LongComparer__ctor_m1468371684,
	LongComparer_Compare_m3267206388,
	LongComparer_Compare_m1396422012,
	SByteComparer__ctor_m3477407026,
	SByteComparer_Compare_m3045065039,
	SByteComparer_Compare_m533535269,
	ShortComparer__ctor_m1243157417,
	ShortComparer_Compare_m1360829877,
	ShortComparer_Compare_m1881262465,
	MonoLimitationAttribute__ctor_m3979406774,
	MonoTODOAttribute__ctor_m1351510135,
	MonoTODOAttribute__ctor_m3050775643,
	MonoTouchAOTHelper__cctor_m3508633665,
	MonoType_get_attributes_m1332507727,
	MonoType_GetDefaultConstructor_m1616852582,
	MonoType_GetAttributeFlagsImpl_m167182975,
	MonoType_GetConstructorImpl_m441167626,
	MonoType_GetConstructors_internal_m2316633399,
	MonoType_GetConstructors_m2574682189,
	MonoType_InternalGetEvent_m1130657893,
	MonoType_GetEvent_m28975240,
	MonoType_GetField_m1337309786,
	MonoType_GetFields_internal_m776921855,
	MonoType_GetFields_m4176012508,
	MonoType_GetInterfaces_m878428211,
	MonoType_GetMethodsByName_m2005909471,
	MonoType_GetMethods_m3840584467,
	MonoType_GetMethodImpl_m3558076162,
	MonoType_GetPropertiesByName_m2491778142,
	MonoType_GetPropertyImpl_m1327032087,
	MonoType_HasElementTypeImpl_m2861175951,
	MonoType_IsArrayImpl_m3283552941,
	MonoType_IsByRefImpl_m2022486753,
	MonoType_IsPointerImpl_m3340652279,
	MonoType_IsPrimitiveImpl_m2401722705,
	MonoType_IsSubclassOf_m1667794028,
	MonoType_InvokeMember_m2156385067,
	MonoType_GetElementType_m170734600,
	MonoType_get_UnderlyingSystemType_m2447717099,
	MonoType_get_Assembly_m4290914179,
	MonoType_get_AssemblyQualifiedName_m2662925380,
	MonoType_getFullName_m837685882,
	MonoType_get_BaseType_m1098640416,
	MonoType_get_FullName_m3242181132,
	MonoType_IsDefined_m838143016,
	MonoType_GetCustomAttributes_m164523340,
	MonoType_GetCustomAttributes_m26060774,
	MonoType_get_MemberType_m4261270584,
	MonoType_get_Name_m1751720248,
	MonoType_get_Namespace_m2015358851,
	MonoType_get_Module_m2397868165,
	MonoType_get_DeclaringType_m90362326,
	MonoType_get_ReflectedType_m3364880648,
	MonoType_get_TypeHandle_m1012024438,
	MonoType_GetArrayRank_m3267817731,
	MonoType_GetObjectData_m3008014917,
	MonoType_ToString_m2539641183,
	MonoType_GetGenericArguments_m485413379,
	MonoType_get_ContainsGenericParameters_m1687910863,
	MonoType_get_IsGenericParameter_m2855599887,
	MonoType_GetGenericTypeDefinition_m3201894896,
	MonoType_CheckMethodSecurity_m576144504,
	MonoType_ReorderParamArrayArguments_m2458683451,
	MonoTypeInfo__ctor_m3401216922,
	MulticastDelegate_GetObjectData_m3957553424,
	MulticastDelegate_Equals_m2502840627,
	MulticastDelegate_GetHashCode_m3864330728,
	MulticastDelegate_GetInvocationList_m4256593605,
	MulticastDelegate_CombineImpl_m2857239134,
	MulticastDelegate_BaseEquals_m335858574,
	MulticastDelegate_KPM_m22863605,
	MulticastDelegate_RemoveImpl_m615507760,
	MulticastNotSupportedException__ctor_m2750561050,
	MulticastNotSupportedException__ctor_m663960493,
	MulticastNotSupportedException__ctor_m521229206,
	NonSerializedAttribute__ctor_m3763812670,
	NotImplementedException__ctor_m3058704252,
	NotImplementedException__ctor_m3095902440,
	NotImplementedException__ctor_m2408412972,
	NotSupportedException__ctor_m2730133172,
	NotSupportedException__ctor_m2494070935,
	NotSupportedException__ctor_m922781896,
	NullReferenceException__ctor_m744513393,
	NullReferenceException__ctor_m3076065613,
	NullReferenceException__ctor_m652863956,
	NumberFormatter__ctor_m2275142545,
	NumberFormatter__cctor_m2992857932,
	NumberFormatter_GetFormatterTables_m910057425,
	NumberFormatter_GetTenPowerOf_m3725144548,
	NumberFormatter_InitDecHexDigits_m829694854,
	NumberFormatter_InitDecHexDigits_m1992166588,
	NumberFormatter_InitDecHexDigits_m2266082744,
	NumberFormatter_FastToDecHex_m699829267,
	NumberFormatter_ToDecHex_m1238855594,
	NumberFormatter_FastDecHexLen_m224865815,
	NumberFormatter_DecHexLen_m3886828604,
	NumberFormatter_DecHexLen_m510984344,
	NumberFormatter_ScaleOrder_m3813786990,
	NumberFormatter_InitialFloatingPrecision_m2468520485,
	NumberFormatter_ParsePrecision_m2004010615,
	NumberFormatter_Init_m3326584660,
	NumberFormatter_InitHex_m3573185377,
	NumberFormatter_Init_m1788236100,
	NumberFormatter_Init_m190003953,
	NumberFormatter_Init_m2506227005,
	NumberFormatter_Init_m2982613221,
	NumberFormatter_Init_m3576155222,
	NumberFormatter_Init_m1925374739,
	NumberFormatter_ResetCharBuf_m1098525658,
	NumberFormatter_Resize_m3876336103,
	NumberFormatter_Append_m950227932,
	NumberFormatter_Append_m1427178134,
	NumberFormatter_Append_m269678094,
	NumberFormatter_GetNumberFormatInstance_m4015471089,
	NumberFormatter_set_CurrentCulture_m1358228087,
	NumberFormatter_get_IntegerDigits_m1758408763,
	NumberFormatter_get_DecimalDigits_m1471374423,
	NumberFormatter_get_IsFloatingSource_m3714711779,
	NumberFormatter_get_IsZero_m3770699077,
	NumberFormatter_get_IsZeroInteger_m2263284741,
	NumberFormatter_RoundPos_m545168719,
	NumberFormatter_RoundDecimal_m2957290908,
	NumberFormatter_RoundBits_m2305061002,
	NumberFormatter_RemoveTrailingZeros_m1055756375,
	NumberFormatter_AddOneToDecHex_m1501523650,
	NumberFormatter_AddOneToDecHex_m1662045257,
	NumberFormatter_CountTrailingZeros_m1178387884,
	NumberFormatter_CountTrailingZeros_m1036924976,
	NumberFormatter_GetInstance_m971769829,
	NumberFormatter_Release_m1879004257,
	NumberFormatter_SetThreadCurrentCulture_m910458896,
	NumberFormatter_NumberToString_m2481532188,
	NumberFormatter_NumberToString_m3726402804,
	NumberFormatter_NumberToString_m2529982306,
	NumberFormatter_NumberToString_m4048866862,
	NumberFormatter_NumberToString_m264078176,
	NumberFormatter_NumberToString_m803024566,
	NumberFormatter_NumberToString_m1906030517,
	NumberFormatter_NumberToString_m406010816,
	NumberFormatter_NumberToString_m2583974918,
	NumberFormatter_NumberToString_m1373805200,
	NumberFormatter_NumberToString_m655666043,
	NumberFormatter_NumberToString_m400339820,
	NumberFormatter_NumberToString_m1790947760,
	NumberFormatter_NumberToString_m3906556024,
	NumberFormatter_NumberToString_m2562899600,
	NumberFormatter_NumberToString_m567544656,
	NumberFormatter_NumberToString_m2966570377,
	NumberFormatter_FastIntegerToString_m390846811,
	NumberFormatter_IntegerToString_m1679294587,
	NumberFormatter_NumberToString_m827252518,
	NumberFormatter_FormatCurrency_m2103540116,
	NumberFormatter_FormatDecimal_m1921932981,
	NumberFormatter_FormatHexadecimal_m2994610679,
	NumberFormatter_FormatFixedPoint_m2462948217,
	NumberFormatter_FormatRoundtrip_m1288785273,
	NumberFormatter_FormatRoundtrip_m19342689,
	NumberFormatter_FormatGeneral_m1667527152,
	NumberFormatter_FormatNumber_m1763569482,
	NumberFormatter_FormatPercent_m270780421,
	NumberFormatter_FormatExponential_m1436810062,
	NumberFormatter_FormatExponential_m2139559983,
	NumberFormatter_FormatCustom_m1169507039,
	NumberFormatter_ZeroTrimEnd_m3065471008,
	NumberFormatter_IsZeroOnly_m46572730,
	NumberFormatter_AppendNonNegativeNumber_m2729989692,
	NumberFormatter_AppendIntegerString_m2788337398,
	NumberFormatter_AppendIntegerString_m2257376141,
	NumberFormatter_AppendDecimalString_m10636623,
	NumberFormatter_AppendDecimalString_m3239747480,
	NumberFormatter_AppendIntegerStringWithGroupSeparator_m86637181,
	NumberFormatter_AppendExponent_m1258666517,
	NumberFormatter_AppendOneDigit_m313720813,
	NumberFormatter_FastAppendDigits_m3294622153,
	NumberFormatter_AppendDigits_m3057727895,
	NumberFormatter_AppendDigits_m4260798464,
	NumberFormatter_Multiply10_m1733956269,
	NumberFormatter_Divide10_m114817904,
	NumberFormatter_GetClone_m4126883757,
	CustomInfo__ctor_m426096741,
	CustomInfo_GetActiveSection_m2184507081,
	CustomInfo_Parse_m4163382069,
	CustomInfo_Format_m1134896917,
	Object__ctor_m297566312,
	Object_Equals_m2439880830,
	Object_Equals_m1397037629,
	Object_Finalize_m3076187857,
	Object_GetHashCode_m2705121830,
	Object_GetType_m88164663,
	Object_MemberwiseClone_m1474068832,
	Object_ToString_m1740002499,
	Object_ReferenceEquals_m610702577,
	Object_InternalGetHashCode_m4213713973,
	Object_FieldGetter_m1068044959,
	Object_FieldSetter_m3873125190,
	ObjectDisposedException__ctor_m3603759869,
	ObjectDisposedException__ctor_m1034312941,
	ObjectDisposedException__ctor_m1894780688,
	ObjectDisposedException_get_Message_m1666887471,
	ObjectDisposedException_GetObjectData_m2330532076,
	ObsoleteAttribute__ctor_m3594271519,
	ObsoleteAttribute__ctor_m3834641885,
	ObsoleteAttribute__ctor_m2274138402,
	OperatingSystem__ctor_m1545635730,
	OperatingSystem_get_Platform_m2793423729,
	OperatingSystem_Clone_m1122165140,
	OperatingSystem_GetObjectData_m1571196722,
	OperatingSystem_ToString_m3445473725,
	OrdinalComparer__ctor_m1028789954,
	OrdinalComparer_Compare_m2819174916,
	OrdinalComparer_Equals_m1106612171,
	OrdinalComparer_GetHashCode_m3219897106,
	OutOfMemoryException__ctor_m3893515912,
	OutOfMemoryException__ctor_m1518469064,
	OutOfMemoryException__ctor_m584364909,
	OverflowException__ctor_m4029085969,
	OverflowException__ctor_m694321376,
	OverflowException__ctor_m2491207501,
	ParamArrayAttribute__ctor_m2680615839,
	PlatformNotSupportedException__ctor_m1787918017,
	PlatformNotSupportedException__ctor_m1693043795,
	RankException__ctor_m4082747811,
	RankException__ctor_m2226473861,
	RankException__ctor_m3453633632,
	AmbiguousMatchException__ctor_m15419215,
	AmbiguousMatchException__ctor_m2012725345,
	AmbiguousMatchException__ctor_m3222545265,
	Assembly__ctor_m823291553,
	Assembly_get_code_base_m282368939,
	Assembly_get_fullname_m3421330653,
	Assembly_get_location_m3128831763,
	Assembly_GetCodeBase_m2422053712,
	Assembly_get_FullName_m293988418,
	Assembly_get_Location_m3857174850,
	Assembly_IsDefined_m1652198537,
	Assembly_GetCustomAttributes_m1347362332,
	Assembly_GetManifestResourceInternal_m1224391897,
	Assembly_GetTypes_m1724781913,
	Assembly_GetTypes_m1237242249,
	Assembly_GetType_m1855422232,
	Assembly_GetType_m2647029381,
	Assembly_InternalGetType_m3065345470,
	Assembly_GetType_m3468564723,
	Assembly_FillName_m1660001542,
	Assembly_GetName_m981771927,
	Assembly_GetName_m2439919985,
	Assembly_UnprotectedGetName_m600830855,
	Assembly_ToString_m2053237013,
	Assembly_Load_m3487507613,
	Assembly_LoadWithPartialName_m3387477452,
	Assembly_load_with_partial_name_m2517830235,
	Assembly_LoadWithPartialName_m3225299950,
	Assembly_LoadWithPartialName_m3378291794,
	Assembly_GetModule_m3867448062,
	Assembly_GetModulesInternal_m3569974584,
	Assembly_GetModules_m4157408231,
	Assembly_GetExecutingAssembly_m4021024968,
	ResolveEventHolder__ctor_m1522332934,
	AssemblyCompanyAttribute__ctor_m1270469981,
	AssemblyCopyrightAttribute__ctor_m1842063359,
	AssemblyDefaultAliasAttribute__ctor_m1809631251,
	AssemblyDelaySignAttribute__ctor_m542336852,
	AssemblyDescriptionAttribute__ctor_m3993445315,
	AssemblyFileVersionAttribute__ctor_m3720707642,
	AssemblyInformationalVersionAttribute__ctor_m4033947902,
	AssemblyKeyFileAttribute__ctor_m535332047,
	AssemblyName__ctor_m2786326352,
	AssemblyName__ctor_m1753467291,
	AssemblyName_get_Name_m4072373679,
	AssemblyName_set_Name_m1981626655,
	AssemblyName_get_CultureInfo_m3135152423,
	AssemblyName_get_Flags_m1616840602,
	AssemblyName_get_FullName_m3351492191,
	AssemblyName_get_KeyPair_m4000803163,
	AssemblyName_get_Version_m538083430,
	AssemblyName_set_Version_m1802337156,
	AssemblyName_ToString_m11651758,
	AssemblyName_GetPublicKey_m1356287156,
	AssemblyName_get_IsPublicKeyValid_m1483495830,
	AssemblyName_InternalGetPublicKeyToken_m3407918444,
	AssemblyName_ComputePublicKeyToken_m824893834,
	AssemblyName_SetPublicKey_m1771377104,
	AssemblyName_SetPublicKeyToken_m582470133,
	AssemblyName_GetObjectData_m1516383869,
	AssemblyName_Clone_m43657973,
	AssemblyName_OnDeserialization_m3779987437,
	AssemblyProductAttribute__ctor_m1203636347,
	AssemblyTitleAttribute__ctor_m3257920016,
	Binder__ctor_m2821133715,
	Binder__cctor_m245494241,
	Binder_get_DefaultBinder_m950908649,
	Binder_ConvertArgs_m2124461494,
	Binder_GetDerivedLevel_m3216810447,
	Binder_FindMostDerivedMatch_m239579024,
	Default__ctor_m325526679,
	Default_BindToMethod_m490530316,
	Default_ReorderParameters_m2076271671,
	Default_IsArrayAssignable_m953489228,
	Default_ChangeType_m1399759417,
	Default_ReorderArgumentArray_m476258478,
	Default_check_type_m3691874551,
	Default_check_arguments_m3882727959,
	Default_SelectMethod_m3090153711,
	Default_SelectMethod_m469311730,
	Default_GetBetterMethod_m3232777160,
	Default_CompareCloserType_m2643961470,
	Default_SelectProperty_m1220817815,
	Default_check_arguments_with_score_m3467814020,
	Default_check_type_with_score_m3022331006,
	ConstructorInfo__ctor_m356047157,
	ConstructorInfo__cctor_m1016079270,
	ConstructorInfo_get_MemberType_m2297974335,
	ConstructorInfo_Invoke_m4089836896,
	CustomAttributeData__ctor_m2966233049,
	CustomAttributeData_get_Constructor_m489601093,
	CustomAttributeData_get_ConstructorArguments_m1602558961,
	CustomAttributeData_get_NamedArguments_m2950811181,
	CustomAttributeData_GetCustomAttributes_m2970182643,
	CustomAttributeData_GetCustomAttributes_m2141595938,
	CustomAttributeData_GetCustomAttributes_m1033457578,
	CustomAttributeData_GetCustomAttributes_m1863564558,
	CustomAttributeData_ToString_m1995965208,
	CustomAttributeData_Equals_m4034962021,
	CustomAttributeData_GetHashCode_m3727773664,
	CustomAttributeNamedArgument_ToString_m1488801416_AdjustorThunk,
	CustomAttributeNamedArgument_Equals_m1414002036_AdjustorThunk,
	CustomAttributeNamedArgument_GetHashCode_m2317130892_AdjustorThunk,
	CustomAttributeTypedArgument_ToString_m864948362_AdjustorThunk,
	CustomAttributeTypedArgument_Equals_m2261980307_AdjustorThunk,
	CustomAttributeTypedArgument_GetHashCode_m1121388927_AdjustorThunk,
	DefaultMemberAttribute__ctor_m1410463653,
	DefaultMemberAttribute_get_MemberName_m3384235354,
	AssemblyBuilder__ctor_m3936521321,
	AssemblyBuilder_basic_init_m1526438565,
	AssemblyBuilder_get_Location_m384539722,
	AssemblyBuilder_DefineDynamicModule_m1476011641,
	AssemblyBuilder_DefineDynamicModule_m755027604,
	AssemblyBuilder_GetModulesInternal_m1170927462,
	AssemblyBuilder_GetTypes_m3415680380,
	AssemblyBuilder_get_IsCompilerContext_m4201958597,
	AssemblyBuilder_get_IsSave_m879473088,
	AssemblyBuilder_get_IsRun_m3300414718,
	AssemblyBuilder_get_AssemblyDir_m1938411035,
	AssemblyBuilder_not_supported_m1735277432,
	AssemblyBuilder_check_name_and_filename_m4027240280,
	AssemblyBuilder_UnprotectedGetName_m4080174862,
	ConstructorBuilder__ctor_m1580993362,
	ConstructorBuilder_get_CallingConvention_m3019479360,
	ConstructorBuilder_get_TypeBuilder_m2755629087,
	ConstructorBuilder_GetParameters_m1348730871,
	ConstructorBuilder_GetParametersInternal_m2039842762,
	ConstructorBuilder_GetParameterCount_m1122995462,
	ConstructorBuilder_Invoke_m3979373259,
	ConstructorBuilder_Invoke_m3010446651,
	ConstructorBuilder_get_MethodHandle_m3934509563,
	ConstructorBuilder_get_Attributes_m1598011285,
	ConstructorBuilder_get_ReflectedType_m2642670880,
	ConstructorBuilder_get_DeclaringType_m2098046507,
	ConstructorBuilder_get_Name_m2426555260,
	ConstructorBuilder_IsDefined_m3603803379,
	ConstructorBuilder_GetCustomAttributes_m2495332786,
	ConstructorBuilder_GetCustomAttributes_m330373636,
	ConstructorBuilder_GetILGenerator_m1421260830,
	ConstructorBuilder_GetILGenerator_m1750792206,
	ConstructorBuilder_GetToken_m109400720,
	ConstructorBuilder_get_Module_m1709295866,
	ConstructorBuilder_ToString_m1596813917,
	ConstructorBuilder_fixup_m3699998230,
	ConstructorBuilder_get_next_table_index_m2681706538,
	ConstructorBuilder_get_IsCompilerContext_m3364441562,
	ConstructorBuilder_not_supported_m1054126936,
	ConstructorBuilder_not_created_m1456215494,
	DynamicMethod_create_dynamic_method_m1579875961,
	DynamicMethod_destroy_dynamic_method_m2651031212,
	DynamicMethod_CreateDynMethod_m3853278069,
	DynamicMethod_Finalize_m3410343626,
	DynamicMethod_GetBaseDefinition_m2593491625,
	DynamicMethod_GetCustomAttributes_m826227141,
	DynamicMethod_GetCustomAttributes_m179017115,
	DynamicMethod_GetParameters_m2873920314,
	DynamicMethod_Invoke_m1697917514,
	DynamicMethod_IsDefined_m2556354904,
	DynamicMethod_ToString_m2710486086,
	DynamicMethod_get_Attributes_m2260783207,
	DynamicMethod_get_CallingConvention_m2686016598,
	DynamicMethod_get_DeclaringType_m4003101913,
	DynamicMethod_get_MethodHandle_m2498039394,
	DynamicMethod_get_Module_m12989615,
	DynamicMethod_get_Name_m1287905,
	DynamicMethod_get_ReflectedType_m2748486053,
	DynamicMethod_get_ReturnType_m4219951145,
	EnumBuilder_get_Assembly_m1175292766,
	EnumBuilder_get_AssemblyQualifiedName_m3542375588,
	EnumBuilder_get_BaseType_m1707640163,
	EnumBuilder_get_DeclaringType_m4266754303,
	EnumBuilder_get_FullName_m86524873,
	EnumBuilder_get_Module_m3038920337,
	EnumBuilder_get_Name_m4016811629,
	EnumBuilder_get_Namespace_m931779410,
	EnumBuilder_get_ReflectedType_m3155130643,
	EnumBuilder_get_TypeHandle_m825995360,
	EnumBuilder_get_UnderlyingSystemType_m1095282781,
	EnumBuilder_GetAttributeFlagsImpl_m2708654755,
	EnumBuilder_GetConstructorImpl_m3068576149,
	EnumBuilder_GetConstructors_m3294436155,
	EnumBuilder_GetCustomAttributes_m3678770762,
	EnumBuilder_GetCustomAttributes_m166600193,
	EnumBuilder_GetElementType_m2534333387,
	EnumBuilder_GetEvent_m4074915332,
	EnumBuilder_GetField_m3489745843,
	EnumBuilder_GetFields_m151883523,
	EnumBuilder_GetInterfaces_m282127151,
	EnumBuilder_GetMethodImpl_m3968140917,
	EnumBuilder_GetMethods_m415781370,
	EnumBuilder_GetPropertyImpl_m569583507,
	EnumBuilder_HasElementTypeImpl_m3477408451,
	EnumBuilder_InvokeMember_m2995510206,
	EnumBuilder_IsArrayImpl_m572123653,
	EnumBuilder_IsByRefImpl_m210003629,
	EnumBuilder_IsPointerImpl_m2644353933,
	EnumBuilder_IsPrimitiveImpl_m3796774069,
	EnumBuilder_IsValueTypeImpl_m57969026,
	EnumBuilder_IsDefined_m4222535176,
	EnumBuilder_CreateNotSupportedException_m3236297331,
	FieldBuilder_get_Attributes_m1473479383,
	FieldBuilder_get_DeclaringType_m41087402,
	FieldBuilder_get_FieldHandle_m535167546,
	FieldBuilder_get_FieldType_m1091288720,
	FieldBuilder_get_Name_m510046506,
	FieldBuilder_get_ReflectedType_m4057589759,
	FieldBuilder_GetCustomAttributes_m664752430,
	FieldBuilder_GetCustomAttributes_m1915970159,
	FieldBuilder_GetValue_m1576493031,
	FieldBuilder_IsDefined_m838988679,
	FieldBuilder_GetFieldOffset_m725157755,
	FieldBuilder_SetValue_m828035213,
	FieldBuilder_get_UMarshal_m1108254289,
	FieldBuilder_CreateNotSupportedException_m2447945803,
	FieldBuilder_get_Module_m1102715255,
	GenericTypeParameterBuilder_IsSubclassOf_m2266644074,
	GenericTypeParameterBuilder_GetAttributeFlagsImpl_m2144850054,
	GenericTypeParameterBuilder_GetConstructorImpl_m863833310,
	GenericTypeParameterBuilder_GetConstructors_m1741403645,
	GenericTypeParameterBuilder_GetEvent_m1409082535,
	GenericTypeParameterBuilder_GetField_m2300277606,
	GenericTypeParameterBuilder_GetFields_m292751540,
	GenericTypeParameterBuilder_GetInterfaces_m1692228685,
	GenericTypeParameterBuilder_GetMethods_m2360745671,
	GenericTypeParameterBuilder_GetMethodImpl_m1665936690,
	GenericTypeParameterBuilder_GetPropertyImpl_m2584778600,
	GenericTypeParameterBuilder_HasElementTypeImpl_m2509088011,
	GenericTypeParameterBuilder_IsAssignableFrom_m67565415,
	GenericTypeParameterBuilder_IsInstanceOfType_m1071939531,
	GenericTypeParameterBuilder_IsArrayImpl_m67259334,
	GenericTypeParameterBuilder_IsByRefImpl_m4112722356,
	GenericTypeParameterBuilder_IsPointerImpl_m2257540205,
	GenericTypeParameterBuilder_IsPrimitiveImpl_m1952010459,
	GenericTypeParameterBuilder_IsValueTypeImpl_m480678299,
	GenericTypeParameterBuilder_InvokeMember_m1647304778,
	GenericTypeParameterBuilder_GetElementType_m871345408,
	GenericTypeParameterBuilder_get_UnderlyingSystemType_m3450067685,
	GenericTypeParameterBuilder_get_Assembly_m2257222024,
	GenericTypeParameterBuilder_get_AssemblyQualifiedName_m2323022482,
	GenericTypeParameterBuilder_get_BaseType_m3389926280,
	GenericTypeParameterBuilder_get_FullName_m4098525591,
	GenericTypeParameterBuilder_IsDefined_m98179866,
	GenericTypeParameterBuilder_GetCustomAttributes_m386082976,
	GenericTypeParameterBuilder_GetCustomAttributes_m580748276,
	GenericTypeParameterBuilder_get_Name_m1181273062,
	GenericTypeParameterBuilder_get_Namespace_m2056767826,
	GenericTypeParameterBuilder_get_Module_m1433762073,
	GenericTypeParameterBuilder_get_DeclaringType_m1741243224,
	GenericTypeParameterBuilder_get_ReflectedType_m2178572472,
	GenericTypeParameterBuilder_get_TypeHandle_m366353680,
	GenericTypeParameterBuilder_GetGenericArguments_m2988765390,
	GenericTypeParameterBuilder_GetGenericTypeDefinition_m1032780002,
	GenericTypeParameterBuilder_get_ContainsGenericParameters_m786165540,
	GenericTypeParameterBuilder_get_IsGenericParameter_m792248181,
	GenericTypeParameterBuilder_get_IsGenericType_m2493787252,
	GenericTypeParameterBuilder_get_IsGenericTypeDefinition_m3082475717,
	GenericTypeParameterBuilder_not_supported_m3358960901,
	GenericTypeParameterBuilder_ToString_m2460043372,
	GenericTypeParameterBuilder_Equals_m3260957994,
	GenericTypeParameterBuilder_GetHashCode_m852224381,
	GenericTypeParameterBuilder_MakeGenericType_m3048165991,
	ILGenerator__ctor_m1540961053,
	ILGenerator__cctor_m2934917055,
	ILGenerator_add_token_fixup_m1816002840,
	ILGenerator_make_room_m2688251824,
	ILGenerator_emit_int_m2322014738,
	ILGenerator_ll_emit_m2218983546,
	ILGenerator_target_len_m542103396,
	ILGenerator_DeclareLocal_m191048170,
	ILGenerator_DeclareLocal_m1660608214,
	ILGenerator_DefineLabel_m835079392,
	ILGenerator_Emit_m3982339419,
	ILGenerator_Emit_m165992488,
	ILGenerator_Emit_m1785051522,
	ILGenerator_Emit_m2655709959,
	ILGenerator_Emit_m990732443,
	ILGenerator_Emit_m1401094534,
	ILGenerator_Emit_m3083135129,
	ILGenerator_Emit_m2239205197,
	ILGenerator_Emit_m3803522508,
	ILGenerator_Emit_m22313773,
	ILGenerator_Emit_m3111835688,
	ILGenerator_EmitCall_m2478864924,
	ILGenerator_MarkLabel_m1160930839,
	ILGenerator_label_fixup_m1749904972,
	ILGenerator_Mono_GetCurrentOffset_m993338688,
	LabelData__ctor_m3949021681_AdjustorThunk,
	Label__ctor_m4171632839_AdjustorThunk,
	Label_Equals_m1321622490_AdjustorThunk,
	Label_GetHashCode_m1231913871_AdjustorThunk,
	LocalBuilder__ctor_m1650329351,
	MethodBuilder__ctor_m3664913099,
	MethodBuilder_get_ContainsGenericParameters_m1358274636,
	MethodBuilder_get_MethodHandle_m565241742,
	MethodBuilder_get_ReturnType_m3514670820,
	MethodBuilder_get_ReflectedType_m3038768129,
	MethodBuilder_get_DeclaringType_m2226312865,
	MethodBuilder_get_Name_m610453823,
	MethodBuilder_get_Attributes_m2740229145,
	MethodBuilder_get_CallingConvention_m4267439137,
	MethodBuilder_GetToken_m2784098896,
	MethodBuilder_GetBaseDefinition_m3391685745,
	MethodBuilder_GetParameters_m3527753207,
	MethodBuilder_GetParameterCount_m3108880742,
	MethodBuilder_Invoke_m3837446660,
	MethodBuilder_IsDefined_m662196788,
	MethodBuilder_GetCustomAttributes_m587605549,
	MethodBuilder_GetCustomAttributes_m731278908,
	MethodBuilder_GetILGenerator_m4152496715,
	MethodBuilder_GetILGenerator_m2421555267,
	MethodBuilder_check_override_m4226508046,
	MethodBuilder_fixup_m1765890582,
	MethodBuilder_ToString_m561658744,
	MethodBuilder_Equals_m3329023947,
	MethodBuilder_GetHashCode_m2905063929,
	MethodBuilder_get_next_table_index_m2755473113,
	MethodBuilder_set_override_m1765815453,
	MethodBuilder_NotSupported_m1497589941,
	MethodBuilder_MakeGenericMethod_m2175748754,
	MethodBuilder_get_IsGenericMethodDefinition_m2943035191,
	MethodBuilder_get_IsGenericMethod_m3216441561,
	MethodBuilder_GetGenericArguments_m1765425737,
	MethodBuilder_get_Module_m2693263127,
	MethodToken__ctor_m2100013302_AdjustorThunk,
	MethodToken__cctor_m2263526478,
	MethodToken_Equals_m460628456_AdjustorThunk,
	MethodToken_GetHashCode_m673885300_AdjustorThunk,
	MethodToken_get_Token_m966062910_AdjustorThunk,
	ModuleBuilder__ctor_m164976504,
	ModuleBuilder__cctor_m2163728271,
	ModuleBuilder_basic_init_m3240533393,
	ModuleBuilder_set_wrappers_type_m2998401134,
	ModuleBuilder_IsTransient_m421403846,
	ModuleBuilder_DefineType_m3763661967,
	ModuleBuilder_AddType_m4198050894,
	ModuleBuilder_DefineType_m3903640095,
	ModuleBuilder_DefineType_m2262733165,
	ModuleBuilder_GetType_m2225679021,
	ModuleBuilder_search_in_array_m1832733816,
	ModuleBuilder_search_nested_in_array_m942242794,
	ModuleBuilder_create_modified_type_m3780542108,
	ModuleBuilder_GetMaybeNested_m3875745566,
	ModuleBuilder_GetType_m813933439,
	ModuleBuilder_get_next_table_index_m1158040331,
	ModuleBuilder_GetTypes_m158355402,
	ModuleBuilder_getUSIndex_m1446676113,
	ModuleBuilder_getToken_m4290400349,
	ModuleBuilder_getMethodToken_m454517975,
	ModuleBuilder_GetToken_m1823519114,
	ModuleBuilder_GetToken_m4274310417,
	ModuleBuilder_GetToken_m1735168917,
	ModuleBuilder_RegisterToken_m4166846047,
	ModuleBuilder_GetTokenGenerator_m4177350090,
	ModuleBuilder_get_FileName_m2155150858,
	ModuleBuilder_CreateGlobalType_m3933178429,
	ModuleBuilderTokenGenerator__ctor_m2360787210,
	ModuleBuilderTokenGenerator_GetToken_m2356555833,
	ModuleBuilderTokenGenerator_GetToken_m2588853565,
	ModuleBuilderTokenGenerator_GetToken_m1396347424,
	OpCode__ctor_m2823239373_AdjustorThunk,
	OpCode_GetHashCode_m1374201362_AdjustorThunk,
	OpCode_Equals_m1376200488_AdjustorThunk,
	OpCode_ToString_m4248967054_AdjustorThunk,
	OpCode_get_Name_m149707431_AdjustorThunk,
	OpCode_get_Size_m3461506715_AdjustorThunk,
	OpCode_get_OperandType_m1634816806_AdjustorThunk,
	OpCode_get_StackBehaviourPop_m4250794726_AdjustorThunk,
	OpCode_get_StackBehaviourPush_m986094870_AdjustorThunk,
	OpCode_get_Value_m917085326_AdjustorThunk,
	OpCode_op_Equality_m3082103192,
	OpCodeNames__cctor_m4023020620,
	OpCodes__cctor_m3821715395,
	ParameterBuilder_get_Attributes_m2132969861,
	ParameterBuilder_get_Name_m4047684794,
	ParameterBuilder_get_Position_m3885059176,
	PropertyBuilder_get_Attributes_m466033853,
	PropertyBuilder_get_CanRead_m3783190070,
	PropertyBuilder_get_CanWrite_m2657562188,
	PropertyBuilder_get_DeclaringType_m1411910527,
	PropertyBuilder_get_Name_m117186655,
	PropertyBuilder_get_PropertyType_m682373713,
	PropertyBuilder_get_ReflectedType_m1888835465,
	PropertyBuilder_GetAccessors_m3962192052,
	PropertyBuilder_GetCustomAttributes_m3798356764,
	PropertyBuilder_GetCustomAttributes_m2917594003,
	PropertyBuilder_GetGetMethod_m1844574876,
	PropertyBuilder_GetIndexParameters_m2501163646,
	PropertyBuilder_GetSetMethod_m128670376,
	PropertyBuilder_GetValue_m1722444490,
	PropertyBuilder_GetValue_m3592513194,
	PropertyBuilder_IsDefined_m406627924,
	PropertyBuilder_SetValue_m3164486317,
	PropertyBuilder_SetValue_m830166741,
	PropertyBuilder_get_Module_m4024354932,
	PropertyBuilder_not_supported_m1290265515,
	TypeBuilder__ctor_m3644689907,
	TypeBuilder__ctor_m3099050601,
	TypeBuilder_GetAttributeFlagsImpl_m2729077290,
	TypeBuilder_setup_internal_class_m4067683076,
	TypeBuilder_create_generic_class_m3823884980,
	TypeBuilder_get_Assembly_m4071790036,
	TypeBuilder_get_AssemblyQualifiedName_m4059714567,
	TypeBuilder_get_BaseType_m3571781126,
	TypeBuilder_get_DeclaringType_m4128305641,
	TypeBuilder_get_UnderlyingSystemType_m4226811350,
	TypeBuilder_GetFullName_m92522820,
	TypeBuilder_get_FullName_m420272554,
	TypeBuilder_get_Module_m4154269895,
	TypeBuilder_get_Name_m1525921477,
	TypeBuilder_get_Namespace_m4175323609,
	TypeBuilder_get_ReflectedType_m3266505878,
	TypeBuilder_GetConstructorImpl_m3925526366,
	TypeBuilder_IsDefined_m1289323273,
	TypeBuilder_GetCustomAttributes_m2898560796,
	TypeBuilder_GetCustomAttributes_m981725999,
	TypeBuilder_DefineConstructor_m2989882735,
	TypeBuilder_DefineConstructor_m3514391445,
	TypeBuilder_DefineDefaultConstructor_m2168449784,
	TypeBuilder_append_method_m751930812,
	TypeBuilder_DefineMethod_m422510144,
	TypeBuilder_DefineMethod_m3408269778,
	TypeBuilder_DefineMethod_m1997123315,
	TypeBuilder_DefineMethodOverride_m2703939108,
	TypeBuilder_create_runtime_class_m2581270900,
	TypeBuilder_is_nested_in_m1146519762,
	TypeBuilder_has_ctor_method_m2987175843,
	TypeBuilder_CreateType_m3375483507,
	TypeBuilder_GetConstructors_m26844333,
	TypeBuilder_GetConstructorsInternal_m3565722264,
	TypeBuilder_GetElementType_m1881206953,
	TypeBuilder_GetEvent_m2166527753,
	TypeBuilder_GetField_m2932767407,
	TypeBuilder_GetFields_m2518194342,
	TypeBuilder_GetInterfaces_m4067367903,
	TypeBuilder_GetMethodsByName_m1441669940,
	TypeBuilder_GetMethods_m455544206,
	TypeBuilder_GetMethodImpl_m3583143647,
	TypeBuilder_GetPropertyImpl_m3104345782,
	TypeBuilder_HasElementTypeImpl_m1871001960,
	TypeBuilder_InvokeMember_m713975721,
	TypeBuilder_IsArrayImpl_m2884820883,
	TypeBuilder_IsByRefImpl_m3775334677,
	TypeBuilder_IsPointerImpl_m2837168342,
	TypeBuilder_IsPrimitiveImpl_m1753586266,
	TypeBuilder_IsValueTypeImpl_m3935440087,
	TypeBuilder_MakeGenericType_m2799607032,
	TypeBuilder_get_TypeHandle_m3498565307,
	TypeBuilder_SetParent_m4101148229,
	TypeBuilder_get_next_table_index_m789974556,
	TypeBuilder_get_IsCompilerContext_m4056143290,
	TypeBuilder_get_is_created_m1192848807,
	TypeBuilder_not_supported_m1239084737,
	TypeBuilder_check_not_created_m3652863637,
	TypeBuilder_check_created_m3513163610,
	TypeBuilder_check_name_m3505884515,
	TypeBuilder_ToString_m3497908325,
	TypeBuilder_IsAssignableFrom_m3127348202,
	TypeBuilder_IsSubclassOf_m3458909121,
	TypeBuilder_IsAssignableTo_m547961029,
	TypeBuilder_GetGenericArguments_m2872156836,
	TypeBuilder_GetGenericTypeDefinition_m1632720438,
	TypeBuilder_get_ContainsGenericParameters_m1769080325,
	TypeBuilder_get_IsGenericParameter_m1751799710,
	TypeBuilder_get_IsGenericTypeDefinition_m1477212742,
	TypeBuilder_get_IsGenericType_m2295780578,
	UnmanagedMarshal_ToMarshalAsAttribute_m3182194847,
	EventInfo__ctor_m3033129999,
	EventInfo_get_EventHandlerType_m420690865,
	EventInfo_get_MemberType_m2405145162,
	AddEventAdapter__ctor_m2428277574,
	AddEventAdapter_Invoke_m3665771100,
	AddEventAdapter_BeginInvoke_m913431108,
	AddEventAdapter_EndInvoke_m3898366634,
	FieldInfo__ctor_m3305575002,
	FieldInfo_get_MemberType_m143061680,
	FieldInfo_get_IsLiteral_m534699794,
	FieldInfo_get_IsStatic_m3482711189,
	FieldInfo_get_IsPublic_m3378038140,
	FieldInfo_get_IsNotSerialized_m2684033086,
	FieldInfo_SetValue_m2460171138,
	FieldInfo_internal_from_handle_type_m3256989094,
	FieldInfo_GetFieldFromHandle_m586851985,
	FieldInfo_GetFieldOffset_m1356898082,
	FieldInfo_GetUnmanagedMarshal_m1813368915,
	FieldInfo_get_UMarshal_m1217454798,
	FieldInfo_GetPseudoCustomAttributes_m3351706050,
	LocalVariableInfo__ctor_m818516327,
	LocalVariableInfo_ToString_m2552653929,
	MemberFilter__ctor_m1555764023,
	MemberFilter_Invoke_m2890658112,
	MemberFilter_BeginInvoke_m3549240552,
	MemberFilter_EndInvoke_m3130107476,
	MemberInfo__ctor_m3258770133,
	MemberInfo_get_Module_m4119009657,
	MemberInfoSerializationHolder__ctor_m709149403,
	MemberInfoSerializationHolder_Serialize_m2002453739,
	MemberInfoSerializationHolder_Serialize_m2491586031,
	MemberInfoSerializationHolder_GetObjectData_m4141100434,
	MemberInfoSerializationHolder_GetRealObject_m3590242972,
	MethodBase__ctor_m1907868998,
	MethodBase_GetMethodFromHandleNoGenericCheck_m1262206995,
	MethodBase_GetMethodFromIntPtr_m3014201362,
	MethodBase_GetMethodFromHandle_m286788163,
	MethodBase_GetMethodFromHandleInternalType_m2695073734,
	MethodBase_GetParameterCount_m2917849922,
	MethodBase_Invoke_m1776411915,
	MethodBase_get_CallingConvention_m2371784139,
	MethodBase_get_IsPublic_m2180846589,
	MethodBase_get_IsStatic_m2399864271,
	MethodBase_get_IsVirtual_m2008546636,
	MethodBase_get_IsAbstract_m428833029,
	MethodBase_get_next_table_index_m3259310018,
	MethodBase_GetGenericArguments_m1292856952,
	MethodBase_get_ContainsGenericParameters_m2144492325,
	MethodBase_get_IsGenericMethodDefinition_m3619640237,
	MethodBase_get_IsGenericMethod_m3017096435,
	MethodInfo__ctor_m2805780217,
	MethodInfo_get_MemberType_m3442377339,
	MethodInfo_get_ReturnType_m3163894070,
	MethodInfo_MakeGenericMethod_m1996785325,
	MethodInfo_GetGenericArguments_m98948877,
	MethodInfo_get_IsGenericMethod_m1711950591,
	MethodInfo_get_IsGenericMethodDefinition_m3304621588,
	MethodInfo_get_ContainsGenericParameters_m3008250450,
	Missing__ctor_m1587294558,
	Missing__cctor_m1154503959,
	Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3173502177,
	Module__ctor_m2380079016,
	Module__cctor_m3457500417,
	Module_get_Assembly_m2485063752,
	Module_get_Name_m1373448298,
	Module_get_ScopeName_m4152486041,
	Module_GetCustomAttributes_m76573271,
	Module_GetObjectData_m497094981,
	Module_GetType_m1977604635,
	Module_GetType_m3678256200,
	Module_InternalGetTypes_m4031912254,
	Module_GetTypes_m3756259854,
	Module_IsDefined_m2423524910,
	Module_IsResource_m553227372,
	Module_ToString_m2471617896,
	Module_filter_by_type_name_m1840126910,
	Module_filter_by_type_name_ignore_case_m711265203,
	MonoCMethod__ctor_m1867900682,
	MonoCMethod_GetParameters_m3596508252,
	MonoCMethod_InternalInvoke_m131287437,
	MonoCMethod_Invoke_m1340636245,
	MonoCMethod_Invoke_m2700167622,
	MonoCMethod_get_MethodHandle_m3757890674,
	MonoCMethod_get_Attributes_m757768605,
	MonoCMethod_get_CallingConvention_m1104433355,
	MonoCMethod_get_ReflectedType_m3914411905,
	MonoCMethod_get_DeclaringType_m3406114400,
	MonoCMethod_get_Name_m3090866252,
	MonoCMethod_IsDefined_m3900688634,
	MonoCMethod_GetCustomAttributes_m3823059477,
	MonoCMethod_GetCustomAttributes_m3068196335,
	MonoCMethod_ToString_m3992577062,
	MonoCMethod_GetObjectData_m2489171292,
	MonoEvent__ctor_m1690536578,
	MonoEvent_get_Attributes_m3048829315,
	MonoEvent_GetAddMethod_m210217252,
	MonoEvent_get_DeclaringType_m862221512,
	MonoEvent_get_ReflectedType_m3664183825,
	MonoEvent_get_Name_m3774595291,
	MonoEvent_ToString_m2145104522,
	MonoEvent_IsDefined_m10931749,
	MonoEvent_GetCustomAttributes_m1729688056,
	MonoEvent_GetCustomAttributes_m2369459044,
	MonoEvent_GetObjectData_m3301761592,
	MonoEventInfo_get_event_info_m583997560,
	MonoEventInfo_GetEventInfo_m873645389,
	MonoField__ctor_m5376011,
	MonoField_get_Attributes_m1814015643,
	MonoField_get_FieldHandle_m3729647377,
	MonoField_get_FieldType_m1670137202,
	MonoField_GetParentType_m2478933781,
	MonoField_get_ReflectedType_m471710812,
	MonoField_get_DeclaringType_m2066594735,
	MonoField_get_Name_m2861402224,
	MonoField_IsDefined_m2274038045,
	MonoField_GetCustomAttributes_m2142838032,
	MonoField_GetCustomAttributes_m3687140927,
	MonoField_GetFieldOffset_m3808764875,
	MonoField_GetValueInternal_m532651562,
	MonoField_GetValue_m3124733531,
	MonoField_ToString_m2518484388,
	MonoField_SetValueInternal_m2352116743,
	MonoField_SetValue_m2338106905,
	MonoField_Clone_m3669042226,
	MonoField_GetObjectData_m1292125335,
	MonoField_CheckGeneric_m453069507,
	MonoGenericCMethod__ctor_m1374831274,
	MonoGenericCMethod_get_ReflectedType_m1440479536,
	MonoGenericMethod__ctor_m2795356912,
	MonoGenericMethod_get_ReflectedType_m3748461472,
	MonoMethod__ctor_m2104049215,
	MonoMethod__ctor_m3792454563,
	MonoMethod_get_name_m2690633670,
	MonoMethod_get_base_definition_m282872694,
	MonoMethod_GetBaseDefinition_m2844667474,
	MonoMethod_get_ReturnType_m3656785830,
	MonoMethod_GetParameters_m2077150731,
	MonoMethod_InternalInvoke_m1266143136,
	MonoMethod_Invoke_m2898011027,
	MonoMethod_get_MethodHandle_m4198555269,
	MonoMethod_get_Attributes_m1519794451,
	MonoMethod_get_CallingConvention_m4088809856,
	MonoMethod_get_ReflectedType_m18334703,
	MonoMethod_get_DeclaringType_m3539501442,
	MonoMethod_get_Name_m3372146751,
	MonoMethod_IsDefined_m2906130478,
	MonoMethod_GetCustomAttributes_m3677182122,
	MonoMethod_GetCustomAttributes_m4130180212,
	MonoMethod_GetDllImportAttribute_m853324018,
	MonoMethod_GetPseudoCustomAttributes_m3959384572,
	MonoMethod_ShouldPrintFullName_m1607666412,
	MonoMethod_ToString_m3550677523,
	MonoMethod_GetObjectData_m854317157,
	MonoMethod_MakeGenericMethod_m1386790968,
	MonoMethod_MakeGenericMethod_impl_m1719465708,
	MonoMethod_GetGenericArguments_m4278548385,
	MonoMethod_get_IsGenericMethodDefinition_m3024870835,
	MonoMethod_get_IsGenericMethod_m1665512545,
	MonoMethod_get_ContainsGenericParameters_m3860345224,
	MonoMethodInfo_get_method_info_m88651774,
	MonoMethodInfo_GetMethodInfo_m2481349296,
	MonoMethodInfo_GetDeclaringType_m2924452727,
	MonoMethodInfo_GetReturnType_m914391169,
	MonoMethodInfo_GetAttributes_m2458894713,
	MonoMethodInfo_GetCallingConvention_m3156036493,
	MonoMethodInfo_get_parameter_info_m1729015241,
	MonoMethodInfo_GetParametersInfo_m2209427166,
	MonoProperty__ctor_m588439900,
	MonoProperty_CachePropertyInfo_m2968057423,
	MonoProperty_get_Attributes_m1632795078,
	MonoProperty_get_CanRead_m2001748608,
	MonoProperty_get_CanWrite_m3409349928,
	MonoProperty_get_PropertyType_m4138957578,
	MonoProperty_get_ReflectedType_m4009479510,
	MonoProperty_get_DeclaringType_m966464220,
	MonoProperty_get_Name_m3049728465,
	MonoProperty_GetAccessors_m412928203,
	MonoProperty_GetGetMethod_m2489912362,
	MonoProperty_GetIndexParameters_m440199833,
	MonoProperty_GetSetMethod_m527596913,
	MonoProperty_IsDefined_m2173657168,
	MonoProperty_GetCustomAttributes_m2723308902,
	MonoProperty_GetCustomAttributes_m3619796755,
	MonoProperty_CreateGetterDelegate_m2478402519,
	MonoProperty_GetValue_m995140552,
	MonoProperty_GetValue_m2828248678,
	MonoProperty_SetValue_m342801444,
	MonoProperty_ToString_m3100929865,
	MonoProperty_GetOptionalCustomModifiers_m62958967,
	MonoProperty_GetRequiredCustomModifiers_m306465896,
	MonoProperty_GetObjectData_m4077457866,
	GetterAdapter__ctor_m2389296347,
	GetterAdapter_Invoke_m3767885970,
	GetterAdapter_BeginInvoke_m3429316396,
	GetterAdapter_EndInvoke_m164602429,
	MonoPropertyInfo_get_property_info_m1599555644,
	MonoPropertyInfo_GetTypeModifiers_m3090493443,
	ParameterInfo__ctor_m2869882516,
	ParameterInfo__ctor_m2779026345,
	ParameterInfo__ctor_m3269320476,
	ParameterInfo_ToString_m2002405990,
	ParameterInfo_get_ParameterType_m4197803362,
	ParameterInfo_get_Attributes_m1582734594,
	ParameterInfo_get_IsIn_m1278224586,
	ParameterInfo_get_IsOptional_m2957997858,
	ParameterInfo_get_IsOut_m867677222,
	ParameterInfo_get_IsRetval_m86270398,
	ParameterInfo_get_Member_m3284376465,
	ParameterInfo_get_Name_m3739685559,
	ParameterInfo_get_Position_m2927189904,
	ParameterInfo_GetCustomAttributes_m2376494592,
	ParameterInfo_IsDefined_m1890759429,
	ParameterInfo_GetPseudoCustomAttributes_m2207478763,
	Pointer__ctor_m2714841439,
	Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m609897590,
	Pointer_Box_m389276611,
	PropertyInfo__ctor_m4235916625,
	PropertyInfo_get_MemberType_m2794839864,
	PropertyInfo_GetGetMethod_m1510309854,
	PropertyInfo_GetValue_m403181050,
	PropertyInfo_SetValue_m2777755129,
	PropertyInfo_GetOptionalCustomModifiers_m2883850568,
	PropertyInfo_GetRequiredCustomModifiers_m3241367329,
	StrongNameKeyPair__ctor_m2394160001,
	StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m2655882830,
	StrongNameKeyPair_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1665239530,
	StrongNameKeyPair_GetRSA_m2008774769,
	StrongNameKeyPair_StrongName_m1031343114,
	TargetException__ctor_m4172127019,
	TargetException__ctor_m1440702323,
	TargetException__ctor_m3701535709,
	TargetInvocationException__ctor_m3011316584,
	TargetInvocationException__ctor_m1498620089,
	TargetInvocationException__ctor_m2859292946,
	TargetParameterCountException__ctor_m2135390327,
	TargetParameterCountException__ctor_m4113674829,
	TargetParameterCountException__ctor_m400549751,
	TypeDelegator__ctor_m3613242258,
	TypeDelegator_get_Assembly_m3283071283,
	TypeDelegator_get_AssemblyQualifiedName_m907578895,
	TypeDelegator_get_BaseType_m1404832719,
	TypeDelegator_get_FullName_m369652946,
	TypeDelegator_get_Module_m402693140,
	TypeDelegator_get_Name_m690019205,
	TypeDelegator_get_Namespace_m2110525994,
	TypeDelegator_get_TypeHandle_m1498852405,
	TypeDelegator_get_UnderlyingSystemType_m990164729,
	TypeDelegator_GetAttributeFlagsImpl_m2642839032,
	TypeDelegator_GetConstructorImpl_m3080184268,
	TypeDelegator_GetConstructors_m2496352484,
	TypeDelegator_GetCustomAttributes_m3064730286,
	TypeDelegator_GetCustomAttributes_m1118628524,
	TypeDelegator_GetElementType_m4265261164,
	TypeDelegator_GetEvent_m3148520673,
	TypeDelegator_GetField_m2897478010,
	TypeDelegator_GetFields_m1661146203,
	TypeDelegator_GetInterfaces_m1608820881,
	TypeDelegator_GetMethodImpl_m725915800,
	TypeDelegator_GetMethods_m911682671,
	TypeDelegator_GetPropertyImpl_m656398553,
	TypeDelegator_HasElementTypeImpl_m2350626737,
	TypeDelegator_InvokeMember_m4050724539,
	TypeDelegator_IsArrayImpl_m2097588942,
	TypeDelegator_IsByRefImpl_m613197127,
	TypeDelegator_IsDefined_m1601251036,
	TypeDelegator_IsPointerImpl_m458295709,
	TypeDelegator_IsPrimitiveImpl_m2362421338,
	TypeDelegator_IsValueTypeImpl_m3770949884,
	TypeFilter__ctor_m3644914440,
	TypeFilter_Invoke_m3862132457,
	TypeFilter_BeginInvoke_m1623271879,
	TypeFilter_EndInvoke_m998903841,
	ResolveEventArgs__ctor_m1455935166,
	ResolveEventHandler__ctor_m1911137231,
	ResolveEventHandler_Invoke_m1337322179,
	ResolveEventHandler_BeginInvoke_m762369743,
	ResolveEventHandler_EndInvoke_m1085261130,
	NameOrId_get_IsName_m2723783478,
	NameOrId_get_Id_m2318951827,
	NameOrId_ToString_m1694085646,
	NeutralResourcesLanguageAttribute__ctor_m868478272,
	ResourceManager__ctor_m4162875493,
	ResourceManager__cctor_m3647223129,
	ResourceReader__ctor_m204352998,
	ResourceReader__ctor_m3853106506,
	ResourceReader_System_Collections_IEnumerable_GetEnumerator_m577123352,
	ResourceReader_System_IDisposable_Dispose_m3207991025,
	ResourceReader_ReadHeaders_m1190430799,
	ResourceReader_CreateResourceInfo_m1818330740,
	ResourceReader_Read7BitEncodedInt_m3568166465,
	ResourceReader_ReadValueVer2_m2797880867,
	ResourceReader_ReadValueVer1_m183253382,
	ResourceReader_ReadNonPredefinedValue_m2638853518,
	ResourceReader_LoadResourceValues_m104914612,
	ResourceReader_Close_m3765232219,
	ResourceReader_GetEnumerator_m3404589731,
	ResourceReader_Dispose_m3597121875,
	ResourceCacheItem__ctor_m3279356314_AdjustorThunk,
	ResourceEnumerator__ctor_m3428592283,
	ResourceEnumerator_get_Entry_m1508537883,
	ResourceEnumerator_get_Key_m3323042710,
	ResourceEnumerator_get_Value_m3946340682,
	ResourceEnumerator_get_Current_m3987005752,
	ResourceEnumerator_MoveNext_m422576100,
	ResourceEnumerator_Reset_m3754276504,
	ResourceEnumerator_FillCache_m1661715061,
	ResourceInfo__ctor_m1985704952_AdjustorThunk,
	ResourceSet__ctor_m3356376607,
	ResourceSet__ctor_m153254307,
	ResourceSet__ctor_m2006909906,
	ResourceSet__ctor_m3618395942,
	ResourceSet_System_Collections_IEnumerable_GetEnumerator_m2807499934,
	ResourceSet_Dispose_m2881303269,
	ResourceSet_Dispose_m1823973062,
	ResourceSet_GetEnumerator_m3459697719,
	ResourceSet_GetObjectInternal_m162983637,
	ResourceSet_GetObject_m1383205650,
	ResourceSet_GetObject_m3744937321,
	ResourceSet_ReadResources_m3663669011,
	RuntimeResourceSet__ctor_m1178110395,
	RuntimeResourceSet__ctor_m915567562,
	RuntimeResourceSet__ctor_m2765575100,
	RuntimeResourceSet_GetObject_m1236819169,
	RuntimeResourceSet_GetObject_m2665759398,
	RuntimeResourceSet_CloneDisposableObjectIfPossible_m2725520898,
	SatelliteContractVersionAttribute__ctor_m3630863995,
	Win32Resource_get_ResourceType_m1654432376,
	Win32Resource_ToString_m1615154437,
	CompilationRelaxationsAttribute__ctor_m2313138045,
	CompilerGeneratedAttribute__ctor_m3151881902,
	DecimalConstantAttribute__ctor_m3583301917,
	DefaultDependencyAttribute__ctor_m502524668,
	FixedBufferAttribute__ctor_m2453309552,
	FixedBufferAttribute_get_ElementType_m539172858,
	FixedBufferAttribute_get_Length_m1478886548,
	InternalsVisibleToAttribute__ctor_m2564612584,
	RuntimeCompatibilityAttribute__ctor_m1311107907,
	RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2506646892,
	RuntimeHelpers_InitializeArray_m4077124945,
	RuntimeHelpers_InitializeArray_m3117905507,
	RuntimeHelpers_get_OffsetToStringData_m2192601476,
	StringFreezingAttribute__ctor_m2350592359,
	CriticalFinalizerObject__ctor_m3245424448,
	CriticalFinalizerObject_Finalize_m2010384847,
	ReliabilityContractAttribute__ctor_m2124570898,
	COMException__ctor_m3707984232,
	COMException__ctor_m1066143105,
	COMException_ToString_m2192592964,
	ClassInterfaceAttribute__ctor_m637338123,
	ComDefaultInterfaceAttribute__ctor_m332930853,
	ComImportAttribute__ctor_m3468592294,
	ComVisibleAttribute__ctor_m1596017997,
	DispIdAttribute__ctor_m223675039,
	DllImportAttribute__ctor_m1397784140,
	DllImportAttribute_get_Value_m621189650,
	ExternalException__ctor_m2877839282,
	ExternalException__ctor_m4224477539,
	FieldOffsetAttribute__ctor_m591213967,
	GCHandle__ctor_m2690474163_AdjustorThunk,
	GCHandle_get_IsAllocated_m1058226959_AdjustorThunk,
	GCHandle_get_Target_m1824973883_AdjustorThunk,
	GCHandle_Alloc_m3823409740,
	GCHandle_Free_m1457699368_AdjustorThunk,
	GCHandle_GetTarget_m1711976502,
	GCHandle_GetTargetHandle_m423901123,
	GCHandle_FreeHandle_m2765220421,
	GCHandle_Equals_m146069735_AdjustorThunk,
	GCHandle_GetHashCode_m2446251778_AdjustorThunk,
	GuidAttribute__ctor_m3183273657,
	InAttribute__ctor_m3499482504,
	InterfaceTypeAttribute__ctor_m3307583035,
	Marshal__cctor_m4007734770,
	Marshal_copy_from_unmanaged_m2834266824,
	Marshal_Copy_m1222846562,
	Marshal_Copy_m1714210296,
	Marshal_ReadByte_m1960935664,
	Marshal_WriteByte_m951096718,
	MarshalAsAttribute__ctor_m1885514494,
	MarshalDirectiveException__ctor_m629358357,
	MarshalDirectiveException__ctor_m636944700,
	OptionalAttribute__ctor_m1218709376,
	OutAttribute__ctor_m1231442694,
	PreserveSigAttribute__ctor_m332009382,
	SafeHandle__ctor_m124356559,
	SafeHandle_Close_m1630741059,
	SafeHandle_DangerousAddRef_m614714386,
	SafeHandle_DangerousGetHandle_m3697436134,
	SafeHandle_DangerousRelease_m190326290,
	SafeHandle_Dispose_m817995135,
	SafeHandle_Dispose_m4229010569,
	SafeHandle_SetHandle_m2809947802,
	SafeHandle_Finalize_m3866180675,
	TypeLibImportClassAttribute__ctor_m2302178978,
	TypeLibVersionAttribute__ctor_m2033697886,
	UnmanagedFunctionPointerAttribute__ctor_m2291887142,
	ActivatedClientTypeEntry__ctor_m1905793997,
	ActivatedClientTypeEntry_get_ApplicationUrl_m2894992111,
	ActivatedClientTypeEntry_get_ContextAttributes_m4017563407,
	ActivatedClientTypeEntry_get_ObjectType_m1969125393,
	ActivatedClientTypeEntry_ToString_m2494181680,
	ActivatedServiceTypeEntry__ctor_m3973743857,
	ActivatedServiceTypeEntry_get_ObjectType_m537376111,
	ActivatedServiceTypeEntry_ToString_m1591455874,
	ActivationServices_get_ConstructionActivator_m1239151545,
	ActivationServices_RemoteActivate_m3345439282,
	ActivationServices_CreateProxyFromAttributes_m3864561181,
	ActivationServices_CreateConstructionCall_m2894682304,
	ActivationServices_CreateInstanceFromMessage_m2493847255,
	ActivationServices_AllocateUninitializedClassInstance_m1640049132,
	ActivationServices_EnableProxyActivation_m1823951881,
	AppDomainLevelActivator__ctor_m3990740325,
	AppDomainLevelActivator_get_NextActivator_m2892367069,
	AppDomainLevelActivator_Activate_m1419028841,
	ConstructionLevelActivator__ctor_m3779412964,
	ConstructionLevelActivator_get_NextActivator_m815517039,
	ConstructionLevelActivator_Activate_m1875520998,
	ContextLevelActivator__ctor_m100091473,
	ContextLevelActivator_get_NextActivator_m3456480201,
	ContextLevelActivator_Activate_m1196612728,
	RemoteActivationAttribute__ctor_m2149009645,
	RemoteActivationAttribute_IsContextOK_m112778382,
	RemoteActivationAttribute_GetPropertiesForNewContext_m2023065452,
	RemoteActivator_Activate_m3917386814,
	RemoteActivator_InitializeLifetimeService_m3335532355,
	RemoteActivator_get_NextActivator_m31954545,
	UrlAttribute_get_UrlValue_m381261874,
	UrlAttribute_Equals_m758046158,
	UrlAttribute_GetHashCode_m3894447089,
	UrlAttribute_GetPropertiesForNewContext_m2281450996,
	UrlAttribute_IsContextOK_m1228378186,
	ChannelData__ctor_m3415426655,
	ChannelData_get_ServerProviders_m632481016,
	ChannelData_get_ClientProviders_m594662942,
	ChannelData_get_CustomProperties_m1852130080,
	ChannelData_CopyFrom_m727830216,
	ChannelInfo__ctor_m1094732233,
	ChannelInfo__ctor_m1024254061,
	ChannelInfo_get_ChannelData_m1060390506,
	AsyncRequest__ctor_m492494552,
	CADSerializer_DeserializeMessage_m4131058444,
	CADSerializer_SerializeMessage_m899341376,
	CADSerializer_SerializeObject_m2985211104,
	CADSerializer_DeserializeObject_m243132091,
	ChannelServices__cctor_m2475086854,
	ChannelServices_get_CrossContextChannel_m2544947561,
	ChannelServices_CreateClientChannelSinkChain_m3117081582,
	ChannelServices_CreateClientChannelSinkChain_m1795214139,
	ChannelServices_RegisterChannel_m292045697,
	ChannelServices_RegisterChannel_m2211869627,
	ChannelServices_RegisterChannelConfig_m3525848799,
	ChannelServices_CreateProvider_m2537021726,
	ChannelServices_SyncDispatchMessage_m1259812344,
	ChannelServices_CheckIncomingMessage_m1297157039,
	ChannelServices_CheckReturnMessage_m42854321,
	ChannelServices_IsLocalCall_m3035930722,
	ChannelServices_GetCurrentChannelInfo_m3041604116,
	CrossAppDomainChannel__ctor_m834919757,
	CrossAppDomainChannel__cctor_m2481165765,
	CrossAppDomainChannel_RegisterCrossAppDomainChannel_m1413768602,
	CrossAppDomainChannel_get_ChannelName_m2549253909,
	CrossAppDomainChannel_get_ChannelPriority_m3418073750,
	CrossAppDomainChannel_get_ChannelData_m2094862616,
	CrossAppDomainChannel_StartListening_m3738943719,
	CrossAppDomainChannel_CreateMessageSink_m3655964231,
	CrossAppDomainData__ctor_m1598366643,
	CrossAppDomainData_get_DomainID_m3516796532,
	CrossAppDomainData_get_ProcessID_m2166337712,
	CrossAppDomainSink__ctor_m1449849319,
	CrossAppDomainSink__cctor_m1839450486,
	CrossAppDomainSink_GetSink_m1351608552,
	CrossAppDomainSink_get_TargetDomainId_m1510098893,
	CrossAppDomainSink_ProcessMessageInDomain_m3657983318,
	CrossAppDomainSink_SyncProcessMessage_m2599866017,
	CrossAppDomainSink_AsyncProcessMessage_m4214688566,
	CrossAppDomainSink_SendAsyncMessage_m1900004718,
	SinkProviderData__ctor_m1624738837,
	SinkProviderData_get_Children_m4009299018,
	SinkProviderData_get_Properties_m3454573235,
	ClientActivatedIdentity__ctor_m20616531,
	ClientActivatedIdentity_GetServerObject_m446547394,
	ClientActivatedIdentity_SetClientProxy_m1934671808,
	ClientActivatedIdentity_OnLifetimeExpired_m635240647,
	ClientActivatedIdentity_SyncObjectProcessMessage_m2838343040,
	ClientActivatedIdentity_AsyncObjectProcessMessage_m195435417,
	ClientIdentity__ctor_m3042435594,
	ClientIdentity_get_ClientProxy_m1281632708,
	ClientIdentity_set_ClientProxy_m3470388302,
	ClientIdentity_CreateObjRef_m3373052626,
	ClientIdentity_get_TargetUri_m648770569,
	ConfigHandler__ctor_m1707380160,
	ConfigHandler_ValidatePath_m3895556516,
	ConfigHandler_CheckPath_m3079311646,
	ConfigHandler_OnStartParsing_m3490329046,
	ConfigHandler_OnProcessingInstruction_m4212209262,
	ConfigHandler_OnIgnorableWhitespace_m278399491,
	ConfigHandler_OnStartElement_m1487743489,
	ConfigHandler_ParseElement_m3124222564,
	ConfigHandler_OnEndElement_m2712669221,
	ConfigHandler_ReadCustomProviderData_m3199409838,
	ConfigHandler_ReadLifetine_m208994800,
	ConfigHandler_ParseTime_m1787834288,
	ConfigHandler_ReadChannel_m781299361,
	ConfigHandler_ReadProvider_m3620509535,
	ConfigHandler_ReadClientActivated_m2004035168,
	ConfigHandler_ReadServiceActivated_m3103044384,
	ConfigHandler_ReadClientWellKnown_m2020621905,
	ConfigHandler_ReadServiceWellKnown_m3267506269,
	ConfigHandler_ReadInteropXml_m2362675760,
	ConfigHandler_ReadPreload_m1590193711,
	ConfigHandler_GetNotNull_m2259274773,
	ConfigHandler_ExtractAssembly_m2143791058,
	ConfigHandler_OnChars_m2375115779,
	ConfigHandler_OnEndParsing_m3764034673,
	Context__ctor_m254302079,
	Context__cctor_m416731170,
	Context_Finalize_m968260866,
	Context_get_DefaultContext_m2041247543,
	Context_get_ContextID_m438722087,
	Context_get_ContextProperties_m3283598326,
	Context_get_IsDefaultContext_m588840058,
	Context_get_NeedsContextSink_m2822465981,
	Context_RegisterDynamicProperty_m2307208816,
	Context_UnregisterDynamicProperty_m1191983692,
	Context_GetDynamicPropertyCollection_m3657471357,
	Context_NotifyGlobalDynamicSinks_m695341235,
	Context_get_HasGlobalDynamicSinks_m3672814609,
	Context_NotifyDynamicSinks_m1841702879,
	Context_get_HasDynamicSinks_m3952434387,
	Context_get_HasExitSinks_m408916482,
	Context_GetProperty_m3204855576,
	Context_SetProperty_m3238063729,
	Context_Freeze_m2594571993,
	Context_ToString_m1073616138,
	Context_GetServerContextSinkChain_m3154465897,
	Context_GetClientContextSinkChain_m2136947545,
	Context_CreateServerObjectSinkChain_m1209471584,
	Context_CreateEnvoySink_m3365634710,
	Context_SwitchToContext_m1475712852,
	Context_CreateNewContext_m3053563976,
	Context_DoCallBack_m749197451,
	Context_AllocateDataSlot_m2078817162,
	Context_AllocateNamedDataSlot_m103537862,
	Context_FreeNamedDataSlot_m2664298100,
	Context_GetData_m2148900675,
	Context_GetNamedDataSlot_m2010711813,
	Context_SetData_m3538804592,
	ContextAttribute__ctor_m3271528688,
	ContextAttribute_get_Name_m1376922427,
	ContextAttribute_Equals_m614768756,
	ContextAttribute_Freeze_m3288175579,
	ContextAttribute_GetHashCode_m3530575001,
	ContextAttribute_GetPropertiesForNewContext_m1632930262,
	ContextAttribute_IsContextOK_m1726359618,
	ContextAttribute_IsNewContextOK_m2778900898,
	ContextCallbackObject__ctor_m3499682402,
	ContextCallbackObject_DoCallBack_m3942380501,
	CrossContextChannel__ctor_m3755842292,
	CrossContextChannel_SyncProcessMessage_m130533374,
	CrossContextChannel_AsyncProcessMessage_m3361381761,
	ContextRestoreSink__ctor_m3837217860,
	ContextRestoreSink_SyncProcessMessage_m1014797578,
	ContextRestoreSink_AsyncProcessMessage_m280611108,
	CrossContextDelegate__ctor_m2846080406,
	CrossContextDelegate_Invoke_m3121381558,
	CrossContextDelegate_BeginInvoke_m3781308708,
	CrossContextDelegate_EndInvoke_m3186232431,
	DynamicPropertyCollection__ctor_m3168670804,
	DynamicPropertyCollection_get_HasProperties_m4067429750,
	DynamicPropertyCollection_RegisterDynamicProperty_m3950689041,
	DynamicPropertyCollection_UnregisterDynamicProperty_m3435802631,
	DynamicPropertyCollection_NotifyMessage_m1895207271,
	DynamicPropertyCollection_FindProperty_m2338552444,
	DynamicPropertyReg__ctor_m2316273312,
	SynchronizationAttribute__ctor_m1613804100,
	SynchronizationAttribute__ctor_m399162031,
	SynchronizationAttribute_get_IsReEntrant_m3503478049,
	SynchronizationAttribute_set_Locked_m2760363037,
	SynchronizationAttribute_AcquireLock_m776819619,
	SynchronizationAttribute_ReleaseLock_m1030353464,
	SynchronizationAttribute_GetPropertiesForNewContext_m3620327520,
	SynchronizationAttribute_GetClientContextSink_m2797862094,
	SynchronizationAttribute_GetServerContextSink_m2864017660,
	SynchronizationAttribute_IsContextOK_m324067792,
	SynchronizationAttribute_ExitContext_m1981564947,
	SynchronizationAttribute_EnterContext_m1660729920,
	SynchronizedClientContextSink__ctor_m4129963630,
	SynchronizedClientContextSink_AsyncProcessMessage_m3574843998,
	SynchronizedClientContextSink_SyncProcessMessage_m2605077513,
	SynchronizedContextReplySink__ctor_m1162999750,
	SynchronizedContextReplySink_AsyncProcessMessage_m591479608,
	SynchronizedContextReplySink_SyncProcessMessage_m3077458053,
	SynchronizedServerContextSink__ctor_m3996826342,
	SynchronizedServerContextSink_AsyncProcessMessage_m3545264767,
	SynchronizedServerContextSink_SyncProcessMessage_m395228665,
	DisposerReplySink__ctor_m2547952970,
	DisposerReplySink_SyncProcessMessage_m2432481672,
	DisposerReplySink_AsyncProcessMessage_m614392448,
	EnvoyInfo__ctor_m276600651,
	EnvoyInfo_get_EnvoySinks_m1211050346,
	FormatterData__ctor_m3990517908,
	Identity__ctor_m2221672896,
	Identity_get_ChannelSink_m3905420913,
	Identity_set_ChannelSink_m3085217742,
	Identity_get_EnvoySink_m1643114474,
	Identity_get_ObjectUri_m3138646444,
	Identity_set_ObjectUri_m3158626967,
	Identity_get_IsConnected_m2848760353,
	Identity_get_Disposed_m2663903683,
	Identity_set_Disposed_m1049871465,
	Identity_get_ClientDynamicProperties_m60531821,
	Identity_get_ServerDynamicProperties_m1517273532,
	Identity_get_HasServerDynamicSinks_m2759301415,
	Identity_NotifyClientDynamicSinks_m1859963616,
	Identity_NotifyServerDynamicSinks_m3451215395,
	InternalRemotingServices__cctor_m1652165283,
	InternalRemotingServices_GetCachedSoapAttribute_m1042302982,
	Lease__ctor_m3269477734,
	Lease_get_CurrentLeaseTime_m3433257884,
	Lease_get_CurrentState_m2210872233,
	Lease_Activate_m1293019137,
	Lease_set_InitialLeaseTime_m122297036,
	Lease_get_RenewOnCallTime_m1966809790,
	Lease_set_RenewOnCallTime_m1737118470,
	Lease_set_SponsorshipTimeout_m2290526220,
	Lease_Renew_m1703962644,
	Lease_Unregister_m186366095,
	Lease_UpdateState_m2746833210,
	Lease_CheckNextSponsor_m2023022816,
	Lease_ProcessSponsorResponse_m3090612911,
	RenewalDelegate__ctor_m3753117779,
	RenewalDelegate_Invoke_m3491491419,
	RenewalDelegate_BeginInvoke_m1180839451,
	RenewalDelegate_EndInvoke_m250802919,
	LeaseManager__ctor_m4015084757,
	LeaseManager_SetPollTime_m3584231103,
	LeaseManager_TrackLifetime_m1859704813,
	LeaseManager_StartManager_m3152740510,
	LeaseManager_StopManager_m2567480487,
	LeaseManager_ManageLeases_m421471288,
	LeaseSink__ctor_m2235463210,
	LeaseSink_SyncProcessMessage_m3942566741,
	LeaseSink_AsyncProcessMessage_m2450477097,
	LeaseSink_RenewLease_m578578728,
	LifetimeServices__cctor_m2128864873,
	LifetimeServices_get_LeaseManagerPollTime_m2374486473,
	LifetimeServices_set_LeaseManagerPollTime_m3035471458,
	LifetimeServices_get_LeaseTime_m1675572716,
	LifetimeServices_set_LeaseTime_m4128883058,
	LifetimeServices_get_RenewOnCallTime_m4192398854,
	LifetimeServices_set_RenewOnCallTime_m3218163665,
	LifetimeServices_get_SponsorshipTimeout_m1857544448,
	LifetimeServices_set_SponsorshipTimeout_m2538334028,
	LifetimeServices_TrackLifetime_m2415237423,
	ArgInfo__ctor_m1950205784,
	ArgInfo_GetInOutArgCount_m2742066148,
	ArgInfo_GetInOutArgs_m3837333346,
	AsyncResult__ctor_m911358409,
	AsyncResult_get_AsyncState_m2322299153,
	AsyncResult_get_AsyncWaitHandle_m1971359513,
	AsyncResult_get_CompletedSynchronously_m3353049627,
	AsyncResult_get_IsCompleted_m2089788488,
	AsyncResult_get_EndInvokeCalled_m3770405353,
	AsyncResult_set_EndInvokeCalled_m130520183,
	AsyncResult_get_AsyncDelegate_m3808237550,
	AsyncResult_get_NextSink_m1844209137,
	AsyncResult_AsyncProcessMessage_m2076471000,
	AsyncResult_GetReplyMessage_m2321330725,
	AsyncResult_SetMessageCtrl_m2891069413,
	AsyncResult_SetCompletedSynchronously_m3406063945,
	AsyncResult_EndInvoke_m2943900386,
	AsyncResult_SyncProcessMessage_m2334986884,
	AsyncResult_get_CallMessage_m1679778649,
	AsyncResult_set_CallMessage_m2298693197,
	CADArgHolder__ctor_m993579695,
	CADMessageBase__ctor_m2964311354,
	CADMessageBase_MarshalProperties_m466198678,
	CADMessageBase_UnmarshalProperties_m4178096524,
	CADMessageBase_IsPossibleToIgnoreMarshal_m817717449,
	CADMessageBase_MarshalArgument_m1629674998,
	CADMessageBase_UnmarshalArgument_m2058572696,
	CADMessageBase_MarshalArguments_m1927937746,
	CADMessageBase_UnmarshalArguments_m1347717101,
	CADMessageBase_SaveLogicalCallContext_m862853946,
	CADMessageBase_GetLogicalCallContext_m3861983492,
	CADMethodCallMessage__ctor_m4205158101,
	CADMethodCallMessage_get_Uri_m1711428083,
	CADMethodCallMessage_Create_m3871584080,
	CADMethodCallMessage_GetArguments_m3041854375,
	CADMethodCallMessage_GetArgs_m4253987163,
	CADMethodCallMessage_get_PropertiesCount_m1249125054,
	CADMethodCallMessage_GetSignature_m841763657,
	CADMethodCallMessage_GetMethod_m1779242604,
	CADMethodReturnMessage__ctor_m2974228354,
	CADMethodReturnMessage_Create_m691563714,
	CADMethodReturnMessage_GetArguments_m1470050566,
	CADMethodReturnMessage_GetArgs_m343322724,
	CADMethodReturnMessage_GetReturnValue_m2466270334,
	CADMethodReturnMessage_GetException_m4034410903,
	CADMethodReturnMessage_get_PropertiesCount_m4281298296,
	CADObjRef__ctor_m2673939978,
	CADObjRef_get_TypeName_m3141447028,
	CADObjRef_get_URI_m3186150256,
	CallContext__ctor_m383148220,
	CallContext_CreateLogicalCallContext_m4045492885,
	CallContext_SetCurrentCallContext_m2971462454,
	CallContext_RestoreCallContext_m271861767,
	CallContextRemotingData__ctor_m1780036207,
	CallContextRemotingData_Clone_m14303327,
	ClientContextReplySink__ctor_m975656650,
	ClientContextReplySink_SyncProcessMessage_m2049760216,
	ClientContextReplySink_AsyncProcessMessage_m4062537038,
	ClientContextTerminatorSink__ctor_m3775290972,
	ClientContextTerminatorSink_SyncProcessMessage_m432234354,
	ClientContextTerminatorSink_AsyncProcessMessage_m980226669,
	ConstructionCall__ctor_m3123819328,
	ConstructionCall__ctor_m4256641225,
	ConstructionCall_InitDictionary_m2824447813,
	ConstructionCall_get_IsContextOk_m2782950412,
	ConstructionCall_set_IsContextOk_m2994486781,
	ConstructionCall_get_ActivationType_m402163916,
	ConstructionCall_get_ActivationTypeName_m3152330302,
	ConstructionCall_get_Activator_m2234315252,
	ConstructionCall_set_Activator_m1916046285,
	ConstructionCall_get_CallSiteActivationAttributes_m3498917408,
	ConstructionCall_SetActivationAttributes_m2210519374,
	ConstructionCall_get_ContextProperties_m4226046805,
	ConstructionCall_InitMethodProperty_m2021094586,
	ConstructionCall_GetObjectData_m1001686567,
	ConstructionCall_get_Properties_m3011379795,
	ConstructionCall_get_SourceProxy_m1712998109,
	ConstructionCallDictionary__ctor_m2541174073,
	ConstructionCallDictionary__cctor_m3953897917,
	ConstructionCallDictionary_GetMethodProperty_m868507224,
	ConstructionCallDictionary_SetMethodProperty_m3145285304,
	ConstructionResponse__ctor_m507689770,
	ConstructionResponse__ctor_m131220658,
	ConstructionResponse__ctor_m746108047,
	ConstructionResponse_get_Properties_m4079816931,
	EnvoyTerminatorSink__ctor_m2835977419,
	EnvoyTerminatorSink__cctor_m2182802076,
	EnvoyTerminatorSink_SyncProcessMessage_m3404100686,
	EnvoyTerminatorSink_AsyncProcessMessage_m3017446614,
	ErrorMessage__ctor_m4021425049,
	ErrorMessage_get_ArgCount_m3216492616,
	ErrorMessage_get_Args_m1886173730,
	ErrorMessage_get_MethodBase_m2501437782,
	ErrorMessage_get_MethodName_m2090524261,
	ErrorMessage_get_MethodSignature_m3912515700,
	ErrorMessage_get_Properties_m240354089,
	ErrorMessage_get_TypeName_m4051144354,
	ErrorMessage_get_Uri_m528922187,
	ErrorMessage_GetArg_m2320124058,
	ErrorMessage_get_LogicalCallContext_m597698035,
	Header__ctor_m1921907550,
	Header__ctor_m3451012432,
	Header__ctor_m2140843914,
	HeaderHandler__ctor_m2052730798,
	HeaderHandler_Invoke_m3513051789,
	HeaderHandler_BeginInvoke_m3867166640,
	HeaderHandler_EndInvoke_m1991538959,
	LogicalCallContext__ctor_m1263247987,
	LogicalCallContext__ctor_m2167632604,
	LogicalCallContext_get_HasInfo_m3847716861,
	LogicalCallContext_GetObjectData_m841612502,
	LogicalCallContext_SetData_m1808598347,
	LogicalCallContext_Clone_m1816384810,
	LogicalCallContext_get_Datastore_m629418756,
	MethodCall__ctor_m2176599175,
	MethodCall__ctor_m3517356389,
	MethodCall__ctor_m2820791328,
	MethodCall__ctor_m3669645,
	MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m2491597453,
	MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m1919576807,
	MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m3106215723,
	MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3258819983,
	MethodCall_InitMethodProperty_m1333573177,
	MethodCall_GetObjectData_m3807460959,
	MethodCall_get_ArgCount_m1601487409,
	MethodCall_get_Args_m148309537,
	MethodCall_get_LogicalCallContext_m555393702,
	MethodCall_get_MethodBase_m550047245,
	MethodCall_get_MethodName_m264867159,
	MethodCall_get_MethodSignature_m2407904958,
	MethodCall_get_Properties_m3740161820,
	MethodCall_InitDictionary_m865799153,
	MethodCall_get_TypeName_m3873929301,
	MethodCall_get_Uri_m1720935531,
	MethodCall_set_Uri_m3442466207,
	MethodCall_GetArg_m502890301,
	MethodCall_Init_m86192062,
	MethodCall_ResolveMethod_m326183261,
	MethodCall_CastTo_m1915249774,
	MethodCall_GetTypeNameFromAssemblyQualifiedName_m1018622420,
	MethodCall_get_GenericArguments_m1010093584,
	MethodCallDictionary__ctor_m2167303393,
	MethodCallDictionary__cctor_m2213329406,
	MethodDictionary__ctor_m4235342752,
	MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m4169036899,
	MethodDictionary_get_HasInternalProperties_m1604426346,
	MethodDictionary_get_InternalProperties_m321207497,
	MethodDictionary_set_MethodKeys_m1451825752,
	MethodDictionary_AllocInternalProperties_m1683153261,
	MethodDictionary_GetInternalProperties_m2215984424,
	MethodDictionary_IsOverridenKey_m946843558,
	MethodDictionary_get_Item_m1201458851,
	MethodDictionary_set_Item_m489343035,
	MethodDictionary_GetMethodProperty_m3206728418,
	MethodDictionary_SetMethodProperty_m3032369066,
	MethodDictionary_get_Values_m957801003,
	MethodDictionary_Add_m1460237891,
	MethodDictionary_Remove_m2649551615,
	MethodDictionary_get_Count_m4037025569,
	MethodDictionary_get_SyncRoot_m518515391,
	MethodDictionary_CopyTo_m2912468790,
	MethodDictionary_GetEnumerator_m1619497063,
	DictionaryEnumerator__ctor_m713073424,
	DictionaryEnumerator_get_Current_m2769714278,
	DictionaryEnumerator_MoveNext_m1462973125,
	DictionaryEnumerator_Reset_m2916117190,
	DictionaryEnumerator_get_Entry_m1635969600,
	DictionaryEnumerator_get_Key_m2423649820,
	DictionaryEnumerator_get_Value_m2166220004,
	MethodResponse__ctor_m1914987550,
	MethodResponse__ctor_m696083067,
	MethodResponse__ctor_m2813895138,
	MethodResponse__ctor_m604622297,
	MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m3937741607,
	MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m1299782913,
	MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m3291545427,
	MethodResponse_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m661149313,
	MethodResponse_InitMethodProperty_m3208531417,
	MethodResponse_get_ArgCount_m1397964487,
	MethodResponse_get_Args_m3774150470,
	MethodResponse_get_Exception_m2873702313,
	MethodResponse_get_LogicalCallContext_m3456939940,
	MethodResponse_get_MethodBase_m513691916,
	MethodResponse_get_MethodName_m256884228,
	MethodResponse_get_MethodSignature_m3918608730,
	MethodResponse_get_OutArgCount_m116356169,
	MethodResponse_get_OutArgs_m1057512500,
	MethodResponse_get_Properties_m2411220224,
	MethodResponse_get_ReturnValue_m3947544853,
	MethodResponse_get_TypeName_m1691049826,
	MethodResponse_get_Uri_m3281745614,
	MethodResponse_set_Uri_m700763379,
	MethodResponse_GetArg_m4250300354,
	MethodResponse_GetObjectData_m1523088668,
	MethodReturnDictionary__ctor_m3850821940,
	MethodReturnDictionary__cctor_m278392388,
	MonoMethodMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m929239303,
	MonoMethodMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3448319263,
	MonoMethodMessage_get_Properties_m3713673222,
	MonoMethodMessage_get_ArgCount_m632716600,
	MonoMethodMessage_get_Args_m2110710723,
	MonoMethodMessage_get_LogicalCallContext_m2835676725,
	MonoMethodMessage_get_MethodBase_m2884727594,
	MonoMethodMessage_get_MethodName_m3805361957,
	MonoMethodMessage_get_MethodSignature_m580784519,
	MonoMethodMessage_get_TypeName_m3758247133,
	MonoMethodMessage_get_Uri_m2484777536,
	MonoMethodMessage_set_Uri_m958867306,
	MonoMethodMessage_GetArg_m2932717642,
	MonoMethodMessage_get_Exception_m1271355240,
	MonoMethodMessage_get_OutArgCount_m3123660340,
	MonoMethodMessage_get_OutArgs_m1742115111,
	MonoMethodMessage_get_ReturnValue_m1500706237,
	MonoMethodMessage_get_AsyncResult_m3874702476,
	MonoMethodMessage_get_CallType_m3702481004,
	ObjRefSurrogate__ctor_m455472707,
	ObjRefSurrogate_GetObjectData_m4269947720,
	ObjRefSurrogate_SetObjectData_m2217650033,
	RemotingSurrogate__ctor_m1062105321,
	RemotingSurrogate_GetObjectData_m1446383768,
	RemotingSurrogate_SetObjectData_m2713731796,
	RemotingSurrogateSelector__ctor_m1846610173,
	RemotingSurrogateSelector__cctor_m332560138,
	RemotingSurrogateSelector_GetSurrogate_m3900875713,
	ReturnMessage__ctor_m2352989078,
	ReturnMessage__ctor_m1555286069,
	ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_Uri_m266953644,
	ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m2462079058,
	ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_get_TargetIdentity_m2936584507,
	ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_TargetIdentity_m3799371543,
	ReturnMessage_get_ArgCount_m51405423,
	ReturnMessage_get_Args_m398905527,
	ReturnMessage_get_LogicalCallContext_m2352570297,
	ReturnMessage_get_MethodBase_m2391555884,
	ReturnMessage_get_MethodName_m1311605024,
	ReturnMessage_get_MethodSignature_m399735125,
	ReturnMessage_get_Properties_m3665464616,
	ReturnMessage_get_TypeName_m3469766621,
	ReturnMessage_get_Uri_m2690508903,
	ReturnMessage_set_Uri_m3134200303,
	ReturnMessage_GetArg_m3510565487,
	ReturnMessage_get_Exception_m3375728265,
	ReturnMessage_get_OutArgCount_m1954300070,
	ReturnMessage_get_OutArgs_m1641976511,
	ReturnMessage_get_ReturnValue_m3976996692,
	ServerContextTerminatorSink__ctor_m2519287841,
	ServerContextTerminatorSink_SyncProcessMessage_m3762853959,
	ServerContextTerminatorSink_AsyncProcessMessage_m2674040571,
	ServerObjectReplySink__ctor_m3589614014,
	ServerObjectReplySink_SyncProcessMessage_m512968558,
	ServerObjectReplySink_AsyncProcessMessage_m1580266605,
	ServerObjectTerminatorSink__ctor_m3974426286,
	ServerObjectTerminatorSink_SyncProcessMessage_m2085589766,
	ServerObjectTerminatorSink_AsyncProcessMessage_m3445474816,
	StackBuilderSink__ctor_m2065448592,
	StackBuilderSink_SyncProcessMessage_m1218070084,
	StackBuilderSink_AsyncProcessMessage_m4112015303,
	StackBuilderSink_ExecuteAsyncMessage_m277782655,
	StackBuilderSink_CheckParameters_m707496278,
	SoapAttribute__ctor_m1857608874,
	SoapAttribute_get_UseAttribute_m3866369531,
	SoapAttribute_get_XmlNamespace_m859394681,
	SoapAttribute_SetReflectionObject_m4109300849,
	SoapFieldAttribute__ctor_m790943423,
	SoapFieldAttribute_get_XmlElementName_m2203304026,
	SoapFieldAttribute_IsInteropXmlElement_m2819415462,
	SoapFieldAttribute_SetReflectionObject_m1576380366,
	SoapMethodAttribute__ctor_m1788265923,
	SoapMethodAttribute_get_UseAttribute_m1147780171,
	SoapMethodAttribute_get_XmlNamespace_m4029617514,
	SoapMethodAttribute_SetReflectionObject_m503748123,
	SoapParameterAttribute__ctor_m2146835121,
	SoapTypeAttribute__ctor_m4090878544,
	SoapTypeAttribute_get_UseAttribute_m3046604208,
	SoapTypeAttribute_get_XmlElementName_m2920861364,
	SoapTypeAttribute_get_XmlNamespace_m1959618787,
	SoapTypeAttribute_get_XmlTypeName_m3319890470,
	SoapTypeAttribute_get_XmlTypeNamespace_m4211398148,
	SoapTypeAttribute_get_IsInteropXmlElement_m3413949955,
	SoapTypeAttribute_get_IsInteropXmlType_m629667929,
	SoapTypeAttribute_SetReflectionObject_m1691526413,
	ObjRef__ctor_m823137228,
	ObjRef__ctor_m4078135099,
	ObjRef__ctor_m1449728429,
	ObjRef__ctor_m1843524090,
	ObjRef__cctor_m1958474437,
	ObjRef_get_IsReferenceToWellKnow_m3951611746,
	ObjRef_get_ChannelInfo_m434196038,
	ObjRef_get_EnvoyInfo_m1782007847,
	ObjRef_set_EnvoyInfo_m3653812956,
	ObjRef_get_TypeInfo_m1614059810,
	ObjRef_set_TypeInfo_m2180735217,
	ObjRef_get_URI_m3017576950,
	ObjRef_set_URI_m2491129464,
	ObjRef_GetObjectData_m270012899,
	ObjRef_GetRealObject_m2243479605,
	ObjRef_UpdateChannelInfo_m871421559,
	ObjRef_get_ServerType_m4102914975,
	ProviderData__ctor_m2835711616,
	ProviderData_CopyFrom_m3402276734,
	ProxyAttribute_CreateInstance_m1531306115,
	ProxyAttribute_CreateProxy_m2826946776,
	ProxyAttribute_GetPropertiesForNewContext_m3751460645,
	ProxyAttribute_IsContextOK_m1572386839,
	RealProxy__ctor_m1860285982,
	RealProxy__ctor_m192459610,
	RealProxy__ctor_m192642440,
	RealProxy_InternalGetProxyType_m2154819545,
	RealProxy_GetProxiedType_m130698758,
	RealProxy_GetObjectData_m3709348912,
	RealProxy_get_ObjectIdentity_m2790771985,
	RealProxy_set_ObjectIdentity_m1045687518,
	RealProxy_InternalGetTransparentProxy_m1765012608,
	RealProxy_GetTransparentProxy_m3318846301,
	RealProxy_AttachServer_m1185328196,
	RealProxy_SetTargetDomain_m1886392211,
	RemotingProxy__ctor_m1504681762,
	RemotingProxy__ctor_m2714995444,
	RemotingProxy__cctor_m4096951805,
	RemotingProxy_Invoke_m1410974208,
	RemotingProxy_AttachIdentity_m4004191225,
	RemotingProxy_get_TypeName_m4085898624,
	RemotingProxy_Finalize_m2695236116,
	RemotingConfiguration__cctor_m2997734064,
	RemotingConfiguration_get_ApplicationName_m593755586,
	RemotingConfiguration_set_ApplicationName_m2517000516,
	RemotingConfiguration_get_ProcessId_m2180277012,
	RemotingConfiguration_LoadDefaultDelayedChannels_m1289761552,
	RemotingConfiguration_IsActivationAllowed_m1504757950,
	RemotingConfiguration_IsRemotelyActivatedClientType_m4117048589,
	RemotingConfiguration_RegisterActivatedClientType_m4212089575,
	RemotingConfiguration_RegisterActivatedServiceType_m526187030,
	RemotingConfiguration_RegisterWellKnownClientType_m1237674062,
	RemotingConfiguration_RegisterWellKnownServiceType_m4099334725,
	RemotingConfiguration_RegisterChannelTemplate_m3105688054,
	RemotingConfiguration_RegisterClientProviderTemplate_m3950558786,
	RemotingConfiguration_RegisterServerProviderTemplate_m2865814762,
	RemotingConfiguration_RegisterChannels_m1089224873,
	RemotingConfiguration_RegisterTypes_m2378540395,
	RemotingConfiguration_CustomErrorsEnabled_m646255533,
	RemotingConfiguration_SetCustomErrorsMode_m12233052,
	RemotingException__ctor_m1814113852,
	RemotingException__ctor_m2916537666,
	RemotingException__ctor_m1015537352,
	RemotingException__ctor_m3625866612,
	RemotingServices__cctor_m4056345423,
	RemotingServices_InternalExecute_m1851601664,
	RemotingServices_GetVirtualMethod_m3786317812,
	RemotingServices_IsTransparentProxy_m1535738947,
	RemotingServices_InternalExecuteMessage_m311230144,
	RemotingServices_Connect_m1080129988,
	RemotingServices_GetServerTypeForUri_m1917852216,
	RemotingServices_Unmarshal_m3744595373,
	RemotingServices_Unmarshal_m260048024,
	RemotingServices_Marshal_m98061768,
	RemotingServices_Marshal_m3646189857,
	RemotingServices_NewUri_m4184087063,
	RemotingServices_GetRealProxy_m2081098851,
	RemotingServices_GetMethodBaseFromMethodMessage_m383468467,
	RemotingServices_GetMethodBaseFromName_m3194612939,
	RemotingServices_FindInterfaceMethod_m2125212568,
	RemotingServices_GetObjectData_m3902019633,
	RemotingServices_IsMethodOverloaded_m3262659413,
	RemotingServices_IsOneWay_m1772807839,
	RemotingServices_CreateClientProxy_m3886727610,
	RemotingServices_CreateClientProxy_m809906894,
	RemotingServices_CreateClientProxyForContextBound_m783705199,
	RemotingServices_GetIdentityForUri_m2001974121,
	RemotingServices_RemoveAppNameFromUri_m388703745,
	RemotingServices_GetOrCreateClientIdentity_m648299611,
	RemotingServices_GetClientChannelSinkChain_m1499550585,
	RemotingServices_CreateContextBoundObjectIdentity_m978835616,
	RemotingServices_CreateClientActivatedServerIdentity_m3488968707,
	RemotingServices_CreateWellKnownServerIdentity_m1170328801,
	RemotingServices_RegisterServerIdentity_m196914637,
	RemotingServices_GetProxyForRemoteObject_m1790739297,
	RemotingServices_GetRemoteObject_m2117098022,
	RemotingServices_RegisterInternalChannels_m3803685582,
	RemotingServices_DisposeIdentity_m2605848806,
	RemotingServices_GetMessageTargetIdentity_m1302164612,
	RemotingServices_SetMessageTargetIdentity_m4083751943,
	RemotingServices_GetNormalizedUri_m3119784285,
	ServerIdentity__ctor_m1627037015,
	ServerIdentity_get_ObjectType_m1709199788,
	ServerIdentity_StartTrackingLifetime_m861002296,
	ServerIdentity_OnLifetimeExpired_m3729485875,
	ServerIdentity_CreateObjRef_m3435315642,
	ServerIdentity_AttachServerObject_m3892044390,
	ServerIdentity_get_Lease_m2153931427,
	ServerIdentity_get_Context_m1732876343,
	ServerIdentity_set_Context_m168811777,
	ServerIdentity_DisposeServerObject_m1376146261,
	TrackingServices__cctor_m2525949557,
	TrackingServices_NotifyMarshaledObject_m2850851267,
	TrackingServices_NotifyUnmarshaledObject_m2784831802,
	TrackingServices_NotifyDisconnectedObject_m1755566214,
	SingleCallIdentity__ctor_m512106477,
	SingleCallIdentity_SyncObjectProcessMessage_m1937976823,
	SingleCallIdentity_AsyncObjectProcessMessage_m1739361290,
	SingletonIdentity__ctor_m3846583373,
	SingletonIdentity_GetServerObject_m4017943093,
	SingletonIdentity_SyncObjectProcessMessage_m2934017657,
	SingletonIdentity_AsyncObjectProcessMessage_m1982295016,
	SoapServices__cctor_m3121621510,
	SoapServices_get_XmlNsForClrTypeWithAssembly_m2133585561,
	SoapServices_get_XmlNsForClrTypeWithNs_m3680841936,
	SoapServices_get_XmlNsForClrTypeWithNsAndAssembly_m2954042252,
	SoapServices_CodeXmlNamespaceForClrTypeNamespace_m4100633536,
	SoapServices_GetNameKey_m1553516689,
	SoapServices_GetAssemblyName_m1160306025,
	SoapServices_GetXmlElementForInteropType_m1310850578,
	SoapServices_GetXmlNamespaceForMethodCall_m4199193440,
	SoapServices_GetXmlNamespaceForMethodResponse_m72953636,
	SoapServices_GetXmlTypeForInteropType_m226269097,
	SoapServices_PreLoad_m3694555274,
	SoapServices_PreLoad_m1533129052,
	SoapServices_RegisterInteropXmlElement_m2539810323,
	SoapServices_RegisterInteropXmlType_m3725804773,
	SoapServices_EncodeNs_m635167772,
	TypeInfo__ctor_m3177869375,
	TypeEntry__ctor_m3850067423,
	TypeEntry_get_AssemblyName_m249907965,
	TypeEntry_set_AssemblyName_m740439947,
	TypeEntry_get_TypeName_m3730760050,
	TypeEntry_set_TypeName_m2292673915,
	TypeInfo__ctor_m3520353822,
	TypeInfo_get_TypeName_m3637299865,
	WellKnownClientTypeEntry__ctor_m2471908952,
	WellKnownClientTypeEntry_get_ApplicationUrl_m3926146748,
	WellKnownClientTypeEntry_get_ObjectType_m1043664788,
	WellKnownClientTypeEntry_get_ObjectUrl_m2025814880,
	WellKnownClientTypeEntry_ToString_m1119458503,
	WellKnownServiceTypeEntry__ctor_m2390594423,
	WellKnownServiceTypeEntry_get_Mode_m514401854,
	WellKnownServiceTypeEntry_get_ObjectType_m3211195371,
	WellKnownServiceTypeEntry_get_ObjectUri_m560402900,
	WellKnownServiceTypeEntry_ToString_m1546833365,
	ArrayFixupRecord__ctor_m3071763795,
	ArrayFixupRecord_FixupImpl_m4264567432,
	BaseFixupRecord__ctor_m3105931241,
	BaseFixupRecord_DoFixup_m1407429548,
	DelayedFixupRecord__ctor_m1500671818,
	DelayedFixupRecord_FixupImpl_m521536759,
	FixupRecord__ctor_m4156740480,
	FixupRecord_FixupImpl_m2569366786,
	FormatterConverter__ctor_m4071877133,
	FormatterConverter_Convert_m1357098163,
	FormatterConverter_ToBoolean_m1680758923,
	FormatterConverter_ToInt16_m4282804414,
	FormatterConverter_ToInt32_m2929341202,
	FormatterConverter_ToInt64_m495840699,
	FormatterConverter_ToString_m1584725205,
	FormatterServices_GetObjectData_m4284691678,
	FormatterServices_GetSerializableMembers_m3934333240,
	FormatterServices_GetFields_m2777940282,
	FormatterServices_GetUninitializedObject_m3413592581,
	FormatterServices_GetSafeUninitializedObject_m3890738292,
	BinaryCommon__cctor_m2978407547,
	BinaryCommon_IsPrimitive_m378904036,
	BinaryCommon_GetTypeCode_m448697888,
	BinaryCommon_GetTypeFromCode_m39036572,
	BinaryCommon_CheckSerializable_m3673092502,
	BinaryCommon_SwapBytes_m3963737189,
	BinaryFormatter__ctor_m971003555,
	BinaryFormatter__ctor_m2620705134,
	BinaryFormatter_get_DefaultSurrogateSelector_m3548531270,
	BinaryFormatter_set_AssemblyFormat_m1359106493,
	BinaryFormatter_get_Binder_m166854567,
	BinaryFormatter_get_Context_m1651087560,
	BinaryFormatter_get_SurrogateSelector_m2111882017,
	BinaryFormatter_set_SurrogateSelector_m1467080126,
	BinaryFormatter_get_FilterLevel_m1292975963,
	BinaryFormatter_Deserialize_m193346007,
	BinaryFormatter_Deserialize_m1553018041,
	BinaryFormatter_NoCheckDeserialize_m2274318934,
	BinaryFormatter_DeserializeMethodResponse_m1401162302,
	BinaryFormatter_NoCheckDeserializeMethodResponse_m1919376975,
	BinaryFormatter_Serialize_m1744386044,
	BinaryFormatter_Serialize_m2476455399,
	BinaryFormatter_WriteBinaryHeader_m4239804844,
	BinaryFormatter_ReadBinaryHeader_m2339643348,
	ClrTypeMetadata__ctor_m420857278,
	ClrTypeMetadata_get_RequiresTypes_m1619438370,
	CodeGenerator__cctor_m3167429173,
	CodeGenerator_GenerateMetadataType_m649965872,
	CodeGenerator_GenerateMetadataTypeInternal_m675242502,
	CodeGenerator_LoadFromPtr_m1784813519,
	CodeGenerator_EmitWriteTypeSpec_m3265719084,
	CodeGenerator_EmitLoadTypeAssembly_m1985536832,
	CodeGenerator_EmitWrite_m1452031614,
	CodeGenerator_EmitWritePrimitiveValue_m3054192573,
	CodeGenerator_EnumToUnderlying_m3778945530,
	MemberTypeMetadata__ctor_m2376841411,
	MemberTypeMetadata_WriteAssemblies_m881083943,
	MemberTypeMetadata_WriteTypeData_m3992201821,
	MemberTypeMetadata_WriteObjectData_m2840447988,
	MessageFormatter_WriteMethodCall_m4240742925,
	MessageFormatter_WriteMethodResponse_m514023078,
	MessageFormatter_ReadMethodCall_m2327590823,
	MessageFormatter_ReadMethodResponse_m1259800219,
	MessageFormatter_ReadMethodResponse_m1946725361,
	MessageFormatter_AllTypesArePrimitive_m3953742542,
	MessageFormatter_IsMethodPrimitive_m2805243043,
	MessageFormatter_GetExtraProperties_m305191653,
	MessageFormatter_IsInternalKey_m3679497458,
	ObjectReader__ctor_m2595396997,
	ObjectReader_ReadObjectGraph_m340866276,
	ObjectReader_ReadObjectGraph_m1689734232,
	ObjectReader_ReadNextObject_m1498077612,
	ObjectReader_ReadNextObject_m2150937777,
	ObjectReader_get_CurrentObject_m2820303483,
	ObjectReader_ReadObject_m540696579,
	ObjectReader_ReadAssembly_m2963555857,
	ObjectReader_ReadObjectInstance_m3952621118,
	ObjectReader_ReadRefTypeObjectInstance_m3311150386,
	ObjectReader_ReadObjectContent_m1654577346,
	ObjectReader_RegisterObject_m1853376334,
	ObjectReader_ReadStringIntance_m1523916863,
	ObjectReader_ReadGenericArray_m1710471713,
	ObjectReader_ReadBoxedPrimitiveTypeValue_m4086653205,
	ObjectReader_ReadArrayOfPrimitiveType_m3374303005,
	ObjectReader_BlockRead_m304158408,
	ObjectReader_ReadArrayOfObject_m671957184,
	ObjectReader_ReadArrayOfString_m3550800559,
	ObjectReader_ReadSimpleArray_m428957657,
	ObjectReader_ReadTypeMetadata_m3785645385,
	ObjectReader_ReadValue_m3145979203,
	ObjectReader_SetObjectValue_m2761159765,
	ObjectReader_RecordFixup_m4125245357,
	ObjectReader_GetDeserializationType_m1493678790,
	ObjectReader_ReadType_m1663843507,
	ObjectReader_ReadPrimitiveTypeValue_m4293111728,
	ArrayNullFiller__ctor_m1460935784,
	TypeMetadata__ctor_m646635308,
	ObjectWriter__ctor_m2586423995,
	ObjectWriter__cctor_m2748224627,
	ObjectWriter_WriteObjectGraph_m1096671657,
	ObjectWriter_QueueObject_m3487717536,
	ObjectWriter_WriteQueuedObjects_m502447341,
	ObjectWriter_WriteObjectInstance_m4123656775,
	ObjectWriter_WriteSerializationEnd_m4228661922,
	ObjectWriter_WriteObject_m3639703743,
	ObjectWriter_GetObjectData_m2149519430,
	ObjectWriter_CreateMemberTypeMetadata_m577610186,
	ObjectWriter_WriteArray_m1738497250,
	ObjectWriter_WriteGenericArray_m1575646718,
	ObjectWriter_WriteObjectArray_m1109545282,
	ObjectWriter_WriteStringArray_m312537653,
	ObjectWriter_WritePrimitiveTypeArray_m3383767374,
	ObjectWriter_BlockWrite_m827549826,
	ObjectWriter_WriteSingleDimensionArrayElements_m3412300123,
	ObjectWriter_WriteNullFiller_m2949512160,
	ObjectWriter_WriteObjectReference_m1459514019,
	ObjectWriter_WriteValue_m3485076606,
	ObjectWriter_WriteString_m2607199782,
	ObjectWriter_WriteAssembly_m3173779754,
	ObjectWriter_WriteAssemblyName_m3097158773,
	ObjectWriter_GetAssemblyId_m1980650584,
	ObjectWriter_GetAssemblyNameId_m2316410453,
	ObjectWriter_RegisterAssembly_m1967120293,
	ObjectWriter_WritePrimitiveValue_m3342686922,
	ObjectWriter_WriteTypeCode_m1789140116,
	ObjectWriter_GetTypeTag_m1892768509,
	ObjectWriter_WriteTypeSpec_m3700372600,
	MetadataReference__ctor_m15653650,
	SerializableTypeMetadata__ctor_m4102127793,
	SerializableTypeMetadata_IsCompatible_m3569756077,
	SerializableTypeMetadata_WriteAssemblies_m2027618830,
	SerializableTypeMetadata_WriteTypeData_m1099030367,
	SerializableTypeMetadata_WriteObjectData_m2148012904,
	SerializableTypeMetadata_get_RequiresTypes_m556665051,
	TypeMetadata__ctor_m3381216780,
	TypeMetadata_IsCompatible_m3213233239,
	MultiArrayFixupRecord__ctor_m1290009050,
	MultiArrayFixupRecord_FixupImpl_m1721674130,
	ObjectIDGenerator__ctor_m2117120656,
	ObjectIDGenerator__cctor_m2337609134,
	ObjectIDGenerator_GetId_m2052009363,
	ObjectIDGenerator_get_NextId_m3343770173,
	InstanceComparer__ctor_m2655670473,
	InstanceComparer_System_Collections_IComparer_Compare_m1420501866,
	InstanceComparer_System_Collections_IHashCodeProvider_GetHashCode_m1305577427,
	ObjectManager__ctor_m1844334865,
	ObjectManager_DoFixups_m3038765937,
	ObjectManager_GetObjectRecord_m1104835114,
	ObjectManager_GetObject_m1462343561,
	ObjectManager_RaiseDeserializationEvent_m49333530,
	ObjectManager_RaiseOnDeserializingEvent_m964884748,
	ObjectManager_RaiseOnDeserializedEvent_m2281637371,
	ObjectManager_AddFixup_m2154325362,
	ObjectManager_RecordArrayElementFixup_m3896982476,
	ObjectManager_RecordArrayElementFixup_m2171848602,
	ObjectManager_RecordDelayedFixup_m337814852,
	ObjectManager_RecordFixup_m290973772,
	ObjectManager_RegisterObjectInternal_m3473857785,
	ObjectManager_RegisterObject_m2087328880,
	ObjectRecord__ctor_m2962775102,
	ObjectRecord_SetMemberValue_m1045887821,
	ObjectRecord_SetArrayValue_m2756856461,
	ObjectRecord_SetMemberValue_m4000081321,
	ObjectRecord_get_IsInstanceReady_m2304516395,
	ObjectRecord_get_IsUnsolvedObjectReference_m1163921033,
	ObjectRecord_get_IsRegistered_m1980446745,
	ObjectRecord_DoFixups_m1169675535,
	ObjectRecord_RemoveFixup_m2598771603,
	ObjectRecord_UnchainFixup_m3191243952,
	ObjectRecord_ChainFixup_m1889316362,
	ObjectRecord_LoadData_m1119843494,
	ObjectRecord_get_HasPendingFixups_m1177656782,
	SerializationBinder__ctor_m1110997808,
	SerializationCallbacks__ctor_m3863304525,
	SerializationCallbacks__cctor_m1674315180,
	SerializationCallbacks_get_HasSerializedCallbacks_m104160818,
	SerializationCallbacks_get_HasDeserializedCallbacks_m989630968,
	SerializationCallbacks_GetMethodsByAttribute_m2095490433,
	SerializationCallbacks_Invoke_m4060432420,
	SerializationCallbacks_RaiseOnSerializing_m563766125,
	SerializationCallbacks_RaiseOnSerialized_m2457587934,
	SerializationCallbacks_RaiseOnDeserializing_m3047111085,
	SerializationCallbacks_RaiseOnDeserialized_m3761893080,
	SerializationCallbacks_GetSerializationCallbacks_m2939476649,
	CallbackHandler__ctor_m3390474190,
	CallbackHandler_Invoke_m3512549308,
	CallbackHandler_BeginInvoke_m1038689394,
	CallbackHandler_EndInvoke_m719226939,
	SerializationEntry__ctor_m1411687997_AdjustorThunk,
	SerializationEntry_get_Name_m1530029541_AdjustorThunk,
	SerializationEntry_get_ObjectType_m1155580012_AdjustorThunk,
	SerializationEntry_get_Value_m2039470570_AdjustorThunk,
	SerializationException__ctor_m3772074258,
	SerializationException__ctor_m3862484944,
	SerializationException__ctor_m3131447373,
	SerializationInfo__ctor_m2923079689,
	SerializationInfo_get_AssemblyName_m3241199889,
	SerializationInfo_get_FullTypeName_m558954005,
	SerializationInfo_get_MemberCount_m3751947557,
	SerializationInfo_AddValue_m3906743584,
	SerializationInfo_GetValue_m42271953,
	SerializationInfo_SetType_m3923964808,
	SerializationInfo_GetEnumerator_m1082663843,
	SerializationInfo_AddValue_m2780248522,
	SerializationInfo_AddValue_m412754688,
	SerializationInfo_AddValue_m3427199315,
	SerializationInfo_AddValue_m1927057880,
	SerializationInfo_AddValue_m1803776749,
	SerializationInfo_AddValue_m3963995439,
	SerializationInfo_AddValue_m2020653395,
	SerializationInfo_AddValue_m2872281893,
	SerializationInfo_GetBoolean_m1756153320,
	SerializationInfo_GetInt16_m3858430398,
	SerializationInfo_GetInt32_m2640574809,
	SerializationInfo_GetInt64_m2503729515,
	SerializationInfo_GetString_m3155282843,
	SerializationInfoEnumerator__ctor_m2264653019,
	SerializationInfoEnumerator_System_Collections_IEnumerator_get_Current_m2029240404,
	SerializationInfoEnumerator_get_Current_m1365373082,
	SerializationInfoEnumerator_get_Name_m4203920197,
	SerializationInfoEnumerator_get_ObjectType_m3505100851,
	SerializationInfoEnumerator_get_Value_m433044828,
	SerializationInfoEnumerator_MoveNext_m2496151825,
	SerializationInfoEnumerator_Reset_m1193994596,
	SerializationObjectManager__ctor_m460008415,
	SerializationObjectManager_RegisterObject_m951822324,
	SerializationObjectManager_RaiseOnSerializedEvent_m272248422,
	U3CRegisterObjectU3Ec__AnonStorey3__ctor_m1338377904,
	U3CRegisterObjectU3Ec__AnonStorey3_U3CU3Em__2_m1816853296,
	StreamingContext__ctor_m1072028025_AdjustorThunk,
	StreamingContext__ctor_m2604757771_AdjustorThunk,
	StreamingContext_get_Context_m541495931_AdjustorThunk,
	StreamingContext_get_State_m3338773567_AdjustorThunk,
	StreamingContext_Equals_m2722903674_AdjustorThunk,
	StreamingContext_GetHashCode_m2281950854_AdjustorThunk,
	RuntimeFieldHandle__ctor_m984632319_AdjustorThunk,
	RuntimeFieldHandle_get_Value_m4138444424_AdjustorThunk,
	RuntimeFieldHandle_GetObjectData_m95767031_AdjustorThunk,
	RuntimeFieldHandle_Equals_m4012367076_AdjustorThunk,
	RuntimeFieldHandle_GetHashCode_m2632095277_AdjustorThunk,
	RuntimeMethodHandle__ctor_m2229201676_AdjustorThunk,
	RuntimeMethodHandle__ctor_m2867240657_AdjustorThunk,
	RuntimeMethodHandle_get_Value_m723997769_AdjustorThunk,
	RuntimeMethodHandle_GetObjectData_m2865437866_AdjustorThunk,
	RuntimeMethodHandle_Equals_m3301340296_AdjustorThunk,
	RuntimeMethodHandle_GetHashCode_m750321292_AdjustorThunk,
	RuntimeTypeHandle__ctor_m3315980708_AdjustorThunk,
	RuntimeTypeHandle_get_Value_m1525396455_AdjustorThunk,
	RuntimeTypeHandle_GetObjectData_m1599302095_AdjustorThunk,
	RuntimeTypeHandle_Equals_m2857439487_AdjustorThunk,
	RuntimeTypeHandle_GetHashCode_m3999856879_AdjustorThunk,
	SByte_System_IConvertible_ToBoolean_m3272910093_AdjustorThunk,
	SByte_System_IConvertible_ToByte_m2268214252_AdjustorThunk,
	SByte_System_IConvertible_ToChar_m1489191771_AdjustorThunk,
	SByte_System_IConvertible_ToDateTime_m1659899958_AdjustorThunk,
	SByte_System_IConvertible_ToDecimal_m2548745278_AdjustorThunk,
	SByte_System_IConvertible_ToDouble_m2381680501_AdjustorThunk,
	SByte_System_IConvertible_ToInt16_m885121451_AdjustorThunk,
	SByte_System_IConvertible_ToInt32_m1636694485_AdjustorThunk,
	SByte_System_IConvertible_ToInt64_m2107229906_AdjustorThunk,
	SByte_System_IConvertible_ToSByte_m2452868086_AdjustorThunk,
	SByte_System_IConvertible_ToSingle_m1083054891_AdjustorThunk,
	SByte_System_IConvertible_ToType_m4075253447_AdjustorThunk,
	SByte_System_IConvertible_ToUInt16_m1592743959_AdjustorThunk,
	SByte_System_IConvertible_ToUInt32_m4275534457_AdjustorThunk,
	SByte_System_IConvertible_ToUInt64_m4151910932_AdjustorThunk,
	SByte_CompareTo_m3835733927_AdjustorThunk,
	SByte_Equals_m865896384_AdjustorThunk,
	SByte_GetHashCode_m2824841835_AdjustorThunk,
	SByte_CompareTo_m2441919575_AdjustorThunk,
	SByte_Equals_m3032561558_AdjustorThunk,
	SByte_Parse_m3630846728,
	SByte_Parse_m3250497834,
	SByte_Parse_m2899090751,
	SByte_TryParse_m2431806379,
	SByte_ToString_m3584531119_AdjustorThunk,
	SByte_ToString_m1735624261_AdjustorThunk,
	SByte_ToString_m2762508873_AdjustorThunk,
	SByte_ToString_m2708934884_AdjustorThunk,
	AllowPartiallyTrustedCallersAttribute__ctor_m1248209229,
	CodeAccessPermission__ctor_m1135661531,
	CodeAccessPermission_Equals_m1555575992,
	CodeAccessPermission_GetHashCode_m880096813,
	CodeAccessPermission_ToString_m797953232,
	CodeAccessPermission_Element_m4280812549,
	CodeAccessPermission_ThrowInvalidPermission_m3890026412,
	AsymmetricAlgorithm__ctor_m1554933721,
	AsymmetricAlgorithm_System_IDisposable_Dispose_m4219596803,
	AsymmetricAlgorithm_get_KeySize_m2113907895,
	AsymmetricAlgorithm_set_KeySize_m2163393617,
	AsymmetricAlgorithm_Clear_m1528825448,
	AsymmetricAlgorithm_GetNamedParam_m2128682280,
	AsymmetricKeyExchangeFormatter__ctor_m1720558774,
	AsymmetricSignatureDeformatter__ctor_m88114807,
	AsymmetricSignatureFormatter__ctor_m3278494933,
	Base64Constants__cctor_m1668117186,
	CryptoConfig__cctor_m34707108,
	CryptoConfig_Initialize_m168211670,
	CryptoConfig_CreateFromName_m1538277313,
	CryptoConfig_CreateFromName_m2674746512,
	CryptoConfig_MapNameToOID_m2044758263,
	CryptoConfig_EncodeOID_m2635914623,
	CryptoConfig_EncodeLongNumber_m4127306320,
	CryptographicException__ctor_m1391449859,
	CryptographicException__ctor_m503735289,
	CryptographicException__ctor_m1422015889,
	CryptographicException__ctor_m3803155940,
	CryptographicException__ctor_m3486909073,
	CryptographicUnexpectedOperationException__ctor_m1394830404,
	CryptographicUnexpectedOperationException__ctor_m2381988196,
	CryptographicUnexpectedOperationException__ctor_m69881930,
	CspParameters__ctor_m277845443,
	CspParameters__ctor_m2741097571,
	CspParameters__ctor_m1928090281,
	CspParameters__ctor_m3852972821,
	CspParameters_get_Flags_m4238672607,
	CspParameters_set_Flags_m397261363,
	DES__ctor_m1833611161,
	DES__cctor_m3576612725,
	DES_Create_m1258183099,
	DES_Create_m2166467748,
	DES_IsWeakKey_m1784515364,
	DES_IsSemiWeakKey_m2495136119,
	DES_get_Key_m3419790416,
	DES_set_Key_m2569946991,
	DESCryptoServiceProvider__ctor_m3757531594,
	DESCryptoServiceProvider_CreateDecryptor_m3245980552,
	DESCryptoServiceProvider_CreateEncryptor_m2830855064,
	DESCryptoServiceProvider_GenerateIV_m683687014,
	DESCryptoServiceProvider_GenerateKey_m1810256255,
	DESTransform__ctor_m878979107,
	DESTransform__cctor_m244488330,
	DESTransform_CipherFunct_m3527261721,
	DESTransform_Permutation_m252663723,
	DESTransform_BSwap_m2723001589,
	DESTransform_SetKey_m3436155416,
	DESTransform_ProcessBlock_m2449315636,
	DESTransform_ECB_m1168033891,
	DESTransform_GetStrongKey_m1464830895,
	DSA__ctor_m1979872003,
	DSA_Create_m1220983153,
	DSA_Create_m2559649673,
	DSA_ZeroizePrivateKey_m1053698176,
	DSA_FromXmlString_m1479532250,
	DSA_ToXmlString_m3836885162,
	DSACryptoServiceProvider__ctor_m517243624,
	DSACryptoServiceProvider__ctor_m1139102382,
	DSACryptoServiceProvider__ctor_m3949670084,
	DSACryptoServiceProvider__cctor_m3823760945,
	DSACryptoServiceProvider_Finalize_m1286601265,
	DSACryptoServiceProvider_get_KeySize_m786836990,
	DSACryptoServiceProvider_get_PublicOnly_m3933928860,
	DSACryptoServiceProvider_ExportParameters_m591135777,
	DSACryptoServiceProvider_ImportParameters_m611916501,
	DSACryptoServiceProvider_CreateSignature_m267208648,
	DSACryptoServiceProvider_VerifySignature_m2080101421,
	DSACryptoServiceProvider_Dispose_m1092393028,
	DSACryptoServiceProvider_OnKeyGenerated_m2274596916,
	DSASignatureDeformatter__ctor_m2759753186,
	DSASignatureDeformatter__ctor_m2889130126,
	DSASignatureDeformatter_SetHashAlgorithm_m3186995552,
	DSASignatureDeformatter_SetKey_m2999549245,
	DSASignatureDeformatter_VerifySignature_m4260177023,
	DSASignatureDescription__ctor_m2058525095,
	DSASignatureFormatter__ctor_m2328815619,
	DSASignatureFormatter_CreateSignature_m3254505990,
	DSASignatureFormatter_SetHashAlgorithm_m2004578631,
	DSASignatureFormatter_SetKey_m3643725525,
	HMAC__ctor_m97939284,
	HMAC_get_BlockSizeValue_m455678067,
	HMAC_set_BlockSizeValue_m2639576659,
	HMAC_set_HashName_m2561756873,
	HMAC_get_Key_m623825087,
	HMAC_set_Key_m2848363914,
	HMAC_get_Block_m1432537422,
	HMAC_KeySetup_m661741544,
	HMAC_Dispose_m3665032088,
	HMAC_HashCore_m3684104066,
	HMAC_HashFinal_m1921180827,
	HMAC_Initialize_m3157696427,
	HMAC_Create_m2390117573,
	HMAC_Create_m2148924157,
	HMACMD5__ctor_m3129799368,
	HMACMD5__ctor_m3008609295,
	HMACRIPEMD160__ctor_m4073272899,
	HMACRIPEMD160__ctor_m2981281487,
	HMACSHA1__ctor_m4144697316,
	HMACSHA1__ctor_m446190279,
	HMACSHA256__ctor_m346174875,
	HMACSHA256__ctor_m3379531528,
	HMACSHA384__ctor_m82969736,
	HMACSHA384__ctor_m1677515580,
	HMACSHA384__cctor_m3009390673,
	HMACSHA384_set_ProduceLegacyHmacValues_m76936446,
	HMACSHA512__ctor_m2615612210,
	HMACSHA512__ctor_m348055215,
	HMACSHA512__cctor_m4155933671,
	HMACSHA512_set_ProduceLegacyHmacValues_m3961135292,
	HashAlgorithm__ctor_m190815979,
	HashAlgorithm_System_IDisposable_Dispose_m3925361195,
	HashAlgorithm_get_CanReuseTransform_m3278578776,
	HashAlgorithm_ComputeHash_m2825542963,
	HashAlgorithm_ComputeHash_m2044824070,
	HashAlgorithm_Create_m644612360,
	HashAlgorithm_get_Hash_m482540885,
	HashAlgorithm_get_HashSize_m1025185937,
	HashAlgorithm_Dispose_m620242512,
	HashAlgorithm_TransformBlock_m4006041779,
	HashAlgorithm_TransformFinalBlock_m3005451348,
	KeySizes__ctor_m3113946058,
	KeySizes_get_MaxSize_m3897255827,
	KeySizes_get_MinSize_m1903718763,
	KeySizes_get_SkipSize_m2783487614,
	KeySizes_IsLegal_m2429848889,
	KeySizes_IsLegalKeySize_m2571462035,
	KeyedHashAlgorithm__ctor_m4053775756,
	KeyedHashAlgorithm_Finalize_m3436068827,
	KeyedHashAlgorithm_get_Key_m1843505301,
	KeyedHashAlgorithm_set_Key_m711403901,
	KeyedHashAlgorithm_Dispose_m2325408902,
	KeyedHashAlgorithm_ZeroizeKey_m1611290675,
	MACTripleDES__ctor_m1301195406,
	MACTripleDES_Setup_m560957914,
	MACTripleDES_Finalize_m3761305675,
	MACTripleDES_Dispose_m3118990285,
	MACTripleDES_Initialize_m3918381832,
	MACTripleDES_HashCore_m2803969153,
	MACTripleDES_HashFinal_m3613553534,
	MD5__ctor_m3848300604,
	MD5_Create_m3522414168,
	MD5_Create_m3289886172,
	MD5CryptoServiceProvider__ctor_m3271163125,
	MD5CryptoServiceProvider__cctor_m2609586198,
	MD5CryptoServiceProvider_Finalize_m950838019,
	MD5CryptoServiceProvider_Dispose_m3502499818,
	MD5CryptoServiceProvider_HashCore_m2558876268,
	MD5CryptoServiceProvider_HashFinal_m2625727830,
	MD5CryptoServiceProvider_Initialize_m2402854924,
	MD5CryptoServiceProvider_ProcessBlock_m3522014752,
	MD5CryptoServiceProvider_ProcessFinalBlock_m2241588515,
	MD5CryptoServiceProvider_AddLength_m142725782,
	RC2__ctor_m1146135664,
	RC2_Create_m2516417038,
	RC2_Create_m2052783340,
	RC2_get_EffectiveKeySize_m285632245,
	RC2_get_KeySize_m146781412,
	RC2_set_KeySize_m2968816949,
	RC2CryptoServiceProvider__ctor_m420166935,
	RC2CryptoServiceProvider_get_EffectiveKeySize_m3835262416,
	RC2CryptoServiceProvider_CreateDecryptor_m3810731330,
	RC2CryptoServiceProvider_CreateEncryptor_m1615052595,
	RC2CryptoServiceProvider_GenerateIV_m1412313176,
	RC2CryptoServiceProvider_GenerateKey_m468082592,
	RC2Transform__ctor_m1795280107,
	RC2Transform__cctor_m4067495236,
	RC2Transform_ECB_m1047445751,
	RIPEMD160__ctor_m860963627,
	RIPEMD160Managed__ctor_m1837600365,
	RIPEMD160Managed_Initialize_m2173168986,
	RIPEMD160Managed_HashCore_m2350629432,
	RIPEMD160Managed_HashFinal_m1016449914,
	RIPEMD160Managed_Finalize_m2864487594,
	RIPEMD160Managed_ProcessBlock_m3304263146,
	RIPEMD160Managed_Compress_m126479169,
	RIPEMD160Managed_CompressFinal_m497690796,
	RIPEMD160Managed_ROL_m2647139887,
	RIPEMD160Managed_F_m2051853483,
	RIPEMD160Managed_G_m3625715749,
	RIPEMD160Managed_H_m2707761209,
	RIPEMD160Managed_I_m2107336345,
	RIPEMD160Managed_J_m1336489154,
	RIPEMD160Managed_FF_m738585160,
	RIPEMD160Managed_GG_m3020389474,
	RIPEMD160Managed_HH_m90236373,
	RIPEMD160Managed_II_m1560285116,
	RIPEMD160Managed_JJ_m112143231,
	RIPEMD160Managed_FFF_m3692014807,
	RIPEMD160Managed_GGG_m1715572318,
	RIPEMD160Managed_HHH_m2839246531,
	RIPEMD160Managed_III_m3606824266,
	RIPEMD160Managed_JJJ_m4161373884,
	RNGCryptoServiceProvider__ctor_m2355451105,
	RNGCryptoServiceProvider__cctor_m3587754670,
	RNGCryptoServiceProvider_Check_m3453818294,
	RNGCryptoServiceProvider_RngOpen_m792795472,
	RNGCryptoServiceProvider_RngInitialize_m2025286560,
	RNGCryptoServiceProvider_RngGetBytes_m1695806698,
	RNGCryptoServiceProvider_RngClose_m3915778345,
	RNGCryptoServiceProvider_GetBytes_m918414272,
	RNGCryptoServiceProvider_GetNonZeroBytes_m1918423726,
	RNGCryptoServiceProvider_Finalize_m1304072372,
	RSA__ctor_m2923348713,
	RSA_Create_m4065275734,
	RSA_Create_m2021570897,
	RSA_ZeroizePrivateKey_m4052091611,
	RSA_FromXmlString_m2537913712,
	RSA_ToXmlString_m2922661427,
	RSACryptoServiceProvider__ctor_m2288290917,
	RSACryptoServiceProvider__ctor_m357386130,
	RSACryptoServiceProvider__ctor_m2378475222,
	RSACryptoServiceProvider__cctor_m3113818354,
	RSACryptoServiceProvider_Common_m861233239,
	RSACryptoServiceProvider_Finalize_m1969564496,
	RSACryptoServiceProvider_get_KeySize_m2654153358,
	RSACryptoServiceProvider_get_PublicOnly_m4039982639,
	RSACryptoServiceProvider_DecryptValue_m3095079293,
	RSACryptoServiceProvider_EncryptValue_m944137256,
	RSACryptoServiceProvider_ExportParameters_m3871179960,
	RSACryptoServiceProvider_ImportParameters_m614616705,
	RSACryptoServiceProvider_Dispose_m1199148535,
	RSACryptoServiceProvider_OnKeyGenerated_m863837376,
	RSAPKCS1KeyExchangeFormatter__ctor_m1170240343,
	RSAPKCS1KeyExchangeFormatter_CreateKeyExchange_m1611814432,
	RSAPKCS1KeyExchangeFormatter_SetRSAKey_m1477802943,
	RSAPKCS1SHA1SignatureDescription__ctor_m621804060,
	RSAPKCS1SignatureDeformatter__ctor_m3540701537,
	RSAPKCS1SignatureDeformatter__ctor_m3706544163,
	RSAPKCS1SignatureDeformatter_SetHashAlgorithm_m1602190713,
	RSAPKCS1SignatureDeformatter_SetKey_m614724234,
	RSAPKCS1SignatureDeformatter_VerifySignature_m1810970621,
	RSAPKCS1SignatureFormatter__ctor_m1234483002,
	RSAPKCS1SignatureFormatter_CreateSignature_m3191980616,
	RSAPKCS1SignatureFormatter_SetHashAlgorithm_m446605265,
	RSAPKCS1SignatureFormatter_SetKey_m2935054088,
	RandomNumberGenerator__ctor_m1589693309,
	RandomNumberGenerator_Create_m4162970280,
	RandomNumberGenerator_Create_m2019689173,
	Rijndael__ctor_m4179966697,
	Rijndael_Create_m3053077028,
	Rijndael_Create_m1026182146,
	RijndaelManaged__ctor_m1562735454,
	RijndaelManaged_GenerateIV_m667430910,
	RijndaelManaged_GenerateKey_m1736287430,
	RijndaelManaged_CreateDecryptor_m1421727258,
	RijndaelManaged_CreateEncryptor_m263736311,
	RijndaelManagedTransform__ctor_m1033522223,
	RijndaelManagedTransform_System_IDisposable_Dispose_m539902307,
	RijndaelManagedTransform_get_CanReuseTransform_m2604443164,
	RijndaelManagedTransform_TransformBlock_m1610137419,
	RijndaelManagedTransform_TransformFinalBlock_m1454105523,
	RijndaelTransform__ctor_m3424202476,
	RijndaelTransform__cctor_m2439033240,
	RijndaelTransform_Clear_m2609662851,
	RijndaelTransform_ECB_m670662322,
	RijndaelTransform_SubByte_m3037693507,
	RijndaelTransform_Encrypt128_m1940909042,
	RijndaelTransform_Encrypt192_m3191066202,
	RijndaelTransform_Encrypt256_m2353669657,
	RijndaelTransform_Decrypt128_m4239115689,
	RijndaelTransform_Decrypt192_m3453970103,
	RijndaelTransform_Decrypt256_m4151308345,
	SHA1__ctor_m2454864745,
	SHA1_Create_m1390871308,
	SHA1_Create_m2934697039,
	SHA1CryptoServiceProvider__ctor_m4195188793,
	SHA1CryptoServiceProvider_Finalize_m1793183797,
	SHA1CryptoServiceProvider_Dispose_m1653611664,
	SHA1CryptoServiceProvider_HashCore_m3575298072,
	SHA1CryptoServiceProvider_HashFinal_m2727634713,
	SHA1CryptoServiceProvider_Initialize_m1426968065,
	SHA1Internal__ctor_m2437096624,
	SHA1Internal_HashCore_m1635242363,
	SHA1Internal_HashFinal_m1760803056,
	SHA1Internal_Initialize_m499810128,
	SHA1Internal_ProcessBlock_m1991889327,
	SHA1Internal_InitialiseBuff_m2891366785,
	SHA1Internal_FillBuff_m3615718415,
	SHA1Internal_ProcessFinalBlock_m1403775421,
	SHA1Internal_AddLength_m2737455899,
	SHA1Managed__ctor_m3689558429,
	SHA1Managed_HashCore_m3836844037,
	SHA1Managed_HashFinal_m2365675383,
	SHA1Managed_Initialize_m1494395538,
	SHA256__ctor_m4000989288,
	SHA256_Create_m610202894,
	SHA256_Create_m697467885,
	SHA256Managed__ctor_m2170017447,
	SHA256Managed_HashCore_m329219284,
	SHA256Managed_HashFinal_m2914312286,
	SHA256Managed_Initialize_m1787080315,
	SHA256Managed_ProcessBlock_m2297835517,
	SHA256Managed_ProcessFinalBlock_m3518004226,
	SHA256Managed_AddLength_m1060552216,
	SHA384__ctor_m202253083,
	SHA384_Create_m3237405884,
	SHA384_Create_m1745173416,
	SHA384Managed__ctor_m3220477113,
	SHA384Managed_Initialize_m1661896576,
	SHA384Managed_Initialize_m703960418,
	SHA384Managed_HashCore_m3010817561,
	SHA384Managed_HashFinal_m2401837128,
	SHA384Managed_update_m2910797953,
	SHA384Managed_processWord_m3832940157,
	SHA384Managed_unpackWord_m785426507,
	SHA384Managed_adjustByteCounts_m2921970088,
	SHA384Managed_processLength_m1746354084,
	SHA384Managed_processBlock_m1272529332,
	SHA512__ctor_m84228937,
	SHA512_Create_m3934606971,
	SHA512_Create_m3236870067,
	SHA512Managed__ctor_m330347986,
	SHA512Managed_Initialize_m2527292789,
	SHA512Managed_Initialize_m2478368867,
	SHA512Managed_HashCore_m2377807474,
	SHA512Managed_HashFinal_m2173184560,
	SHA512Managed_update_m3202186042,
	SHA512Managed_processWord_m1015820257,
	SHA512Managed_unpackWord_m3785560830,
	SHA512Managed_adjustByteCounts_m3003603904,
	SHA512Managed_processLength_m2162821715,
	SHA512Managed_processBlock_m1725885004,
	SHA512Managed_rotateRight_m3393943223,
	SHA512Managed_Ch_m213737293,
	SHA512Managed_Maj_m3649014337,
	SHA512Managed_Sum0_m1216661412,
	SHA512Managed_Sum1_m4163780989,
	SHA512Managed_Sigma0_m921579649,
	SHA512Managed_Sigma1_m922902398,
	SHAConstants__cctor_m1699027474,
	SignatureDescription__ctor_m3689246904,
	SignatureDescription_set_DeformatterAlgorithm_m2634775062,
	SignatureDescription_set_DigestAlgorithm_m1385003273,
	SignatureDescription_set_FormatterAlgorithm_m3829972493,
	SignatureDescription_set_KeyAlgorithm_m3497860189,
	SymmetricAlgorithm__ctor_m467277132,
	SymmetricAlgorithm_System_IDisposable_Dispose_m3402297829,
	SymmetricAlgorithm_Finalize_m2361523015,
	SymmetricAlgorithm_Clear_m3302238152,
	SymmetricAlgorithm_Dispose_m1120980942,
	SymmetricAlgorithm_get_BlockSize_m3551721617,
	SymmetricAlgorithm_set_BlockSize_m812732862,
	SymmetricAlgorithm_get_FeedbackSize_m3666584308,
	SymmetricAlgorithm_get_IV_m1875559108,
	SymmetricAlgorithm_set_IV_m3196220308,
	SymmetricAlgorithm_get_Key_m3241860519,
	SymmetricAlgorithm_set_Key_m1775642191,
	SymmetricAlgorithm_get_KeySize_m4185004893,
	SymmetricAlgorithm_set_KeySize_m3805756466,
	SymmetricAlgorithm_get_LegalKeySizes_m1340766361,
	SymmetricAlgorithm_get_Mode_m654054760,
	SymmetricAlgorithm_set_Mode_m4060916368,
	SymmetricAlgorithm_get_Padding_m1011382560,
	SymmetricAlgorithm_set_Padding_m1690860683,
	SymmetricAlgorithm_CreateDecryptor_m3477646776,
	SymmetricAlgorithm_CreateEncryptor_m617415315,
	SymmetricAlgorithm_Create_m2726390826,
	ToBase64Transform_System_IDisposable_Dispose_m1701635576,
	ToBase64Transform_Finalize_m4202114424,
	ToBase64Transform_get_CanReuseTransform_m702204640,
	ToBase64Transform_get_InputBlockSize_m1094416431,
	ToBase64Transform_get_OutputBlockSize_m1897680077,
	ToBase64Transform_Dispose_m2199216182,
	ToBase64Transform_TransformBlock_m2497349397,
	ToBase64Transform_InternalTransformBlock_m3458782414,
	ToBase64Transform_TransformFinalBlock_m2460017188,
	ToBase64Transform_InternalTransformFinalBlock_m360524956,
	TripleDES__ctor_m4045412014,
	TripleDES_get_Key_m1921822970,
	TripleDES_set_Key_m3464715319,
	TripleDES_IsWeakKey_m2147489852,
	TripleDES_Create_m3761371613,
	TripleDES_Create_m2471273334,
	TripleDESCryptoServiceProvider__ctor_m758388349,
	TripleDESCryptoServiceProvider_GenerateIV_m3862928583,
	TripleDESCryptoServiceProvider_GenerateKey_m1212686842,
	TripleDESCryptoServiceProvider_CreateDecryptor_m740960117,
	TripleDESCryptoServiceProvider_CreateEncryptor_m450924958,
	TripleDESTransform__ctor_m3915497765,
	TripleDESTransform_ECB_m731927780,
	TripleDESTransform_GetStrongKey_m292426577,
	X509Certificate__ctor_m1008109281,
	X509Certificate__ctor_m1413707489,
	X509Certificate__ctor_m1321742168,
	X509Certificate__ctor_m4186241804,
	X509Certificate_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1836612204,
	X509Certificate_System_Runtime_Serialization_ISerializable_GetObjectData_m1891910043,
	X509Certificate_tostr_m197816703,
	X509Certificate_Equals_m861530042,
	X509Certificate_GetCertHash_m274210048,
	X509Certificate_GetCertHashString_m3484127109,
	X509Certificate_GetEffectiveDateString_m1666677721,
	X509Certificate_GetExpirationDateString_m1253593872,
	X509Certificate_GetHashCode_m3969199094,
	X509Certificate_GetIssuerName_m1601331538,
	X509Certificate_GetName_m1060481339,
	X509Certificate_GetPublicKey_m4184729161,
	X509Certificate_GetRawCertData_m781236105,
	X509Certificate_ToString_m3415629710,
	X509Certificate_ToString_m2340207075,
	X509Certificate_get_Issuer_m2934704867,
	X509Certificate_get_Subject_m2638144878,
	X509Certificate_Equals_m3784196370,
	X509Certificate_Import_m3563119820,
	X509Certificate_Reset_m2350932593,
	PermissionSet__ctor_m2328457660,
	PermissionSet__ctor_m1880216441,
	PermissionSet_set_DeclarativeSecurity_m858801747,
	PermissionSet_CreateFromBinaryFormat_m3762234240,
	SecurityPermission__ctor_m1462427327,
	SecurityPermission_set_Flags_m1503445204,
	SecurityPermission_IsUnrestricted_m3327262311,
	SecurityPermission_IsSubsetOf_m545000671,
	SecurityPermission_ToXml_m355131433,
	SecurityPermission_IsEmpty_m2033068359,
	SecurityPermission_Cast_m2392017566,
	SecurityPermissionAttribute_set_SkipVerification_m4061350763,
	StrongNamePublicKeyBlob_Equals_m3655422942,
	StrongNamePublicKeyBlob_GetHashCode_m1678068698,
	StrongNamePublicKeyBlob_ToString_m724833278,
	ApplicationTrust__ctor_m515003198,
	Evidence__ctor_m415538579,
	Evidence_get_Count_m4079441921,
	Evidence_get_SyncRoot_m2835084965,
	Evidence_get_HostEvidenceList_m2705108086,
	Evidence_get_AssemblyEvidenceList_m632963901,
	Evidence_CopyTo_m872435527,
	Evidence_Equals_m1478353107,
	Evidence_GetEnumerator_m302914965,
	Evidence_GetHashCode_m2129946875,
	EvidenceEnumerator__ctor_m3211544433,
	EvidenceEnumerator_MoveNext_m183460296,
	EvidenceEnumerator_Reset_m2337577119,
	EvidenceEnumerator_get_Current_m1264365535,
	Hash__ctor_m1849242049,
	Hash__ctor_m2891763106,
	Hash_GetObjectData_m2136403986,
	Hash_ToString_m1453919145,
	Hash_GetData_m1957063775,
	StrongName_get_Name_m1932850490,
	StrongName_get_PublicKey_m46076020,
	StrongName_get_Version_m4243032012,
	StrongName_Equals_m384811149,
	StrongName_GetHashCode_m4255451393,
	StrongName_ToString_m3130222752,
	WindowsIdentity__ctor_m3086466707,
	WindowsIdentity__cctor_m1315799505,
	WindowsIdentity_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3428853631,
	WindowsIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2539658116,
	WindowsIdentity_Dispose_m3466258450,
	WindowsIdentity_GetCurrentToken_m841791956,
	WindowsIdentity_GetTokenName_m2370798233,
	SecurityContext__ctor_m3125602325,
	SecurityContext__ctor_m1730177197,
	SecurityContext_Capture_m1047743382,
	SecurityContext_get_FlowSuppressed_m1627541854,
	SecurityContext_get_CompressedStack_m3401528670,
	SecurityCriticalAttribute__ctor_m2491468454,
	SecurityElement__ctor_m6516005,
	SecurityElement__ctor_m750466183,
	SecurityElement__cctor_m3326869319,
	SecurityElement_get_Children_m1231540612,
	SecurityElement_get_Tag_m2258014803,
	SecurityElement_set_Text_m3975773934,
	SecurityElement_AddAttribute_m311510562,
	SecurityElement_AddChild_m1606852781,
	SecurityElement_Escape_m1342311983,
	SecurityElement_Unescape_m327386968,
	SecurityElement_IsValidAttributeName_m713904709,
	SecurityElement_IsValidAttributeValue_m948345692,
	SecurityElement_IsValidTag_m1803475254,
	SecurityElement_IsValidText_m1346599242,
	SecurityElement_SearchForChildByTag_m900466299,
	SecurityElement_ToString_m1918878627,
	SecurityElement_ToXml_m3664345083,
	SecurityElement_GetAttribute_m3347489583,
	SecurityAttribute__ctor_m1429827508,
	SecurityAttribute_get_Name_m2543977264,
	SecurityAttribute_get_Value_m2111064489,
	SecurityException__ctor_m836898292,
	SecurityException__ctor_m1631242336,
	SecurityException__ctor_m254177942,
	SecurityException_get_Demanded_m2500043391,
	SecurityException_get_FirstPermissionThatFailed_m3934559164,
	SecurityException_get_PermissionState_m3857825198,
	SecurityException_get_PermissionType_m2237538728,
	SecurityException_get_GrantedSet_m2643283539,
	SecurityException_get_RefusedSet_m2404284794,
	SecurityException_GetObjectData_m1968030344,
	SecurityException_ToString_m3228070608,
	SecurityFrame__ctor_m2140076703_AdjustorThunk,
	SecurityFrame__GetSecurityStack_m449275820,
	SecurityFrame_InitFromRuntimeFrame_m1714852458_AdjustorThunk,
	SecurityFrame_get_Assembly_m2874566710_AdjustorThunk,
	SecurityFrame_get_Domain_m681627326_AdjustorThunk,
	SecurityFrame_ToString_m339310712_AdjustorThunk,
	SecurityFrame_GetStack_m347707425,
	SecurityManager__cctor_m975553111,
	SecurityManager_get_SecurityEnabled_m3467182822,
	SecurityManager_Decode_m84973736,
	SecurityManager_Decode_m2551103128,
	SecuritySafeCriticalAttribute__ctor_m3038748144,
	SuppressUnmanagedCodeSecurityAttribute__ctor_m1009318222,
	UnverifiableCodeAttribute__ctor_m3990698597,
	SerializableAttribute__ctor_m3782985861,
	Single_System_IConvertible_ToBoolean_m1716619219_AdjustorThunk,
	Single_System_IConvertible_ToByte_m997362015_AdjustorThunk,
	Single_System_IConvertible_ToChar_m1898259383_AdjustorThunk,
	Single_System_IConvertible_ToDateTime_m1748479284_AdjustorThunk,
	Single_System_IConvertible_ToDecimal_m325860800_AdjustorThunk,
	Single_System_IConvertible_ToDouble_m1584722292_AdjustorThunk,
	Single_System_IConvertible_ToInt16_m809233024_AdjustorThunk,
	Single_System_IConvertible_ToInt32_m872115569_AdjustorThunk,
	Single_System_IConvertible_ToInt64_m1650421025_AdjustorThunk,
	Single_System_IConvertible_ToSByte_m1208276900_AdjustorThunk,
	Single_System_IConvertible_ToSingle_m1939829239_AdjustorThunk,
	Single_System_IConvertible_ToType_m3312441682_AdjustorThunk,
	Single_System_IConvertible_ToUInt16_m1263555070_AdjustorThunk,
	Single_System_IConvertible_ToUInt32_m289030200_AdjustorThunk,
	Single_System_IConvertible_ToUInt64_m3299129161_AdjustorThunk,
	Single_CompareTo_m2785801815_AdjustorThunk,
	Single_Equals_m438106747_AdjustorThunk,
	Single_CompareTo_m189772128_AdjustorThunk,
	Single_Equals_m1601893879_AdjustorThunk,
	Single_GetHashCode_m1558506138_AdjustorThunk,
	Single_IsInfinity_m936314085,
	Single_IsNaN_m4024467661,
	Single_IsNegativeInfinity_m1556741963,
	Single_IsPositiveInfinity_m1411272350,
	Single_Parse_m3840407583,
	Single_ToString_m3947131094_AdjustorThunk,
	Single_ToString_m3107811250_AdjustorThunk,
	Single_ToString_m543431371_AdjustorThunk,
	StackOverflowException__ctor_m592204071,
	StackOverflowException__ctor_m3139217097,
	StackOverflowException__ctor_m3777153282,
	String__ctor_m1266423354,
	String__ctor_m1926862525,
	String__ctor_m1800510039,
	String__ctor_m229724522,
	String__cctor_m261295518,
	String_System_IConvertible_ToBoolean_m887520575,
	String_System_IConvertible_ToByte_m4057316234,
	String_System_IConvertible_ToChar_m863771412,
	String_System_IConvertible_ToDateTime_m3578483777,
	String_System_IConvertible_ToDecimal_m997069272,
	String_System_IConvertible_ToDouble_m3740733360,
	String_System_IConvertible_ToInt16_m1880095008,
	String_System_IConvertible_ToInt32_m2665383247,
	String_System_IConvertible_ToInt64_m3494136111,
	String_System_IConvertible_ToSByte_m945078350,
	String_System_IConvertible_ToSingle_m2571483125,
	String_System_IConvertible_ToType_m3431692856,
	String_System_IConvertible_ToUInt16_m2888090399,
	String_System_IConvertible_ToUInt32_m281099219,
	String_System_IConvertible_ToUInt64_m4086947440,
	String_System_Collections_Generic_IEnumerableU3CcharU3E_GetEnumerator_m1490086850,
	String_System_Collections_IEnumerable_GetEnumerator_m3198926340,
	String_Equals_m1744302937,
	String_Equals_m1039194686,
	String_Equals_m2270643605,
	String_get_Chars_m2986988803,
	String_Clone_m3573869765,
	String_CopyTo_m2803757991,
	String_ToCharArray_m1492846834,
	String_ToCharArray_m2268354229,
	String_Split_m3646115398,
	String_Split_m2077324731,
	String_Split_m3580120853,
	String_Split_m2533743664,
	String_Split_m4013853433,
	String_Substring_m2848979100,
	String_Substring_m1610150815,
	String_SubstringUnchecked_m1840487357,
	String_Trim_m923598732,
	String_Trim_m3384720403,
	String_TrimStart_m1431283012,
	String_TrimEnd_m3824727301,
	String_FindNotWhiteSpace_m2733198255,
	String_FindNotInTable_m421831114,
	String_Compare_m3735043349,
	String_Compare_m1071830722,
	String_Compare_m1293271421,
	String_Compare_m945110377,
	String_CompareTo_m3030934538,
	String_CompareTo_m3414379165,
	String_CompareOrdinal_m1012192092,
	String_CompareOrdinalUnchecked_m2277084468,
	String_CompareOrdinalCaseInsensitiveUnchecked_m2925624579,
	String_EndsWith_m1901926500,
	String_IndexOfAny_m4159774896,
	String_IndexOfAny_m2323029521,
	String_IndexOfAny_m2882391940,
	String_IndexOfAnyUnchecked_m953388766,
	String_IndexOf_m1298810678,
	String_IndexOf_m3950524021,
	String_IndexOfOrdinal_m962178384,
	String_IndexOfOrdinalUnchecked_m460601827,
	String_IndexOfOrdinalIgnoreCaseUnchecked_m2823953141,
	String_IndexOf_m363431711,
	String_IndexOf_m2466398549,
	String_IndexOf_m1248948328,
	String_IndexOfUnchecked_m3677172170,
	String_IndexOf_m1977622757,
	String_IndexOf_m3406607758,
	String_IndexOf_m2410372598,
	String_LastIndexOfAny_m545540478,
	String_LastIndexOfAnyUnchecked_m1231532039,
	String_LastIndexOf_m3451222878,
	String_LastIndexOf_m578673845,
	String_LastIndexOf_m3228770703,
	String_LastIndexOfUnchecked_m2119268555,
	String_LastIndexOf_m2676535141,
	String_LastIndexOf_m95398196,
	String_IsNullOrEmpty_m2969720369,
	String_PadRight_m50345030,
	String_StartsWith_m1759067526,
	String_Replace_m3726209165,
	String_Replace_m1273907647,
	String_ReplaceUnchecked_m1381393810,
	String_ReplaceFallback_m1061004996,
	String_Remove_m562998446,
	String_ToLower_m2029374922,
	String_ToLower_m3490221821,
	String_ToLowerInvariant_m110751226,
	String_ToUpperInvariant_m2531236323,
	String_ToString_m838249115,
	String_ToString_m3872792296,
	String_Format_m2844511972,
	String_Format_m2556382932,
	String_Format_m3339413201,
	String_Format_m630303134,
	String_Format_m1881875187,
	String_FormatHelper_m3913915042,
	String_Copy_m3813992399,
	String_Concat_m904156431,
	String_Concat_m1715369213,
	String_Concat_m3937257545,
	String_Concat_m3755062657,
	String_Concat_m2163913788,
	String_Concat_m2971454694,
	String_Concat_m1809518182,
	String_ConcatInternal_m190606771,
	String_Insert_m3534971326,
	String_Join_m2050845953,
	String_Join_m29736248,
	String_JoinUnchecked_m3111386027,
	String_get_Length_m3847582255,
	String_ParseFormatSpecifier_m3134189457,
	String_ParseDecimal_m3629679395,
	String_InternalSetChar_m884839805,
	String_InternalSetLength_m3661226516,
	String_GetHashCode_m1906374149,
	String_GetCaseInsensitiveHashCode_m3282844242,
	String_CreateString_m4016935005,
	String_CreateString_m780602784,
	String_CreateString_m2329023138,
	String_CreateString_m3439913850,
	String_CreateString_m3400201881,
	String_CreateString_m860434552,
	String_CreateString_m2818852475,
	String_CreateString_m1262864254,
	String_memcpy4_m979367827,
	String_memcpy2_m2048375426,
	String_memcpy1_m4209751456,
	String_memcpy_m2826223007,
	String_CharCopy_m98228993,
	String_CharCopyReverse_m1548661297,
	String_CharCopy_m3838781968,
	String_CharCopy_m2254797373,
	String_CharCopyReverse_m692227313,
	String_InternalSplit_m1398300789,
	String_InternalAllocateStr_m1198086868,
	String_op_Equality_m920492651,
	String_op_Inequality_m215368492,
	StringComparer__ctor_m621368542,
	StringComparer__cctor_m1626042071,
	StringComparer_get_InvariantCultureIgnoreCase_m2404489191,
	StringComparer_Compare_m991165676,
	StringComparer_Equals_m1418565653,
	StringComparer_GetHashCode_m2080455020,
	SystemException__ctor_m4274309232,
	SystemException__ctor_m3298527747,
	SystemException__ctor_m1515048899,
	SystemException__ctor_m4132668650,
	ASCIIEncoding__ctor_m1380190655,
	ASCIIEncoding_GetByteCount_m2129416242,
	ASCIIEncoding_GetByteCount_m1278774099,
	ASCIIEncoding_GetBytes_m2774699525,
	ASCIIEncoding_GetBytes_m2264249800,
	ASCIIEncoding_GetBytes_m4130454866,
	ASCIIEncoding_GetBytes_m2569027226,
	ASCIIEncoding_GetCharCount_m1680860125,
	ASCIIEncoding_GetChars_m2543669481,
	ASCIIEncoding_GetChars_m3984780680,
	ASCIIEncoding_GetMaxByteCount_m3220079164,
	ASCIIEncoding_GetMaxCharCount_m3025651522,
	ASCIIEncoding_GetString_m58523364,
	ASCIIEncoding_GetBytes_m2555927703,
	ASCIIEncoding_GetByteCount_m1773359527,
	ASCIIEncoding_GetDecoder_m2247302044,
	Decoder__ctor_m4046021500,
	Decoder_set_Fallback_m3834517714,
	Decoder_get_FallbackBuffer_m2656621242,
	DecoderExceptionFallback__ctor_m4044614564,
	DecoderExceptionFallback_CreateFallbackBuffer_m1133375601,
	DecoderExceptionFallback_Equals_m1082173956,
	DecoderExceptionFallback_GetHashCode_m1820789965,
	DecoderExceptionFallbackBuffer__ctor_m3568925774,
	DecoderExceptionFallbackBuffer_get_Remaining_m2901856506,
	DecoderExceptionFallbackBuffer_Fallback_m3780167086,
	DecoderExceptionFallbackBuffer_GetNextChar_m2067268124,
	DecoderFallback__ctor_m1420784892,
	DecoderFallback__cctor_m3250479635,
	DecoderFallback_get_ExceptionFallback_m198794485,
	DecoderFallback_get_ReplacementFallback_m3654210110,
	DecoderFallback_get_StandardSafeFallback_m2130338133,
	DecoderFallbackBuffer__ctor_m2724858323,
	DecoderFallbackBuffer_Reset_m3069554060,
	DecoderFallbackException__ctor_m1480564942,
	DecoderFallbackException__ctor_m2423399765,
	DecoderFallbackException__ctor_m2882024994,
	DecoderReplacementFallback__ctor_m449982280,
	DecoderReplacementFallback__ctor_m2470322217,
	DecoderReplacementFallback_get_DefaultString_m3355062503,
	DecoderReplacementFallback_CreateFallbackBuffer_m2031816144,
	DecoderReplacementFallback_Equals_m3183889441,
	DecoderReplacementFallback_GetHashCode_m1611165826,
	DecoderReplacementFallbackBuffer__ctor_m1669699347,
	DecoderReplacementFallbackBuffer_get_Remaining_m1493654090,
	DecoderReplacementFallbackBuffer_Fallback_m1261056214,
	DecoderReplacementFallbackBuffer_GetNextChar_m2858228391,
	DecoderReplacementFallbackBuffer_Reset_m3943028589,
	EncoderExceptionFallback__ctor_m3745979420,
	EncoderExceptionFallback_CreateFallbackBuffer_m188459848,
	EncoderExceptionFallback_Equals_m2760188920,
	EncoderExceptionFallback_GetHashCode_m3988634959,
	EncoderExceptionFallbackBuffer__ctor_m2042603395,
	EncoderExceptionFallbackBuffer_get_Remaining_m1573636148,
	EncoderExceptionFallbackBuffer_Fallback_m1464194819,
	EncoderExceptionFallbackBuffer_Fallback_m2954286723,
	EncoderExceptionFallbackBuffer_GetNextChar_m471453226,
	EncoderFallback__ctor_m3732686580,
	EncoderFallback__cctor_m3806755293,
	EncoderFallback_get_ExceptionFallback_m3342076075,
	EncoderFallback_get_ReplacementFallback_m818398284,
	EncoderFallback_get_StandardSafeFallback_m2825654225,
	EncoderFallbackBuffer__ctor_m4249106511,
	EncoderFallbackException__ctor_m4193543656,
	EncoderFallbackException__ctor_m1920003269,
	EncoderFallbackException__ctor_m1051987327,
	EncoderFallbackException__ctor_m1643109704,
	EncoderReplacementFallback__ctor_m2980727890,
	EncoderReplacementFallback__ctor_m1483565116,
	EncoderReplacementFallback_get_DefaultString_m3956016810,
	EncoderReplacementFallback_CreateFallbackBuffer_m4038190929,
	EncoderReplacementFallback_Equals_m1070129250,
	EncoderReplacementFallback_GetHashCode_m3235834578,
	EncoderReplacementFallbackBuffer__ctor_m4044873320,
	EncoderReplacementFallbackBuffer_get_Remaining_m671378385,
	EncoderReplacementFallbackBuffer_Fallback_m2728476550,
	EncoderReplacementFallbackBuffer_Fallback_m19060368,
	EncoderReplacementFallbackBuffer_Fallback_m3618896307,
	EncoderReplacementFallbackBuffer_GetNextChar_m1303403587,
	Encoding__ctor_m2997749867,
	Encoding__ctor_m777655508,
	Encoding__cctor_m1936558127,
	Encoding___m3765636185,
	Encoding_get_IsReadOnly_m3084286821,
	Encoding_get_DecoderFallback_m1525880676,
	Encoding_set_DecoderFallback_m148532738,
	Encoding_get_EncoderFallback_m4088593971,
	Encoding_SetFallbackInternal_m3883046321,
	Encoding_Equals_m1755424895,
	Encoding_GetByteCount_m1264711659,
	Encoding_GetByteCount_m1979300643,
	Encoding_GetBytes_m3823106599,
	Encoding_GetBytes_m3148649984,
	Encoding_GetBytes_m3735967069,
	Encoding_GetBytes_m992709859,
	Encoding_GetChars_m1678858748,
	Encoding_GetDecoder_m1656450963,
	Encoding_InvokeI18N_m3098421862,
	Encoding_GetEncoding_m2801244948,
	Encoding_Clone_m841706634,
	Encoding_GetEncoding_m2599798446,
	Encoding_GetHashCode_m2631196485,
	Encoding_GetPreamble_m388603245,
	Encoding_GetString_m144725032,
	Encoding_GetString_m4017112554,
	Encoding_get_ASCII_m3595602635,
	Encoding_get_BigEndianUnicode_m684646764,
	Encoding_InternalCodePage_m4154357846,
	Encoding_get_Default_m1632902165,
	Encoding_get_ISOLatin1_m2107621369,
	Encoding_get_UTF7_m1817790803,
	Encoding_get_UTF8_m1008486739,
	Encoding_get_UTF8Unmarked_m3350637783,
	Encoding_get_UTF8UnmarkedUnsafe_m320312322,
	Encoding_get_Unicode_m811213576,
	Encoding_get_UTF32_m1591929079,
	Encoding_get_BigEndianUTF32_m2820363135,
	Encoding_GetByteCount_m1966030650,
	Encoding_GetBytes_m2313240322,
	ForwardingDecoder__ctor_m335665988,
	ForwardingDecoder_GetChars_m4228908854,
	Latin1Encoding__ctor_m498920120,
	Latin1Encoding_GetByteCount_m4202252024,
	Latin1Encoding_GetByteCount_m1145650505,
	Latin1Encoding_GetBytes_m4216440037,
	Latin1Encoding_GetBytes_m3765139542,
	Latin1Encoding_GetBytes_m1655294126,
	Latin1Encoding_GetBytes_m3327999871,
	Latin1Encoding_GetCharCount_m3241384207,
	Latin1Encoding_GetChars_m1437558423,
	Latin1Encoding_GetMaxByteCount_m1284135491,
	Latin1Encoding_GetMaxCharCount_m1720752733,
	Latin1Encoding_GetString_m838471821,
	Latin1Encoding_GetString_m254210343,
	StringBuilder__ctor_m3797152686,
	StringBuilder__ctor_m3504405255,
	StringBuilder__ctor_m3121283359,
	StringBuilder__ctor_m2367297767,
	StringBuilder__ctor_m2989139009,
	StringBuilder__ctor_m2502310956,
	StringBuilder__ctor_m2625406916,
	StringBuilder_System_Runtime_Serialization_ISerializable_GetObjectData_m4227593635,
	StringBuilder_get_Capacity_m2088663745,
	StringBuilder_set_Capacity_m3366027632,
	StringBuilder_get_Length_m3238060835,
	StringBuilder_set_Length_m1410065908,
	StringBuilder_get_Chars_m1819843468,
	StringBuilder_set_Chars_m3548656617,
	StringBuilder_ToString_m3317489284,
	StringBuilder_ToString_m774364392,
	StringBuilder_Remove_m940064945,
	StringBuilder_Replace_m1968561789,
	StringBuilder_Replace_m1682610486,
	StringBuilder_Append_m1965104174,
	StringBuilder_Append_m890240332,
	StringBuilder_Append_m3611229522,
	StringBuilder_Append_m1640838743,
	StringBuilder_Append_m2383614642,
	StringBuilder_Append_m2180175564,
	StringBuilder_Append_m4089665817,
	StringBuilder_Append_m3214161208,
	StringBuilder_AppendFormat_m921870684,
	StringBuilder_AppendFormat_m4227532852,
	StringBuilder_AppendFormat_m3016532472,
	StringBuilder_AppendFormat_m3255666490,
	StringBuilder_AppendFormat_m2403596038,
	StringBuilder_Insert_m3039182437,
	StringBuilder_Insert_m1076119876,
	StringBuilder_Insert_m1991415059,
	StringBuilder_InternalEnsureCapacity_m1976244425,
	UTF32Encoding__ctor_m1635603592,
	UTF32Encoding__ctor_m2278531302,
	UTF32Encoding__ctor_m3417652600,
	UTF32Encoding_GetByteCount_m3787179419,
	UTF32Encoding_GetBytes_m3180303867,
	UTF32Encoding_GetCharCount_m3062341871,
	UTF32Encoding_GetChars_m208559531,
	UTF32Encoding_GetMaxByteCount_m2445516862,
	UTF32Encoding_GetMaxCharCount_m2375204529,
	UTF32Encoding_GetDecoder_m3364062151,
	UTF32Encoding_GetPreamble_m2844389005,
	UTF32Encoding_Equals_m2278544394,
	UTF32Encoding_GetHashCode_m2910638225,
	UTF32Encoding_GetByteCount_m3610769032,
	UTF32Encoding_GetByteCount_m3318495092,
	UTF32Encoding_GetBytes_m2832872594,
	UTF32Encoding_GetBytes_m4022298172,
	UTF32Encoding_GetString_m3737249548,
	UTF32Decoder__ctor_m1109508508,
	UTF32Decoder_GetChars_m1925558948,
	UTF7Encoding__ctor_m1257259578,
	UTF7Encoding__ctor_m3592291633,
	UTF7Encoding__cctor_m1116871411,
	UTF7Encoding_GetHashCode_m587267901,
	UTF7Encoding_Equals_m227704363,
	UTF7Encoding_InternalGetByteCount_m711304883,
	UTF7Encoding_GetByteCount_m3616172568,
	UTF7Encoding_InternalGetBytes_m797138468,
	UTF7Encoding_GetBytes_m3609725875,
	UTF7Encoding_InternalGetCharCount_m1454619382,
	UTF7Encoding_GetCharCount_m2792854727,
	UTF7Encoding_InternalGetChars_m2722395139,
	UTF7Encoding_GetChars_m732948009,
	UTF7Encoding_GetMaxByteCount_m1806591568,
	UTF7Encoding_GetMaxCharCount_m3050332930,
	UTF7Encoding_GetDecoder_m3129254348,
	UTF7Encoding_GetByteCount_m209415911,
	UTF7Encoding_GetByteCount_m1175520321,
	UTF7Encoding_GetBytes_m521917477,
	UTF7Encoding_GetBytes_m4073063585,
	UTF7Encoding_GetString_m560035518,
	UTF7Decoder__ctor_m546843796,
	UTF7Decoder_GetChars_m3413809261,
	UTF8Encoding__ctor_m1224805231,
	UTF8Encoding__ctor_m661806809,
	UTF8Encoding__ctor_m1391509536,
	UTF8Encoding_InternalGetByteCount_m771565606,
	UTF8Encoding_InternalGetByteCount_m2120178851,
	UTF8Encoding_GetByteCount_m4152118078,
	UTF8Encoding_GetByteCount_m4153686982,
	UTF8Encoding_InternalGetBytes_m1965760031,
	UTF8Encoding_InternalGetBytes_m359000633,
	UTF8Encoding_GetBytes_m3927828659,
	UTF8Encoding_GetBytes_m1676006378,
	UTF8Encoding_GetBytes_m3254542575,
	UTF8Encoding_InternalGetCharCount_m82458470,
	UTF8Encoding_InternalGetCharCount_m3717563502,
	UTF8Encoding_Fallback_m1398662657,
	UTF8Encoding_Fallback_m3793102142,
	UTF8Encoding_GetCharCount_m2272165989,
	UTF8Encoding_InternalGetChars_m1502871718,
	UTF8Encoding_InternalGetChars_m1682357736,
	UTF8Encoding_GetChars_m1433288684,
	UTF8Encoding_GetMaxByteCount_m420651053,
	UTF8Encoding_GetMaxCharCount_m3762459613,
	UTF8Encoding_GetDecoder_m2951334655,
	UTF8Encoding_GetPreamble_m1911470058,
	UTF8Encoding_Equals_m3216333608,
	UTF8Encoding_GetHashCode_m641510078,
	UTF8Encoding_GetByteCount_m3800586529,
	UTF8Encoding_GetString_m3999408409,
	UTF8Decoder__ctor_m3811899787,
	UTF8Decoder_GetChars_m1236346907,
	UnicodeEncoding__ctor_m1074918879,
	UnicodeEncoding__ctor_m3604373700,
	UnicodeEncoding__ctor_m936764770,
	UnicodeEncoding_GetByteCount_m2118773625,
	UnicodeEncoding_GetByteCount_m3262451645,
	UnicodeEncoding_GetByteCount_m3498858619,
	UnicodeEncoding_GetBytes_m3426267301,
	UnicodeEncoding_GetBytes_m1366350399,
	UnicodeEncoding_GetBytes_m3223155660,
	UnicodeEncoding_GetBytesInternal_m1902824297,
	UnicodeEncoding_GetCharCount_m845015490,
	UnicodeEncoding_GetChars_m3561826263,
	UnicodeEncoding_GetString_m332467280,
	UnicodeEncoding_GetCharsInternal_m98244547,
	UnicodeEncoding_GetMaxByteCount_m3053620432,
	UnicodeEncoding_GetMaxCharCount_m1592623696,
	UnicodeEncoding_GetDecoder_m1504791895,
	UnicodeEncoding_GetPreamble_m3002287178,
	UnicodeEncoding_Equals_m701742893,
	UnicodeEncoding_GetHashCode_m354003420,
	UnicodeEncoding_CopyChars_m785272451,
	UnicodeDecoder__ctor_m3606046165,
	UnicodeDecoder_GetChars_m3463258340,
	ThreadStaticAttribute__ctor_m1099840517,
	CompressedStack__ctor_m2442654875,
	CompressedStack__ctor_m315468647,
	CompressedStack_CreateCopy_m2591279216,
	CompressedStack_Capture_m3327262890,
	CompressedStack_GetObjectData_m2451703776,
	CompressedStack_IsEmpty_m1305135551,
	EventWaitHandle__ctor_m3773182490,
	EventWaitHandle_IsManualReset_m3553816275,
	EventWaitHandle_Reset_m3348053200,
	EventWaitHandle_Set_m2445193251,
	ExecutionContext__ctor_m3874209501,
	ExecutionContext__ctor_m957177596,
	ExecutionContext__ctor_m418421535,
	ExecutionContext_Capture_m681135907,
	ExecutionContext_GetObjectData_m3398518585,
	ExecutionContext_get_SecurityContext_m1232420339,
	ExecutionContext_set_SecurityContext_m3443205304,
	ExecutionContext_get_FlowSuppressed_m3684775418,
	ExecutionContext_IsFlowSuppressed_m1061993478,
	Interlocked_CompareExchange_m3023855514,
	Interlocked_Increment_m3548166048,
	ManualResetEvent__ctor_m4010886457,
	Monitor_Enter_m2249409497,
	Monitor_Exit_m3585316909,
	Monitor_Monitor_pulse_m2491828136,
	Monitor_Monitor_test_synchronised_m517272294,
	Monitor_Pulse_m82725344,
	Monitor_Monitor_wait_m3706677354,
	Monitor_Wait_m1121125180,
	Mutex__ctor_m2825059899,
	Mutex_CreateMutex_internal_m3763633491,
	Mutex_ReleaseMutex_internal_m1411299633,
	Mutex_ReleaseMutex_m3169074890,
	NativeEventCalls_CreateEvent_internal_m3212149556,
	NativeEventCalls_SetEvent_internal_m4068607488,
	NativeEventCalls_ResetEvent_internal_m885886540,
	NativeEventCalls_CloseEvent_internal_m2546122398,
	RegisteredWaitHandle__ctor_m1645196847,
	RegisteredWaitHandle_Wait_m1429620915,
	RegisteredWaitHandle_DoCallBack_m365365633,
	SendOrPostCallback__ctor_m1566534627,
	SendOrPostCallback_Invoke_m937799800,
	SendOrPostCallback_BeginInvoke_m1648400288,
	SendOrPostCallback_EndInvoke_m2485163446,
	SynchronizationContext__ctor_m2514243817,
	SynchronizationContext_get_Current_m3666546046,
	SynchronizationContext_SetSynchronizationContext_m1249070039,
	SynchronizationLockException__ctor_m4154160957,
	SynchronizationLockException__ctor_m3407855920,
	SynchronizationLockException__ctor_m2582325363,
	Thread__ctor_m777188137,
	Thread__cctor_m817723615,
	Thread_get_CurrentContext_m1695017876,
	Thread_CurrentThread_internal_m3271843036,
	Thread_get_CurrentThread_m4142136012,
	Thread_FreeLocalSlotValues_m1195763560,
	Thread_GetDomain_m1615404259,
	Thread_GetDomainID_m3416930910,
	Thread_Thread_internal_m4184414727,
	Thread_Thread_init_m3583989169,
	Thread_GetCachedCurrentCulture_m3435630977,
	Thread_GetSerializedCurrentCulture_m30188251,
	Thread_SetCachedCurrentCulture_m2609530899,
	Thread_GetCachedCurrentUICulture_m3553957669,
	Thread_GetSerializedCurrentUICulture_m3681656498,
	Thread_SetCachedCurrentUICulture_m1729523031,
	Thread_get_CurrentCulture_m349116646,
	Thread_get_CurrentUICulture_m1397429997,
	Thread_set_IsBackground_m3868016371,
	Thread_SetName_internal_m3162565917,
	Thread_set_Name_m3537838048,
	Thread_Start_m2860771284,
	Thread_Thread_free_internal_m333849022,
	Thread_Finalize_m3446740003,
	Thread_SetState_m3429987131,
	Thread_ClrState_m3379113724,
	Thread_GetNewManagedId_m2361425608,
	Thread_GetNewManagedId_internal_m397574299,
	Thread_get_ExecutionContext_m1861734668,
	Thread_get_ManagedThreadId_m1068113671,
	Thread_GetHashCode_m3479107071,
	Thread_GetCompressedStack_m2923422412,
	ThreadAbortException__ctor_m4260562921,
	ThreadAbortException__ctor_m1955533141,
	ThreadInterruptedException__ctor_m144467266,
	ThreadInterruptedException__ctor_m4104953416,
	ThreadPool_QueueUserWorkItem_m1526970260,
	ThreadPool_RegisterWaitForSingleObject_m3828286853,
	ThreadPool_RegisterWaitForSingleObject_m3011264028,
	ThreadStart__ctor_m3250019360,
	ThreadStart_Invoke_m1483406622,
	ThreadStart_BeginInvoke_m614889321,
	ThreadStart_EndInvoke_m3768045394,
	ThreadStateException__ctor_m3372575002,
	ThreadStateException__ctor_m2721596288,
	Timer__ctor_m3795312967,
	Timer__cctor_m3385262259,
	Timer_Init_m891735195,
	Timer_Change_m3724315326,
	Timer_Dispose_m671628881,
	Timer_Change_m3939852749,
	Scheduler__ctor_m3313141270,
	Scheduler__cctor_m4042462055,
	Scheduler_get_Instance_m2990168607,
	Scheduler_Remove_m3288162609,
	Scheduler_Change_m1742004650,
	Scheduler_Add_m21574731,
	Scheduler_InternalRemove_m3297531302,
	Scheduler_SchedulerThread_m10185948,
	Scheduler_ShrinkIfNeeded_m820085397,
	TimerComparer__ctor_m1513620849,
	TimerComparer_Compare_m4202371654,
	TimerCallback__ctor_m3981479132,
	TimerCallback_Invoke_m1938221087,
	TimerCallback_BeginInvoke_m2250763656,
	TimerCallback_EndInvoke_m2599485055,
	WaitCallback__ctor_m1893321019,
	WaitCallback_Invoke_m1820972147,
	WaitCallback_BeginInvoke_m3012509827,
	WaitCallback_EndInvoke_m3047974377,
	WaitHandle__ctor_m1707080176,
	WaitHandle__cctor_m4242752477,
	WaitHandle_System_IDisposable_Dispose_m1791996204,
	WaitHandle_CheckArray_m4078006015,
	WaitHandle_WaitAny_internal_m1870329233,
	WaitHandle_WaitAny_m1809371212,
	WaitHandle_get_Handle_m3260446580,
	WaitHandle_set_Handle_m2472203672,
	WaitHandle_WaitOne_internal_m3849881646,
	WaitHandle_Dispose_m738127030,
	WaitHandle_WaitOne_m2659830932,
	WaitHandle_WaitOne_m2577152516,
	WaitHandle_CheckDisposed_m303961449,
	WaitHandle_Finalize_m2167095134,
	WaitOrTimerCallback__ctor_m2652598011,
	WaitOrTimerCallback_Invoke_m3960825914,
	WaitOrTimerCallback_BeginInvoke_m2905803559,
	WaitOrTimerCallback_EndInvoke_m1418086160,
	TimeSpan__ctor_m1896986612_AdjustorThunk,
	TimeSpan__ctor_m3689759052_AdjustorThunk,
	TimeSpan__ctor_m2047388489_AdjustorThunk,
	TimeSpan__cctor_m3988022323,
	TimeSpan_CalculateTicks_m1336746319,
	TimeSpan_get_Days_m2243259430_AdjustorThunk,
	TimeSpan_get_Hours_m550761902_AdjustorThunk,
	TimeSpan_get_Milliseconds_m3438015508_AdjustorThunk,
	TimeSpan_get_Minutes_m4278980001_AdjustorThunk,
	TimeSpan_get_Seconds_m1883479191_AdjustorThunk,
	TimeSpan_get_Ticks_m2137362016_AdjustorThunk,
	TimeSpan_get_TotalDays_m2049019055_AdjustorThunk,
	TimeSpan_get_TotalHours_m306507525_AdjustorThunk,
	TimeSpan_get_TotalMilliseconds_m2429771311_AdjustorThunk,
	TimeSpan_get_TotalMinutes_m3920401708_AdjustorThunk,
	TimeSpan_get_TotalSeconds_m4083325051_AdjustorThunk,
	TimeSpan_Add_m2350321904_AdjustorThunk,
	TimeSpan_Compare_m753151303,
	TimeSpan_CompareTo_m2181997813_AdjustorThunk,
	TimeSpan_CompareTo_m3633415627_AdjustorThunk,
	TimeSpan_Equals_m3956248018_AdjustorThunk,
	TimeSpan_Duration_m2963553230_AdjustorThunk,
	TimeSpan_Equals_m45505612_AdjustorThunk,
	TimeSpan_FromDays_m3788741098,
	TimeSpan_FromHours_m1109641064,
	TimeSpan_FromMinutes_m1032812593,
	TimeSpan_FromSeconds_m4219356874,
	TimeSpan_FromMilliseconds_m579366253,
	TimeSpan_From_m1575288640,
	TimeSpan_GetHashCode_m1939414618_AdjustorThunk,
	TimeSpan_Negate_m1889505500_AdjustorThunk,
	TimeSpan_Subtract_m1264203589_AdjustorThunk,
	TimeSpan_ToString_m1128692466_AdjustorThunk,
	TimeSpan_op_Addition_m672714982,
	TimeSpan_op_Equality_m1999885032,
	TimeSpan_op_GreaterThan_m734703194,
	TimeSpan_op_GreaterThanOrEqual_m3604983771,
	TimeSpan_op_Inequality_m2467851530,
	TimeSpan_op_LessThan_m1594498345,
	TimeSpan_op_LessThanOrEqual_m300470010,
	TimeSpan_op_Subtraction_m3592306516,
	TimeZone__ctor_m1831364098,
	TimeZone__cctor_m798292265,
	TimeZone_get_CurrentTimeZone_m2520313554,
	TimeZone_IsDaylightSavingTime_m2508743323,
	TimeZone_IsDaylightSavingTime_m3100698649,
	TimeZone_ToLocalTime_m3563701919,
	TimeZone_ToUniversalTime_m2789507578,
	TimeZone_GetLocalTimeDiff_m4276408377,
	TimeZone_GetLocalTimeDiff_m1937927810,
	Type__ctor_m3795799013,
	Type__cctor_m2371893800,
	Type_FilterName_impl_m2651733559,
	Type_FilterNameIgnoreCase_impl_m626688405,
	Type_FilterAttribute_impl_m2354619618,
	Type_get_Attributes_m58528356,
	Type_get_DeclaringType_m1898067526,
	Type_get_HasElementType_m710151977,
	Type_get_IsAbstract_m1120089130,
	Type_get_IsArray_m2591212821,
	Type_get_IsByRef_m1262524108,
	Type_get_IsClass_m589177581,
	Type_get_IsContextful_m1494289047,
	Type_get_IsEnum_m208091508,
	Type_get_IsExplicitLayout_m1182254884,
	Type_get_IsInterface_m3284996719,
	Type_get_IsMarshalByRef_m1681525688,
	Type_get_IsPointer_m4067542339,
	Type_get_IsPrimitive_m1114712797,
	Type_get_IsSealed_m3543837727,
	Type_get_IsSerializable_m1040556850,
	Type_get_IsValueType_m3108065642,
	Type_get_MemberType_m1631050582,
	Type_get_ReflectedType_m825170767,
	Type_get_TypeHandle_m160082026,
	Type_Equals_m1673304139,
	Type_Equals_m709225487,
	Type_EqualsInternal_m3027143100,
	Type_internal_from_handle_m3156085815,
	Type_internal_from_name_m1721940673,
	Type_GetType_m1693760368,
	Type_GetType_m3605423543,
	Type_GetTypeCodeInternal_m1968182887,
	Type_GetTypeCode_m480753082,
	Type_GetTypeFromHandle_m1620074514,
	Type_GetTypeHandle_m1526957577,
	Type_type_is_subtype_of_m1406623598,
	Type_type_is_assignable_from_m76737532,
	Type_GetType_m1766533001,
	Type_IsSubclassOf_m527829736,
	Type_IsAssignableFrom_m3195021585,
	Type_IsInstanceOfType_m2427069822,
	Type_GetArrayRank_m276452511,
	Type_GetField_m2961003358,
	Type_GetHashCode_m1947148725,
	Type_GetMethod_m2019726356,
	Type_GetMethod_m1197120913,
	Type_GetMethod_m1479779718,
	Type_GetMethod_m637078096,
	Type_GetMethod_m1512604930,
	Type_GetMethodImplInternal_m2670548906,
	Type_GetProperty_m3414567179,
	Type_GetProperty_m4206634422,
	Type_GetProperty_m2732503739,
	Type_GetProperty_m2258969843,
	Type_GetProperty_m3294104835,
	Type_GetPropertyImplInternal_m2444270063,
	Type_IsArrayImpl_m2757480859,
	Type_IsValueTypeImpl_m3263052508,
	Type_IsContextfulImpl_m3693603908,
	Type_IsMarshalByRefImpl_m914778231,
	Type_GetConstructor_m2219014380,
	Type_GetConstructor_m950313272,
	Type_GetConstructor_m1195697116,
	Type_ToString_m3975981286,
	Type_get_IsSystemType_m624798880,
	Type_GetGenericArguments_m3500465462,
	Type_get_ContainsGenericParameters_m3456799426,
	Type_get_IsGenericTypeDefinition_m1202066969,
	Type_GetGenericTypeDefinition_impl_m1429894432,
	Type_GetGenericTypeDefinition_m639345035,
	Type_get_IsGenericType_m3396650057,
	Type_MakeGenericType_m1462451309,
	Type_MakeGenericType_m2479309691,
	Type_get_IsGenericParameter_m2240142090,
	Type_get_IsNested_m3546087448,
	Type_GetPseudoCustomAttributes_m1069564574,
	Type_get_IsUserType_m555861786,
	TypeInitializationException__ctor_m3546444694,
	TypeInitializationException_GetObjectData_m583196803,
	TypeLoadException__ctor_m1802671078,
	TypeLoadException__ctor_m2362330792,
	TypeLoadException__ctor_m1154572625,
	TypeLoadException__ctor_m3040414142,
	TypeLoadException_get_Message_m2440738252,
	TypeLoadException_GetObjectData_m2127700107,
	TypedReference_Equals_m2034077850_AdjustorThunk,
	TypedReference_GetHashCode_m2046447331_AdjustorThunk,
	UInt16_System_IConvertible_ToBoolean_m3911119012_AdjustorThunk,
	UInt16_System_IConvertible_ToByte_m3185614807_AdjustorThunk,
	UInt16_System_IConvertible_ToChar_m2096055221_AdjustorThunk,
	UInt16_System_IConvertible_ToDateTime_m2594768090_AdjustorThunk,
	UInt16_System_IConvertible_ToDecimal_m1320731319_AdjustorThunk,
	UInt16_System_IConvertible_ToDouble_m333121300_AdjustorThunk,
	UInt16_System_IConvertible_ToInt16_m2337134904_AdjustorThunk,
	UInt16_System_IConvertible_ToInt32_m1950778303_AdjustorThunk,
	UInt16_System_IConvertible_ToInt64_m3635199533_AdjustorThunk,
	UInt16_System_IConvertible_ToSByte_m2219828332_AdjustorThunk,
	UInt16_System_IConvertible_ToSingle_m2654722405_AdjustorThunk,
	UInt16_System_IConvertible_ToType_m1028622578_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt16_m2455419819_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt32_m1074326139_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt64_m424720762_AdjustorThunk,
	UInt16_CompareTo_m2664746316_AdjustorThunk,
	UInt16_Equals_m642257745_AdjustorThunk,
	UInt16_GetHashCode_m329858256_AdjustorThunk,
	UInt16_CompareTo_m243264328_AdjustorThunk,
	UInt16_Equals_m3755275785_AdjustorThunk,
	UInt16_Parse_m1613088384,
	UInt16_Parse_m3476925403,
	UInt16_TryParse_m4139137016,
	UInt16_TryParse_m3193697465,
	UInt16_ToString_m355311020_AdjustorThunk,
	UInt16_ToString_m3020002356_AdjustorThunk,
	UInt16_ToString_m3056878594_AdjustorThunk,
	UInt16_ToString_m760649087_AdjustorThunk,
	UInt32_System_IConvertible_ToBoolean_m1763673183_AdjustorThunk,
	UInt32_System_IConvertible_ToByte_m4072781199_AdjustorThunk,
	UInt32_System_IConvertible_ToChar_m1873050533_AdjustorThunk,
	UInt32_System_IConvertible_ToDateTime_m2767723441_AdjustorThunk,
	UInt32_System_IConvertible_ToDecimal_m675004071_AdjustorThunk,
	UInt32_System_IConvertible_ToDouble_m940039456_AdjustorThunk,
	UInt32_System_IConvertible_ToInt16_m1659441601_AdjustorThunk,
	UInt32_System_IConvertible_ToInt32_m220754611_AdjustorThunk,
	UInt32_System_IConvertible_ToInt64_m2261037378_AdjustorThunk,
	UInt32_System_IConvertible_ToSByte_m1061556466_AdjustorThunk,
	UInt32_System_IConvertible_ToSingle_m1272823424_AdjustorThunk,
	UInt32_System_IConvertible_ToType_m922356584_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt16_m3125657960_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt32_m1744564280_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt64_m1094958903_AdjustorThunk,
	UInt32_CompareTo_m362578384_AdjustorThunk,
	UInt32_Equals_m351935437_AdjustorThunk,
	UInt32_GetHashCode_m3722548385_AdjustorThunk,
	UInt32_CompareTo_m2218823230_AdjustorThunk,
	UInt32_Equals_m4250336581_AdjustorThunk,
	UInt32_Parse_m197815874,
	UInt32_Parse_m2778221109,
	UInt32_Parse_m3755665066,
	UInt32_Parse_m1373460382,
	UInt32_TryParse_m2819179361,
	UInt32_TryParse_m535404612,
	UInt32_ToString_m2574561716_AdjustorThunk,
	UInt32_ToString_m4293943134_AdjustorThunk,
	UInt32_ToString_m2066897296_AdjustorThunk,
	UInt32_ToString_m2420423038_AdjustorThunk,
	UInt64_System_IConvertible_ToBoolean_m3071416000_AdjustorThunk,
	UInt64_System_IConvertible_ToByte_m1501504925_AdjustorThunk,
	UInt64_System_IConvertible_ToChar_m2074245892_AdjustorThunk,
	UInt64_System_IConvertible_ToDateTime_m3434604642_AdjustorThunk,
	UInt64_System_IConvertible_ToDecimal_m806594027_AdjustorThunk,
	UInt64_System_IConvertible_ToDouble_m602078108_AdjustorThunk,
	UInt64_System_IConvertible_ToInt16_m3895479143_AdjustorThunk,
	UInt64_System_IConvertible_ToInt32_m949522652_AdjustorThunk,
	UInt64_System_IConvertible_ToInt64_m4241475606_AdjustorThunk,
	UInt64_System_IConvertible_ToSByte_m30962591_AdjustorThunk,
	UInt64_System_IConvertible_ToSingle_m925613075_AdjustorThunk,
	UInt64_System_IConvertible_ToType_m4049257834_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt16_m4165747038_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt32_m2784653358_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt64_m2135047981_AdjustorThunk,
	UInt64_CompareTo_m3619843473_AdjustorThunk,
	UInt64_Equals_m1879425698_AdjustorThunk,
	UInt64_GetHashCode_m4209760355_AdjustorThunk,
	UInt64_CompareTo_m1614517204_AdjustorThunk,
	UInt64_Equals_m367573732_AdjustorThunk,
	UInt64_Parse_m819899889,
	UInt64_Parse_m2329819578,
	UInt64_Parse_m1485858293,
	UInt64_TryParse_m2263420204,
	UInt64_ToString_m1529093114_AdjustorThunk,
	UInt64_ToString_m2623377370_AdjustorThunk,
	UInt64_ToString_m2177233542_AdjustorThunk,
	UInt64_ToString_m1695188334_AdjustorThunk,
	UIntPtr__ctor_m4250165422_AdjustorThunk,
	UIntPtr__cctor_m3513964473,
	UIntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m1767630151_AdjustorThunk,
	UIntPtr_Equals_m1316671746_AdjustorThunk,
	UIntPtr_GetHashCode_m3482152298_AdjustorThunk,
	UIntPtr_ToString_m984583492_AdjustorThunk,
	UnauthorizedAccessException__ctor_m246605039,
	UnauthorizedAccessException__ctor_m40101894,
	UnauthorizedAccessException__ctor_m1652256089,
	UnhandledExceptionEventArgs__ctor_m224348470,
	UnhandledExceptionEventArgs_get_ExceptionObject_m862578480,
	UnhandledExceptionEventArgs_get_IsTerminating_m4073714616,
	UnhandledExceptionEventHandler__ctor_m626016213,
	UnhandledExceptionEventHandler_Invoke_m1545705626,
	UnhandledExceptionEventHandler_BeginInvoke_m1761611550,
	UnhandledExceptionEventHandler_EndInvoke_m2316153791,
	UnitySerializationHolder__ctor_m3869442095,
	UnitySerializationHolder_GetTypeData_m2453779479,
	UnitySerializationHolder_GetDBNullData_m714211970,
	UnitySerializationHolder_GetModuleData_m1550266881,
	UnitySerializationHolder_GetObjectData_m3377455907,
	UnitySerializationHolder_GetRealObject_m1624354633,
	ValueType__ctor_m2036258423,
	ValueType_InternalEquals_m1384040357,
	ValueType_DefaultEquals_m2927252100,
	ValueType_Equals_m1524437845,
	ValueType_InternalGetHashCode_m58786863,
	ValueType_GetHashCode_m715362416,
	ValueType_ToString_m2292123621,
	Version__ctor_m872301635,
	Version__ctor_m1394137037,
	Version__ctor_m3537335798,
	Version__ctor_m1550720073,
	Version__ctor_m417728625,
	Version_CheckedSet_m654078179,
	Version_get_Build_m3667751407,
	Version_get_Major_m2457928275,
	Version_get_Minor_m150536655,
	Version_get_Revision_m3982234017,
	Version_Clone_m1749041863,
	Version_CompareTo_m1662919407,
	Version_Equals_m3073813696,
	Version_CompareTo_m3146217210,
	Version_Equals_m1564427710,
	Version_GetHashCode_m672974201,
	Version_ToString_m2279867705,
	Version_CreateFromString_m719054818,
	Version_op_Equality_m3804852517,
	Version_op_Inequality_m1696193441,
	WeakReference__ctor_m24376735,
	WeakReference__ctor_m2401547918,
	WeakReference__ctor_m1054065938,
	WeakReference__ctor_m1244067698,
	WeakReference_AllocateHandle_m1478975559,
	WeakReference_get_Target_m168713953,
	WeakReference_get_TrackResurrection_m942701017,
	WeakReference_Finalize_m2841826116,
	WeakReference_GetObjectData_m2192383095,
	__Il2CppComDelegate_Finalize_m2460829410,
	__Il2CppComObject_Finalize_m2923638372,
	Locale_GetText_m3875126938,
	Locale_GetText_m2640320736,
	HybridDictionary__ctor_m2970901694,
	HybridDictionary__ctor_m1681134385,
	HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m168538452,
	HybridDictionary_get_inner_m3689521430,
	HybridDictionary_get_Count_m1166314536,
	HybridDictionary_get_Item_m319681963,
	HybridDictionary_set_Item_m2997363718,
	HybridDictionary_get_SyncRoot_m1538457321,
	HybridDictionary_Add_m912320053,
	HybridDictionary_CopyTo_m3592404936,
	HybridDictionary_GetEnumerator_m1379032493,
	HybridDictionary_Remove_m2295600623,
	HybridDictionary_Switch_m3818192922,
	ListDictionary__ctor_m2955211750,
	ListDictionary__ctor_m438204031,
	ListDictionary_System_Collections_IEnumerable_GetEnumerator_m884729149,
	ListDictionary_FindEntry_m4121604518,
	ListDictionary_FindEntry_m2629402370,
	ListDictionary_AddImpl_m3184792770,
	ListDictionary_get_Count_m414236492,
	ListDictionary_get_SyncRoot_m4242825143,
	ListDictionary_CopyTo_m1633862866,
	ListDictionary_get_Item_m1272472363,
	ListDictionary_set_Item_m1659493973,
	ListDictionary_Add_m3918308031,
	ListDictionary_Clear_m125005380,
	ListDictionary_GetEnumerator_m3395631195,
	ListDictionary_Remove_m2440983361,
	DictionaryNode__ctor_m1380016344,
	DictionaryNodeEnumerator__ctor_m1005316675,
	DictionaryNodeEnumerator_FailFast_m2494733641,
	DictionaryNodeEnumerator_MoveNext_m736126844,
	DictionaryNodeEnumerator_Reset_m2226320064,
	DictionaryNodeEnumerator_get_Current_m4231688597,
	DictionaryNodeEnumerator_get_DictionaryNode_m2794172961,
	DictionaryNodeEnumerator_get_Entry_m2309234501,
	DictionaryNodeEnumerator_get_Key_m2267812973,
	DictionaryNodeEnumerator_get_Value_m1345533116,
	NameObjectCollectionBase__ctor_m2090733912,
	NameObjectCollectionBase__ctor_m1512146076,
	NameObjectCollectionBase_System_Collections_ICollection_get_SyncRoot_m138749698,
	NameObjectCollectionBase_System_Collections_ICollection_CopyTo_m1225689553,
	NameObjectCollectionBase_Init_m2525481323,
	NameObjectCollectionBase_get_Keys_m2856825671,
	NameObjectCollectionBase_GetEnumerator_m3677320185,
	NameObjectCollectionBase_GetObjectData_m199708727,
	NameObjectCollectionBase_get_Count_m823453971,
	NameObjectCollectionBase_OnDeserialization_m619757901,
	NameObjectCollectionBase_get_IsReadOnly_m1249375452,
	NameObjectCollectionBase_BaseAdd_m3437748750,
	NameObjectCollectionBase_BaseGet_m2807961990,
	NameObjectCollectionBase_BaseGet_m2890420524,
	NameObjectCollectionBase_BaseGetKey_m2677971642,
	NameObjectCollectionBase_FindFirstMatchedItem_m840305173,
	KeysCollection__ctor_m3575458428,
	KeysCollection_System_Collections_ICollection_CopyTo_m1205348167,
	KeysCollection_System_Collections_ICollection_get_SyncRoot_m2638728559,
	KeysCollection_get_Count_m3943311735,
	KeysCollection_GetEnumerator_m2005471619,
	_Item__ctor_m4016463660,
	_KeysEnumerator__ctor_m1664513423,
	_KeysEnumerator_get_Current_m2996478063,
	_KeysEnumerator_MoveNext_m4289758929,
	_KeysEnumerator_Reset_m2283582422,
	NameValueCollection__ctor_m1115358332,
	NameValueCollection__ctor_m4090053322,
	NameValueCollection_Add_m2418530856,
	NameValueCollection_Get_m2464480741,
	NameValueCollection_AsSingleString_m3776180906,
	NameValueCollection_GetKey_m3458770877,
	NameValueCollection_InvalidateCachedArrays_m194313763,
	EditorBrowsableAttribute__ctor_m4133080490,
	EditorBrowsableAttribute_get_State_m21497981,
	EditorBrowsableAttribute_Equals_m3041896197,
	EditorBrowsableAttribute_GetHashCode_m123071459,
	TypeConverterAttribute__ctor_m1774069684,
	TypeConverterAttribute__ctor_m2714055761,
	TypeConverterAttribute__cctor_m2413733117,
	TypeConverterAttribute_Equals_m1580461255,
	TypeConverterAttribute_GetHashCode_m948291090,
	TypeConverterAttribute_get_ConverterTypeName_m2038465322,
	DefaultUriParser__ctor_m2377995797,
	DefaultUriParser__ctor_m2634681684,
	MonoTODOAttribute__ctor_m2269130449,
	MonoTODOAttribute__ctor_m1298576268,
	DefaultCertificatePolicy__ctor_m1887337884,
	DefaultCertificatePolicy_CheckValidationResult_m3811448269,
	FileWebRequest__ctor_m3189951510,
	FileWebRequest__ctor_m41755936,
	FileWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1504466482,
	FileWebRequest_GetObjectData_m577359674,
	FileWebRequestCreator__ctor_m2638763787,
	FileWebRequestCreator_Create_m987324668,
	FtpRequestCreator__ctor_m23058707,
	FtpRequestCreator_Create_m3326083364,
	FtpWebRequest__ctor_m751131654,
	FtpWebRequest__cctor_m699542155,
	FtpWebRequest_U3CcallbackU3Em__B_m3681041041,
	GlobalProxySelection_get_Select_m3427048860,
	HttpRequestCreator__ctor_m2389332355,
	HttpRequestCreator_Create_m400548686,
	HttpVersion__cctor_m1653189495,
	HttpWebRequest__ctor_m1376613083,
	HttpWebRequest__ctor_m1789065007,
	HttpWebRequest__cctor_m1467954389,
	HttpWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m900393946,
	HttpWebRequest_get_Address_m1609525404,
	HttpWebRequest_get_ServicePoint_m1080482337,
	HttpWebRequest_GetServicePoint_m2640244283,
	HttpWebRequest_GetObjectData_m1226445448,
	IPAddress__ctor_m921977496,
	IPAddress__ctor_m149476904,
	IPAddress__cctor_m3038355099,
	IPAddress_SwapShort_m703207735,
	IPAddress_HostToNetworkOrder_m1393269408,
	IPAddress_NetworkToHostOrder_m2704605532,
	IPAddress_Parse_m2200822423,
	IPAddress_TryParse_m2320149543,
	IPAddress_ParseIPV4_m2273992661,
	IPAddress_ParseIPV6_m750830007,
	IPAddress_get_InternalIPv4Address_m3963971538,
	IPAddress_get_ScopeId_m4237202723,
	IPAddress_get_AddressFamily_m1010663936,
	IPAddress_IsLoopback_m29387631,
	IPAddress_ToString_m1181734207,
	IPAddress_ToString_m3532415717,
	IPAddress_Equals_m1823478787,
	IPAddress_GetHashCode_m1210636859,
	IPAddress_Hash_m3747500957,
	IPv6Address__ctor_m4117281080,
	IPv6Address__ctor_m2700673633,
	IPv6Address__ctor_m3704187391,
	IPv6Address__cctor_m2454563501,
	IPv6Address_Parse_m3004687047,
	IPv6Address_Fill_m1519528280,
	IPv6Address_TryParse_m3387120421,
	IPv6Address_TryParse_m2586816298,
	IPv6Address_get_Address_m1389170741,
	IPv6Address_get_ScopeId_m2285850181,
	IPv6Address_set_ScopeId_m3907190992,
	IPv6Address_IsLoopback_m3712926451,
	IPv6Address_SwapUShort_m253384224,
	IPv6Address_AsIPv4Int_m844941024,
	IPv6Address_IsIPv4Compatible_m2636354880,
	IPv6Address_IsIPv4Mapped_m2527005544,
	IPv6Address_ToString_m568854716,
	IPv6Address_ToString_m3978087033,
	IPv6Address_Equals_m2165515875,
	IPv6Address_GetHashCode_m2362916428,
	IPv6Address_Hash_m2034463181,
	RemoteCertificateValidationCallback__ctor_m1251969663,
	RemoteCertificateValidationCallback_Invoke_m727898444,
	RemoteCertificateValidationCallback_BeginInvoke_m1840268146,
	RemoteCertificateValidationCallback_EndInvoke_m1360061860,
	ServicePoint__ctor_m4022457269,
	ServicePoint_get_Address_m4189969258,
	ServicePoint_get_CurrentConnections_m1937296360,
	ServicePoint_get_IdleSince_m2373179824,
	ServicePoint_set_IdleSince_m608781505,
	ServicePoint_set_Expect100Continue_m1237635858,
	ServicePoint_set_UseNagleAlgorithm_m1374731041,
	ServicePoint_set_SendContinue_m3004714502,
	ServicePoint_set_UsesProxy_m2758604003,
	ServicePoint_set_UseConnect_m1377758489,
	ServicePoint_get_AvailableForRecycling_m936700514,
	ServicePointManager__cctor_m3222177795,
	ServicePointManager_get_CertificatePolicy_m1966679142,
	ServicePointManager_get_CheckCertificateRevocationList_m1716454075,
	ServicePointManager_get_SecurityProtocol_m4259357356,
	ServicePointManager_get_ServerCertificateValidationCallback_m984921647,
	ServicePointManager_FindServicePoint_m4119451290,
	ServicePointManager_RecycleServicePoints_m1035558445,
	SPKey__ctor_m3690819622,
	SPKey_GetHashCode_m1832733826,
	SPKey_Equals_m4205549017,
	WebHeaderCollection__ctor_m896654210,
	WebHeaderCollection__ctor_m1308130075,
	WebHeaderCollection__ctor_m1926872774,
	WebHeaderCollection__cctor_m2093192431,
	WebHeaderCollection_System_Runtime_Serialization_ISerializable_GetObjectData_m2698261559,
	WebHeaderCollection_Add_m183143026,
	WebHeaderCollection_AddWithoutValidate_m3120519792,
	WebHeaderCollection_IsRestricted_m2639089215,
	WebHeaderCollection_OnDeserialization_m3998891408,
	WebHeaderCollection_ToString_m1263025316,
	WebHeaderCollection_GetObjectData_m730985326,
	WebHeaderCollection_get_Count_m3224978046,
	WebHeaderCollection_get_Keys_m910440889,
	WebHeaderCollection_Get_m3921484261,
	WebHeaderCollection_GetKey_m809097130,
	WebHeaderCollection_GetEnumerator_m2991425604,
	WebHeaderCollection_IsHeaderValue_m3837500493,
	WebHeaderCollection_IsHeaderName_m2906290131,
	WebProxy__ctor_m4061043939,
	WebProxy__ctor_m3758467778,
	WebProxy__ctor_m3723076346,
	WebProxy_System_Runtime_Serialization_ISerializable_GetObjectData_m430220241,
	WebProxy_get_UseDefaultCredentials_m1572240836,
	WebProxy_GetProxy_m3150838504,
	WebProxy_IsBypassed_m2918071028,
	WebProxy_GetObjectData_m2475888157,
	WebProxy_CheckBypassList_m3657340229,
	WebRequest__ctor_m3593280671,
	WebRequest__ctor_m2895531935,
	WebRequest__cctor_m3940074084,
	WebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m3856360037,
	WebRequest_AddDynamicPrefix_m4246631209,
	WebRequest_GetMustImplement_m1485657458,
	WebRequest_get_DefaultWebProxy_m4155870144,
	WebRequest_GetDefaultWebProxy_m696404479,
	WebRequest_GetObjectData_m1299992613,
	WebRequest_AddPrefix_m3187775913,
	AsnEncodedData__ctor_m3792312694,
	AsnEncodedData__ctor_m726356132,
	AsnEncodedData__ctor_m119764527,
	AsnEncodedData_get_Oid_m402887164,
	AsnEncodedData_set_Oid_m351300829,
	AsnEncodedData_get_RawData_m1706087592,
	AsnEncodedData_set_RawData_m1598714608,
	AsnEncodedData_CopyFrom_m3929882393,
	AsnEncodedData_ToString_m440213605,
	AsnEncodedData_Default_m4101664970,
	AsnEncodedData_BasicConstraintsExtension_m181086136,
	AsnEncodedData_EnhancedKeyUsageExtension_m56921642,
	AsnEncodedData_KeyUsageExtension_m1792651780,
	AsnEncodedData_SubjectKeyIdentifierExtension_m3216418117,
	AsnEncodedData_SubjectAltName_m4049949414,
	AsnEncodedData_NetscapeCertType_m2976595233,
	Oid__ctor_m738937194,
	Oid__ctor_m1869590876,
	Oid__ctor_m3344148807,
	Oid__ctor_m911618594,
	Oid_get_FriendlyName_m1299931775,
	Oid_get_Value_m743416803,
	Oid_GetName_m195392578,
	OidCollection__ctor_m4001685071,
	OidCollection_System_Collections_ICollection_CopyTo_m2400658497,
	OidCollection_System_Collections_IEnumerable_GetEnumerator_m685937025,
	OidCollection_get_Count_m3720881332,
	OidCollection_get_Item_m984725507,
	OidCollection_get_SyncRoot_m3531934854,
	OidCollection_Add_m2569544356,
	OidEnumerator__ctor_m257525176,
	OidEnumerator_System_Collections_IEnumerator_get_Current_m3426335186,
	OidEnumerator_MoveNext_m3138911739,
	OidEnumerator_Reset_m2503707245,
	PublicKey__ctor_m1834139044,
	PublicKey_get_EncodedKeyValue_m199315148,
	PublicKey_get_EncodedParameters_m4197029957,
	PublicKey_get_Key_m3077215602,
	PublicKey_get_Oid_m2056027242,
	PublicKey_GetUnsignedBigInteger_m3873409673,
	PublicKey_DecodeDSA_m3490622362,
	PublicKey_DecodeRSA_m1824703659,
	X500DistinguishedName__ctor_m3469219344,
	X500DistinguishedName_Decode_m3521921960,
	X500DistinguishedName_GetSeparator_m1336760642,
	X500DistinguishedName_DecodeRawData_m3790804100,
	X500DistinguishedName_Canonize_m2594679403,
	X500DistinguishedName_AreEqual_m2828302026,
	X509BasicConstraintsExtension__ctor_m3136793028,
	X509BasicConstraintsExtension__ctor_m1244152959,
	X509BasicConstraintsExtension__ctor_m3721156175,
	X509BasicConstraintsExtension_get_CertificateAuthority_m3360658367,
	X509BasicConstraintsExtension_get_HasPathLengthConstraint_m2072837820,
	X509BasicConstraintsExtension_get_PathLengthConstraint_m1198369084,
	X509BasicConstraintsExtension_CopyFrom_m1931463033,
	X509BasicConstraintsExtension_Decode_m120598446,
	X509BasicConstraintsExtension_Encode_m2310708419,
	X509BasicConstraintsExtension_ToString_m1809935297,
	X509Certificate2__ctor_m2370196240,
	X509Certificate2__cctor_m4292326511,
	X509Certificate2_get_Extensions_m3552930730,
	X509Certificate2_get_IssuerName_m1277209535,
	X509Certificate2_get_NotAfter_m1930122497,
	X509Certificate2_get_NotBefore_m2514418239,
	X509Certificate2_get_PrivateKey_m450647294,
	X509Certificate2_get_PublicKey_m370665820,
	X509Certificate2_get_SerialNumber_m1315874713,
	X509Certificate2_get_SignatureAlgorithm_m2810155907,
	X509Certificate2_get_SubjectName_m2588317215,
	X509Certificate2_get_Thumbprint_m392121246,
	X509Certificate2_get_Version_m2534012675,
	X509Certificate2_GetNameInfo_m869719036,
	X509Certificate2_Find_m2734168143,
	X509Certificate2_GetValueAsString_m1348462142,
	X509Certificate2_ImportPkcs12_m2042454190,
	X509Certificate2_Import_m4026562329,
	X509Certificate2_Reset_m3988214799,
	X509Certificate2_ToString_m3891217889,
	X509Certificate2_ToString_m4246350784,
	X509Certificate2_AppendBuffer_m445040858,
	X509Certificate2_Verify_m1464738766,
	X509Certificate2_get_MonoCertificate_m4228255308,
	X509Certificate2Collection__ctor_m1338914817,
	X509Certificate2Collection__ctor_m3025547695,
	X509Certificate2Collection_get_Item_m1658740919,
	X509Certificate2Collection_Add_m3151757943,
	X509Certificate2Collection_AddRange_m3206541680,
	X509Certificate2Collection_Contains_m3300508662,
	X509Certificate2Collection_Find_m4007010753,
	X509Certificate2Collection_GetEnumerator_m3634416032,
	X509Certificate2Enumerator__ctor_m1083666285,
	X509Certificate2Enumerator_System_Collections_IEnumerator_get_Current_m352453934,
	X509Certificate2Enumerator_System_Collections_IEnumerator_MoveNext_m1563787129,
	X509Certificate2Enumerator_System_Collections_IEnumerator_Reset_m388172138,
	X509Certificate2Enumerator_get_Current_m157909321,
	X509Certificate2Enumerator_MoveNext_m2220460870,
	X509Certificate2Enumerator_Reset_m1308823525,
	X509CertificateCollection__ctor_m147081211,
	X509CertificateCollection__ctor_m3178797723,
	X509CertificateCollection_get_Item_m1177942658,
	X509CertificateCollection_AddRange_m3683116910,
	X509CertificateCollection_GetEnumerator_m1686475779,
	X509CertificateCollection_GetHashCode_m1953348376,
	X509CertificateEnumerator__ctor_m943731472,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m4218613192,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m1392570645,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m1219650180,
	X509CertificateEnumerator_get_Current_m364341970,
	X509CertificateEnumerator_MoveNext_m1557350766,
	X509CertificateEnumerator_Reset_m4026698923,
	X509Chain__ctor_m2878811474,
	X509Chain__ctor_m2674663382,
	X509Chain__cctor_m993507223,
	X509Chain_get_ChainPolicy_m2586552721,
	X509Chain_Build_m1705729171,
	X509Chain_Reset_m1198177101,
	X509Chain_get_Roots_m317091712,
	X509Chain_get_CertificateAuthorities_m804805415,
	X509Chain_get_CertificateCollection_m511297491,
	X509Chain_BuildChainFrom_m2265372442,
	X509Chain_SelectBestFromCollection_m1068759221,
	X509Chain_FindParent_m1515820563,
	X509Chain_IsChainComplete_m1577524584,
	X509Chain_IsSelfIssued_m2588855382,
	X509Chain_ValidateChain_m1402813093,
	X509Chain_Process_m1119354891,
	X509Chain_PrepareForNextCertificate_m3691934993,
	X509Chain_WrapUp_m3160803936,
	X509Chain_ProcessCertificateExtensions_m1468796745,
	X509Chain_IsSignedWith_m2691255686,
	X509Chain_GetSubjectKeyIdentifier_m1349242905,
	X509Chain_GetAuthorityKeyIdentifier_m2237883181,
	X509Chain_GetAuthorityKeyIdentifier_m614536199,
	X509Chain_GetAuthorityKeyIdentifier_m4138418749,
	X509Chain_CheckRevocationOnChain_m1377635439,
	X509Chain_CheckRevocation_m4216573099,
	X509Chain_CheckRevocation_m3466271023,
	X509Chain_FindCrl_m1657810964,
	X509Chain_ProcessCrlExtensions_m236234529,
	X509Chain_ProcessCrlEntryExtensions_m3203112264,
	X509ChainElement__ctor_m252371420,
	X509ChainElement_get_Certificate_m2801643215,
	X509ChainElement_get_ChainElementStatus_m2982250012,
	X509ChainElement_get_StatusFlags_m3731832204,
	X509ChainElement_set_StatusFlags_m2467275568,
	X509ChainElement_Count_m383583639,
	X509ChainElement_Set_m655180762,
	X509ChainElement_UncompressFlags_m781553362,
	X509ChainElementCollection__ctor_m3424079155,
	X509ChainElementCollection_System_Collections_ICollection_CopyTo_m1179155153,
	X509ChainElementCollection_System_Collections_IEnumerable_GetEnumerator_m3829089536,
	X509ChainElementCollection_get_Count_m1678779750,
	X509ChainElementCollection_get_Item_m1978766852,
	X509ChainElementCollection_get_SyncRoot_m4174373457,
	X509ChainElementCollection_GetEnumerator_m2610805770,
	X509ChainElementCollection_Add_m737054930,
	X509ChainElementCollection_Clear_m2271223414,
	X509ChainElementCollection_Contains_m2924813355,
	X509ChainElementEnumerator__ctor_m1674160564,
	X509ChainElementEnumerator_System_Collections_IEnumerator_get_Current_m1913555061,
	X509ChainElementEnumerator_get_Current_m1301774989,
	X509ChainElementEnumerator_MoveNext_m3940594045,
	X509ChainElementEnumerator_Reset_m1416607221,
	X509ChainPolicy__ctor_m852124469,
	X509ChainPolicy_get_ExtraStore_m4191377387,
	X509ChainPolicy_get_RevocationFlag_m3767879093,
	X509ChainPolicy_get_RevocationMode_m3118822552,
	X509ChainPolicy_get_VerificationFlags_m58569326,
	X509ChainPolicy_get_VerificationTime_m4085504449,
	X509ChainPolicy_Reset_m1883700166,
	X509ChainStatus__ctor_m4178125999_AdjustorThunk,
	X509ChainStatus_get_Status_m2572005749_AdjustorThunk,
	X509ChainStatus_set_Status_m263715218_AdjustorThunk,
	X509ChainStatus_set_StatusInformation_m1638042991_AdjustorThunk,
	X509ChainStatus_GetInformation_m245493206,
	X509EnhancedKeyUsageExtension__ctor_m298908880,
	X509EnhancedKeyUsageExtension_CopyFrom_m3750050754,
	X509EnhancedKeyUsageExtension_Decode_m3726500073,
	X509EnhancedKeyUsageExtension_ToString_m350388564,
	X509Extension__ctor_m1624259472,
	X509Extension__ctor_m225879936,
	X509Extension_get_Critical_m1315280133,
	X509Extension_set_Critical_m1180944253,
	X509Extension_CopyFrom_m474590450,
	X509Extension_FormatUnkownData_m3636863676,
	X509ExtensionCollection__ctor_m1730716172,
	X509ExtensionCollection_System_Collections_ICollection_CopyTo_m2505796149,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m4033897067,
	X509ExtensionCollection_get_Count_m3589967016,
	X509ExtensionCollection_get_SyncRoot_m2667861032,
	X509ExtensionCollection_get_Item_m3637880514,
	X509ExtensionCollection_GetEnumerator_m3371013144,
	X509ExtensionEnumerator__ctor_m827820494,
	X509ExtensionEnumerator_System_Collections_IEnumerator_get_Current_m2494161059,
	X509ExtensionEnumerator_get_Current_m256207749,
	X509ExtensionEnumerator_MoveNext_m3077762850,
	X509ExtensionEnumerator_Reset_m2310001600,
	X509KeyUsageExtension__ctor_m1098820427,
	X509KeyUsageExtension__ctor_m1105912158,
	X509KeyUsageExtension__ctor_m524748856,
	X509KeyUsageExtension_get_KeyUsages_m3263859785,
	X509KeyUsageExtension_CopyFrom_m186479533,
	X509KeyUsageExtension_GetValidFlags_m3447294145,
	X509KeyUsageExtension_Decode_m3150759625,
	X509KeyUsageExtension_Encode_m2128077825,
	X509KeyUsageExtension_ToString_m3542316380,
	X509Store__ctor_m275383717,
	X509Store_get_Certificates_m2149701265,
	X509Store_get_Factory_m3282910266,
	X509Store_get_Store_m1426986552,
	X509Store_Close_m799536774,
	X509Store_Open_m909451489,
	X509SubjectKeyIdentifierExtension__ctor_m3160552652,
	X509SubjectKeyIdentifierExtension__ctor_m2055934916,
	X509SubjectKeyIdentifierExtension__ctor_m2644971776,
	X509SubjectKeyIdentifierExtension__ctor_m201177607,
	X509SubjectKeyIdentifierExtension__ctor_m3547362312,
	X509SubjectKeyIdentifierExtension__ctor_m1397817642,
	X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3059478847,
	X509SubjectKeyIdentifierExtension_CopyFrom_m1588766981,
	X509SubjectKeyIdentifierExtension_FromHexChar_m1249358531,
	X509SubjectKeyIdentifierExtension_FromHexChars_m3244835916,
	X509SubjectKeyIdentifierExtension_FromHex_m1011249985,
	X509SubjectKeyIdentifierExtension_Decode_m1505409124,
	X509SubjectKeyIdentifierExtension_Encode_m3345759265,
	X509SubjectKeyIdentifierExtension_ToString_m12089275,
	BaseMachine__ctor_m1534760230,
	BaseMachine_Scan_m3315183438,
	Capture__ctor_m3103117740,
	Capture__ctor_m539415522,
	Capture_get_Index_m745081289,
	Capture_get_Length_m4245536461,
	Capture_get_Value_m3919646039,
	Capture_ToString_m2751919208,
	Capture_get_Text_m3620583591,
	CaptureCollection__ctor_m357483405,
	CaptureCollection_get_Count_m2294375304,
	CaptureCollection_SetValue_m89830704,
	CaptureCollection_get_SyncRoot_m1721113318,
	CaptureCollection_CopyTo_m3566922817,
	CaptureCollection_GetEnumerator_m732412500,
	CategoryUtils_CategoryFromName_m1352081402,
	CategoryUtils_IsCategory_m278753792,
	CategoryUtils_IsCategory_m3604944547,
	FactoryCache__ctor_m206337971,
	FactoryCache_Add_m1371573845,
	FactoryCache_Cleanup_m308458843,
	FactoryCache_Lookup_m2646822264,
	Key__ctor_m251888331,
	Key_GetHashCode_m1667525669,
	Key_Equals_m3074271967,
	Key_ToString_m1970072654,
	Group__ctor_m2243671333,
	Group__ctor_m2495427790,
	Group__ctor_m3285303650,
	Group__cctor_m2230627219,
	Group_get_Captures_m1655762411,
	Group_get_Success_m3823591889,
	GroupCollection__ctor_m3775662598,
	GroupCollection_get_Count_m1328438810,
	GroupCollection_get_Item_m723682197,
	GroupCollection_SetValue_m2707160733,
	GroupCollection_get_SyncRoot_m501373446,
	GroupCollection_CopyTo_m408257156,
	GroupCollection_GetEnumerator_m2543003136,
	Interpreter__ctor_m2134836895,
	Interpreter_ReadProgramCount_m1121096263,
	Interpreter_Scan_m270890411,
	Interpreter_Reset_m2774688020,
	Interpreter_Eval_m858596062,
	Interpreter_EvalChar_m959577577,
	Interpreter_TryMatch_m2615355060,
	Interpreter_IsPosition_m3326918850,
	Interpreter_IsWordChar_m2858055765,
	Interpreter_GetString_m94448266,
	Interpreter_Open_m900076395,
	Interpreter_Close_m126356671,
	Interpreter_Balance_m1978770534,
	Interpreter_Checkpoint_m1239052598,
	Interpreter_Backtrack_m2828876822,
	Interpreter_ResetGroups_m3595179625,
	Interpreter_GetLastDefined_m4107643411,
	Interpreter_CreateMark_m468807491,
	Interpreter_GetGroupInfo_m2253622734,
	Interpreter_PopulateGroup_m4042796257,
	Interpreter_GenerateMatch_m2262987936,
	IntStack_Pop_m1779514793_AdjustorThunk,
	IntStack_Push_m1082581210_AdjustorThunk,
	IntStack_get_Count_m1427289819_AdjustorThunk,
	IntStack_set_Count_m756607812_AdjustorThunk,
	RepeatContext__ctor_m2465637864,
	RepeatContext_get_Count_m1112834530,
	RepeatContext_set_Count_m960350409,
	RepeatContext_get_Start_m1076992038,
	RepeatContext_set_Start_m2870272657,
	RepeatContext_get_IsMinimum_m3640286252,
	RepeatContext_get_IsMaximum_m332552678,
	RepeatContext_get_IsLazy_m2261224997,
	RepeatContext_get_Expression_m255006542,
	RepeatContext_get_Previous_m4220584810,
	InterpreterFactory__ctor_m3950407360,
	InterpreterFactory_NewInstance_m2792693614,
	InterpreterFactory_get_GroupCount_m2226373271,
	InterpreterFactory_get_Gap_m2263656528,
	InterpreterFactory_set_Gap_m3029846199,
	InterpreterFactory_get_Mapping_m1356145599,
	InterpreterFactory_set_Mapping_m1881043811,
	InterpreterFactory_get_NamesMapping_m4228407820,
	InterpreterFactory_set_NamesMapping_m1853107228,
	Interval__ctor_m4022869013_AdjustorThunk,
	Interval_get_Empty_m3617514670,
	Interval_get_IsDiscontiguous_m3016063288_AdjustorThunk,
	Interval_get_IsSingleton_m3386290029_AdjustorThunk,
	Interval_get_IsEmpty_m2731597232_AdjustorThunk,
	Interval_get_Size_m4163671410_AdjustorThunk,
	Interval_IsDisjoint_m1532171337_AdjustorThunk,
	Interval_IsAdjacent_m3021964761_AdjustorThunk,
	Interval_Contains_m1454846757_AdjustorThunk,
	Interval_Contains_m110351300_AdjustorThunk,
	Interval_Intersects_m525534288_AdjustorThunk,
	Interval_Merge_m3454211016_AdjustorThunk,
	Interval_CompareTo_m3282557545_AdjustorThunk,
	IntervalCollection__ctor_m758349803,
	IntervalCollection_get_Item_m3866640912,
	IntervalCollection_Add_m2115898256,
	IntervalCollection_Normalize_m1934892959,
	IntervalCollection_GetMetaCollection_m4029522214,
	IntervalCollection_Optimize_m161975983,
	IntervalCollection_get_Count_m3041256718,
	IntervalCollection_get_SyncRoot_m3527457532,
	IntervalCollection_CopyTo_m2976848759,
	IntervalCollection_GetEnumerator_m3422445219,
	CostDelegate__ctor_m4027655829,
	CostDelegate_Invoke_m898648402,
	CostDelegate_BeginInvoke_m2828452701,
	CostDelegate_EndInvoke_m2797921932,
	Enumerator__ctor_m1228633090,
	Enumerator_get_Current_m359737019,
	Enumerator_MoveNext_m55255603,
	Enumerator_Reset_m2498345483,
	LinkRef__ctor_m3071983504,
	LinkStack__ctor_m1458748896,
	LinkStack_Push_m3081279930,
	LinkStack_Pop_m4048583474,
	MRUList__ctor_m3064247590,
	MRUList_Use_m110810900,
	MRUList_Evict_m4016329834,
	Node__ctor_m3885833051,
	Mark_get_IsDefined_m2539660708_AdjustorThunk,
	Mark_get_Index_m3048692661_AdjustorThunk,
	Mark_get_Length_m2532192442_AdjustorThunk,
	Match__ctor_m624429017,
	Match__ctor_m2464595873,
	Match__ctor_m2425511580,
	Match__cctor_m3511441780,
	Match_get_Empty_m2060287462,
	Match_get_Groups_m841244970,
	Match_NextMatch_m366671308,
	Match_get_Regex_m318048854,
	MatchCollection__ctor_m4138850022,
	MatchCollection_get_Count_m1586545784,
	MatchCollection_get_Item_m3516666721,
	MatchCollection_get_SyncRoot_m1957585059,
	MatchCollection_CopyTo_m3807326147,
	MatchCollection_GetEnumerator_m3899212470,
	MatchCollection_TryToGet_m1813945069,
	MatchCollection_get_FullList_m1829231879,
	Enumerator__ctor_m714733887,
	Enumerator_System_Collections_IEnumerator_Reset_m24787251,
	Enumerator_System_Collections_IEnumerator_get_Current_m666159028,
	Enumerator_System_Collections_IEnumerator_MoveNext_m3182190557,
	PatternCompiler__ctor_m1221514440,
	PatternCompiler_EncodeOp_m3656975400,
	PatternCompiler_GetMachineFactory_m3758869886,
	PatternCompiler_EmitFalse_m1347893438,
	PatternCompiler_EmitTrue_m2226795800,
	PatternCompiler_EmitCount_m1087322477,
	PatternCompiler_EmitCharacter_m1434994858,
	PatternCompiler_EmitCategory_m851169746,
	PatternCompiler_EmitNotCategory_m2023580103,
	PatternCompiler_EmitRange_m2566284920,
	PatternCompiler_EmitSet_m2815529224,
	PatternCompiler_EmitString_m3605578155,
	PatternCompiler_EmitPosition_m2959691703,
	PatternCompiler_EmitOpen_m3165174429,
	PatternCompiler_EmitClose_m2259636270,
	PatternCompiler_EmitBalanceStart_m3310909460,
	PatternCompiler_EmitBalance_m3442526123,
	PatternCompiler_EmitReference_m2546735804,
	PatternCompiler_EmitIfDefined_m2075050865,
	PatternCompiler_EmitSub_m193323684,
	PatternCompiler_EmitTest_m764507779,
	PatternCompiler_EmitBranch_m3879973493,
	PatternCompiler_EmitJump_m3915926156,
	PatternCompiler_EmitRepeat_m697083858,
	PatternCompiler_EmitUntil_m3644194775,
	PatternCompiler_EmitFastRepeat_m3012952683,
	PatternCompiler_EmitIn_m4131231439,
	PatternCompiler_EmitAnchor_m1950537976,
	PatternCompiler_EmitInfo_m780326530,
	PatternCompiler_NewLink_m3699449496,
	PatternCompiler_ResolveLink_m2545921107,
	PatternCompiler_EmitBranchEnd_m2845168300,
	PatternCompiler_EmitAlternationEnd_m2444359097,
	PatternCompiler_MakeFlags_m1977119795,
	PatternCompiler_Emit_m3022689557,
	PatternCompiler_Emit_m1540115729,
	PatternCompiler_Emit_m604664654,
	PatternCompiler_get_CurrentAddress_m295383652,
	PatternCompiler_BeginLink_m1295557963,
	PatternCompiler_EmitLink_m1012034249,
	PatternLinkStack__ctor_m4175825564,
	PatternLinkStack_set_BaseAddress_m1446738163,
	PatternLinkStack_get_OffsetAddress_m3101911097,
	PatternLinkStack_set_OffsetAddress_m2052096082,
	PatternLinkStack_GetOffset_m3697714525,
	PatternLinkStack_GetCurrent_m2744014759,
	PatternLinkStack_SetCurrent_m366511098,
	QuickSearch__ctor_m430910133,
	QuickSearch__cctor_m2494832544,
	QuickSearch_get_Length_m1693906716,
	QuickSearch_Search_m3063517397,
	QuickSearch_SetupShiftTable_m3696400592,
	QuickSearch_GetShiftDistance_m2542665852,
	QuickSearch_GetChar_m1297698557,
	Regex__ctor_m1255796137,
	Regex__ctor_m3948448025,
	Regex__ctor_m1728442805,
	Regex__ctor_m4152689500,
	Regex__cctor_m3370093859,
	Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m4061390789,
	Regex_validate_options_m3221650569,
	Regex_Init_m289933770,
	Regex_InitNewRegex_m3271185474,
	Regex_CreateMachineFactory_m4274762546,
	Regex_get_Options_m3142641900,
	Regex_get_RightToLeft_m2317867572,
	Regex_GetGroupIndex_m4131147974,
	Regex_default_startat_m4206401165,
	Regex_IsMatch_m4067478295,
	Regex_IsMatch_m2113092601,
	Regex_Match_m4145799399,
	Regex_Matches_m979395559,
	Regex_Matches_m2080913806,
	Regex_ToString_m1548107455,
	Regex_get_Gap_m3259754026,
	Regex_CreateMachine_m334863819,
	Regex_GetGroupNamesArray_m3575729002,
	Regex_get_GroupNumbers_m2296197918,
	Alternation__ctor_m1629257642,
	Alternation_get_Alternatives_m1978796879,
	Alternation_AddAlternative_m3625038910,
	Alternation_Compile_m944357616,
	Alternation_GetWidth_m2955030832,
	AnchorInfo__ctor_m3523994803,
	AnchorInfo__ctor_m3869855453,
	AnchorInfo__ctor_m46784903,
	AnchorInfo_get_Offset_m2045445765,
	AnchorInfo_get_Width_m3579824419,
	AnchorInfo_get_Length_m1361685865,
	AnchorInfo_get_IsUnknownWidth_m830883035,
	AnchorInfo_get_IsComplete_m4053892818,
	AnchorInfo_get_Substring_m1799385132,
	AnchorInfo_get_IgnoreCase_m4084905689,
	AnchorInfo_get_Position_m1133366486,
	AnchorInfo_get_IsSubstring_m1536110387,
	AnchorInfo_get_IsPosition_m2100552190,
	AnchorInfo_GetInterval_m2808989035,
	Assertion__ctor_m2128950829,
	Assertion_get_TrueExpression_m2743006331,
	Assertion_set_TrueExpression_m530142558,
	Assertion_get_FalseExpression_m2609188285,
	Assertion_set_FalseExpression_m468310168,
	Assertion_GetWidth_m3431863255,
	BackslashNumber__ctor_m3802423446,
	BackslashNumber_ResolveReference_m4176908213,
	BackslashNumber_Compile_m1825066804,
	BalancingGroup__ctor_m2760700418,
	BalancingGroup_set_Balance_m3289053627,
	BalancingGroup_Compile_m2575117193,
	CaptureAssertion__ctor_m1422197394,
	CaptureAssertion_set_CapturingGroup_m2003123956,
	CaptureAssertion_Compile_m1815624462,
	CaptureAssertion_IsComplex_m237493585,
	CaptureAssertion_get_Alternate_m4172691807,
	CapturingGroup__ctor_m1932199154,
	CapturingGroup_get_Index_m3406974370,
	CapturingGroup_set_Index_m1113018009,
	CapturingGroup_get_Name_m3747712535,
	CapturingGroup_set_Name_m3031988208,
	CapturingGroup_get_IsNamed_m570289083,
	CapturingGroup_Compile_m1789150976,
	CapturingGroup_IsComplex_m4061114763,
	CapturingGroup_CompareTo_m4265294460,
	CharacterClass__ctor_m1294707193,
	CharacterClass__ctor_m2417156412,
	CharacterClass__cctor_m443084915,
	CharacterClass_AddCategory_m3505628817,
	CharacterClass_AddCharacter_m2370152363,
	CharacterClass_AddRange_m3500530626,
	CharacterClass_Compile_m3296067317,
	CharacterClass_GetWidth_m2503189403,
	CharacterClass_IsComplex_m1490839133,
	CharacterClass_GetIntervalCost_m4036989868,
	CompositeExpression__ctor_m2434860303,
	CompositeExpression_get_Expressions_m2951105322,
	CompositeExpression_GetWidth_m936348716,
	CompositeExpression_IsComplex_m2236888323,
	Expression__ctor_m1600460087,
	Expression_GetFixedWidth_m945658,
	Expression_GetAnchorInfo_m2996231682,
	ExpressionAssertion__ctor_m2554412824,
	ExpressionAssertion_set_Reverse_m4141031406,
	ExpressionAssertion_set_Negate_m1236561973,
	ExpressionAssertion_get_TestExpression_m727356674,
	ExpressionAssertion_set_TestExpression_m3544634251,
	ExpressionAssertion_Compile_m2166597834,
	ExpressionAssertion_IsComplex_m2085675212,
	ExpressionCollection__ctor_m2806571689,
	ExpressionCollection_Add_m41125344,
	ExpressionCollection_get_Item_m3510736379,
	ExpressionCollection_set_Item_m2040804459,
	ExpressionCollection_OnValidate_m3555775570,
	Group__ctor_m2980794822,
	Group_AppendExpression_m1633560475,
	Group_Compile_m3355488790,
	Group_GetWidth_m3299755715,
	Group_GetAnchorInfo_m3730312864,
	Literal__ctor_m1697110877,
	Literal_CompileLiteral_m4231400317,
	Literal_Compile_m2228022079,
	Literal_GetWidth_m2673961846,
	Literal_GetAnchorInfo_m810577400,
	Literal_IsComplex_m4067122560,
	NonBacktrackingGroup__ctor_m2332797184,
	NonBacktrackingGroup_Compile_m1731438724,
	NonBacktrackingGroup_IsComplex_m823336948,
	Parser__ctor_m3200411199,
	Parser_ParseDecimal_m245094461,
	Parser_ParseOctal_m1193445574,
	Parser_ParseHex_m3698548444,
	Parser_ParseNumber_m2114552835,
	Parser_ParseName_m1814604608,
	Parser_ParseRegularExpression_m18398587,
	Parser_GetMapping_m1792972121,
	Parser_ParseGroup_m3186460488,
	Parser_ParseGroupingConstruct_m263270497,
	Parser_ParseAssertionType_m2403454228,
	Parser_ParseOptions_m2606822689,
	Parser_ParseCharacterClass_m4285351396,
	Parser_ParseRepetitionBounds_m1246581246,
	Parser_ParseUnicodeCategory_m100397645,
	Parser_ParseSpecial_m1961501104,
	Parser_ParseEscape_m956682155,
	Parser_ParseName_m2057792975,
	Parser_IsNameChar_m698176442,
	Parser_ParseNumber_m3464424197,
	Parser_ParseDigit_m2336300552,
	Parser_ConsumeWhitespace_m3364496713,
	Parser_ResolveReferences_m1518052352,
	Parser_HandleExplicitNumericGroups_m1412234891,
	Parser_IsIgnoreCase_m2210120858,
	Parser_IsMultiline_m3953355516,
	Parser_IsExplicitCapture_m2741347241,
	Parser_IsSingleline_m326238187,
	Parser_IsIgnorePatternWhitespace_m2107132682,
	Parser_IsECMAScript_m674158805,
	Parser_NewParseException_m686511029,
	PositionAssertion__ctor_m569003936,
	PositionAssertion_Compile_m2500980346,
	PositionAssertion_GetWidth_m856687117,
	PositionAssertion_IsComplex_m3339056668,
	PositionAssertion_GetAnchorInfo_m32057718,
	Reference__ctor_m1870245246,
	Reference_get_CapturingGroup_m3861468528,
	Reference_set_CapturingGroup_m1130974240,
	Reference_get_IgnoreCase_m241264953,
	Reference_Compile_m4195878675,
	Reference_GetWidth_m3130781491,
	Reference_IsComplex_m3000063927,
	RegularExpression__ctor_m119502265,
	RegularExpression_set_GroupCount_m3908887512,
	RegularExpression_Compile_m2385682508,
	Repetition__ctor_m1672362629,
	Repetition_get_Expression_m2673886232,
	Repetition_set_Expression_m1234887071,
	Repetition_get_Minimum_m2550947568,
	Repetition_Compile_m988726715,
	Repetition_GetWidth_m1827161831,
	Repetition_GetAnchorInfo_m2615648496,
	Uri__ctor_m800430703,
	Uri__ctor_m3848281005,
	Uri__ctor_m3040793867,
	Uri__ctor_m253204164,
	Uri__ctor_m3577021606,
	Uri__cctor_m38080231,
	Uri_System_Runtime_Serialization_ISerializable_GetObjectData_m4023918416,
	Uri_Merge_m76373955,
	Uri_get_AbsoluteUri_m2582056986,
	Uri_get_Authority_m3816772302,
	Uri_get_Host_m42857288,
	Uri_get_IsFile_m2450018824,
	Uri_get_IsLoopback_m2492530169,
	Uri_get_IsUnc_m2977972311,
	Uri_get_Scheme_m2109479391,
	Uri_get_IsAbsoluteUri_m3666899587,
	Uri_get_OriginalString_m3715995233,
	Uri_CheckHostName_m2213216182,
	Uri_IsIPv4Address_m3535481943,
	Uri_IsDomainAddress_m2867513594,
	Uri_CheckSchemeName_m108657675,
	Uri_IsAlpha_m1282293464,
	Uri_Equals_m3263316701,
	Uri_InternalEquals_m2029068366,
	Uri_GetHashCode_m321999866,
	Uri_GetLeftPart_m3979111399,
	Uri_FromHex_m2610708947,
	Uri_HexEscape_m1589417657,
	Uri_IsHexDigit_m3389749670,
	Uri_IsHexEncoding_m3290929897,
	Uri_AppendQueryAndFragment_m3170766010,
	Uri_ToString_m3742105950,
	Uri_EscapeString_m2061933484,
	Uri_EscapeString_m3864445955,
	Uri_ParseUri_m2150795567,
	Uri_Unescape_m3373094076,
	Uri_Unescape_m910903869,
	Uri_ParseAsWindowsUNC_m2348878458,
	Uri_ParseAsWindowsAbsoluteFilePath_m708354183,
	Uri_ParseAsUnixAbsoluteFilePath_m1476768041,
	Uri_Parse_m736300106,
	Uri_ParseNoExceptions_m4274141693,
	Uri_CompactEscaped_m2984961597,
	Uri_Reduce_m3122437040,
	Uri_HexUnescapeMultiByte_m332853996,
	Uri_GetSchemeDelimiter_m2374610473,
	Uri_GetDefaultPort_m2547653357,
	Uri_GetOpaqueWiseSchemeDelimiter_m1909471550,
	Uri_IsPredefinedScheme_m1188665625,
	Uri_get_Parser_m3737125102,
	Uri_EnsureAbsoluteUri_m2231483494,
	Uri_op_Equality_m685520154,
	UriScheme__ctor_m1399779782_AdjustorThunk,
	UriFormatException__ctor_m1115096473,
	UriFormatException__ctor_m3083316541,
	UriFormatException__ctor_m3466512970,
	UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_m3030326401,
	UriParser__ctor_m2454688443,
	UriParser__cctor_m3655686731,
	UriParser_InitializeAndValidate_m2008117311,
	UriParser_OnRegister_m3283921560,
	UriParser_set_SchemeName_m266448765,
	UriParser_get_DefaultPort_m2544851211,
	UriParser_set_DefaultPort_m4007715058,
	UriParser_CreateDefaults_m404296154,
	UriParser_InternalRegister_m3643767086,
	UriParser_GetParser_m544052729,
	Locale_GetText_m3520169047,
	BigInteger__ctor_m3473491062,
	BigInteger__ctor_m2108826647,
	BigInteger__ctor_m2644482640,
	BigInteger__ctor_m2601366464,
	BigInteger__ctor_m2474659844,
	BigInteger__cctor_m102257529,
	BigInteger_get_Rng_m3283260184,
	BigInteger_GenerateRandom_m3872771375,
	BigInteger_GenerateRandom_m1790382084,
	BigInteger_BitCount_m2055977486,
	BigInteger_TestBit_m2798226118,
	BigInteger_SetBit_m1387902198,
	BigInteger_SetBit_m1723423691,
	BigInteger_LowestSetBit_m1199244228,
	BigInteger_GetBytes_m1259701831,
	BigInteger_ToString_m3260066955,
	BigInteger_ToString_m1181683046,
	BigInteger_Normalize_m3021106862,
	BigInteger_Clear_m2995574218,
	BigInteger_GetHashCode_m1594560121,
	BigInteger_ToString_m3927393477,
	BigInteger_Equals_m63093403,
	BigInteger_ModInverse_m2426215562,
	BigInteger_ModPow_m3776562770,
	BigInteger_GeneratePseudoPrime_m2547138838,
	BigInteger_Incr2_m1531167978,
	BigInteger_op_Implicit_m3414367033,
	BigInteger_op_Implicit_m2547142909,
	BigInteger_op_Addition_m1114527046,
	BigInteger_op_Subtraction_m4245834512,
	BigInteger_op_Modulus_m3242311550,
	BigInteger_op_Modulus_m2565477533,
	BigInteger_op_Division_m3713793389,
	BigInteger_op_Multiply_m3683746602,
	BigInteger_op_LeftShift_m3681213422,
	BigInteger_op_RightShift_m460065452,
	BigInteger_op_Equality_m3872814973,
	BigInteger_op_Inequality_m3469726044,
	BigInteger_op_Equality_m1194739960,
	BigInteger_op_Inequality_m2697143438,
	BigInteger_op_GreaterThan_m2974122765,
	BigInteger_op_LessThan_m463398176,
	BigInteger_op_GreaterThanOrEqual_m3313329514,
	BigInteger_op_LessThanOrEqual_m3925173639,
	Kernel_AddSameSign_m3267067385,
	Kernel_Subtract_m846005223,
	Kernel_MinusEq_m2152832554,
	Kernel_PlusEq_m136676638,
	Kernel_Compare_m2669603547,
	Kernel_SingleByteDivideInPlace_m2393683267,
	Kernel_DwordMod_m3830036736,
	Kernel_DwordDivMod_m1540317819,
	Kernel_multiByteDivide_m450694282,
	Kernel_LeftShift_m4140742987,
	Kernel_RightShift_m3246168448,
	Kernel_Multiply_m193213393,
	Kernel_MultiplyMod2p32pmod_m451690680,
	Kernel_modInverse_m4048046181,
	Kernel_modInverse_m652700340,
	ModulusRing__ctor_m2420310199,
	ModulusRing_BarrettReduction_m3024442734,
	ModulusRing_Multiply_m1975391470,
	ModulusRing_Difference_m3686091506,
	ModulusRing_Pow_m1124248336,
	ModulusRing_Pow_m729002192,
	PrimeGeneratorBase__ctor_m2423671149,
	PrimeGeneratorBase_get_Confidence_m3172213559,
	PrimeGeneratorBase_get_PrimalityTest_m2487240563,
	PrimeGeneratorBase_get_TrialDivisionBounds_m1980088695,
	SequentialSearchPrimeGeneratorBase__ctor_m577913576,
	SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m1918143664,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m907640859,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m2891860459,
	SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m1127740833,
	PrimalityTest__ctor_m763620166,
	PrimalityTest_Invoke_m2948246884,
	PrimalityTest_BeginInvoke_m742423211,
	PrimalityTest_EndInvoke_m1035389364,
	PrimalityTests_GetSPPRounds_m2558073743,
	PrimalityTests_RabinMillerTest_m2544317101,
	ASN1__ctor_m1239252869,
	ASN1__ctor_m682794872,
	ASN1__ctor_m1638893325,
	ASN1_get_Count_m1789520042,
	ASN1_get_Tag_m2789147236,
	ASN1_get_Length_m3269728307,
	ASN1_get_Value_m63296490,
	ASN1_set_Value_m647861841,
	ASN1_CompareArray_m3928975006,
	ASN1_CompareValue_m1642100296,
	ASN1_Add_m2431139999,
	ASN1_GetBytes_m1968380955,
	ASN1_Decode_m1245286596,
	ASN1_DecodeTLV_m3927350254,
	ASN1_get_Item_m2255075813,
	ASN1_Element_m4088315026,
	ASN1_ToString_m45458043,
	ASN1Convert_FromInt32_m1154451899,
	ASN1Convert_FromOid_m3844102704,
	ASN1Convert_ToInt32_m1017403318,
	ASN1Convert_ToOid_m3847701408,
	ASN1Convert_ToDateTime_m1246060840,
	BitConverterLE_GetUIntBytes_m795219058,
	BitConverterLE_GetBytes_m3268825786,
	ARC4Managed__ctor_m2553537404,
	ARC4Managed_Finalize_m315143160,
	ARC4Managed_Dispose_m3340445210,
	ARC4Managed_get_Key_m2476146969,
	ARC4Managed_set_Key_m859266296,
	ARC4Managed_get_CanReuseTransform_m1145713138,
	ARC4Managed_CreateEncryptor_m2249585492,
	ARC4Managed_CreateDecryptor_m1966583816,
	ARC4Managed_GenerateIV_m2029637723,
	ARC4Managed_GenerateKey_m1607343060,
	ARC4Managed_KeySetup_m2449315676,
	ARC4Managed_CheckInput_m1562172012,
	ARC4Managed_TransformBlock_m1687647868,
	ARC4Managed_InternalTransformBlock_m1047162329,
	ARC4Managed_TransformFinalBlock_m2223084380,
	CryptoConvert_ToHex_m4034982758,
	HMAC__ctor_m775015853,
	HMAC_get_Key_m1410673610,
	HMAC_set_Key_m3535779141,
	HMAC_Initialize_m4068357959,
	HMAC_HashFinal_m1453827676,
	HMAC_HashCore_m1045651335,
	HMAC_initializePad_m59014980,
	KeyBuilder_get_Rng_m983065666,
	KeyBuilder_Key_m1482371611,
	MD2__ctor_m2402458789,
	MD2_Create_m3511476020,
	MD2_Create_m1292792200,
	MD2Managed__ctor_m3243422744,
	MD2Managed__cctor_m1915574725,
	MD2Managed_Padding_m1334210368,
	MD2Managed_Initialize_m2341076836,
	MD2Managed_HashCore_m1280598655,
	MD2Managed_HashFinal_m808964912,
	MD2Managed_MD2Transform_m3143426291,
	MD4__ctor_m919379109,
	MD4_Create_m1588482044,
	MD4_Create_m4111026039,
	MD4Managed__ctor_m2284724408,
	MD4Managed_Initialize_m469436465,
	MD4Managed_HashCore_m3384203071,
	MD4Managed_HashFinal_m3850238392,
	MD4Managed_Padding_m3091724296,
	MD4Managed_F_m2794461001,
	MD4Managed_G_m2118206422,
	MD4Managed_H_m213605525,
	MD4Managed_ROL_m691796253,
	MD4Managed_FF_m3294771481,
	MD4Managed_GG_m1845276249,
	MD4Managed_HH_m2535673516,
	MD4Managed_Encode_m386285215,
	MD4Managed_Decode_m4273685594,
	MD4Managed_MD4Transform_m1101832482,
	MD5SHA1__ctor_m4081016482,
	MD5SHA1_Initialize_m675470944,
	MD5SHA1_HashFinal_m4115488658,
	MD5SHA1_HashCore_m4171647335,
	MD5SHA1_CreateSignature_m3583449066,
	MD5SHA1_VerifySignature_m915115209,
	PKCS1__cctor_m2848504824,
	PKCS1_Compare_m8562819,
	PKCS1_I2OSP_m2559784711,
	PKCS1_OS2IP_m1443067185,
	PKCS1_RSASP1_m4286349561,
	PKCS1_RSAVP1_m43771175,
	PKCS1_Sign_v15_m3459793192,
	PKCS1_Verify_v15_m4192025173,
	PKCS1_Verify_v15_m400093581,
	PKCS1_Encode_v15_m2077073129,
	EncryptedPrivateKeyInfo__ctor_m3415744930,
	EncryptedPrivateKeyInfo__ctor_m25839594,
	EncryptedPrivateKeyInfo_get_Algorithm_m3027828440,
	EncryptedPrivateKeyInfo_get_EncryptedData_m491452551,
	EncryptedPrivateKeyInfo_get_Salt_m1261804721,
	EncryptedPrivateKeyInfo_get_IterationCount_m2912222740,
	EncryptedPrivateKeyInfo_Decode_m3008916518,
	PrivateKeyInfo__ctor_m3331475997,
	PrivateKeyInfo__ctor_m2715455038,
	PrivateKeyInfo_get_PrivateKey_m3647771102,
	PrivateKeyInfo_Decode_m986145117,
	PrivateKeyInfo_RemoveLeadingZero_m3592760008,
	PrivateKeyInfo_Normalize_m2274647848,
	PrivateKeyInfo_DecodeRSA_m4129124827,
	PrivateKeyInfo_DecodeDSA_m2335813142,
	RC4__ctor_m3531760091,
	RC4__cctor_m362546962,
	RC4_get_IV_m2290186270,
	RC4_set_IV_m844219403,
	RSAManaged__ctor_m3504773110,
	RSAManaged__ctor_m350841446,
	RSAManaged_Finalize_m297255587,
	RSAManaged_GenerateKeyPair_m2364618953,
	RSAManaged_get_KeySize_m1441482916,
	RSAManaged_get_PublicOnly_m405847294,
	RSAManaged_DecryptValue_m1804388365,
	RSAManaged_EncryptValue_m4149543654,
	RSAManaged_ExportParameters_m1754454264,
	RSAManaged_ImportParameters_m1117427048,
	RSAManaged_Dispose_m2347279430,
	RSAManaged_ToXmlString_m2369501989,
	RSAManaged_GetPaddedValue_m2182626630,
	KeyGeneratedEventHandler__ctor_m4032730305,
	KeyGeneratedEventHandler_Invoke_m99769071,
	KeyGeneratedEventHandler_BeginInvoke_m3227934731,
	KeyGeneratedEventHandler_EndInvoke_m2862962495,
	ContentInfo__ctor_m1955840786,
	ContentInfo__ctor_m2855743200,
	ContentInfo__ctor_m2928874476,
	ContentInfo__ctor_m3397951412,
	ContentInfo_get_ASN1_m2959326143,
	ContentInfo_get_Content_m4053224038,
	ContentInfo_set_Content_m2581255245,
	ContentInfo_get_ContentType_m4018261807,
	ContentInfo_set_ContentType_m3848100294,
	ContentInfo_GetASN1_m2535172199,
	EncryptedData__ctor_m257803736,
	EncryptedData__ctor_m4001546383,
	EncryptedData_get_EncryptionAlgorithm_m905084934,
	EncryptedData_get_EncryptedContent_m3205649670,
	Alert__ctor_m3135936936,
	Alert__ctor_m2879739792,
	Alert_get_Level_m4249630350,
	Alert_get_Description_m3833114036,
	Alert_get_IsWarning_m1365397992,
	Alert_get_IsCloseNotify_m3157384796,
	Alert_inferAlertLevel_m151204576,
	Alert_GetAlertMessage_m1942367141,
	CertificateSelectionCallback__ctor_m3437537928,
	CertificateSelectionCallback_Invoke_m3129973019,
	CertificateSelectionCallback_BeginInvoke_m598704794,
	CertificateSelectionCallback_EndInvoke_m916047629,
	CertificateValidationCallback__ctor_m1962610296,
	CertificateValidationCallback_Invoke_m1014111289,
	CertificateValidationCallback_BeginInvoke_m3301716879,
	CertificateValidationCallback_EndInvoke_m4224203910,
	CertificateValidationCallback2__ctor_m1685875113,
	CertificateValidationCallback2_Invoke_m3381554834,
	CertificateValidationCallback2_BeginInvoke_m3360174801,
	CertificateValidationCallback2_EndInvoke_m2456956161,
	CipherSuite__ctor_m2440635082,
	CipherSuite__cctor_m3668442490,
	CipherSuite_get_EncryptionCipher_m3029637613,
	CipherSuite_get_DecryptionCipher_m2839827488,
	CipherSuite_get_ClientHMAC_m377589750,
	CipherSuite_get_ServerHMAC_m714506854,
	CipherSuite_get_CipherAlgorithmType_m137858741,
	CipherSuite_get_HashAlgorithmName_m3758129154,
	CipherSuite_get_HashAlgorithmType_m1029363505,
	CipherSuite_get_HashSize_m4060916532,
	CipherSuite_get_ExchangeAlgorithmType_m1633709183,
	CipherSuite_get_CipherMode_m425550365,
	CipherSuite_get_Code_m3847824475,
	CipherSuite_get_Name_m1137568068,
	CipherSuite_get_IsExportable_m677202963,
	CipherSuite_get_KeyMaterialSize_m3569550689,
	CipherSuite_get_KeyBlockSize_m519075451,
	CipherSuite_get_ExpandedKeyMaterialSize_m197590106,
	CipherSuite_get_EffectiveKeyBits_m2380229009,
	CipherSuite_get_IvSize_m630778063,
	CipherSuite_get_Context_m1621551997,
	CipherSuite_set_Context_m1978767807,
	CipherSuite_Write_m1172814058,
	CipherSuite_Write_m1841735015,
	CipherSuite_InitializeCipher_m2397698608,
	CipherSuite_EncryptRecord_m4196378593,
	CipherSuite_DecryptRecord_m1495386860,
	CipherSuite_CreatePremasterSecret_m4264566459,
	CipherSuite_PRF_m2801806009,
	CipherSuite_Expand_m2729769226,
	CipherSuite_createEncryptionCipher_m2533565116,
	CipherSuite_createDecryptionCipher_m1176259509,
	CipherSuiteCollection__ctor_m384434353,
	CipherSuiteCollection_System_Collections_IList_get_Item_m2175128671,
	CipherSuiteCollection_System_Collections_IList_set_Item_m904255570,
	CipherSuiteCollection_System_Collections_ICollection_get_SyncRoot_m630394386,
	CipherSuiteCollection_System_Collections_IEnumerable_GetEnumerator_m3240848888,
	CipherSuiteCollection_System_Collections_IList_Contains_m1220133031,
	CipherSuiteCollection_System_Collections_IList_IndexOf_m1361500977,
	CipherSuiteCollection_System_Collections_IList_Insert_m1567261820,
	CipherSuiteCollection_System_Collections_IList_Remove_m2463347416,
	CipherSuiteCollection_System_Collections_IList_RemoveAt_m2600067414,
	CipherSuiteCollection_System_Collections_IList_Add_m1178326810,
	CipherSuiteCollection_get_Item_m2791953484,
	CipherSuiteCollection_get_Item_m4188309062,
	CipherSuiteCollection_set_Item_m2392524001,
	CipherSuiteCollection_get_Item_m3790183696,
	CipherSuiteCollection_get_Count_m4271692531,
	CipherSuiteCollection_CopyTo_m3857518994,
	CipherSuiteCollection_Clear_m2642701260,
	CipherSuiteCollection_IndexOf_m2232557119,
	CipherSuiteCollection_IndexOf_m2770510321,
	CipherSuiteCollection_Add_m2046232751,
	CipherSuiteCollection_add_m3005595589,
	CipherSuiteCollection_add_m1422128145,
	CipherSuiteCollection_cultureAwareCompare_m2072548979,
	CipherSuiteFactory_GetSupportedCiphers_m3260014148,
	CipherSuiteFactory_GetTls1SupportedCiphers_m3691819504,
	CipherSuiteFactory_GetSsl3SupportedCiphers_m3757358569,
	ClientContext__ctor_m3993227749,
	ClientContext_get_SslStream_m1583577309,
	ClientContext_get_ClientHelloProtocol_m1654639078,
	ClientContext_set_ClientHelloProtocol_m4189379912,
	ClientContext_Clear_m1774063253,
	ClientRecordProtocol__ctor_m2839844778,
	ClientRecordProtocol_GetMessage_m797000123,
	ClientRecordProtocol_ProcessHandshakeMessage_m1002991731,
	ClientRecordProtocol_createClientHandshakeMessage_m3325677558,
	ClientRecordProtocol_createServerHandshakeMessage_m2804371400,
	ClientSessionCache__cctor_m1380704214,
	ClientSessionCache_Add_m964342678,
	ClientSessionCache_FromHost_m273325760,
	ClientSessionCache_FromContext_m343076119,
	ClientSessionCache_SetContextInCache_m2875733100,
	ClientSessionCache_SetContextFromCache_m3781380849,
	ClientSessionInfo__ctor_m2436192270,
	ClientSessionInfo__cctor_m1143076802,
	ClientSessionInfo_Finalize_m2165787049,
	ClientSessionInfo_get_HostName_m2118440995,
	ClientSessionInfo_get_Id_m2119140021,
	ClientSessionInfo_get_Valid_m1260893789,
	ClientSessionInfo_GetContext_m1679628259,
	ClientSessionInfo_SetContext_m2115875186,
	ClientSessionInfo_KeepAlive_m1020179566,
	ClientSessionInfo_Dispose_m1535509451,
	ClientSessionInfo_Dispose_m3253728296,
	ClientSessionInfo_CheckDisposed_m1172439856,
	Context__ctor_m1288667393,
	Context_get_AbbreviatedHandshake_m3907920227,
	Context_set_AbbreviatedHandshake_m827173393,
	Context_get_ProtocolNegotiated_m4220412840,
	Context_set_ProtocolNegotiated_m2904861662,
	Context_get_SecurityProtocol_m3228286292,
	Context_set_SecurityProtocol_m2833661610,
	Context_get_SecurityProtocolFlags_m2022471746,
	Context_get_Protocol_m1078422015,
	Context_get_SessionId_m1086671147,
	Context_set_SessionId_m942328427,
	Context_get_CompressionMethod_m2647114016,
	Context_set_CompressionMethod_m2054483993,
	Context_get_ServerSettings_m1982578801,
	Context_get_ClientSettings_m2874391194,
	Context_get_LastHandshakeMsg_m2730646725,
	Context_set_LastHandshakeMsg_m1770618067,
	Context_get_HandshakeState_m2425796590,
	Context_set_HandshakeState_m1329976135,
	Context_get_ReceivedConnectionEnd_m4011125537,
	Context_set_ReceivedConnectionEnd_m911334662,
	Context_get_SentConnectionEnd_m963812869,
	Context_set_SentConnectionEnd_m1367645582,
	Context_get_SupportedCiphers_m1883682196,
	Context_set_SupportedCiphers_m4238648387,
	Context_get_HandshakeMessages_m3655705111,
	Context_get_WriteSequenceNumber_m1115956887,
	Context_set_WriteSequenceNumber_m942577065,
	Context_get_ReadSequenceNumber_m3883329199,
	Context_set_ReadSequenceNumber_m2154909392,
	Context_get_ClientRandom_m1437588520,
	Context_set_ClientRandom_m2974454575,
	Context_get_ServerRandom_m2710024742,
	Context_set_ServerRandom_m2929894009,
	Context_get_RandomCS_m1367948315,
	Context_set_RandomCS_m2687068745,
	Context_get_RandomSC_m1891758699,
	Context_set_RandomSC_m2364786761,
	Context_get_MasterSecret_m676083615,
	Context_set_MasterSecret_m3419105191,
	Context_get_ClientWriteKey_m3174706656,
	Context_set_ClientWriteKey_m1601425248,
	Context_get_ServerWriteKey_m2199131569,
	Context_set_ServerWriteKey_m3347272648,
	Context_get_ClientWriteIV_m1729804632,
	Context_set_ClientWriteIV_m3405909624,
	Context_get_ServerWriteIV_m1839374659,
	Context_set_ServerWriteIV_m1007123427,
	Context_get_RecordProtocol_m2261754827,
	Context_set_RecordProtocol_m3067654641,
	Context_GetUnixTime_m3811151335,
	Context_GetSecureRandomBytes_m3676009387,
	Context_Clear_m2678836033,
	Context_ClearKeyInfo_m1155154290,
	Context_DecodeProtocolCode_m2249547310,
	Context_ChangeProtocol_m2412635871,
	Context_get_Current_m2853615040,
	Context_get_Negotiating_m2044579817,
	Context_get_Read_m4172356735,
	Context_get_Write_m1564343513,
	Context_StartSwitchingSecurityParameters_m28285865,
	Context_EndSwitchingSecurityParameters_m4148956166,
	TlsClientCertificate__ctor_m101524132,
	TlsClientCertificate_get_ClientCertificate_m1637836254,
	TlsClientCertificate_Update_m1882970209,
	TlsClientCertificate_GetClientCertificate_m566867090,
	TlsClientCertificate_SendCertificates_m1965594186,
	TlsClientCertificate_ProcessAsSsl3_m3265529850,
	TlsClientCertificate_ProcessAsTls1_m3232146441,
	TlsClientCertificate_FindParentCertificate_m3844441401,
	TlsClientCertificateVerify__ctor_m1589614281,
	TlsClientCertificateVerify_Update_m3046208881,
	TlsClientCertificateVerify_ProcessAsSsl3_m1125097704,
	TlsClientCertificateVerify_ProcessAsTls1_m1051495755,
	TlsClientCertificateVerify_getClientCertRSA_m1205662940,
	TlsClientCertificateVerify_getUnsignedBigInteger_m3003216819,
	TlsClientFinished__ctor_m399357014,
	TlsClientFinished__cctor_m1023921005,
	TlsClientFinished_Update_m2408925771,
	TlsClientFinished_ProcessAsSsl3_m3094597606,
	TlsClientFinished_ProcessAsTls1_m2429863130,
	TlsClientHello__ctor_m1986768336,
	TlsClientHello_Update_m3773127362,
	TlsClientHello_ProcessAsSsl3_m3427133094,
	TlsClientHello_ProcessAsTls1_m2549285167,
	TlsClientKeyExchange__ctor_m31786095,
	TlsClientKeyExchange_ProcessAsSsl3_m2576462374,
	TlsClientKeyExchange_ProcessAsTls1_m338960549,
	TlsClientKeyExchange_ProcessCommon_m2327374157,
	TlsServerCertificate__ctor_m389328097,
	TlsServerCertificate_Update_m3204893479,
	TlsServerCertificate_ProcessAsSsl3_m1306583193,
	TlsServerCertificate_ProcessAsTls1_m819212276,
	TlsServerCertificate_checkCertificateUsage_m2152016773,
	TlsServerCertificate_validateCertificates_m4242999387,
	TlsServerCertificate_checkServerIdentity_m2801575130,
	TlsServerCertificate_checkDomainName_m2543190336,
	TlsServerCertificate_Match_m2996121276,
	TlsServerCertificateRequest__ctor_m1334974076,
	TlsServerCertificateRequest_Update_m2763887540,
	TlsServerCertificateRequest_ProcessAsSsl3_m1084200341,
	TlsServerCertificateRequest_ProcessAsTls1_m3214041063,
	TlsServerFinished__ctor_m1445633918,
	TlsServerFinished__cctor_m3102699406,
	TlsServerFinished_Update_m4073404386,
	TlsServerFinished_ProcessAsSsl3_m2791932180,
	TlsServerFinished_ProcessAsTls1_m173877572,
	TlsServerHello__ctor_m3887266572,
	TlsServerHello_Update_m3935081401,
	TlsServerHello_ProcessAsSsl3_m3146647238,
	TlsServerHello_ProcessAsTls1_m3844152353,
	TlsServerHello_processProtocol_m3969427189,
	TlsServerHelloDone__ctor_m173627900,
	TlsServerHelloDone_ProcessAsSsl3_m3042614798,
	TlsServerHelloDone_ProcessAsTls1_m952337401,
	TlsServerKeyExchange__ctor_m3572942737,
	TlsServerKeyExchange_Update_m453798279,
	TlsServerKeyExchange_ProcessAsSsl3_m2880115419,
	TlsServerKeyExchange_ProcessAsTls1_m49623614,
	TlsServerKeyExchange_verifySignature_m3412856769,
	HandshakeMessage__ctor_m2692487706,
	HandshakeMessage__ctor_m1353615444,
	HandshakeMessage__ctor_m1555296807,
	HandshakeMessage_get_Context_m3036797856,
	HandshakeMessage_get_HandshakeType_m478242308,
	HandshakeMessage_get_ContentType_m1693718190,
	HandshakeMessage_Process_m810828609,
	HandshakeMessage_Update_m2417837686,
	HandshakeMessage_EncodeMessage_m3919107786,
	HandshakeMessage_Compare_m2214647946,
	HttpsClientStream__ctor_m3125726871,
	HttpsClientStream_get_TrustFailure_m1151901888,
	HttpsClientStream_RaiseServerCertificateValidation_m3782467213,
	HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2058474197,
	HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1202173386,
	PrivateKeySelectionCallback__ctor_m265141085,
	PrivateKeySelectionCallback_Invoke_m921844982,
	PrivateKeySelectionCallback_BeginInvoke_m2814232473,
	PrivateKeySelectionCallback_EndInvoke_m2229365437,
	RSASslSignatureDeformatter__ctor_m4026549112,
	RSASslSignatureDeformatter_VerifySignature_m1061897602,
	RSASslSignatureDeformatter_SetHashAlgorithm_m895570787,
	RSASslSignatureDeformatter_SetKey_m2204705853,
	RSASslSignatureFormatter__ctor_m1299283008,
	RSASslSignatureFormatter_CreateSignature_m2614788251,
	RSASslSignatureFormatter_SetHashAlgorithm_m3864232300,
	RSASslSignatureFormatter_SetKey_m979790541,
	RecordProtocol__ctor_m1695232390,
	RecordProtocol__cctor_m1280873827,
	RecordProtocol_get_Context_m3273611300,
	RecordProtocol_SendRecord_m515492272,
	RecordProtocol_ProcessChangeCipherSpec_m15839975,
	RecordProtocol_GetMessage_m2086135164,
	RecordProtocol_BeginReceiveRecord_m295321170,
	RecordProtocol_InternalReceiveRecordCallback_m1713318629,
	RecordProtocol_EndReceiveRecord_m1872541318,
	RecordProtocol_ReceiveRecord_m3797641756,
	RecordProtocol_ReadRecordBuffer_m180543381,
	RecordProtocol_ReadClientHelloV2_m4052496367,
	RecordProtocol_ReadStandardRecordBuffer_m3738063864,
	RecordProtocol_ProcessAlert_m1036912531,
	RecordProtocol_SendAlert_m1931708341,
	RecordProtocol_SendAlert_m2670098001,
	RecordProtocol_SendAlert_m3736432480,
	RecordProtocol_SendChangeCipherSpec_m464005157,
	RecordProtocol_BeginSendRecord_m615249746,
	RecordProtocol_InternalSendRecordCallback_m682661965,
	RecordProtocol_BeginSendRecord_m3926976520,
	RecordProtocol_EndSendRecord_m4264777321,
	RecordProtocol_SendRecord_m927045752,
	RecordProtocol_EncodeRecord_m164201598,
	RecordProtocol_EncodeRecord_m3312835762,
	RecordProtocol_encryptRecordFragment_m710101985,
	RecordProtocol_decryptRecordFragment_m66623237,
	RecordProtocol_Compare_m4182754688,
	RecordProtocol_ProcessCipherSpecV2Buffer_m487045483,
	RecordProtocol_MapV2CipherCode_m4087331414,
	ReceiveRecordAsyncResult__ctor_m277637112,
	ReceiveRecordAsyncResult_get_Record_m223479150,
	ReceiveRecordAsyncResult_get_ResultingBuffer_m1839161335,
	ReceiveRecordAsyncResult_get_InitialBuffer_m2924495696,
	ReceiveRecordAsyncResult_get_AsyncState_m431861941,
	ReceiveRecordAsyncResult_get_AsyncException_m631453737,
	ReceiveRecordAsyncResult_get_CompletedWithError_m2856009536,
	ReceiveRecordAsyncResult_get_AsyncWaitHandle_m1781023438,
	ReceiveRecordAsyncResult_get_IsCompleted_m1918259948,
	ReceiveRecordAsyncResult_SetComplete_m1372905673,
	ReceiveRecordAsyncResult_SetComplete_m1568733499,
	ReceiveRecordAsyncResult_SetComplete_m464469214,
	SendRecordAsyncResult__ctor_m425551707,
	SendRecordAsyncResult_get_Message_m1204240861,
	SendRecordAsyncResult_get_AsyncState_m4196194494,
	SendRecordAsyncResult_get_AsyncException_m3556917569,
	SendRecordAsyncResult_get_CompletedWithError_m3232037803,
	SendRecordAsyncResult_get_AsyncWaitHandle_m1466641472,
	SendRecordAsyncResult_get_IsCompleted_m3929307031,
	SendRecordAsyncResult_SetComplete_m153213906,
	SendRecordAsyncResult_SetComplete_m170417386,
	SecurityParameters__ctor_m3952189175,
	SecurityParameters_get_Cipher_m108846204,
	SecurityParameters_set_Cipher_m588445085,
	SecurityParameters_get_ClientWriteMAC_m225554750,
	SecurityParameters_set_ClientWriteMAC_m2984527188,
	SecurityParameters_get_ServerWriteMAC_m3430427271,
	SecurityParameters_set_ServerWriteMAC_m3003817350,
	SecurityParameters_Clear_m680574382,
	SslCipherSuite__ctor_m1470082018,
	SslCipherSuite_ComputeServerRecordMAC_m1297079805,
	SslCipherSuite_ComputeClientRecordMAC_m3756410489,
	SslCipherSuite_ComputeMasterSecret_m3963626850,
	SslCipherSuite_ComputeKeys_m661027754,
	SslCipherSuite_prf_m922878400,
	SslClientStream__ctor_m2402546929,
	SslClientStream__ctor_m4190306291,
	SslClientStream__ctor_m3745813135,
	SslClientStream__ctor_m3478574780,
	SslClientStream__ctor_m3351906728,
	SslClientStream_add_ServerCertValidation_m2218216724,
	SslClientStream_remove_ServerCertValidation_m1143339871,
	SslClientStream_add_ClientCertSelection_m1387948363,
	SslClientStream_remove_ClientCertSelection_m24681826,
	SslClientStream_add_PrivateKeySelection_m1663125063,
	SslClientStream_remove_PrivateKeySelection_m3637735463,
	SslClientStream_add_ServerCertValidation2_m3943665702,
	SslClientStream_remove_ServerCertValidation2_m4151895043,
	SslClientStream_get_InputBuffer_m4092356391,
	SslClientStream_get_ClientCertificates_m998716871,
	SslClientStream_get_SelectedClientCertificate_m2941927287,
	SslClientStream_get_ServerCertValidationDelegate_m2765155187,
	SslClientStream_set_ServerCertValidationDelegate_m466396564,
	SslClientStream_get_ClientCertSelectionDelegate_m473995521,
	SslClientStream_set_ClientCertSelectionDelegate_m1261530976,
	SslClientStream_get_PrivateKeyCertSelectionDelegate_m3868652817,
	SslClientStream_set_PrivateKeyCertSelectionDelegate_m4100936974,
	SslClientStream_Finalize_m1251363641,
	SslClientStream_Dispose_m232031134,
	SslClientStream_OnBeginNegotiateHandshake_m3734240069,
	SslClientStream_SafeReceiveRecord_m2217679740,
	SslClientStream_OnNegotiateHandshakeCallback_m4211921295,
	SslClientStream_OnLocalCertificateSelection_m205226847,
	SslClientStream_get_HaveRemoteValidation2Callback_m2858953511,
	SslClientStream_OnRemoteCertificateValidation2_m2342781980,
	SslClientStream_OnRemoteCertificateValidation_m2343517080,
	SslClientStream_RaiseServerCertificateValidation_m3477149273,
	SslClientStream_RaiseServerCertificateValidation2_m2589974695,
	SslClientStream_RaiseClientCertificateSelection_m3936211295,
	SslClientStream_OnLocalPrivateKeySelection_m1934775249,
	SslClientStream_RaisePrivateKeySelection_m3394190501,
	SslHandshakeHash__ctor_m4169387017,
	SslHandshakeHash_Initialize_m290045843,
	SslHandshakeHash_HashFinal_m2573455475,
	SslHandshakeHash_HashCore_m2801927991,
	SslHandshakeHash_CreateSignature_m1634235041,
	SslHandshakeHash_initializePad_m1074089276,
	SslStreamBase__ctor_m3009266308,
	SslStreamBase__cctor_m548992348,
	SslStreamBase_AsyncHandshakeCallback_m2936782521,
	SslStreamBase_get_MightNeedHandshake_m909005056,
	SslStreamBase_NegotiateHandshake_m2455724401,
	SslStreamBase_RaiseLocalCertificateSelection_m980106471,
	SslStreamBase_RaiseRemoteCertificateValidation_m944390272,
	SslStreamBase_RaiseRemoteCertificateValidation2_m2908038766,
	SslStreamBase_RaiseLocalPrivateKeySelection_m4112368540,
	SslStreamBase_get_CheckCertRevocationStatus_m2739906607,
	SslStreamBase_set_CheckCertRevocationStatus_m912861213,
	SslStreamBase_get_CipherAlgorithm_m2320969781,
	SslStreamBase_get_CipherStrength_m449292740,
	SslStreamBase_get_HashAlgorithm_m2687781311,
	SslStreamBase_get_HashStrength_m2770482134,
	SslStreamBase_get_KeyExchangeStrength_m217695965,
	SslStreamBase_get_KeyExchangeAlgorithm_m1073399962,
	SslStreamBase_get_SecurityProtocol_m596101988,
	SslStreamBase_get_ServerCertificate_m656316972,
	SslStreamBase_get_ServerCertificates_m2154373069,
	SslStreamBase_BeginNegotiateHandshake_m4180435790,
	SslStreamBase_EndNegotiateHandshake_m1124299797,
	SslStreamBase_BeginRead_m3146234303,
	SslStreamBase_InternalBeginRead_m3419999901,
	SslStreamBase_InternalReadCallback_m3350299308,
	SslStreamBase_InternalBeginWrite_m1722032773,
	SslStreamBase_InternalWriteCallback_m3466627959,
	SslStreamBase_BeginWrite_m2003981130,
	SslStreamBase_EndRead_m495357226,
	SslStreamBase_EndWrite_m4073224031,
	SslStreamBase_Close_m967013602,
	SslStreamBase_Flush_m3601530442,
	SslStreamBase_Read_m2534198002,
	SslStreamBase_Read_m231548581,
	SslStreamBase_Seek_m270320723,
	SslStreamBase_SetLength_m844764688,
	SslStreamBase_Write_m1052022549,
	SslStreamBase_Write_m2024331816,
	SslStreamBase_get_CanRead_m2005873964,
	SslStreamBase_get_CanSeek_m701584365,
	SslStreamBase_get_CanWrite_m1622082918,
	SslStreamBase_get_Length_m561490526,
	SslStreamBase_get_Position_m3505809821,
	SslStreamBase_set_Position_m1470736124,
	SslStreamBase_Finalize_m3260913635,
	SslStreamBase_Dispose_m3190415328,
	SslStreamBase_resetBuffer_m3910686848,
	SslStreamBase_checkDisposed_m1981591244,
	InternalAsyncResult__ctor_m2194591319,
	InternalAsyncResult_get_ProceedAfterHandshake_m2508379800,
	InternalAsyncResult_get_FromWrite_m4228047810,
	InternalAsyncResult_get_Buffer_m228115020,
	InternalAsyncResult_get_Offset_m2101861835,
	InternalAsyncResult_get_Count_m2015941083,
	InternalAsyncResult_get_BytesRead_m3975435112,
	InternalAsyncResult_get_AsyncState_m1436290550,
	InternalAsyncResult_get_AsyncException_m3185530354,
	InternalAsyncResult_get_CompletedWithError_m3777099678,
	InternalAsyncResult_get_AsyncWaitHandle_m2580490319,
	InternalAsyncResult_get_IsCompleted_m2607263611,
	InternalAsyncResult_SetComplete_m3332189472,
	InternalAsyncResult_SetComplete_m693091794,
	InternalAsyncResult_SetComplete_m963842420,
	InternalAsyncResult_SetComplete_m544889140,
	TlsCipherSuite__ctor_m3580955828,
	TlsCipherSuite_ComputeServerRecordMAC_m3941098609,
	TlsCipherSuite_ComputeClientRecordMAC_m886198623,
	TlsCipherSuite_ComputeMasterSecret_m362444953,
	TlsCipherSuite_ComputeKeys_m1386728983,
	TlsClientSettings__ctor_m3220697265,
	TlsClientSettings_get_TargetHost_m2463481414,
	TlsClientSettings_set_TargetHost_m3350021121,
	TlsClientSettings_get_Certificates_m2671943654,
	TlsClientSettings_set_Certificates_m3887201895,
	TlsClientSettings_get_ClientCertificate_m3139459118,
	TlsClientSettings_set_ClientCertificate_m3374228612,
	TlsClientSettings_UpdateCertificateRSA_m3878128853,
	TlsException__ctor_m3652817735,
	TlsException__ctor_m2342093437,
	TlsException__ctor_m596254082,
	TlsException__ctor_m3717683709,
	TlsException__ctor_m818940807,
	TlsException__ctor_m3242533711,
	TlsException_get_Alert_m1206526559,
	TlsServerSettings__ctor_m373357120,
	TlsServerSettings_get_ServerKeyExchange_m691183033,
	TlsServerSettings_set_ServerKeyExchange_m3302765325,
	TlsServerSettings_get_Certificates_m3981837031,
	TlsServerSettings_set_Certificates_m3313375596,
	TlsServerSettings_get_CertificateRSA_m597274968,
	TlsServerSettings_get_RsaParameters_m2264301690,
	TlsServerSettings_set_RsaParameters_m853026166,
	TlsServerSettings_set_SignedParams_m3618693098,
	TlsServerSettings_get_CertificateRequest_m842655670,
	TlsServerSettings_set_CertificateRequest_m1039729760,
	TlsServerSettings_set_CertificateTypes_m2047242411,
	TlsServerSettings_set_DistinguisedNames_m787752700,
	TlsServerSettings_UpdateCertificateRSA_m3985265846,
	TlsStream__ctor_m787793111,
	TlsStream__ctor_m277557575,
	TlsStream_get_EOF_m953226442,
	TlsStream_get_CanWrite_m16389328,
	TlsStream_get_CanRead_m2847511450,
	TlsStream_get_CanSeek_m1261421145,
	TlsStream_get_Position_m1904146856,
	TlsStream_set_Position_m3867366920,
	TlsStream_get_Length_m1907852793,
	TlsStream_ReadSmallValue_m2559586275,
	TlsStream_ReadByte_m3396126844,
	TlsStream_ReadInt16_m1728211431,
	TlsStream_ReadInt24_m3096782201,
	TlsStream_ReadBytes_m2334803179,
	TlsStream_Write_m4246040664,
	TlsStream_Write_m1412844442,
	TlsStream_WriteInt24_m58952549,
	TlsStream_Write_m1413106584,
	TlsStream_Write_m4133894341,
	TlsStream_Reset_m369197964,
	TlsStream_ToArray_m4177184296,
	TlsStream_Flush_m3793197834,
	TlsStream_SetLength_m2444039643,
	TlsStream_Seek_m895611617,
	TlsStream_Read_m3392972801,
	TlsStream_Write_m188217214,
	ValidationResult_get_Trusted_m2108852505,
	ValidationResult_get_ErrorCode_m1533688152,
	AuthorityKeyIdentifierExtension__ctor_m373495498,
	AuthorityKeyIdentifierExtension_Decode_m1082741678,
	AuthorityKeyIdentifierExtension_get_Identifier_m548598067,
	AuthorityKeyIdentifierExtension_ToString_m1643863557,
	BasicConstraintsExtension__ctor_m3191645544,
	BasicConstraintsExtension_Decode_m2935957709,
	BasicConstraintsExtension_Encode_m2009213240,
	BasicConstraintsExtension_get_CertificateAuthority_m391198292,
	BasicConstraintsExtension_ToString_m2170556997,
	ExtendedKeyUsageExtension__ctor_m3228998638,
	ExtendedKeyUsageExtension_Decode_m2326833343,
	ExtendedKeyUsageExtension_Encode_m2182457162,
	ExtendedKeyUsageExtension_get_KeyPurpose_m187586919,
	ExtendedKeyUsageExtension_ToString_m2116504780,
	GeneralNames__ctor_m3642449536,
	GeneralNames_get_DNSNames_m3788548987,
	GeneralNames_get_IPAddresses_m4242915644,
	GeneralNames_ToString_m489778282,
	KeyUsageExtension__ctor_m3414452076,
	KeyUsageExtension_Decode_m1408685233,
	KeyUsageExtension_Encode_m2561267096,
	KeyUsageExtension_Support_m3508856672,
	KeyUsageExtension_ToString_m3134109315,
	NetscapeCertTypeExtension__ctor_m323882095,
	NetscapeCertTypeExtension_Decode_m251886799,
	NetscapeCertTypeExtension_Support_m3981181230,
	NetscapeCertTypeExtension_ToString_m1800688476,
	SubjectAltNameExtension__ctor_m1991362362,
	SubjectAltNameExtension_Decode_m2617923884,
	SubjectAltNameExtension_get_DNSNames_m2346000460,
	SubjectAltNameExtension_get_IPAddresses_m1641002124,
	SubjectAltNameExtension_ToString_m3628154311,
	PKCS12__ctor_m1854440921,
	PKCS12__ctor_m2471257156,
	PKCS12__ctor_m2483239261,
	PKCS12__cctor_m3271060407,
	PKCS12_Decode_m163534693,
	PKCS12_Finalize_m507756088,
	PKCS12_set_Password_m4088935795,
	PKCS12_get_IterationCount_m3005687235,
	PKCS12_set_IterationCount_m2605460921,
	PKCS12_get_Keys_m3893933360,
	PKCS12_get_Certificates_m166242546,
	PKCS12_get_RNG_m64541056,
	PKCS12_Compare_m219153845,
	PKCS12_GetSymmetricAlgorithm_m3480654844,
	PKCS12_Decrypt_m1280162536,
	PKCS12_Decrypt_m3441995779,
	PKCS12_Encrypt_m3618991685,
	PKCS12_GetExistingParameters_m3446652479,
	PKCS12_AddPrivateKey_m1877554254,
	PKCS12_ReadSafeBag_m3435973087,
	PKCS12_CertificateSafeBag_m1505366012,
	PKCS12_MAC_m3355614022,
	PKCS12_GetBytes_m415958948,
	PKCS12_EncryptedContentInfo_m729936927,
	PKCS12_AddCertificate_m3679554094,
	PKCS12_AddCertificate_m3820167082,
	PKCS12_RemoveCertificate_m3555301339,
	PKCS12_RemoveCertificate_m2774912578,
	PKCS12_Clone_m2085085101,
	PKCS12_get_MaximumPasswordLength_m3603260090,
	DeriveBytes__ctor_m2211845228,
	DeriveBytes__cctor_m3019062497,
	DeriveBytes_set_HashName_m3612196732,
	DeriveBytes_set_IterationCount_m3824132378,
	DeriveBytes_set_Password_m4086840123,
	DeriveBytes_set_Salt_m1400945044,
	DeriveBytes_Adjust_m1814768799,
	DeriveBytes_Derive_m1232352666,
	DeriveBytes_DeriveKey_m2933043667,
	DeriveBytes_DeriveIV_m973925711,
	DeriveBytes_DeriveMAC_m2121691743,
	SafeBag__ctor_m3881032521,
	SafeBag_get_BagOID_m2153399743,
	SafeBag_get_ASN1_m2293701606,
	X501__cctor_m2428304915,
	X501_ToString_m2260475203,
	X501_ToString_m3840057611,
	X501_AppendEntry_m2479013363,
	X509Certificate__ctor_m553243489,
	X509Certificate__cctor_m1746020738,
	X509Certificate_Parse_m54358579,
	X509Certificate_GetUnsignedBigInteger_m877462855,
	X509Certificate_get_DSA_m2644963799,
	X509Certificate_set_DSA_m753722200,
	X509Certificate_get_Extensions_m2532937142,
	X509Certificate_get_Hash_m410033711,
	X509Certificate_get_IssuerName_m47554030,
	X509Certificate_get_KeyAlgorithm_m3935660380,
	X509Certificate_get_KeyAlgorithmParameters_m3698130868,
	X509Certificate_set_KeyAlgorithmParameters_m2010117999,
	X509Certificate_get_PublicKey_m950835056,
	X509Certificate_get_RSA_m1755006809,
	X509Certificate_set_RSA_m3534515075,
	X509Certificate_get_RawData_m2626675988,
	X509Certificate_get_SerialNumber_m3924188880,
	X509Certificate_get_Signature_m2498854864,
	X509Certificate_get_SignatureAlgorithm_m122054440,
	X509Certificate_get_SubjectName_m3871411396,
	X509Certificate_get_ValidFrom_m845748800,
	X509Certificate_get_ValidUntil_m1838041919,
	X509Certificate_get_Version_m3419034307,
	X509Certificate_get_IsCurrent_m469817010,
	X509Certificate_WasCurrent_m1146083014,
	X509Certificate_VerifySignature_m3988463526,
	X509Certificate_VerifySignature_m3538124832,
	X509Certificate_VerifySignature_m429904987,
	X509Certificate_get_IsSelfSigned_m4064195693,
	X509Certificate_GetIssuerName_m3173047029,
	X509Certificate_GetSubjectName_m3288368674,
	X509Certificate_GetObjectData_m2952009451,
	X509Certificate_PEM_m2020851166,
	X509CertificateCollection__ctor_m2066277891,
	X509CertificateCollection__ctor_m3467061452,
	X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m647852366,
	X509CertificateCollection_get_Item_m3285563224,
	X509CertificateCollection_Add_m2277657976,
	X509CertificateCollection_AddRange_m2165814476,
	X509CertificateCollection_Contains_m743657353,
	X509CertificateCollection_GetEnumerator_m1275665495,
	X509CertificateCollection_GetHashCode_m2303492950,
	X509CertificateCollection_IndexOf_m2003755268,
	X509CertificateCollection_Remove_m2199606504,
	X509CertificateCollection_Compare_m3676635762,
	X509CertificateEnumerator__ctor_m85694331,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m1846030361,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m2626270621,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2039524926,
	X509CertificateEnumerator_get_Current_m1004537031,
	X509CertificateEnumerator_MoveNext_m3925432749,
	X509CertificateEnumerator_Reset_m1825523691,
	X509Chain__ctor_m3563800449,
	X509Chain__ctor_m1084071882,
	X509Chain_get_Status_m348797749,
	X509Chain_get_TrustAnchors_m2434696767,
	X509Chain_Build_m2469702749,
	X509Chain_IsValid_m3670863655,
	X509Chain_FindCertificateParent_m2809823532,
	X509Chain_FindCertificateRoot_m1937726457,
	X509Chain_IsTrusted_m1243554942,
	X509Chain_IsParent_m2689546349,
	X509Crl__ctor_m1817187405,
	X509Crl_Parse_m3164013387,
	X509Crl_get_Extensions_m922657393,
	X509Crl_get_Hash_m464217067,
	X509Crl_get_IssuerName_m552696835,
	X509Crl_get_NextUpdate_m604794549,
	X509Crl_Compare_m3418726913,
	X509Crl_GetCrlEntry_m1550247114,
	X509Crl_GetCrlEntry_m641501875,
	X509Crl_GetHashName_m4214678741,
	X509Crl_VerifySignature_m1902456590,
	X509Crl_VerifySignature_m1808348256,
	X509Crl_VerifySignature_m2177510742,
	X509CrlEntry__ctor_m4013514048,
	X509CrlEntry_get_SerialNumber_m3627212772,
	X509CrlEntry_get_RevocationDate_m303599135,
	X509CrlEntry_get_Extensions_m3390427621,
	X509Extension__ctor_m710637961,
	X509Extension__ctor_m1474351312,
	X509Extension_Decode_m3172373814,
	X509Extension_Encode_m3152909591,
	X509Extension_get_Oid_m1003388288,
	X509Extension_get_Critical_m2974578711,
	X509Extension_get_Value_m3529546267,
	X509Extension_Equals_m1779194186,
	X509Extension_GetHashCode_m1797796679,
	X509Extension_WriteLine_m1662885247,
	X509Extension_ToString_m3727002866,
	X509ExtensionCollection__ctor_m2474799343,
	X509ExtensionCollection__ctor_m551870633,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m1475785462,
	X509ExtensionCollection_IndexOf_m2996504451,
	X509ExtensionCollection_get_Item_m4249795832,
	X509Store__ctor_m2736551756,
	X509Store_get_Certificates_m1092347772,
	X509Store_get_Crls_m1211262034,
	X509Store_Load_m2048139132,
	X509Store_LoadCertificate_m1587806288,
	X509Store_LoadCrl_m1881903843,
	X509Store_CheckStore_m2045435685,
	X509Store_BuildCertificatesCollection_m3030935583,
	X509Store_BuildCrlsCollection_m1991312527,
	X509StoreManager_get_CurrentUser_m719101392,
	X509StoreManager_get_LocalMachine_m269504582,
	X509StoreManager_get_TrustedRootCertificates_m2180997293,
	X509Stores__ctor_m1786355972,
	X509Stores_get_TrustedRoot_m1736182879,
	X509Stores_Open_m1037335183,
	Locale_GetText_m1626635120,
	Locale_GetText_m2427493201,
	KeyBuilder_get_Rng_m3373220441,
	KeyBuilder_Key_m2503211157,
	KeyBuilder_IV_m3340234014,
	SymmetricTransform__ctor_m2693628991,
	SymmetricTransform_System_IDisposable_Dispose_m3657987482,
	SymmetricTransform_Finalize_m4129642865,
	SymmetricTransform_Dispose_m375394407,
	SymmetricTransform_get_CanReuseTransform_m3495714228,
	SymmetricTransform_Transform_m1683494363,
	SymmetricTransform_CBC_m3648398454,
	SymmetricTransform_CFB_m1755507252,
	SymmetricTransform_OFB_m3690147804,
	SymmetricTransform_CTS_m764800021,
	SymmetricTransform_CheckInput_m2092289040,
	SymmetricTransform_TransformBlock_m851059707,
	SymmetricTransform_get_KeepLastBlock_m2492071306,
	SymmetricTransform_InternalTransformBlock_m1743612142,
	SymmetricTransform_Random_m3740038270,
	SymmetricTransform_ThrowBadPaddingException_m2898061954,
	SymmetricTransform_FinalEncrypt_m748885414,
	SymmetricTransform_FinalDecrypt_m764004682,
	SymmetricTransform_TransformFinalBlock_m1030888689,
	Action__ctor_m2994342681,
	Action_Invoke_m937035532,
	Action_BeginInvoke_m2907948038,
	Action_EndInvoke_m1690492879,
	Check_Source_m4098695967,
	Check_SourceAndPredicate_m2332465641,
	ExtensionAttribute__ctor_m1708143005,
	Aes__ctor_m178909601,
	AesManaged__ctor_m1349486362,
	AesManaged_GenerateIV_m1368817386,
	AesManaged_GenerateKey_m2004209814,
	AesManaged_CreateDecryptor_m692040246,
	AesManaged_CreateEncryptor_m2294080233,
	AesManaged_get_IV_m118095902,
	AesManaged_set_IV_m3705704588,
	AesManaged_get_Key_m538801386,
	AesManaged_set_Key_m767972181,
	AesManaged_get_KeySize_m1181452829,
	AesManaged_set_KeySize_m1150692274,
	AesManaged_CreateDecryptor_m752875210,
	AesManaged_CreateEncryptor_m1611897367,
	AesManaged_Dispose_m615303088,
	AesTransform__ctor_m3143546745,
	AesTransform__cctor_m2567644034,
	AesTransform_ECB_m240244807,
	AesTransform_SubByte_m3350159546,
	AesTransform_Encrypt128_m424393011,
	AesTransform_Decrypt128_m3018534522,
	AssetFileNameExtensionAttribute__ctor_m592302761,
	FreeFunctionAttribute__ctor_m225850777,
	FreeFunctionAttribute__ctor_m3967403258,
	FreeFunctionAttribute__ctor_m1198537781,
	NativeConditionalAttribute__ctor_m1745668596,
	NativeConditionalAttribute_set_Condition_m607771195,
	NativeConditionalAttribute_set_Enabled_m2378894961,
	NativeHeaderAttribute__ctor_m457462113,
	NativeHeaderAttribute_set_Header_m3310668383,
	NativeMethodAttribute__ctor_m3134540192,
	NativeMethodAttribute__ctor_m2941746701,
	NativeMethodAttribute__ctor_m3056337369,
	NativeMethodAttribute__ctor_m2749818278,
	NativeMethodAttribute_set_Name_m1946475768,
	NativeMethodAttribute_set_IsThreadSafe_m2457033065,
	NativeMethodAttribute_set_IsFreeFunction_m1931350581,
	NativeMethodAttribute_set_ThrowsException_m3369126807,
	NativeMethodAttribute_set_HasExplicitThis_m2961870915,
	NativeNameAttribute__ctor_m3296876808,
	NativeNameAttribute_set_Name_m3579254766,
	NativePropertyAttribute__ctor_m1920537355,
	NativePropertyAttribute__ctor_m2033094153,
	NativeThrowsAttribute__ctor_m3216633458,
	NativeThrowsAttribute_set_ThrowsException_m4039166389,
	NativeTypeAttribute__ctor_m2993484825,
	NativeTypeAttribute__ctor_m1043629716,
	NativeTypeAttribute__ctor_m133676646,
	NativeTypeAttribute__ctor_m1677513894,
	NativeTypeAttribute_set_Header_m48420006,
	NativeTypeAttribute_set_IntermediateScriptingStructName_m3613994509,
	NativeTypeAttribute_set_CodegenOptions_m3839252515,
	NotNullAttribute__ctor_m3740658540,
	StaticAccessorAttribute__ctor_m2905272167,
	StaticAccessorAttribute_set_Name_m2926172476,
	StaticAccessorAttribute_set_Type_m2333258271,
	ThreadSafeAttribute__ctor_m601575521,
	UnmarshalledAttribute__ctor_m534761184,
	VisibleToOtherModulesAttribute__ctor_m3491053854,
	NativeClassAttribute__ctor_m3911617424,
	NativeClassAttribute__ctor_m4136257185,
	NativeClassAttribute_set_QualifiedNativeName_m801351239,
	NativeClassAttribute_set_Declaration_m1218368926,
	GeneratedByOldBindingsGeneratorAttribute__ctor_m3683043001,
	RequiredByNativeCodeAttribute__ctor_m119855101,
	RequiredByNativeCodeAttribute_set_Optional_m1276771824,
	RequiredByNativeCodeAttribute_set_GenerateProxy_m2819488747,
	UsedByNativeCodeAttribute__ctor_m2647015777,
	ThreadAndSerializationSafeAttribute__ctor_m3739981144,
	UnityEngineModuleAssembly__ctor_m242195730,
	UnityString_Format_m261690510,
	WritableAttribute__ctor_m1991076220,
	AddComponentMenu__ctor_m867138430,
	AnimationCurve__ctor_m1565662948,
	AnimationCurve__ctor_m3000526466,
	AnimationCurve_Internal_Destroy_m3899747917,
	AnimationCurve_Internal_Create_m3956683041,
	AnimationCurve_Finalize_m2397002729,
	Application_CallLowMemory_m2813539296,
	Application_CallLogCallback_m255562505,
	Application_Internal_ApplicationWantsToQuit_m2059931957,
	Application_Internal_ApplicationQuit_m2936209313,
	Application_InvokeOnBeforeRender_m2875673833,
	LogCallback__ctor_m144650965,
	LogCallback_Invoke_m1707963620,
	LogCallback_BeginInvoke_m1868775196,
	LogCallback_EndInvoke_m2243211259,
	LowMemoryCallback__ctor_m3675715235,
	LowMemoryCallback_Invoke_m1926578529,
	LowMemoryCallback_BeginInvoke_m2877696488,
	LowMemoryCallback_EndInvoke_m2581361171,
	AsyncOperation_InternalDestroy_m3592294443,
	AsyncOperation_Finalize_m1841265672,
	AsyncOperation_InvokeCompletionEvent_m1410305036,
	AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m681389990,
	AttributeHelperEngine_GetRequiredComponents_m568829708,
	AttributeHelperEngine_CheckIsEditorScript_m705968799,
	AttributeHelperEngine_GetDefaultExecutionOrderFor_m2255077112,
	AttributeHelperEngine__cctor_m1900959362,
	BeforeRenderHelper_Invoke_m50072094,
	BeforeRenderHelper__cctor_m1834968278,
	Behaviour__ctor_m346897018,
	Behaviour_get_enabled_m753527255,
	BootConfigData__ctor_m4255151374,
	BootConfigData_WrapBootConfigData_m329603588,
	Camera_get_nearClipPlane_m837839537,
	Camera_get_farClipPlane_m538536689,
	Camera_get_cullingMask_m679085748,
	Camera_get_eventMask_m819189086,
	Camera_get_clearFlags_m992534691,
	Camera_get_pixelRect_m2283183456,
	Camera_get_targetTexture_m2278634983,
	Camera_get_targetDisplay_m2285699927,
	Camera_ScreenPointToRay_m3401628776,
	Camera_ScreenPointToRay_m2119345216,
	Camera_ScreenPointToRay_m3764635188,
	Camera_RaycastTry_m3913529496,
	Camera_RaycastTry2D_m2460696262,
	Camera_GetAllCamerasCount_m2278705835,
	Camera_GetAllCamerasImpl_m2534099441,
	Camera_get_allCamerasCount_m528453758,
	Camera_GetAllCameras_m668492922,
	Camera_FireOnPreCull_m2869588437,
	Camera_FireOnPreRender_m3450823610,
	Camera_FireOnPostRender_m1456255957,
	Camera_get_pixelRect_Injected_m2326986893,
	Camera_ScreenPointToRay_Injected_m1162756571,
	Camera_RaycastTry_Injected_m3801956476,
	Camera_RaycastTry2D_Injected_m85653607,
	CameraCallback__ctor_m899467377,
	CameraCallback_Invoke_m3308824940,
	CameraCallback_BeginInvoke_m4249233405,
	CameraCallback_EndInvoke_m3846578433,
	ClassLibraryInitializer_Init_m988673678,
	Component__ctor_m1928064382,
	Component_get_gameObject_m442555142,
	Component_GetComponentFastPath_m1180649031,
	Coroutine__ctor_m1058504400,
	Coroutine_Finalize_m1957108547,
	Coroutine_ReleaseCoroutine_m947702340,
	Cubemap__ctor_m1096546642,
	Cubemap__ctor_m1549386221,
	Cubemap__ctor_m1814722504,
	Cubemap_Internal_CreateImpl_m2853780628,
	Cubemap_Internal_Create_m3302016289,
	CullingGroup_Finalize_m2121330955,
	CullingGroup_DisposeInternal_m1966833260,
	CullingGroup_Dispose_m782801025,
	CullingGroup_SendEvents_m2491312335,
	CullingGroup_FinalizerFailure_m1165085675,
	StateChanged__ctor_m2759994044,
	StateChanged_Invoke_m1925531365,
	StateChanged_BeginInvoke_m4029305912,
	StateChanged_EndInvoke_m3313423087,
	Debug_get_unityLogger_m2239795986,
	Debug_Log_m4051431634,
	Debug_LogFormat_m309087137,
	Debug_LogError_m2850623458,
	Debug_LogError_m1665621915,
	Debug_LogErrorFormat_m575266265,
	Debug_LogException_m2207318968,
	Debug_LogWarningFormat_m2535776735,
	Debug__cctor_m1523394265,
	DebugLogHandler__ctor_m3380237231,
	DebugLogHandler_Internal_Log_m4175774469,
	DebugLogHandler_Internal_LogException_m4213045108,
	DebugLogHandler_LogFormat_m487864506,
	DebugLogHandler_LogException_m302830419,
	DefaultExecutionOrder_get_order_m1454999278,
	Display__ctor_m501911701,
	Display__ctor_m3105658851,
	Display_get_systemWidth_m2423595549,
	Display_get_systemHeight_m730809466,
	Display_RelativeMouseAt_m1648644586,
	Display_RecreateDisplayList_m4040831261,
	Display_FireDisplaysUpdated_m41210855,
	Display_GetSystemExtImpl_m2808197389,
	Display_RelativeMouseAtImpl_m3843151955,
	Display__cctor_m1972153728,
	DisplaysUpdatedDelegate__ctor_m2116638722,
	DisplaysUpdatedDelegate_Invoke_m3203573844,
	DisplaysUpdatedDelegate_BeginInvoke_m1285971490,
	DisplaysUpdatedDelegate_EndInvoke_m3857124817,
	ArgumentCache__ctor_m2732653802,
	ArgumentCache_get_unityObjectArgument_m3434100,
	ArgumentCache_get_unityObjectArgumentAssemblyTypeName_m3450114170,
	ArgumentCache_get_intArgument_m1309958679,
	ArgumentCache_get_floatArgument_m3471193103,
	ArgumentCache_get_stringArgument_m3872675090,
	ArgumentCache_get_boolArgument_m2277082935,
	ArgumentCache_TidyAssemblyTypeName_m3234393930,
	ArgumentCache_OnBeforeSerialize_m659261798,
	ArgumentCache_OnAfterDeserialize_m1256813518,
	BaseInvokableCall__ctor_m768115019,
	BaseInvokableCall__ctor_m2110966014,
	BaseInvokableCall_AllowInvoke_m878393606,
	InvokableCall__ctor_m1303836326,
	InvokableCall_add_Delegate_m491308793,
	InvokableCall_remove_Delegate_m1376110510,
	InvokableCall_Invoke_m999392415,
	InvokableCall_Invoke_m1437964737,
	InvokableCall_Find_m1300374869,
	InvokableCallList__ctor_m829480958,
	InvokableCallList_AddPersistentInvokableCall_m778853773,
	InvokableCallList_AddListener_m230402324,
	InvokableCallList_RemoveListener_m1769379719,
	InvokableCallList_ClearPersistent_m1904264973,
	InvokableCallList_PrepareInvoke_m4003891334,
	PersistentCall__ctor_m1217622171,
	PersistentCall_get_target_m830923650,
	PersistentCall_get_methodName_m4214122315,
	PersistentCall_get_mode_m483997668,
	PersistentCall_get_arguments_m3144105308,
	PersistentCall_IsValid_m2325196163,
	PersistentCall_GetRuntimeCall_m3976533158,
	PersistentCall_GetObjectCall_m4041241444,
	PersistentCallGroup__ctor_m1525263635,
	PersistentCallGroup_Initialize_m4253175514,
	UnityAction__ctor_m772160306,
	UnityAction_Invoke_m893829196,
	UnityAction_BeginInvoke_m1892359299,
	UnityAction_EndInvoke_m2754068291,
	UnityEvent__ctor_m431206565,
	UnityEvent_FindMethod_Impl_m2312362624,
	UnityEvent_GetDelegate_m3669208949,
	UnityEventBase__ctor_m1851535676,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m3869333132,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m3212312200,
	UnityEventBase_FindMethod_m622251156,
	UnityEventBase_FindMethod_m3366332957,
	UnityEventBase_DirtyPersistentCalls_m3575963459,
	UnityEventBase_RebuildPersistentCallsIfNeeded_m216788690,
	UnityEventBase_AddCall_m3539965410,
	UnityEventBase_RemoveListener_m3326364145,
	UnityEventBase_PrepareInvoke_m1785382128,
	UnityEventBase_ToString_m1554306026,
	UnityEventBase_GetValidMethodInfo_m3989987635,
	ExcludeFromObjectFactoryAttribute__ctor_m3758218116,
	ExcludeFromPresetAttribute__ctor_m3043931884,
	UpdateFunction__ctor_m1238640540,
	UpdateFunction_Invoke_m3360475851,
	UpdateFunction_BeginInvoke_m1039085470,
	UpdateFunction_EndInvoke_m3485575773,
	CameraPlayable_GetHandle_m1459651790_AdjustorThunk,
	CameraPlayable_Equals_m4009879053_AdjustorThunk,
	MaterialEffectPlayable_GetHandle_m4279427933_AdjustorThunk,
	MaterialEffectPlayable_Equals_m3750885802_AdjustorThunk,
	TextureMixerPlayable_GetHandle_m2203457785_AdjustorThunk,
	TextureMixerPlayable_Equals_m1074187513_AdjustorThunk,
	GraphicsFormatUtility_GetGraphicsFormat_m3445248969,
	GraphicsFormatUtility_GetGraphicsFormat_Native_TextureFormat_m433736368,
	GraphicsFormatUtility_IsSRGBFormat_m3893170616,
	GraphicsFormatUtility_GetRenderTextureFormat_m2347522639,
	GraphicsFormatUtility_IsCrunchFormat_m1697721778,
	RenderPipelineManager_get_currentPipeline_m1638613344,
	RenderPipelineManager_set_currentPipeline_m3492857006,
	RenderPipelineManager_CleanupRenderPipeline_m3545163046,
	RenderPipelineManager_DoRenderLoop_Internal_m3799666479,
	RenderPipelineManager_PrepareRenderPipeline_m4184225229,
	ScriptableRenderContext__ctor_m172989033_AdjustorThunk,
	SupportedRenderingFeatures__ctor_m2713823667,
	SupportedRenderingFeatures_get_active_m2140763039,
	SupportedRenderingFeatures_set_active_m3446087961,
	SupportedRenderingFeatures_get_defaultMixedLightingMode_m301083500,
	SupportedRenderingFeatures_get_supportedMixedLightingModes_m2613534515,
	SupportedRenderingFeatures_get_supportedLightmapBakeTypes_m1596512019,
	SupportedRenderingFeatures_get_supportedLightmapsModes_m141329491,
	SupportedRenderingFeatures_FallbackMixedLightingModeByRef_m3859171964,
	SupportedRenderingFeatures_IsMixedLightingModeSupported_m1976902692,
	SupportedRenderingFeatures_IsMixedLightingModeSupportedByRef_m2282093837,
	SupportedRenderingFeatures_IsLightmapBakeTypeSupported_m625512092,
	SupportedRenderingFeatures_IsLightmapBakeTypeSupportedByRef_m2970279241,
	SupportedRenderingFeatures_IsLightmapsModeSupportedByRef_m3859475728,
	SupportedRenderingFeatures__cctor_m146778484,
	GUIElement__ctor_m3257342989,
	GUILayer_HitTest_m512928460,
	GUILayer_HitTest_m2079012401,
	GUILayer_HitTest_Injected_m3662865982,
	GameObject__ctor_m3707688467,
	GameObject_SendMessage_m3720186693,
	GameObject_Internal_CreateGameObject_m2533291801,
	Gradient__ctor_m173848750,
	Gradient_Init_m2499008394,
	Gradient_Cleanup_m3422458828,
	Gradient_Finalize_m3995355035,
	Input_GetMouseButton_m513753021,
	Input_GetMouseButtonDown_m2081676745,
	Input_get_mousePosition_m1616496925,
	Input_INTERNAL_get_mousePosition_m1805263023,
	Input__cctor_m325696046,
	DefaultValueAttribute__ctor_m1514328230,
	DefaultValueAttribute_get_Value_m3086344020,
	DefaultValueAttribute_Equals_m443523471,
	DefaultValueAttribute_GetHashCode_m3368187153,
	ExcludeFromDocsAttribute__ctor_m1509941807,
	Logger__ctor_m439059923,
	Logger_get_logHandler_m1335645353,
	Logger_set_logHandler_m4059005946,
	Logger_get_logEnabled_m3154120769,
	Logger_set_logEnabled_m1180597166,
	Logger_get_filterLogType_m1177392786,
	Logger_set_filterLogType_m3622751173,
	Logger_IsLogTypeAllowed_m3527674834,
	Logger_GetString_m3669755330,
	Logger_Log_m969976427,
	Logger_Log_m2585387088,
	Logger_LogFormat_m3030796110,
	Logger_LogFormat_m3300686007,
	Logger_LogException_m4285204825,
	LowerResBlitTexture_LowerResBlitTextureDontStripMe_m2024164512,
	ManagedStreamHelpers_ValidateLoadFromStream_m580138133,
	ManagedStreamHelpers_ManagedStreamRead_m481666286,
	ManagedStreamHelpers_ManagedStreamSeek_m3158782053,
	ManagedStreamHelpers_ManagedStreamLength_m2930872960,
	Material__ctor_m1662457592,
	Material__ctor_m249231841,
	Material__ctor_m2433149719,
	Material_CreateWithShader_m1270998153,
	Material_CreateWithMaterial_m2373088899,
	Material_CreateWithString_m4283839020,
	Mathf_Abs_m3281243566,
	Mathf_Max_m3146388979,
	Mathf_Approximately_m245805902,
	Mathf__cctor_m1175545152,
	Mesh__ctor_m2533762929,
	Mesh_Internal_Create_m2853543051,
	MeshFilter_DontStripMeshFilter_m2877155929,
	MeshRenderer_DontStripMeshRenderer_m3387425681,
	MonoBehaviour__ctor_m1579109191,
	MonoBehaviour_IsInvoking_m3949123101,
	MonoBehaviour_CancelInvoke_m4090783926,
	MonoBehaviour_Invoke_m4227543964,
	MonoBehaviour_InvokeRepeating_m650519629,
	MonoBehaviour_CancelInvoke_m2180046661,
	MonoBehaviour_IsInvoking_m1028838749,
	MonoBehaviour_StartCoroutine_m2618285814,
	MonoBehaviour_StartCoroutine_m1654577315,
	MonoBehaviour_StartCoroutine_m3411253000,
	MonoBehaviour_StartCoroutine_Auto_m594129169,
	MonoBehaviour_StopCoroutine_m615723318,
	MonoBehaviour_StopCoroutine_m907039165,
	MonoBehaviour_StopCoroutine_m1962070247,
	MonoBehaviour_StopAllCoroutines_m3328507247,
	MonoBehaviour_get_useGUILayout_m2803119319,
	MonoBehaviour_set_useGUILayout_m3492031340,
	MonoBehaviour_print_m330341231,
	MonoBehaviour_Internal_CancelInvokeAll_m3703850945,
	MonoBehaviour_Internal_IsInvokingAll_m2820042090,
	MonoBehaviour_InvokeDelayed_m3352484957,
	MonoBehaviour_CancelInvoke_m3252264575,
	MonoBehaviour_IsInvoking_m3285132449,
	MonoBehaviour_IsObjectMonoBehaviour_m2134950949,
	MonoBehaviour_StartCoroutineManaged_m1730988625,
	MonoBehaviour_StartCoroutineManaged2_m3584675188,
	MonoBehaviour_StopCoroutineManaged_m3194025768,
	MonoBehaviour_StopCoroutineFromEnumeratorManaged_m3390002661,
	MonoBehaviour_GetScriptClassName_m1053457852,
	MessageEventArgs__ctor_m14798785,
	PlayerConnection__ctor_m2639507345,
	PlayerConnection_get_instance_m1750121257,
	PlayerConnection_get_isConnected_m911966057,
	PlayerConnection_CreateInstance_m902052006,
	PlayerConnection_OnEnable_m4286555589,
	PlayerConnection_GetConnectionNativeApi_m3116196780,
	PlayerConnection_Register_m2197766869,
	PlayerConnection_Unregister_m262505929,
	PlayerConnection_RegisterConnection_m141514498,
	PlayerConnection_RegisterDisconnection_m2618599213,
	PlayerConnection_Send_m3929969666,
	PlayerConnection_BlockUntilRecvMsg_m1369178756,
	PlayerConnection_DisconnectAll_m2907137535,
	PlayerConnection_MessageCallbackInternal_m1914517467,
	PlayerConnection_ConnectedCallbackInternal_m1706913195,
	PlayerConnection_DisconnectedCallback_m1697017309,
	U3CBlockUntilRecvMsgU3Ec__AnonStorey2__ctor_m1575056730,
	U3CBlockUntilRecvMsgU3Ec__AnonStorey2_U3CU3Em__0_m2225790220,
	U3CRegisterU3Ec__AnonStorey0__ctor_m1879208136,
	U3CRegisterU3Ec__AnonStorey0_U3CU3Em__0_m491998414,
	U3CUnregisterU3Ec__AnonStorey1__ctor_m1684143015,
	U3CUnregisterU3Ec__AnonStorey1_U3CU3Em__0_m1122526650,
	PlayerEditorConnectionEvents__ctor_m3177489832,
	PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_m2094591713,
	PlayerEditorConnectionEvents_AddAndCreate_m3046878154,
	PlayerEditorConnectionEvents_UnregisterManagedCallback_m400366024,
	U3CAddAndCreateU3Ec__AnonStorey1__ctor_m1186055370,
	U3CAddAndCreateU3Ec__AnonStorey1_U3CU3Em__0_m2847856411,
	U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0__ctor_m2486500792,
	U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_U3CU3Em__0_m444206473,
	U3CUnregisterManagedCallbackU3Ec__AnonStorey2__ctor_m299200807,
	U3CUnregisterManagedCallbackU3Ec__AnonStorey2_U3CU3Em__0_m4104626642,
	ConnectionChangeEvent__ctor_m764126802,
	MessageEvent__ctor_m1231650089,
	MessageTypeSubscribers__ctor_m1543468991,
	MessageTypeSubscribers_get_MessageTypeId_m1143155832,
	MessageTypeSubscribers_set_MessageTypeId_m841325789,
	Object__ctor_m1087895580,
	Object_GetHashCode_m1944636947,
	Object_Equals_m4262027856,
	Object_op_Implicit_m3574996620,
	Object_CompareBaseObjects_m2405226032,
	Object_IsNativeObjectAlive_m3095908075,
	Object_GetCachedPtr_m151292858,
	Object_get_name_m4211327027,
	Object_set_hideFlags_m1648752846,
	Object_ToString_m3272709752,
	Object_op_Equality_m1810815630,
	Object_op_Inequality_m4071470834,
	Object_ToString_m1579850521,
	Object_GetName_m4137306623,
	Object__cctor_m2398773973,
	Playable__ctor_m3175303195_AdjustorThunk,
	Playable_get_Null_m3556999077,
	Playable_GetHandle_m98909670_AdjustorThunk,
	Playable_Equals_m328753404_AdjustorThunk,
	Playable__cctor_m464525928,
	PlayableAsset__ctor_m2395156306,
	PlayableAsset_get_duration_m3549083384,
	PlayableAsset_get_outputs_m2130546921,
	PlayableAsset_Internal_CreatePlayable_m2550417712,
	PlayableAsset_Internal_GetPlayableAssetDuration_m2090502339,
	PlayableBehaviour__ctor_m3891915003,
	PlayableBehaviour_Clone_m2851991741,
	PlayableBinding__cctor_m2159960528,
	CreateOutputMethod__ctor_m3884516706,
	CreateOutputMethod_Invoke_m549607425,
	CreateOutputMethod_BeginInvoke_m3202548900,
	CreateOutputMethod_EndInvoke_m325504645,
	PlayableHandle_get_Null_m218234861,
	PlayableHandle_op_Equality_m3344837515,
	PlayableHandle_Equals_m1666612586_AdjustorThunk,
	PlayableHandle_Equals_m2546735654_AdjustorThunk,
	PlayableHandle_GetHashCode_m1297878485_AdjustorThunk,
	PlayableHandle_CompareVersion_m2748798983,
	PlayableOutput__ctor_m3330119218_AdjustorThunk,
	PlayableOutput_GetHandle_m777137769_AdjustorThunk,
	PlayableOutput_Equals_m3146274716_AdjustorThunk,
	PlayableOutput__cctor_m2348686299,
	PlayableOutputHandle_get_Null_m1200584339,
	PlayableOutputHandle_GetHashCode_m2803245663_AdjustorThunk,
	PlayableOutputHandle_op_Equality_m388301694,
	PlayableOutputHandle_Equals_m334596297_AdjustorThunk,
	PlayableOutputHandle_Equals_m2815498676_AdjustorThunk,
	PlayableOutputHandle_CompareVersion_m841260813,
	PlayerConnectionInternal__ctor_m2406218802,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_SendMessage_m389985885,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Poll_m4148886575,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_RegisterInternal_m1817895617,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_UnregisterInternal_m2713195108,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Initialize_m2565175798,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_IsConnected_m2695194553,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_DisconnectAll_m2071255904,
	PlayerConnectionInternal_IsConnected_m1260708709,
	PlayerConnectionInternal_Initialize_m103452032,
	PlayerConnectionInternal_RegisterInternal_m3800897166,
	PlayerConnectionInternal_UnregisterInternal_m477908195,
	PlayerConnectionInternal_SendMessage_m2378413408,
	PlayerConnectionInternal_PollInternal_m3759016321,
	PlayerConnectionInternal_DisconnectAll_m4073996061,
	PreloadData_PreloadDataDontStripMe_m1119277139,
	PropertyName__ctor_m1858502781_AdjustorThunk,
	PropertyName__ctor_m3511806171_AdjustorThunk,
	PropertyName__ctor_m912660408_AdjustorThunk,
	PropertyName_op_Equality_m2761233272,
	PropertyName_GetHashCode_m3570549176_AdjustorThunk,
	PropertyName_Equals_m2608649819_AdjustorThunk,
	PropertyName_Equals_m3623975820_AdjustorThunk,
	PropertyName_op_Implicit_m1633828199,
	PropertyName_op_Implicit_m114733813,
	PropertyName_ToString_m3328159423_AdjustorThunk,
	PropertyNameUtils_PropertyNameFromString_m3719796130,
	PropertyNameUtils_PropertyNameFromString_Injected_m1259736140,
	QualitySettings_get_activeColorSpace_m2902748248,
	Quaternion__ctor_m435141806_AdjustorThunk,
	Quaternion_GetHashCode_m2636680144_AdjustorThunk,
	Quaternion_Equals_m1863659319_AdjustorThunk,
	Quaternion_Equals_m2038868948_AdjustorThunk,
	Quaternion_ToString_m2203056442_AdjustorThunk,
	Quaternion__cctor_m2965965177,
	Ray_get_direction_m761601601_AdjustorThunk,
	Ray_ToString_m1732834890_AdjustorThunk,
	Rect_get_x_m3839990490_AdjustorThunk,
	Rect_get_y_m1501338330_AdjustorThunk,
	Rect_get_width_m3421484486_AdjustorThunk,
	Rect_get_height_m1358425599_AdjustorThunk,
	Rect_get_xMin_m581135837_AdjustorThunk,
	Rect_get_yMin_m2601414109_AdjustorThunk,
	Rect_get_xMax_m3018144503_AdjustorThunk,
	Rect_get_yMax_m743455479_AdjustorThunk,
	Rect_Contains_m1232228501_AdjustorThunk,
	Rect_GetHashCode_m1816164252_AdjustorThunk,
	Rect_Equals_m4169342960_AdjustorThunk,
	Rect_Equals_m3951234117_AdjustorThunk,
	Rect_ToString_m447614148_AdjustorThunk,
	RectTransform_SendReapplyDrivenProperties_m187867097,
	ReapplyDrivenProperties__ctor_m836366652,
	ReapplyDrivenProperties_Invoke_m1151937880,
	ReapplyDrivenProperties_BeginInvoke_m4260606555,
	ReapplyDrivenProperties_EndInvoke_m700307436,
	ReflectionProbe_CallReflectionProbeEvent_m1520775591,
	ReflectionProbe_CallSetDefaultReflection_m2835659734,
	RenderTexture__ctor_m3368882316,
	RenderTexture__ctor_m339910950,
	RenderTexture__ctor_m2281969544,
	RenderTexture__ctor_m1155694963,
	RenderTexture__ctor_m1464033784,
	RenderTexture__ctor_m2187158709,
	RenderTexture__ctor_m769234016,
	RenderTexture_SetRenderTextureDescriptor_m735607607,
	RenderTexture_INTERNAL_CALL_SetRenderTextureDescriptor_m1959074794,
	RenderTexture_GetDescriptor_m2430275682,
	RenderTexture_INTERNAL_CALL_GetDescriptor_m317084978,
	RenderTexture_set_depth_m936447630,
	RenderTexture_set_width_m410512079,
	RenderTexture_set_height_m1102706773,
	RenderTexture_set_format_m2479999990,
	RenderTexture_SetSRGBReadWrite_m2270512694,
	RenderTexture_Internal_Create_m347030155,
	RenderTexture_get_descriptor_m722729156,
	RenderTexture_ValidateRenderTextureDesc_m1651269986,
	RenderTextureDescriptor_get_width_m26344548_AdjustorThunk,
	RenderTextureDescriptor_get_height_m1891977024_AdjustorThunk,
	RenderTextureDescriptor_get_msaaSamples_m2437860573_AdjustorThunk,
	RenderTextureDescriptor_get_volumeDepth_m3098156076_AdjustorThunk,
	RenderTextureDescriptor_get_depthBufferBits_m2160829816_AdjustorThunk,
	RenderTextureDescriptor__cctor_m3115061957,
	RequireComponent__ctor_m886241599,
	Scene_get_handle_m1544696971_AdjustorThunk,
	Scene_GetHashCode_m2998285532_AdjustorThunk,
	Scene_Equals_m581999093_AdjustorThunk,
	SceneManager_Internal_SceneLoaded_m2694652025,
	SceneManager_Internal_SceneUnloaded_m3247148570,
	SceneManager_Internal_ActiveSceneChanged_m3676176255,
	Screen_get_width_m345039817,
	Screen_get_height_m1623532518,
	ScriptableObject__ctor_m1310743131,
	ScriptableObject_CreateInstance_m2611081756,
	ScriptableObject_CreateScriptableObject_m3504774547,
	ScriptableObject_CreateScriptableObjectInstanceFromType_m2783367459,
	SendMouseEvents_SetMouseMoved_m2822596724,
	SendMouseEvents_HitTestLegacyGUI_m579942228,
	SendMouseEvents_DoSendMouseEvents_m2140870850,
	SendMouseEvents_SendEvents_m1956471769,
	SendMouseEvents__cctor_m2378365934,
	HitInfo_SendMessage_m1343099429_AdjustorThunk,
	HitInfo_op_Implicit_m665224877,
	HitInfo_Compare_m2336739674,
	FormerlySerializedAsAttribute__ctor_m520861771,
	SerializeField__ctor_m808862924,
	SetupCoroutine_InvokeMoveNext_m3199342729,
	SetupCoroutine_InvokeMember_m2661944898,
	Sprite__ctor_m332781120,
	StackTraceUtility_SetProjectFolder_m830524047,
	StackTraceUtility_ExtractStackTrace_m3279197967,
	StackTraceUtility_IsSystemStacktraceType_m299828041,
	StackTraceUtility_ExtractStringFromExceptionInternal_m2686726792,
	StackTraceUtility_PostprocessStacktrace_m1043256299,
	StackTraceUtility_ExtractFormattedStackTrace_m1281750362,
	StackTraceUtility__cctor_m1981266436,
	SystemInfo_IsFormatSupported_m1855899386,
	Texture__ctor_m3554519797,
	Texture_set_width_m1057761909,
	Texture_set_height_m589028641,
	Texture_ValidateFormat_m3925257631,
	Texture2D__ctor_m3176621650,
	Texture2D__ctor_m373113269,
	Texture2D_Internal_CreateImpl_m110138258,
	Texture2D_Internal_Create_m3592711635,
	Texture2DArray__ctor_m1759046501,
	Texture2DArray__ctor_m2627654179,
	Texture2DArray__ctor_m4056612996,
	Texture2DArray_Internal_CreateImpl_m1122945648,
	Texture2DArray_Internal_Create_m2217927355,
	Texture3D__ctor_m1599887784,
	Texture3D__ctor_m448815750,
	Texture3D_Internal_CreateImpl_m1882516456,
	Texture3D_Internal_Create_m4250388922,
	Transform__ctor_m3470711880,
	Transform_get_childCount_m3145433196,
	Transform_GetEnumerator_m2717073726,
	Transform_GetChild_m1092972975,
	Enumerator__ctor_m1351041375,
	Enumerator_get_Current_m2591725252,
	Enumerator_MoveNext_m4275888254,
	Enumerator_Reset_m39541243,
	SpriteAtlasManager_RequestAtlas_m455709951,
	SpriteAtlasManager_PostRegisteredAtlas_m3806600148,
	SpriteAtlasManager_Register_m2413332465,
	SpriteAtlasManager__cctor_m3642741753,
	RequestAtlasCallback__ctor_m3023745648,
	RequestAtlasCallback_Invoke_m378128467,
	RequestAtlasCallback_BeginInvoke_m2655374249,
	RequestAtlasCallback_EndInvoke_m2592639818,
	UnhandledExceptionHandler_RegisterUECatcher_m1350255469,
	UnhandledExceptionHandler_HandleUnhandledException_m2430609357,
	UnhandledExceptionHandler_PrintException_m385608237,
	UnhandledExceptionHandler_NativeUnhandledExceptionHandler_m2534568686,
	UnityException__ctor_m1456865679,
	UnityException__ctor_m872329880,
	UnityException__ctor_m170038890,
	UnityLogWriter__ctor_m1834616883,
	UnityLogWriter_WriteStringToUnityLog_m2695353836,
	UnityLogWriter_WriteStringToUnityLogImpl_m2026412198,
	UnityLogWriter_Init_m3866572946,
	UnityLogWriter_Write_m3542862483,
	UnityLogWriter_Write_m345199408,
	UnityLogWriter_Write_m3864776786,
	UnitySynchronizationContext__ctor_m1707488257,
	UnitySynchronizationContext_Exec_m3359802660,
	UnitySynchronizationContext_InitializeSynchronizationContext_m3217591031,
	UnitySynchronizationContext_ExecuteTasks_m1310741010,
	WorkRequest_Invoke_m3488164927_AdjustorThunk,
	Vector2__ctor_m3970636864_AdjustorThunk,
	Vector2_ToString_m1205609053_AdjustorThunk,
	Vector2_GetHashCode_m3916089713_AdjustorThunk,
	Vector2_Equals_m832062989_AdjustorThunk,
	Vector2_Equals_m1313188271_AdjustorThunk,
	Vector2_op_Implicit_m4260192859,
	Vector2__cctor_m2108982652,
	Vector3__ctor_m3353183577_AdjustorThunk,
	Vector3_GetHashCode_m2879461828_AdjustorThunk,
	Vector3_Equals_m1753054704_AdjustorThunk,
	Vector3_Equals_m906392898_AdjustorThunk,
	Vector3_SqrMagnitude_m3025115945,
	Vector3_get_zero_m1409827619,
	Vector3_op_Subtraction_m3073674971,
	Vector3_op_Equality_m4231250055,
	Vector3_op_Inequality_m315980366,
	Vector3_ToString_m759076600_AdjustorThunk,
	Vector3__cctor_m2599650684,
	WaitForSeconds__ctor_m2199082655,
	YieldInstruction__ctor_m1498450609,
	LocalNotification_Finalize_m4237923715,
	LocalNotification__cctor_m2450334404,
	NotificationHelper_DestroyLocal_m2248823824,
	NotificationHelper_DestroyRemote_m3390574007,
	RemoteNotification_Finalize_m1702910735,
	MathfInternal__cctor_m2622893686,
	NetFxCoreExtensions_CreateDelegate_m751211712,
	NetFxCoreExtensions_GetMethodInfo_m444570327,
	Analytics_GetUnityAnalyticsHandler_m2772482435,
	Analytics_CustomEvent_m692224174,
	Analytics_CustomEvent_m3835919949,
	AnalyticsSessionInfo_CallSessionStateChanged_m1270932408,
	SessionStateChanged__ctor_m2637910444,
	SessionStateChanged_Invoke_m4203746932,
	SessionStateChanged_BeginInvoke_m1132835327,
	SessionStateChanged_EndInvoke_m3581055289,
	CustomEventData__ctor_m4146403782,
	CustomEventData_Finalize_m1724721833,
	CustomEventData_Destroy_m2070199408,
	CustomEventData_Dispose_m4023815755,
	CustomEventData_Internal_Create_m4267220301,
	CustomEventData_Internal_Destroy_m3916992396,
	CustomEventData_AddString_m1770058667,
	CustomEventData_AddInt32_m548429697,
	CustomEventData_AddUInt32_m4102684736,
	CustomEventData_AddInt64_m3934322106,
	CustomEventData_AddUInt64_m725801310,
	CustomEventData_AddBool_m1904653514,
	CustomEventData_AddDouble_m631895201,
	CustomEventData_AddDictionary_m266566478,
	UnityAnalyticsHandler__ctor_m2433349566,
	UnityAnalyticsHandler_Finalize_m1527596444,
	UnityAnalyticsHandler_Destroy_m945739537,
	UnityAnalyticsHandler_Dispose_m300860768,
	UnityAnalyticsHandler_IsInitialized_m2620746640,
	UnityAnalyticsHandler_Internal_Create_m852466012,
	UnityAnalyticsHandler_Internal_Destroy_m2102025341,
	UnityAnalyticsHandler_SendCustomEventName_m839221434,
	UnityAnalyticsHandler_SendCustomEvent_m1223269116,
	RemoteConfigSettings_Finalize_m2805990196,
	RemoteConfigSettings_Destroy_m1854335118,
	RemoteConfigSettings_Dispose_m2083915538,
	RemoteConfigSettings_Internal_Destroy_m1072151938,
	RemoteConfigSettings_RemoteConfigSettingsUpdated_m2409101234,
	RemoteSettings_RemoteSettingsUpdated_m1182006011,
	RemoteSettings_RemoteSettingsBeforeFetchFromServer_m4228537265,
	RemoteSettings_RemoteSettingsUpdateCompleted_m2956290507,
	UpdatedEventHandler__ctor_m3406570235,
	UpdatedEventHandler_Invoke_m3026613363,
	UpdatedEventHandler_BeginInvoke_m424999959,
	UpdatedEventHandler_EndInvoke_m3714202114,
	AudioClipPlayable_GetHandle_m1762771314_AdjustorThunk,
	AudioClipPlayable_Equals_m3705880618_AdjustorThunk,
	AudioMixerPlayable_GetHandle_m57919556_AdjustorThunk,
	AudioMixerPlayable_Equals_m1649866213_AdjustorThunk,
	AudioClip__ctor_m1211547677,
	AudioClip_get_ambisonic_m3815052287,
	AudioClip_InvokePCMReaderCallback_Internal_m224395634,
	AudioClip_InvokePCMSetPositionCallback_Internal_m3097960898,
	PCMReaderCallback__ctor_m4269754975,
	PCMReaderCallback_Invoke_m2948796957,
	PCMReaderCallback_BeginInvoke_m3391809637,
	PCMReaderCallback_EndInvoke_m3916876196,
	PCMSetPositionCallback__ctor_m2909837933,
	PCMSetPositionCallback_Invoke_m2167694991,
	PCMSetPositionCallback_BeginInvoke_m2701134198,
	PCMSetPositionCallback_EndInvoke_m1405765992,
	AudioExtensionDefinition_GetExtensionType_m1450823952,
	AudioExtensionManager_GetAudioListener_m817760607,
	AudioExtensionManager_AddSpatializerExtension_m820561940,
	AudioExtensionManager_AddAmbisonicDecoderExtension_m3197702864,
	AudioExtensionManager_WriteExtensionProperties_m1988587615,
	AudioExtensionManager_AddSpatializerExtension_m3915849352,
	AudioExtensionManager_WriteExtensionProperties_m3028464154,
	AudioExtensionManager_AddExtensionToManager_m3475649283,
	AudioExtensionManager_RemoveExtensionFromManager_m442924172,
	AudioExtensionManager_Update_m3269307447,
	AudioExtensionManager_GetReadyToPlay_m1557263244,
	AudioExtensionManager_RegisterBuiltinDefinitions_m2742744104,
	AudioExtensionManager__cctor_m1361600190,
	AudioListener_GetNumExtensionProperties_m3139224773,
	AudioListener_ReadExtensionName_m929423100,
	AudioListener_INTERNAL_CALL_ReadExtensionName_m4145804327,
	AudioListener_ReadExtensionPropertyName_m3416271339,
	AudioListener_INTERNAL_CALL_ReadExtensionPropertyName_m330480156,
	AudioListener_ReadExtensionPropertyValue_m2443832840,
	AudioListener_ClearExtensionProperties_m3849891634,
	AudioListener_INTERNAL_CALL_ClearExtensionProperties_m2036387607,
	AudioListener_AddExtension_m994751216,
	AudioListenerExtension__ctor_m2046026665,
	AudioListenerExtension_get_audioListener_m3597041395,
	AudioListenerExtension_set_audioListener_m3412289012,
	AudioListenerExtension_ReadExtensionProperty_m3059773029,
	AudioListenerExtension_WriteExtensionProperty_m4064727398,
	AudioListenerExtension_ExtensionUpdate_m1303405084,
	AudioSettings_GetSpatializerPluginName_m1324100978,
	AudioSettings_InvokeOnAudioConfigurationChanged_m3131294153,
	AudioSettings_InvokeOnAudioManagerUpdate_m4044425648,
	AudioSettings_InvokeOnAudioSourcePlay_m3298744573,
	AudioSettings_GetAmbisonicDecoderPluginName_m19603540,
	AudioConfigurationChangeHandler__ctor_m1059338375,
	AudioConfigurationChangeHandler_Invoke_m1233557945,
	AudioConfigurationChangeHandler_BeginInvoke_m4104069447,
	AudioConfigurationChangeHandler_EndInvoke_m4175380841,
	AudioSource_get_clip_m1234340632,
	AudioSource_get_isPlaying_m1896551654,
	AudioSource_get_spatializeInternal_m2117549793,
	AudioSource_get_spatialize_m3609701298,
	AudioSource_GetNumExtensionProperties_m1231815209,
	AudioSource_ReadExtensionName_m725112169,
	AudioSource_INTERNAL_CALL_ReadExtensionName_m36001502,
	AudioSource_ReadExtensionPropertyName_m2761820692,
	AudioSource_INTERNAL_CALL_ReadExtensionPropertyName_m3643462071,
	AudioSource_ReadExtensionPropertyValue_m72717540,
	AudioSource_ClearExtensionProperties_m2116074582,
	AudioSource_INTERNAL_CALL_ClearExtensionProperties_m2159298662,
	AudioSource_AddSpatializerExtension_m2560794359,
	AudioSource_AddAmbisonicExtension_m304476911,
	AudioSourceExtension__ctor_m3132593001,
	AudioSourceExtension_get_audioSource_m1465006871,
	AudioSourceExtension_set_audioSource_m3729768988,
	AudioSourceExtension_ReadExtensionProperty_m2693120442,
	AudioSourceExtension_WriteExtensionProperty_m2866033202,
	AudioSourceExtension_Play_m420799475,
	AudioSourceExtension_Stop_m387892536,
	AudioSourceExtension_ExtensionUpdate_m2790353999,
	AudioSourceExtension_OnDestroy_m345467428,
	AudioSampleProvider_Finalize_m18935654,
	AudioSampleProvider_Dispose_m1993565764,
	AudioSampleProvider_get_id_m2692334523,
	AudioSampleProvider_set_id_m4177090282,
	AudioSampleProvider_InvokeSampleFramesAvailable_m3478252833,
	AudioSampleProvider_InvokeSampleFramesOverflow_m2840062631,
	AudioSampleProvider_InternalSetScriptingPtr_m3742743270,
	ConsumeSampleFramesNativeFunction__ctor_m144532415,
	ConsumeSampleFramesNativeFunction_Invoke_m1773312795,
	ConsumeSampleFramesNativeFunction_BeginInvoke_m342678987,
	ConsumeSampleFramesNativeFunction_EndInvoke_m2143737533,
	SampleFramesHandler__ctor_m3908528909,
	SampleFramesHandler_Invoke_m544261268,
	SampleFramesHandler_BeginInvoke_m2992664336,
	SampleFramesHandler_EndInvoke_m3715791887,
	GameCenterPlatform__ctor_m3480810288,
	GameCenterPlatform_ClearAchievementDescriptions_m3199616787,
	GameCenterPlatform_SetAchievementDescription_m2719524812,
	GameCenterPlatform_SetAchievementDescriptionImage_m2009264244,
	GameCenterPlatform_TriggerAchievementDescriptionCallback_m1287503847,
	GameCenterPlatform_AuthenticateCallbackWrapper_m4011908437,
	GameCenterPlatform_ClearFriends_m2665387026,
	GameCenterPlatform_SetFriends_m2547098207,
	GameCenterPlatform_SetFriendImage_m1493682250,
	GameCenterPlatform_TriggerFriendsCallbackWrapper_m361081277,
	GameCenterPlatform_AchievementCallbackWrapper_m2338913583,
	GameCenterPlatform_ProgressCallbackWrapper_m3465714225,
	GameCenterPlatform_ScoreCallbackWrapper_m3923626712,
	GameCenterPlatform_ScoreLoaderCallbackWrapper_m1077077857,
	GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_LoadFriends_m3748446850,
	GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_Authenticate_m218097008,
	GameCenterPlatform_UnityEngine_SocialPlatforms_ISocialPlatform_Authenticate_m2367877202,
	GameCenterPlatform_get_localUser_m479829000,
	GameCenterPlatform_PopulateLocalUser_m1862420460,
	GameCenterPlatform_LoadAchievementDescriptions_m1319531997,
	GameCenterPlatform_ReportProgress_m1060252293,
	GameCenterPlatform_LoadAchievements_m1317357678,
	GameCenterPlatform_ReportScore_m3808549820,
	GameCenterPlatform_LoadScores_m3157018272,
	GameCenterPlatform_LoadScores_m256327074,
	GameCenterPlatform_LeaderboardCallbackWrapper_m3412260669,
	GameCenterPlatform_GetLoading_m3528572516,
	GameCenterPlatform_VerifyAuthentication_m3694658262,
	GameCenterPlatform_ShowAchievementsUI_m3491114525,
	GameCenterPlatform_ShowLeaderboardUI_m7770043,
	GameCenterPlatform_ClearUsers_m1079725881,
	GameCenterPlatform_SetUser_m898357462,
	GameCenterPlatform_SetUserImage_m4005778020,
	GameCenterPlatform_TriggerUsersCallbackWrapper_m3887512651,
	GameCenterPlatform_LoadUsers_m1469846403,
	GameCenterPlatform_SafeSetUserImage_m1839197851,
	GameCenterPlatform_SafeClearArray_m2305618285,
	GameCenterPlatform_CreateLeaderboard_m2947842674,
	GameCenterPlatform_CreateAchievement_m1439743707,
	GameCenterPlatform_TriggerResetAchievementCallback_m3410354914,
	GameCenterPlatform_Authenticate_m2003613329,
	GameCenterPlatform_GetAuthenticated_m3482613734,
	GameCenterPlatform_Internal_UserName_m477057936,
	GameCenterPlatform_Internal_UserID_m2444628078,
	GameCenterPlatform_GetIsUnderage_m1283642296,
	GameCenterPlatform_GetUserImage_m1487654451,
	GameCenterPlatform_LoadFriends_m1431418758,
	GameCenterPlatform_InternalLoadAchievementDescriptions_m2154800288,
	GameCenterPlatform_InternalLoadAchievements_m858095906,
	GameCenterPlatform_InternalReportProgress_m52275066,
	GameCenterPlatform_InternalReportScore_m2330670912,
	GameCenterPlatform_InternalLoadScores_m542421317,
	GameCenterPlatform_Internal_ShowAchievementsUI_m3176553150,
	GameCenterPlatform_Internal_ShowLeaderboardUI_m3245064684,
	GameCenterPlatform_Internal_LoadUsers_m1208837786,
	GameCenterPlatform_ResetAllAchievements_m1516414240,
	GameCenterPlatform_ShowDefaultAchievementBanner_m619858364,
	GameCenterPlatform_ResetAllAchievements_m157050371,
	GameCenterPlatform_ShowDefaultAchievementCompletionBanner_m2497844455,
	GameCenterPlatform_ShowLeaderboardUI_m2045709011,
	GameCenterPlatform_ShowSpecificLeaderboardUI_m533216100,
	GameCenterPlatform__cctor_m2996229915,
	U3CUnityEngine_SocialPlatforms_ISocialPlatform_AuthenticateU3Ec__AnonStorey0__ctor_m917935746,
	U3CUnityEngine_SocialPlatforms_ISocialPlatform_AuthenticateU3Ec__AnonStorey0_U3CU3Em__0_m2063879487,
	GcAchievementData_ToAchievement_m891470019_AdjustorThunk,
	GcAchievementDescriptionData_ToAchievementDescription_m1622571845_AdjustorThunk,
	GcLeaderboard__ctor_m3682449037,
	GcLeaderboard_Finalize_m2458217293,
	GcLeaderboard_Contains_m3398117473,
	GcLeaderboard_SetScores_m1580490387,
	GcLeaderboard_SetLocalScore_m58125728,
	GcLeaderboard_SetMaxRange_m2107263614,
	GcLeaderboard_SetTitle_m3468474500,
	GcLeaderboard_Internal_LoadScores_m1159036535,
	GcLeaderboard_GcLeaderboard_LoadScores_m4200881954,
	GcLeaderboard_Loading_m224610944,
	GcLeaderboard_GcLeaderboard_Loading_m3170934238,
	GcLeaderboard_Dispose_m2785609281,
	GcLeaderboard_GcLeaderboard_Dispose_m540559132,
	GcScoreData_ToScore_m2448550203_AdjustorThunk,
	GcUserProfileData_ToUserProfile_m3948549088_AdjustorThunk,
	GcUserProfileData_AddToArray_m4269441263_AdjustorThunk,
	Achievement__ctor_m2166901798,
	Achievement__ctor_m2441923414,
	Achievement__ctor_m3081548999,
	Achievement_ToString_m3521250266,
	Achievement_get_id_m89809597,
	Achievement_set_id_m2790336588,
	Achievement_get_percentCompleted_m2110138160,
	Achievement_set_percentCompleted_m1653565997,
	Achievement_get_completed_m1377700980,
	Achievement_get_hidden_m4063998500,
	Achievement_get_lastReportedDate_m2200074798,
	AchievementDescription__ctor_m2104645942,
	AchievementDescription_ToString_m2063334390,
	AchievementDescription_SetImage_m2442437087,
	AchievementDescription_get_id_m985811184,
	AchievementDescription_set_id_m751528388,
	AchievementDescription_get_title_m417729785,
	AchievementDescription_get_achievedDescription_m387769685,
	AchievementDescription_get_unachievedDescription_m690845291,
	AchievementDescription_get_hidden_m1497330198,
	AchievementDescription_get_points_m4273978152,
	Leaderboard__ctor_m1030108446,
	Leaderboard_ToString_m1544604165,
	Leaderboard_SetLocalUserScore_m3569886016,
	Leaderboard_SetMaxRange_m629679481,
	Leaderboard_SetScores_m2163784072,
	Leaderboard_SetTitle_m459905577,
	Leaderboard_GetUserFilter_m1077085961,
	Leaderboard_get_id_m4258535896,
	Leaderboard_set_id_m3990768853,
	Leaderboard_get_userScope_m4090697307,
	Leaderboard_set_userScope_m4131851828,
	Leaderboard_get_range_m167968592,
	Leaderboard_set_range_m1868499957,
	Leaderboard_get_timeScope_m4226979676,
	Leaderboard_set_timeScope_m3468042286,
	LocalUser__ctor_m4260307073,
	LocalUser_SetFriends_m298063769,
	LocalUser_SetAuthenticated_m3352566618,
	LocalUser_SetUnderage_m1848352351,
	LocalUser_get_authenticated_m385074490,
	Score__ctor_m2390363112,
	Score__ctor_m1554947855,
	Score_ToString_m885507283,
	Score_get_leaderboardID_m3645107971,
	Score_set_leaderboardID_m268558918,
	Score_get_value_m3180422307,
	Score_set_value_m935893699,
	UserProfile__ctor_m3353918255,
	UserProfile__ctor_m2409346676,
	UserProfile_ToString_m2232825484,
	UserProfile_SetUserName_m1732526939,
	UserProfile_SetUserID_m1137218839,
	UserProfile_SetImage_m418239758,
	UserProfile_get_userName_m3063744753,
	UserProfile_get_id_m3178143816,
	UserProfile_get_isFriend_m3838691482,
	UserProfile_get_state_m3340793320,
	Range__ctor_m3975982763_AdjustorThunk,
	AnalyticsEvent_get_debugMode_m2240954048,
	AnalyticsEvent_OnValidationFailed_m2609604624,
	AnalyticsEvent_Custom_m227997836,
	AnalyticsEvent__cctor_m3994162614,
	CertificateHandler_Release_m648790222,
	CertificateHandler_Finalize_m2289088740,
	CertificateHandler_ValidateCertificate_m937187171,
	CertificateHandler_ValidateCertificateNative_m2315002656,
	CertificateHandler_Dispose_m2100863831,
	WebRequestUtils_RedirectTo_m55747000,
	WebRequestUtils__cctor_m4190982137,
	AnalyticsEventParam__ctor_m1888826734,
	AnalyticsEventParam_get_requirementType_m1268059884,
	AnalyticsEventParam_get_groupID_m569309506,
	AnalyticsEventParam_get_valueProperty_m583328026,
	AnalyticsEventParam_get_name_m708127086,
	AnalyticsEventParam_get_value_m2837935290,
	AnalyticsEventParamListContainer__ctor_m1995104893,
	AnalyticsEventParamListContainer_get_parameters_m4180299006,
	AnalyticsEventParamListContainer_set_parameters_m2253031841,
	AnalyticsEventTracker__ctor_m3064238498,
	AnalyticsEventTracker_get_payload_m308762692,
	AnalyticsEventTracker_TriggerEvent_m860167642,
	AnalyticsEventTracker_SendEvent_m1365958832,
	AnalyticsEventTracker_Awake_m2780522130,
	AnalyticsEventTracker_Start_m1087627554,
	AnalyticsEventTracker_OnEnable_m1121905268,
	AnalyticsEventTracker_OnDisable_m1553012800,
	AnalyticsEventTracker_OnApplicationPause_m2936008520,
	AnalyticsEventTracker_OnDestroy_m3032713758,
	AnalyticsEventTracker_TimedTrigger_m758162441,
	U3CTimedTriggerU3Ec__Iterator0__ctor_m375484522,
	U3CTimedTriggerU3Ec__Iterator0_MoveNext_m825792986,
	U3CTimedTriggerU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3822291412,
	U3CTimedTriggerU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m4218891528,
	U3CTimedTriggerU3Ec__Iterator0_Dispose_m3542186276,
	U3CTimedTriggerU3Ec__Iterator0_Reset_m1406161701,
	AnalyticsEventTrackerSettings__cctor_m99217142,
	AnalyticsTracker__ctor_m3762295226,
	AnalyticsTracker_get_eventName_m2051345506,
	AnalyticsTracker_set_eventName_m370326070,
	AnalyticsTracker_get_TP_m2800669040,
	AnalyticsTracker_set_TP_m4206182699,
	AnalyticsTracker_Awake_m2774678677,
	AnalyticsTracker_Start_m3944341596,
	AnalyticsTracker_OnEnable_m175592117,
	AnalyticsTracker_OnDisable_m2584849643,
	AnalyticsTracker_OnApplicationPause_m2421888091,
	AnalyticsTracker_OnDestroy_m3072032071,
	AnalyticsTracker_TriggerEvent_m2244736785,
	AnalyticsTracker_SendEvent_m2955089255,
	AnalyticsTracker_BuildParameters_m43920649,
	EventTrigger__ctor_m3931360164,
	EventTrigger_get_triggerType_m4159785260,
	EventTrigger_get_lifecycleEvent_m3324346053,
	EventTrigger_get_initTime_m3511193067,
	EventTrigger_set_initTime_m3128947762,
	EventTrigger_get_repeatTime_m1602140789,
	EventTrigger_set_repeatTime_m1188543944,
	EventTrigger_get_repetitions_m2606968061,
	EventTrigger_set_repetitions_m1079340996,
	EventTrigger_AddRule_m2980113967,
	EventTrigger_RemoveRule_m1596811726,
	EventTrigger_Test_m2021527001,
	OnTrigger__ctor_m2072368789,
	OnTrigger_Invoke_m2120872091,
	OnTrigger_BeginInvoke_m1406677296,
	OnTrigger_EndInvoke_m1076439436,
	StandardEventPayload__ctor_m1676969451,
	StandardEventPayload_get_parameters_m4209814697,
	StandardEventPayload_get_name_m1853779774,
	StandardEventPayload_set_name_m549984672,
	StandardEventPayload_Send_m3454575092,
	StandardEventPayload_GetParameters_m2672427676,
	StandardEventPayload_IsCustomDataValid_m922891381,
	StandardEventPayload_IsRequiredDataValid_m361738930,
	StandardEventPayload__cctor_m3346303468,
	TrackableField__ctor_m3758796351,
	TrackableField_GetValue_m4059393238,
	TrackableProperty__ctor_m29288901,
	TrackableProperty_get_fields_m3682628132,
	TrackableProperty_set_fields_m1461281003,
	TrackableProperty_GetHashCode_m3407865350,
	FieldWithTarget__ctor_m583221563,
	FieldWithTarget_get_paramName_m3501478659,
	FieldWithTarget_set_paramName_m2405671065,
	FieldWithTarget_get_target_m2252597932,
	FieldWithTarget_set_target_m875118251,
	FieldWithTarget_get_fieldPath_m341366840,
	FieldWithTarget_set_fieldPath_m2073198625,
	FieldWithTarget_get_typeString_m238478345,
	FieldWithTarget_set_typeString_m937652251,
	FieldWithTarget_get_doStatic_m1956244749,
	FieldWithTarget_set_doStatic_m3781634168,
	FieldWithTarget_get_staticString_m2597372683,
	FieldWithTarget_set_staticString_m3203090702,
	FieldWithTarget_GetValue_m2315870500,
	TrackablePropertyBase__ctor_m2201057683,
	TrackableTrigger__ctor_m4147744174,
	TriggerListContainer__ctor_m1390596431,
	TriggerListContainer_get_rules_m110726358,
	TriggerListContainer_set_rules_m474815225,
	TriggerMethod__ctor_m1863255651,
	TriggerRule__ctor_m225466603,
	TriggerRule_Test_m2595382785,
	TriggerRule_Test_m3134988565,
	TriggerRule_TestByObject_m3099447300,
	TriggerRule_TestByEnum_m2798194165,
	TriggerRule_TestByString_m2890887363,
	TriggerRule_TestByBool_m4144604729,
	TriggerRule_TestByDouble_m960810189,
	TriggerRule_SafeEquals_m2862813043,
	TriggerRule_GetDouble_m2201978033,
	ValueProperty__ctor_m2723448180,
	ValueProperty_get_valueType_m2516961412,
	ValueProperty_set_valueType_m3307530546,
	ValueProperty_get_propertyValue_m3340090327,
	ValueProperty_get_target_m1728151320,
	ValueProperty_IsValid_m3724034537,
};
