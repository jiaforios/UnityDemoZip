#if PLATFORM_TVOS

#import "UnityViewControllerBase.h"
#import "UnityAppController.h"

@implementation UnityDefaultViewController
@end

#endif // PLATFORM_TVOS
